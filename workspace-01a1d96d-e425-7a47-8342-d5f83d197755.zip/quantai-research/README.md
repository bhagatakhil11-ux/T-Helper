# QuantAI Research Kit (Windows) — research only, no live trading

Ye toolkit **sirf research ke liye** hai. Iska kaam ek hi sawaal ka imaandaar jawab dena:

> "Is strategy mein asli edge hai, ya main sirf random patterns dekh raha hun?"

Ye koi broker se connect nahi hota, koi order place nahi karta, koi API key nahi maangta.

---

## 0. Pehle 2 minute: ye kya hai aur kya nahi

| Hai | Nahi hai |
|---|---|
| CSV import + strict validation | Live trading engine |
| Data provenance (real vs fake clearly labelled) | Profit guarantee |
| Purged chronological train/val/test | Broker connection |
| Random Forest + honest baselines | LLM / Gemini calls |
| Next-bar-open backtest + Indian costs | "AI soch kar trade karega" magic |
| Buy & hold se comparison | Prediction of the future |

**LLM kyun nahi:** trading decision microseconds mein, deterministic aur audit-able hona chahiye. LLM slow hai, har baar different jawab de sakta hai, aur market ka future nahi jaanta. Isliye decision engine = math + ML + hard risk limits. LLM ko baad mein sirf *report samjhane* ke liye jod sakte hain.

---

## 1. Windows setup (ek baar, ~10 minute)

### Step 1 — Python install karo
1. https://www.python.org/downloads/ kholo
2. Python **3.11 ya 3.12** download karo (3.13 bhi chalega)
3. Install karte waqt **"Add python.exe to PATH"** checkbox tick karna — ye zaroori hai
4. Install complete karo

### Step 2 — Check karo
PowerShell kholo (Start menu → "PowerShell") aur likho:

```powershell
python --version
```

`Python 3.12.x` jaisa kuch dikhna chahiye.

### Step 3 — Project folder mein jao
ZIP extract karo, phir:

```powershell
cd $HOME\Downloads\quantai-research
```

(Agar kahin aur extract kiya hai toh woh path do.)

### Step 4 — Virtual environment banao

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Agar error aaye *"running scripts is disabled"*:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Ab prompt ke aage `(.venv)` dikhega.

### Step 5 — Libraries install karo

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### Step 6 — Tests chalao (ye zaroori hai)

```powershell
python -m pytest tests -q
```

Expected: **58 passed**. Agar ye pass nahi hua toh aage mat badho.

---

## 2. Step A — Smoke test (fake data se pipeline check)

Pehle confirm karo ki machinery kaam kar rahi hai. Ye **fake data** hai, isliye iske results se koi market conclusion nahi nikalta.

```powershell
python make_fixture.py --bars 2000 --timeframe 1D --out data\TEST_FIXTURE_1D.csv

python run_research.py --csv data\TEST_FIXTURE_1D.csv --symbol TESTFIX --timeframe 1D --source-type TEST_FIXTURE --out results_fixture
```

Output mein aisa kuch aayega:

```text
VERDICT: PLUMBING_ONLY — NO MARKET CONCLUSION
  - Data is NOT real market history. This run only proves the pipeline works.
Data: TEST_FIXTURE_NOT_MARKET_DATA | 2000 bars | RESEARCH_GRADE
Test accuracy 0.4450 vs majority 0.4319 / momentum 0.3901
  Ensemble (60% rules + 40% ML)      trades=  0 net=  +0.00% DD= 0.00% Sharpe=N/A
  Rules only (no ML)                 trades= 10 net=  -5.72% DD= 5.72% Sharpe=-2.24
  Indicators (EMA/RSI/MACD/BB)       trades=  4 net=  -0.80% DD= 1.86% Sharpe=N/A
  ML only                            trades=  1 net=  +0.92% DD= 0.52% Sharpe=N/A
  Buy & hold benchmark               trades=  0 net= -12.97% DD=18.87% Sharpe=N/A
```

Dekho: random data par ensemble ne **0 trade** liye. Ye sahi behaviour hai — jab edge nahi hai toh trade nahi karna chahiye. Agar koi tool random data par "90% profit" dikhaye, woh tool jhooth bol raha hai.

**Paanch strategies ek hi test window par** (same purged split, same costs, same unseen window) — isliye unka comparison apples-to-apples hai:

| Strategy | Kya hai |
|---|---|
| Ensemble | 60% rules + 40% ML score |
| Rules only | Sirf RSI/MACD/Bollinger/EMA rules, ML nahi |
| **Indicators** | **Pure technical-indicator score (EMA20/50/200, RSI14, MACD histogram, Bollinger %B). ML model bilkul nahi dekhta.** |
| ML only | Sirf Random Forest probability |
| Buy & hold | Benchmark (gross, index directly trade nahi hota) |

Indicators strategy bhi **same purged chronological split aur same unseen test window** par chalti hai, aur har indicator causally compute hota hai (bar *t* ka signal sirf bar 0…*t* se banta hai) — koi look-ahead nahi.

> ⚠️ Candlestick patterns aur support/resistance **guaranteed signals nahi hain**. Ye kit unhe strategy mein use nahi karta; terminal (web app) mein wo sirf observation ke roop mein dikhate hain.

Terminal ke Charts & TA tab ke liye teen descriptive additions bhi iss kit ke modules mein sync hain (strategy logic inhe use nahi karti):

- **Zone activity** (`levels.py`) — har support/resistance zone ab apne **touch count**, **reaction count** (0.5 ATR ke andar 5 bars mein price away gaya?), **reaction rate**, touch history aur ek **strength label** (`strong` / `moderate` / `weak` / `failed`) deta hai. Bahut touches par kam reactions = price level ko **through** kar raha tha — yeh strength nahi, weakness hai.
- **Pattern strength** (`patterns.py`) — har detected pattern ko **volume** (us bar ka volume, usse pehle ke bars ke average ke muqable) aur **location** (recent range mein kahan tha) ke basis par `weak` / `medium` / `strong` milta hai. Ye sirf pattern ki quality hai — success ki probability nahi.
- **Confluence** (`charting.py`) — TA summary mein ek section jo **kitne indicator readings ek hi direction mein point kar rahe hain** yeh count karta hai. Yeh ek **count** hai, BUY/SELL signal **nahi** — aur yeh non-independent readings (same price series se bane hue) hone ke kaaran edge ka proof bhi nahi hai.

Files banengi: `results_fixture\report.md`, `report.json`, `equity_curves.png`

---

## 3. Step B — Asli data lao (ye sabse important step hai)

### CSV format

```csv
timestamp,open,high,low,close,volume
2015-01-01 00:00:00,745.00,752.30,743.10,750.85,3254100
2015-01-02 00:00:00,750.85,758.00,749.50,756.20,2987400
```

- `timestamp` — daily ke liye `YYYY-MM-DD`, intraday ke liye `YYYY-MM-DD HH:MM:SS` (IST)
- `volume` — whole number (fractional volume reject hoga)
- Optional `symbol` column bhi de sakte ho
- Ek file mein **ek hi symbol** rakho

### Data kahan se lein (authorized raaste)

| Source | Kya milega | Kharcha |
|---|---|---|
| **NSE website — historical bhavcopy / security-wise data** | Daily OHLCV, official | Free |
| **Broker historical candle API** (Upstox / Angel One / Dhan / Fyers) | Daily + intraday, apne account se | Free–sasta, account chahiye |
| **Paid data vendor** (TrueData, GDFL, Accelpix) | Clean intraday, adjusted | ~₹500–3000/month |

**Meri salah:** shuru mein **RELIANCE daily, 8–10 saal** NSE ki official site se lo. Free hai, aur daily data mein gaps/corporate action samajhna aasan hai.

**Ye mat karna:** kisi site ko scrape karke rate-limit bypass karna, ya Telegram se "leaked data" lena. Data galat hoga toh poora research bekaar.

### Corporate actions — ye dhyan se
Multi-year data mein **splits aur bonuses** hote hain. Agar data adjusted nahi hai toh 1:1 split 50% "crash" jaisa dikhega aur strategy usse galat signal samjhegi.

Isliye:
- Adjusted data ho toh `--adjustment SPLIT_AND_BONUS_ADJUSTED`
- Raw data ho toh `--adjustment UNADJUSTED`
- Pata nahi toh default `UNKNOWN_UNVERIFIED` — report mein warning aayegi

Kit 22%+ ke single-bar jumps ko flag karta hai, lekin **prices ko chhota-bada nahi karta**.

---

## 4. Step C — Asli data par research chalao

```powershell
python run_research.py --csv data\RELIANCE_1D.csv --symbol RELIANCE --timeframe 1D --adjustment SPLIT_AND_BONUS_ADJUSTED --out results_reliance
```

Optional: NSE holidays ki list do taaki holidays ko "missing data" na gine:

```powershell
python run_research.py --csv data\RELIANCE_1D.csv --symbol RELIANCE --timeframe 1D --holidays data\nse_holidays.txt --out results_reliance
```

`nse_holidays.txt` mein ek line par ek date: `2025-08-15`

---

## 5. Report kaise padhein — verdict ka matlab

| Verdict | Matlab | Kya karna hai |
|---|---|---|
| `PLUMBING_ONLY` | Fake/test data tha | Asli data lao |
| `NO EDGE EVIDENCE — DO NOT DEPLOY` | Costs ke baad paisa nahi bana, ya baseline se haar gaya | Strategy badlo. **Live mat karo.** |
| `CANDIDATE — NEEDS MORE DATA + PAPER TRADING` | Is window mein baseline aur buy&hold dono ko haraya | Aur symbols/periods test karo, phir paper trading |

**Koi bhi verdict "profit guarantee" nahi hai.** `CANDIDATE` ka matlab sirf "further testing ke layak hai".

### Report mein kya dekhna hai
1. **Data provenance** — `IMPORTED_CSV_UNVERIFIED` hi rahega jab tak vendor verified na ho. Ye imaandaari hai.
2. **Test accuracy vs baselines** — agar majority baseline 55% hai aur model 56%, toh model bekaar hai.
3. **Ensemble vs Buy & hold** — agar buy & hold jeet gaya, tumhari complexity ne kuch nahi joda.
4. **Total costs** — kitna paisa brokerage/STT/slippage mein gaya.
5. **Rejected signals** — kitne trades risk engine ne roke.
6. **Sharpe N/A** — 5 se kam trades par Sharpe calculate karna jhooth hai, isliye N/A aata hai.

---

## 6. Jo rules ye kit todta nahi

Ye sab tests se enforce hote hain (`tests/test_pipeline.py`):

- Test fixture ko kabhi "real market data" nahi banaya jaata
- Imported CSV = **unverified**, verified nahi
- Invalid rows **reject** hote hain, chupke se theek nahi hote
- Fractional volume reject (silently truncate nahi)
- Intraday timestamps timeframe grid par aligned hone chahiye
- Features **causal** hain — future bar ka data use nahi hota
- Train/val/test **chronological + purged**, koi shuffling nahi
- Signal bar `t` close → entry bar `t+1` **open** (same-bar close par entry nahi)
- Gap-down stop **open** par fill hota hai (stop par nahi) — realistic loss
- Ek bar mein stop aur target dono ho toh **stop pehle** maana jaata hai
- Drawdown mein **unrealized loss** bhi ginta hai
- Risk/cash allow na kare toh quantity **0** — forced 1 share nahi
- Daily drawdown breaker aur consecutive-loss cooldown backtest mein bhi lagta hai
- **Weekly loss limit** bhi lagta hai — **ISO week** (Monday–Sunday) ke start ke equity se
  measure hota hai, default **5%**, range **1–15%**. Breach par naye entries block ho jaate
  hain (poora engine nahi rukta) aur har breach report mein record hota hai.
- **Progressive cooldown** teen bands mein hai (default threshold 3 losses):
  **3–4 losses → 15 bars · 5–6 → 30 bars · 7+ → 50 bars**. Teesra band **flat** hai — cooldown
  aage barhta nahi, isliye koi lambi losing streak engine ko unbounded time ke liye lock nahi
  kar sakti. Teeno band ki lengths config se badal sakti hain.
- **Volatility-adjusted sizing** optional hai aur **default OFF** hai. On karne par
  `risk = base × clamp(target ATR% ÷ measured ATR%, min, max)` — matlab zyada volatile market
  mein position chhoti hoti hai. Ye **forecast** nahi karta, sirf already-ho-chuke volatility
  par react karta hai.
- Weekly breach, cooldown aur volatility sizing — terminal ke backend rules se bilkul same
  hain (`tests/test_risk_rules.py` dono kits ko aapas mein sync rakhta hai)
- Costs **dono legs** par
- Sharpe **N/A** jab data kam ho — jhootha 0.0 nahi

---

## 7. Folder structure

```text
quantai-research/
├── README.md                 ← ye file
├── requirements.txt
├── run_research.py           ← main command
├── make_fixture.py           ← fake data generator (clearly labelled)
├── quantai/
│   ├── config.py             ← costs, risk limits, thresholds
│   ├── data.py               ← CSV validation + provenance
│   ├── features.py           ← causal features, labels, purged split
│   ├── indicators.py         ← causal EMA/SMA/RSI/MACD/Bollinger/ATR/VWAP
│   ├── patterns.py           ← candlestick pattern detection + strength (volume/location)
│   ├── levels.py             ← causal support/resistance zones + touch/reaction activity
│   ├── charting.py           ← chart payload + TA summary + confluence count
│   ├── model.py              ← Random Forest, baselines, walk-forward
│   └── backtest.py           ← next-bar execution, risk, MTM (5 modes)
├── tests/
│   ├── test_pipeline.py      ← 16 regression tests
│   ├── test_indicators.py    ← 26 indicator correctness tests
│   ├── test_patterns.py      ← 16 pattern detection tests
│   └── test_risk_rules.py    ← 14 shared risk-rule tests (weekly limit, cooldown bands, vol sizing)
└── data/                     ← apni CSV yahan rakho
```

---

## 8. Tumhara roadmap

```text
[1] Android app ke Phase 2.2 safety fixes    → AI Studio ko prompt bhejo
[2] Ye kit setup karo (Windows)             → 58 tests pass
[3] RELIANCE daily 8-10 saal CSV lao        → NSE official
[4] Research chalao, verdict padho          → yahan faisla hoga
[5] Agar NO EDGE → strategy badlo, repeat   → live ki taraf mat badho
[6] Agar CANDIDATE → aur symbols + paper trading (PC market hours mein on hai)
[7] Uske baad broker + compliance + chhota capital
```

Step 4 hi asli gate hai. Usse pehle app mein aur features add karna waqt barbaad karna hai.

---

## 10. Feature set aur calibration (v2.0)

### 22 causal features — `features-v2.0`

Feature set ab 8 se badh kar **22** hai, aur har feature strictly causal hai —
bar `t` ka feature sirf bar `0..t` se banta hai. Koi bhi rolling window centred
nahi hai, koi `ewm` aage nahi dekhta, aur koi `shift(n)` with `n > 0` pichhle
data ki taraf hi jaata hai.

| Family | Features |
| --- | --- |
| Returns | `return_1`, `return_3`, `return_5`, `return_10` |
| Volatility | `atr_ratio`, `atr_expansion`, `volatility_20`, `volatility_ratio` |
| Volume | `volume_ratio`, `volume_trend`, `volume_zscore` |
| EMA distance | `ema_9_dist`, `ema_21_dist`, `ema_50_dist`, `ema_200_dist`, `ema_9_21_diff` |
| RSI | `rsi_14_norm`, `rsi_slope_5` |
| MACD | `macd_hist_norm`, `macd_norm`, `macd_cross` |
| Bollinger | `bb_percent_b` |

Pehle ke 8 features (`features-v1.0`) ke formulas bilkul same hain, isliye
har downstream consumer (rules-only backtest, paper replay, purane reports)
bilkul pehle jaisa behave karta hai.

**Warm-up:** `FEATURE_WARMUP = 60`. Ye ek *floor* hai — `build_dataset()`
hamesha isse kam warm-up allow nahi karta, kyunki 200-period EMA aur
100-period ATR baseline dono ko 60 settled bars chahiye.

### Probability calibration — sirf validation split par

Random forest teeno noisy classes par aksar galat bars par over-confident hota
hai. Calibrator sirf **confidence** theek karta hai, **prediction** nahi:

```
z = log(p)                       # forest ke log-probabilities
p_calibrated = softmax(z / T)    # == p ** (1/T), renormalised
```

`T` **sirf validation split** par fit hota hai — test split calibrator ko
kabhi nahi milta, isliye test ke calibration numbers ek sachmuch
out-of-sample measurement hain.

**Guarantee kya hai, kya nahi:**

- ✅ Har row ka **class order** (aur isliye arg-max / predicted class) bilkul
  same rehta hai. Accuracy, macro-F1 aur confusion matrix **badalte nahi**.
- ✅ Brier, log-loss aur ECE improve hote hain (test split par ECE aam taur par
  3-5x girta hai).
- ❌ Iska matlab **nahi** ki trading behaviour same rahega. `p_up - p_down` par
  chalne wala threshold rule calibration ke baad zyada ya kam baar fire kar
  sakta hai. Isliye report mein calibrated aur raw dono backtest numbers alag
  se print hote hain.

**Per-class Platt scaling kyun nahi:** `T` ek hi positive number hai, isliye
class order kabhi nahi badal sakta. Per-class transform class order badal sakta
hai, jo "better probabilities" ke naam par live trading behaviour ko badal
deta hai. Temperature scaling ye nahi kar sakta.

Calibration **edge ka proof nahi hai** — sirf ye kehta hai ki probability par
bharosa karna sahi hai.

**Deployment policy (har report mein explicitly likha hota hai):**

| | |
| --- | --- |
| Deployed artifact | `CalibratedForest` (forest + calibrator) — raw forest kabhi deploy nahi hota |
| Calibrated probabilities threshold entries chalate hain? | **haan** |
| Kya guarantee hai | predicted class (arg-max) aur accuracy raw forest jaisi hi rehti hai |
| Kya guarantee **nahi** hai | entries ki sankhya — `p_up - p_down` par threshold flattened probabilities ke baad zyada ya kam baar fire karta hai |

Isliye calibrated run ka trade count aur net result hi deployed behaviour batate
hain. Report raw aur calibrated dono test-split metrics dikhata hai.

### Feature-importance stability (multiple seeds)

Model ko kai random seeds se refit karke importance rankings compare hote
hain: mean rank, rank standard deviation, rank correlation, top-5 frequency
aur ek 0-100 stability score.

**Ye ek diagnostic hai, verdict nahi.** Stability ka matlab hai ki model kai
seeds par wahi kahani batata hai — iska isse **koi lena-dena nahi** ki model me
predictive power rakhta hai. Har walk-forward fold apna importance snapshot
rakhta hai, aur report mean importance + top-5 frequency aggregate karta hai.

---

## 9. Zaroori warning

- Ye toolkit **past data** par test karta hai. Past performance future profit ki guarantee nahi hai.
- Market mein **loss ho sakta hai**, poora capital bhi.
- Real money lagane se pehle: mahino ka paper trading, broker ke algo requirements, aur SEBI ke applicable rules verify karo.
- Sirf woh paisa lagao jo doob jaye toh tumhari life na ruke.
