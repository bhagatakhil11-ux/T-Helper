"""QuantAI research toolkit — RESEARCH ONLY. No broker, no live orders."""
from .config import (CostModel, DataOrigin, ResearchConfig, ResearchQuality,
                     RiskConfig, VerificationStatus)
from .data import DatasetMeta, load_csv, write_meta
from .quality import (QualityAssessment, analyse_gaps, analyse_volume,
                      assess_quality, detect_corporate_actions)

__all__ = [
    "CostModel", "RiskConfig", "ResearchConfig", "DataOrigin",
    "VerificationStatus", "ResearchQuality", "DatasetMeta", "load_csv", "write_meta",
    "QualityAssessment", "assess_quality", "detect_corporate_actions",
    "analyse_gaps", "analyse_volume",
]
