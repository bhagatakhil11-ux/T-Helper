"""Command-line research runner.

Example (Windows PowerShell):
    python run_research.py --csv data\\RELIANCE_1D.csv --symbol RELIANCE --timeframe 1D
"""
from __future__ import annotations

from dataclasses import asdict

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from quantai.backtest import run_backtest
from quantai.config import (CostModel, DataOrigin, ResearchConfig, ResearchQuality,
                            RiskConfig, DataOrigin as DO)
from quantai.data import load_csv, write_meta
from quantai.features import FEATURE_NAMES, build_dataset, build_features, purged_split
from quantai.indicators import compute_indicators
from quantai.model import (CalibratedForest, aggregate_walk_forward_importance,
                           calibration_report, evaluate, feature_importance,
                           feature_importance_stability, fit_forest,
                           fit_probability_calibrator, momentum_baseline,
                           walk_forward, _proba)


def verdict(meta, test_rep, bt_ens, bt_bh, wf) -> tuple[str, list[str]]:
    reasons: list[str] = []
    if meta.source_type in (DO.SIMULATED, DO.TEST_FIXTURE):
        reasons.append("Data is NOT real market history. This run only proves the pipeline works.")
        return "PLUMBING_ONLY — NO MARKET CONCLUSION", reasons
    if meta.research_quality is ResearchQuality.LOW_CONFIDENCE_INSUFFICIENT_DATA:
        reasons.append(f"Only {meta.candle_count} bars (< {meta.required_research_bars} needed). Sample too small to trust.")
    if test_rep.accuracy <= max(test_rep.majority_baseline_accuracy, test_rep.momentum_baseline_accuracy):
        reasons.append("Model did not beat simple baselines on the unseen test split.")
    if bt_ens.net_profit <= 0:
        reasons.append("Strategy lost money on the unseen window after costs and slippage.")
    if bt_ens.total_trades < 5:
        reasons.append("Fewer than 5 trades: statistically meaningless.")
    if wf and np.mean([f["accuracy"] for f in wf]) < test_rep.accuracy - 0.10:
        reasons.append("Walk-forward accuracy is materially worse than the single holdout: possible overfit.")
    if bt_bh.net_profit > bt_ens.net_profit:
        reasons.append("Buy & hold beat the strategy on the same window. Complexity added no value.")
    if reasons:
        return "NO EDGE EVIDENCE — DO NOT DEPLOY", reasons
    return "CANDIDATE — NEEDS MORE DATA + PAPER TRADING", [
        "Beat baselines and buy & hold after costs on this window. This is NOT proof of future profit.",
        "Next: more symbols, more periods, then months of paper trading.",
    ]


def main() -> None:
    ap = argparse.ArgumentParser(description="QuantAI research runner (no live trading)")
    ap.add_argument("--csv", required=True)
    ap.add_argument("--symbol", required=True)
    ap.add_argument("--timeframe", default="1D", choices=["1m", "5m", "15m", "1D"])
    ap.add_argument("--source-type", default="IMPORTED_CSV",
                    choices=[e.value for e in DataOrigin])
    ap.add_argument("--adjustment", default="UNKNOWN_UNVERIFIED",
                    choices=["UNKNOWN_UNVERIFIED", "UNADJUSTED", "SPLIT_AND_BONUS_ADJUSTED"])
    ap.add_argument("--holidays", default=None, help="Optional file with one YYYY-MM-DD per line")
    ap.add_argument("--horizon", type=int, default=5)
    ap.add_argument("--out", default="results")
    ap.add_argument("--entry-threshold", type=float, default=0.42)
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    holidays = set()
    if args.holidays:
        holidays = {l.strip() for l in Path(args.holidays).read_text().splitlines() if l.strip()}

    cfg = ResearchConfig(symbol=args.symbol.upper(), timeframe=args.timeframe,
                         forward_horizon=args.horizon,
                         cost=CostModel(is_intraday=args.timeframe != "1D"),
                         risk=RiskConfig())

    df, meta = load_csv(args.csv, args.symbol, args.timeframe,
                        source_type=DataOrigin(args.source_type),
                        adjustment_policy=args.adjustment, holidays=holidays)
    write_meta(meta, out)
    df.to_csv(out / "clean_candles.csv", index=False)

    round_trip = 2 * (cfg.cost.slippage_pct + cfg.cost.delivery_stt + cfg.cost.exchange_turnover)
    X, y, candles, feats = build_dataset(df, cfg.forward_horizon, round_trip,
                                         cfg.return_threshold, cfg.warmup_bars)
    split = purged_split(candles, cfg.forward_horizon, cfg.train_frac, cfg.val_frac)
    pos_of = {int(c): k for k, c in enumerate(candles)}
    tr = np.array([pos_of[int(c)] for c in split.train_idx])
    va = np.array([pos_of[int(c)] for c in split.val_idx])
    te = np.array([pos_of[int(c)] for c in split.test_idx])

    clf = fit_forest(X[tr], y[tr], cfg.n_estimators, cfg.max_depth,
                     cfg.min_samples_leaf, cfg.random_state)
    mom = momentum_baseline(X[:, 0], cfg.return_threshold)

    # Probability calibration: fitted on the VALIDATION split only, so the
    # unseen test split stays genuinely unseen by the calibrator.
    calibrator = fit_probability_calibrator(clf, X[va], y[va])
    model = CalibratedForest(clf, calibrator)
    val_raw, test_raw = _proba(clf, X[va]), _proba(clf, X[te])
    val_cal, test_cal = calibrator.apply(val_raw), calibrator.apply(test_raw)
    calibration = {
        "method": calibrator.method,
        "fitted_on": "validation split only (the unseen test split was never used to fit it)",
        "calibrator": calibrator.to_dict(),
        "validation": calibration_report(val_raw, val_cal, y[va]),
        "unseen_test": calibration_report(test_raw, test_cal, y[te]),
        "deployment_policy": {
            "deployed_artifact": "calibrated",
            "artifact_description": "The CalibratedForest (forest + calibrator) is the model "
                                    "that gets saved, reloaded and replayed. The raw forest "
                                    "is never deployed.",
            "affects_threshold_entries": True,
            "threshold_policy_note": "YES — the calibrated probabilities ARE what the backtest "
                                     "and the paper replay feed into the threshold rule "
                                     "(p_up - p_down >= entry_threshold). Because the calibrated "
                                     "probabilities are flatter, the same threshold can fire "
                                     "more or less often than it did on the raw probabilities. "
                                     "The calibrated run is therefore the one whose trade count "
                                     "and net result describe the deployed behaviour.",
            "argmax_guarantee": "The predicted class (arg-max) and the accuracy are provably "
                                "identical to the raw forest's — only the confidence and the "
                                "entry frequency can move.",
        },
        "note": "Calibration corrects CONFIDENCE, not the prediction: temperature scaling "
                "preserves the class order of every row, so the predicted class (arg-max) and "
                "the accuracy are unchanged. It is NOT a guarantee that trading behaviour is "
                "unchanged — a threshold rule acting on p_up - p_down can fire more or less "
                "often after calibration. It is not evidence of an edge.",
    }

    val_rep = evaluate(clf, X[va], y[va], y[tr], mom[va], "validation (model selection only)")
    test_rep = evaluate(clf, X[te], y[te], y[tr], mom[te], "unseen test (used once)")
    test_rep_cal = evaluate(clf, X[te], y[te], y[tr], mom[te], "unseen test (calibrated)",
                            proba_override=test_cal)
    wf = walk_forward(X, y, candles, cfg.forward_horizon, cfg.walk_forward_folds,
                      min(cfg.n_estimators, 200), cfg.max_depth, cfg.min_samples_leaf,
                      cfg.random_state)
    wf_importance = aggregate_walk_forward_importance(wf)

    # Feature-importance stability across random seeds (train split only).
    stability = feature_importance_stability(
        X[tr], y[tr],
        seeds=(cfg.random_state, cfg.random_state + 17, cfg.random_state + 101),
        n_estimators=min(cfg.n_estimators, 200), max_depth=cfg.max_depth,
        min_samples_leaf=cfg.min_samples_leaf)

    # Predictions for every bar with valid features (model saw TRAIN ONLY).
    full_feats = build_features(df)
    proba = np.full((len(df), 3), np.nan)
    ok = full_feats[FEATURE_NAMES].notna().all(axis=1).to_numpy()
    if ok.any():
        p = model.predict_proba(full_feats.loc[ok, FEATURE_NAMES].to_numpy())
        tmp = np.zeros((ok.sum(), 3))
        for col, cls in enumerate(model.classes_):
            tmp[:, int(cls)] = p[:, col]
        proba[ok] = tmp

    test_start = int(split.test_idx[0])
    # Causal indicator set: the indicator strategy runs on the SAME purged split
    # and the SAME unseen test window as every other strategy.
    ind = compute_indicators(df, cfg.timeframe)
    runs = {}
    for mode, label in [("ensemble", "Ensemble (60% rules + 40% ML)"),
                        ("rules_only", "Rules only (no ML)"),
                        ("indicators", "Indicators (EMA/RSI/MACD/BB)"),
                        ("ml_only", "ML only"),
                        ("buy_and_hold", "Buy & hold benchmark")]:
        runs[mode] = run_backtest(df, full_feats, test_start, cfg.cost, cfg.risk,
                                  cfg.timeframe, proba=proba, mode=mode,
                                  entry_threshold=args.entry_threshold, label=label,
                                  indicator_df=ind)

    status, reasons = verdict(meta, test_rep, runs["ensemble"], runs["buy_and_hold"], wf)

    report = {
        "DISCLAIMER": "Research output only. No live orders. Past results do not predict future profit.",
        "verdict": status, "verdict_reasons": reasons,
        "dataset": meta.to_dict(),
        "config": cfg.to_dict(),
        "cost_model": cfg.cost.summary(),
        # The risk rules this run actually executed under — without them two
        # research runs are not comparable.
        "risk_config": asdict(cfg.risk),
        "risk_summary": cfg.risk.summary(),
        "execution_contract": "Signal at bar[t] close -> entry at bar[t+1] open + slippage; "
                              "gap opens fill at open; stop assumed before target inside a bar; "
                              "MTM equity and unrealized drawdown every bar.",
        "split": split.to_dict(),
        "validation": val_rep.to_dict(),
        "unseen_test": test_rep.to_dict(),
        "unseen_test_calibrated": test_rep_cal.to_dict(),
        "calibration": calibration,
        "walk_forward": wf,
        "feature_importance": feature_importance(clf),
        "feature_importance_stability": stability,
        "walk_forward_feature_importance": wf_importance,
        "backtests": {k: v.to_dict() for k, v in runs.items()},
    }
    (out / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    for k, v in runs.items():
        pd.DataFrame(v.trade_log).to_csv(out / f"trades_{k}.csv", index=False)

    fig, ax = plt.subplots(figsize=(11, 5))
    for mode, res in runs.items():
        ax.plot(res.equity_curve, label=f"{res.label} ({res.net_return_pct:+.2f}%)", linewidth=1.4)
    ax.set_title(f"{meta.symbol} {meta.timeframe} — unseen test window\n{meta.verification_status.value}")
    ax.set_xlabel("Bar in test window"); ax.set_ylabel("Equity (INR)")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)
    fig.tight_layout(); fig.savefig(out / "equity_curves.png", dpi=130); plt.close(fig)

    ens = runs["ensemble"]
    lines = [
        f"# QuantAI research report — {meta.symbol} {meta.timeframe}", "",
        f"**Verdict: {status}**", "",
        *[f"- {r}" for r in reasons], "",
        "## Data provenance", "",
        f"- Origin: `{meta.source_type.value}`",
        f"- Verification: `{meta.verification_status.value}`",
        f"- Dataset ID: `{meta.dataset_id}`",
        f"- SHA-256: `{meta.sha256[:16]}…`",
        f"- Bars: {meta.candle_count} (research-grade needs {meta.required_research_bars})",
        f"- Quality: `{meta.research_quality.value}`",
        f"- Range: {meta.start} → {meta.end}",
        f"- Rejected rows: {meta.rows_rejected}, duplicates dropped: {meta.duplicates}, gaps: {meta.missing_bars}",
        "", "### Data warnings", "",
        *[f"- {w}" for w in meta.warnings], "",
        "## Split (purged, chronological)", "",
        "```json", json.dumps(split.to_dict(), indent=2), "```", "",
        "## Unseen test classification", "",
        f"- Accuracy: **{test_rep.accuracy:.4f}**",
        f"- Majority baseline: {test_rep.majority_baseline_accuracy:.4f}",
        f"- Momentum baseline: {test_rep.momentum_baseline_accuracy:.4f}",
        f"- Macro F1: {test_rep.macro_f1:.4f} | LogLoss: {test_rep.log_loss:.4f} | Brier: {test_rep.brier:.4f}",
        f"- Confusion (rows=actual, cols=pred, order DOWN/SIDE/UP): `{test_rep.confusion}`", "",
        "## Probability calibration (fitted on the validation split only)", "",
        f"- Method: `{calibration['method']}`",
        f"- Temperature: `{calibration['calibrator']['temperature']:.4f}` "
        f"(fitted on {calibration['calibrator']['n_samples']} validation samples)",
        f"- Fitted on: {calibration['fitted_on']}", "",
        "| Split | Brier raw → calibrated | ECE raw → calibrated | LogLoss raw → calibrated |",
        "|---|---|---|---|",
        f"| Validation (fitted here) | {calibration['validation']['brier_raw']:.4f} → "
        f"{calibration['validation']['brier_calibrated']:.4f} | "
        f"{calibration['validation']['expected_calibration_error_raw']:.4f} → "
        f"{calibration['validation']['expected_calibration_error_calibrated']:.4f} | "
        f"{calibration['validation']['log_loss_raw']:.4f} → "
        f"{calibration['validation']['log_loss_calibrated']:.4f} |",
        f"| Unseen test | {calibration['unseen_test']['brier_raw']:.4f} → "
        f"{calibration['unseen_test']['brier_calibrated']:.4f} | "
        f"{calibration['unseen_test']['expected_calibration_error_raw']:.4f} → "
        f"{calibration['unseen_test']['expected_calibration_error_calibrated']:.4f} | "
        f"{calibration['unseen_test']['log_loss_raw']:.4f} → "
        f"{calibration['unseen_test']['log_loss_calibrated']:.4f} |", "",
        f"- Accuracy raw → calibrated (must not change): "
        f"{calibration['unseen_test']['accuracy_raw']:.4f} → "
        f"{calibration['unseen_test']['accuracy_calibrated']:.4f}",
        f"- Arg-max preserved on test: `{calibration['unseen_test']['argmax_preserved']}`", "",
        "### Deployment policy", "",
        f"- Deployed artifact: `{calibration['deployment_policy']['deployed_artifact']}`",
        f"- Calibrated probabilities drive threshold entries: "
        f"`{calibration['deployment_policy']['affects_threshold_entries']}`", "",
        f"> {calibration['deployment_policy']['threshold_policy_note']}", "",
        f"> {calibration['deployment_policy']['argmax_guarantee']}", "",
        f"> {calibration['note']}", "",
        "## Feature-importance stability (across random seeds)", "",
        f"- Seeds: `{stability['seeds']}`",
        f"- Stability score: `{stability['stability_score']}/100`",
        f"- Mean rank correlation: `{stability['rank_correlation_mean']}`", "",
        *[f"- ⚠ {flag}" for flag in stability.get("flags", [])], "",
        f"> {stability.get('note', '')}", "",
        "## Walk-forward feature importance", "",
        f"- Folds aggregated: {wf_importance['n_folds']}",
        f"- Most consistent across folds: "
        f"{', '.join(wf_importance.get('most_consistent_features', []))}", "",
        "```json", json.dumps(wf_importance.get("mean", {}), indent=2), "```", "",
        "## Backtests on the same unseen window", "",
        "| Strategy | Trades | Win % | Net % | Max DD % | Sharpe | Costs |",
        "|---|---|---|---|---|---|---|",
    ]
    for res in runs.values():
        sh = "N/A" if res.sharpe is None else f"{res.sharpe:.2f}"
        lines.append(f"| {res.label} | {res.total_trades} | {res.win_rate_pct:.1f} | "
                     f"{res.net_return_pct:+.2f} | {res.max_drawdown_pct:.2f} | {sh} | "
                     f"Rs{res.total_costs:,.0f} |")
    lines += ["", f"Sharpe status (ensemble): {ens.sharpe_reason}", "",
              f"Rejected signals (ensemble): `{ens.rejected_signals}`", "",
              "## Walk-forward folds", "",
              "```json", json.dumps(wf, indent=2), "```", "",
              "## Cost model", "", cfg.cost.summary(), "",
              "## Execution contract", "", report["execution_contract"], "",
              "---", report["DISCLAIMER"], ""]
    (out / "report.md").write_text("\n".join(lines), encoding="utf-8")

    print("=" * 70)
    print(f"VERDICT: {status}")
    for r in reasons:
        print(f"  - {r}")
    print(f"Data: {meta.verification_status.value} | {meta.candle_count} bars | {meta.research_quality.value}")
    print(f"Test accuracy {test_rep.accuracy:.4f} vs majority {test_rep.majority_baseline_accuracy:.4f} "
          f"/ momentum {test_rep.momentum_baseline_accuracy:.4f}")
    for res in runs.values():
        sh = "N/A" if res.sharpe is None else f"{res.sharpe:.2f}"
        print(f"  {res.label:34s} trades={res.total_trades:3d} net={res.net_return_pct:+7.2f}% "
              f"DD={res.max_drawdown_pct:5.2f}% Sharpe={sh}")
    print(f"\nWrote: {out/'report.md'}, report.json, equity_curves.png")
    print("=" * 70)


if __name__ == "__main__":
    main()
