"""Risk rules in the standalone research kit.

The research kit shares the risk semantics with the terminal: the same
weekly loss limit, the same progressive-cooldown bands and the same
volatility-adjusted sizing helper. These tests pin the shared behaviour so
the two kits can never drift apart silently.
"""
from __future__ import annotations

import pandas as pd
import pytest

from quantai.config import RiskConfig
from quantai.risk_rules import (MAX_COOLDOWN_BARS, daily_drawdown_pct,
                                effective_risk_pct, iso_week_key,
                                progressive_cooldown_bars, weekly_drawdown_pct)


# ---------------------------------------------------------------------------
# weekly loss limit
# ---------------------------------------------------------------------------
def test_iso_week_key_groups_by_iso_week():
    assert iso_week_key(pd.Timestamp("2024-01-01")) == "2024-W01"   # Monday
    assert iso_week_key(pd.Timestamp("2024-01-07")) == "2024-W01"   # Sunday
    assert iso_week_key(pd.Timestamp("2024-01-08")) == "2024-W02"   # next Monday


def test_weekly_drawdown_is_measured_from_the_week_start():
    assert weekly_drawdown_pct(100000.0, 100000.0) == 0.0
    assert weekly_drawdown_pct(100000.0, 95000.0) == pytest.approx(5.0)
    assert weekly_drawdown_pct(0.0, 95000.0) == 0.0


def test_the_weekly_limit_defaults_to_five_percent():
    assert RiskConfig().max_weekly_drawdown_pct == 5.0


def test_the_daily_and_weekly_limits_are_independent():
    cfg = RiskConfig(max_daily_drawdown_pct=2.0, max_weekly_drawdown_pct=6.0)
    assert cfg.max_daily_drawdown_pct == 2.0
    assert cfg.max_weekly_drawdown_pct == 6.0
    assert daily_drawdown_pct(100000.0, 98000.0) == pytest.approx(2.0)


# ---------------------------------------------------------------------------
# progressive cooldown
# ---------------------------------------------------------------------------
def test_the_progressive_cooldown_bands():
    """3 losses -> 15 bars, 5 -> 30 bars, 7+ -> 50 bars."""
    assert progressive_cooldown_bars(3, 3, 15, True) == 15
    assert progressive_cooldown_bars(4, 3, 15, True) == 15
    assert progressive_cooldown_bars(5, 3, 15, True) == 30
    assert progressive_cooldown_bars(6, 3, 15, True) == 30
    assert progressive_cooldown_bars(7, 3, 15, True) == 50
    assert progressive_cooldown_bars(20, 3, 15, True) == 50


def test_the_third_cooldown_band_is_flat():
    """The cooldown stops growing — a long streak can never lock the engine out."""
    for losses in (7, 9, 11, 100, 1000):
        assert progressive_cooldown_bars(losses, 3, 15, True) == 50


def test_the_cooldown_bands_are_configurable():
    assert progressive_cooldown_bars(3, 3, 10, True, level2_bars=20, level3_bars=40) == 10
    assert progressive_cooldown_bars(5, 3, 10, True, level2_bars=20, level3_bars=40) == 20
    assert progressive_cooldown_bars(7, 3, 10, True, level2_bars=20, level3_bars=40) == 40


def test_the_cooldown_bands_never_shrink():
    assert progressive_cooldown_bars(5, 3, 15, True, level2_bars=5, level3_bars=1) == 15
    assert progressive_cooldown_bars(7, 3, 15, True, level2_bars=5, level3_bars=1) == 15


def test_the_fixed_cooldown_is_unchanged_when_progressive_is_off():
    for losses in (3, 5, 7, 11, 25):
        assert progressive_cooldown_bars(losses, 3, 15, False) == 15


def test_the_cooldown_never_exceeds_the_hard_cap():
    assert progressive_cooldown_bars(500, 3, 15, True, level2_bars=100,
                                     level3_bars=10_000) <= MAX_COOLDOWN_BARS


# ---------------------------------------------------------------------------
# volatility-adjusted sizing
# ---------------------------------------------------------------------------
def test_volatility_sizing_is_off_by_default():
    cfg = RiskConfig()
    assert cfg.auto_risk_by_volatility is False


def test_with_volatility_sizing_off_the_risk_is_unchanged():
    base, detail = effective_risk_pct(0.5, atr=2.0, price=100.0, auto=False)
    assert base == 0.5
    assert detail["factor"] == 1.0
    assert detail["auto"] is False


def test_volatility_sizing_shrinks_the_risk_when_the_market_is_volatile():
    # ATR 4% of price against a 2% target -> the factor is 0.5
    base, detail = effective_risk_pct(0.5, atr=4.0, price=100.0, auto=True,
                                      target_atr_pct=2.0, min_factor=0.25, max_factor=2.0)
    assert detail["atr_pct"] == pytest.approx(4.0)
    assert detail["factor"] == pytest.approx(0.5)
    assert base == pytest.approx(0.25)


def test_volatility_sizing_is_clamped():
    base, detail = effective_risk_pct(0.5, atr=50.0, price=100.0, auto=True,
                                      target_atr_pct=2.0, min_factor=0.25, max_factor=2.0)
    assert detail["factor"] == 0.25
    assert base == pytest.approx(0.125)
    base, detail = effective_risk_pct(0.5, atr=0.1, price=100.0, auto=True,
                                      target_atr_pct=2.0, min_factor=0.25, max_factor=2.0)
    assert detail["factor"] == 2.0
    assert base == pytest.approx(1.0)
