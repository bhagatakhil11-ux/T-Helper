"""Dataset quality: corporate-action detection, gap reporting, volume anomalies
and the 0-100 quality score.

Every expectation is hand-checked against a deliberately constructed CSV.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantai.data import load_csv
from quantai.quality import (analyse_gaps, analyse_volume, detect_corporate_actions)


def _bars(n, start="2024-01-01", price=100.0, volume=1000):
    ts = pd.date_range(start, periods=n, freq="B", tz="Asia/Kolkata")
    return pd.DataFrame({"timestamp": ts, "open": np.full(n, price),
                         "high": np.full(n, price + 1), "low": np.full(n, price - 1),
                         "close": np.full(n, price), "volume": np.full(n, volume, dtype=float)})


def _write(tmp_path, df, name="d.csv"):
    p = tmp_path / name
    p.write_text(df.to_csv(index=False))
    return p


# ---------------------------------------------------------------- corporate actions
def test_half_price_split_is_detected(tmp_path):
    df = _bars(100)
    df.loc[50:, ["open", "high", "low", "close"]] /= 2.0
    _, meta = load_csv(_write(tmp_path, df, "split.csv"), "X", "1D")

    assert meta.corporate_action_count == 1
    ev = meta.corporate_actions[0]
    assert ev["kind"] == "CORPORATE_ACTION_SUSPECTED"
    assert ev["implied_ratio"] == "1:2"
    assert ev["confidence_label"] == "HIGH"
    assert "corporate-action register" in ev["caveat"]


def test_prices_are_never_modified_by_the_detector(tmp_path):
    df = _bars(100)
    before = df["close"].copy()
    df.loc[50:, ["open", "high", "low", "close"]] /= 2.0
    out, _ = load_csv(_write(tmp_path, df, "split.csv"), "X", "1D")
    assert out["close"].iloc[50] == pytest.approx(before.iloc[50] / 2.0)


def test_clean_series_has_no_discontinuities():
    df = _bars(100)
    assert detect_corporate_actions(df, "1D") == []


# ---------------------------------------------------------------- gaps
def test_missing_session_is_reported(tmp_path):
    df = _bars(60).drop(index=30).reset_index(drop=True)
    _, meta = load_csv(_write(tmp_path, df, "gap.csv"), "X", "1D")
    gr = meta.gap_report
    assert gr["missing_sessions"] >= 1
    assert any(e["kind"] == "MISSING_SESSION" for e in gr["events"])


def test_holiday_skip_is_not_missing_data(tmp_path):
    df = _bars(60)
    dropped = df.loc[30, "timestamp"].strftime("%Y-%m-%d")
    df = df.drop(index=30).reset_index(drop=True)
    _, meta = load_csv(_write(tmp_path, df, "gap.csv"), "X", "1D", holidays={dropped})
    assert meta.gap_report["holiday_sessions"] >= 1
    assert meta.gap_report["missing_sessions"] == 0


def test_gap_numbers_match_the_legacy_counter():
    from quantai.data import _count_gaps

    ts = pd.Series(pd.date_range("2024-01-01", periods=40, freq="B", tz="Asia/Kolkata"))
    legacy_missing, legacy_skipped, _ = _count_gaps(ts, "1D", set())
    rep = analyse_gaps(ts, "1D", set())
    assert rep.missing_bars == legacy_missing
    assert rep.holiday_skips == legacy_skipped


# ---------------------------------------------------------------- volume
def test_volume_spike_and_zero_are_flagged_not_rejected(tmp_path):
    df = _bars(100)
    df.loc[60, "volume"] = 1000 * 50
    df.loc[70, "volume"] = 0
    out, meta = load_csv(_write(tmp_path, df, "v.csv"), "X", "1D")
    assert len(out) == 100
    assert meta.abnormal_volume_bars >= 1
    assert meta.zero_volume_bars == 1


def test_zscore_catches_a_spike_below_the_ratio_threshold(tmp_path):
    df = _bars(200)
    df.loc[100, "volume"] = 1000 * 5
    _, meta = load_csv(_write(tmp_path, df, "z.csv"), "X", "1D")
    vp = meta.volume_profile
    assert vp["ratio_alert_bars"] == 0
    assert vp["zscore_alerts"] >= 1


def test_volume_profile_states_its_method():
    prof = analyse_volume(pd.Series([100.0] * 40 + [100000.0]))
    assert "rolling" in prof.method.lower()
    assert "z-score" in prof.method.lower()


# ---------------------------------------------------------------- quality score
def test_quality_score_is_bounded_and_broken_down(tmp_path):
    _, meta = load_csv(_write(tmp_path, _bars(2000), "ok.csv"), "X", "1D")
    assert 0 <= meta.data_quality_score <= 100
    assert meta.data_quality_grade in ("A", "B", "C", "D", "F")
    assert {c["key"] for c in meta.data_quality_components} == {
        "row_integrity", "continuity", "volume_sanity", "price_consistency", "sufficiency"}


def test_serious_issue_caps_the_grade(tmp_path):
    df = _bars(2000)
    df.loc[100:, ["open", "high", "low", "close"]] /= 2.0
    _, meta = load_csv(_write(tmp_path, df, "split.csv"), "X", "1D")
    assert meta.serious_issues
    assert meta.data_quality_score <= 70
