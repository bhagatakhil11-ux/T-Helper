# QuantAI research report — TESTFIX 1D

**Verdict: PLUMBING_ONLY — NO MARKET CONCLUSION**

- Data is NOT real market history. This run only proves the pipeline works.

## Data provenance

- Origin: `TEST_FIXTURE`
- Verification: `TEST_FIXTURE_NOT_MARKET_DATA`
- Dataset ID: `TESTFIX_1D_928feb5e0496`
- SHA-256: `928feb5e04962a72…`
- Bars: 2000 (research-grade needs 1500)
- Quality: `RESEARCH_GRADE`
- Range: 2015-01-01T00:00:00+05:30 → 2022-08-31T00:00:00+05:30
- Rejected rows: 0, duplicates dropped: 0, gaps: 0

### Data warnings

- Adjustment policy unknown: multi-year splits/bonuses can create fake signals. Verify before trusting results.
- NOT REAL MARKET DATA. Results describe plumbing only, never market edge.

## Split (purged, chronological)

```json
{
  "train": {
    "count": 1176,
    "first_candle": 35,
    "last_candle": 1210
  },
  "validation": {
    "count": 392,
    "first_candle": 1216,
    "last_candle": 1607
  },
  "test": {
    "count": 382,
    "first_candle": 1613,
    "last_candle": 1994
  },
  "purged": {
    "count": 10,
    "first_candle": 1211,
    "last_candle": 1612
  },
  "feature_version": "features-v1.0"
}
```

## Unseen test classification

- Accuracy: **0.4450**
- Majority baseline: 0.4319
- Momentum baseline: 0.3901
- Macro F1: 0.3237 | LogLoss: 1.0763 | Brier: 0.6516
- Confusion (rows=actual, cols=pred, order DOWN/SIDE/UP): `[[111, 0, 54], [51, 0, 29], [78, 0, 59]]`

## Backtests on the same unseen window

| Strategy | Trades | Win % | Net % | Max DD % | Sharpe | Costs |
|---|---|---|---|---|---|---|
| Ensemble (60% rules + 40% ML) | 0 | 0.0 | +0.00 | 0.00 | N/A | Rs0 |
| Rules only (no ML) | 10 | 0.0 | -5.72 | 5.72 | -2.24 | Rs3,282 |
| ML only | 1 | 100.0 | +0.92 | 0.52 | N/A | Rs341 |
| Buy & hold benchmark | 1 | 0.0 | -12.97 | 18.87 | -0.71 | Rs1,039 |

Sharpe status (ensemble): N/A: needs >= 30 bars and >= 5 closed trades (got 387 bars, 0 trades)

Rejected signals (ensemble): `{'risk_qty_zero': 0, 'daily_drawdown': 0, 'cooldown': 0, 'exposure_cap': 0, 'insufficient_cash': 0, 'no_signal': 386, 'intraday_no_overnight': 0, 'total_drawdown_halt': 0, 'max_open_positions': 0, 'volume_cap': 0}`

## Walk-forward folds

```json
[
  {
    "fold": 1,
    "train_candles": [
      35,
      818
    ],
    "purged_candles": [
      819,
      823
    ],
    "test_candles": [
      824,
      1115
    ],
    "test_samples": 292,
    "accuracy": 0.3698630136986301,
    "macro_f1": 0.2687868346231335
  },
  {
    "fold": 2,
    "train_candles": [
      35,
      1110
    ],
    "purged_candles": [
      1111,
      1115
    ],
    "test_candles": [
      1116,
      1407
    ],
    "test_samples": 292,
    "accuracy": 0.3527397260273973,
    "macro_f1": 0.24444444444444446
  },
  {
    "fold": 3,
    "train_candles": [
      35,
      1402
    ],
    "purged_candles": [
      1403,
      1407
    ],
    "test_candles": [
      1408,
      1699
    ],
    "test_samples": 292,
    "accuracy": 0.4178082191780822,
    "macro_f1": 0.29193121693121693
  },
  {
    "fold": 4,
    "train_candles": [
      35,
      1694
    ],
    "purged_candles": [
      1695,
      1699
    ],
    "test_candles": [
      1700,
      1991
    ],
    "test_samples": 292,
    "accuracy": 0.4486301369863014,
    "macro_f1": 0.3104824684896566
  }
]
```

## Cost model

NSE Delivery (assumed effective 2025-10-01): slippage 0.030%/fill, STT 0.10% both legs, brokerage min(Rs20, 0.03%), exchange+SEBI+stamp+18% GST

## Execution contract

Signal at bar[t] close -> entry at bar[t+1] open + slippage; gap opens fill at open; stop assumed before target inside a bar; MTM equity and unrealized drawdown every bar.

---
Research output only. No live orders. Past results do not predict future profit.
