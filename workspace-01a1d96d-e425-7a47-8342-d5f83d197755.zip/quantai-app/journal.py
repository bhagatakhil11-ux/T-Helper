"""Persistent trading journal (SQLite) for paper-replay trades only.

Backtest trades are research artifacts and are exported separately; they are
NOT mixed into the live paper journal. Every journal row comes from an actual
simulated fill in the replay engine.
"""
from __future__ import annotations

import csv
import io
import sqlite3
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

JOURNAL_FIELDS = [
    "id", "created_at", "run_id", "dataset_id", "symbol", "timeframe", "strategy",
    "direction", "qty", "entry_time", "entry_price", "exit_time", "exit_price",
    "stop", "target", "pnl", "costs", "entry_reason", "exit_reason", "notes",
    "tags", "emotion",
]

# The suggested tag vocabulary. These are ONLY suggestions — a trader may
# type any custom tag. The list exists so the UI can offer one-click tagging
# instead of forcing free text on every row.
SUGGESTED_TAGS = [
    "breakout", "mean-reversion", "trend-following", "news", "gap",
    "mistake", "revenge-trade", "fomo-trade", "overtrade", "late-entry",
    "followed-plan", "patient", "a-plus-setup", "b-grade-setup",
    "scalp", "swing", "held-through-loss", "cut-early",
]

# The emotional state recorded alongside the trade notes. The point is to
# notice the PATTERN ("my revenge trades lose money"), not to moralise.
EMOTION_STATES = ["calm", "fomo", "revenge", "neutral"]

# Risk / engine events (kill switch, halts, limit breaches) are NOT trades.
# They live in their own table so the journal never has to pretend a kill
# switch was a trade — and so a trade count stays a trade count.
JOURNAL_EVENT_FIELDS = [
    "id", "created_at", "event_type", "reason", "detail",
    "run_id", "dataset_id", "symbol", "timeframe", "strategy",
    "bar", "equity", "net_pnl", "open_position",
]

# The event types the engine can record.
EVENT_TYPES = [
    "kill_switch_engaged", "kill_switch_released", "risk_limit_halt",
    "weekly_limit_engaged", "daily_limit_engaged", "cooldown_engaged",
    "risk_settings_changed",
]

# Column definitions added after the first release. Kept as data so the
# migration below stays declarative.
EXTRA_COLUMNS = [
    ("tags", "TEXT DEFAULT ''"),
    ("emotion", "TEXT DEFAULT ''"),
]

MAX_TAGS = 8
MAX_TAG_LEN = 32
MAX_EMOTION_LEN = 24


def normalize_tags(tags) -> list[str]:
    """Normalise a tag payload into a clean, de-duplicated, ordered list.

    Accepts a list or a comma-separated string. Tags are lower-cased, spaces
    become hyphens, empties are dropped, order of first appearance is kept
    (so the trader's own ordering survives) and the count is capped.
    """
    if tags is None:
        return []
    if isinstance(tags, str):
        raw = tags.replace(";", ",").split(",")
    elif isinstance(tags, (list, tuple, set)):
        raw = list(tags)
    else:
        raw = [tags]
    out: list[str] = []
    for t in raw:
        s = str(t).strip().lower()
        # Any run of whitespace becomes a single hyphen: "Mean Reversion" ->
        # "mean-reversion". Underscores are normalised to hyphens too, so a
        # tag never exists in two spellings.
        s = "-".join(s.split())
        s = s.replace("_", "-")
        s = "-".join(part for part in s.split("-") if part)
        if not s:
            continue
        s = s[:MAX_TAG_LEN]
        if s not in out:
            out.append(s)
        if len(out) >= MAX_TAGS:
            break
    return out


def tags_to_text(tags) -> str:
    return ",".join(normalize_tags(tags))


def text_to_tags(text) -> list[str]:
    if not text:
        return []
    return normalize_tags(str(text).split(","))


def normalize_emotion(emotion) -> str:
    """Validate the emotional state. Empty means 'not recorded'."""
    if emotion is None:
        return ""
    s = str(emotion).strip().lower()
    if not s:
        return ""
    s = s.replace("_", "-")[:MAX_EMOTION_LEN]
    return s


class Journal:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.lock = threading.RLock()
        self._init_db()

    def _conn(self):
        conn = sqlite3.connect(self.path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _init_db(self):
        with self.lock, self._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS trades (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    run_id TEXT,
                    dataset_id TEXT,
                    symbol TEXT,
                    timeframe TEXT,
                    strategy TEXT,
                    direction TEXT,
                    qty INTEGER,
                    entry_time TEXT,
                    entry_price REAL,
                    exit_time TEXT,
                    exit_price REAL,
                    stop REAL,
                    target REAL,
                    pnl REAL,
                    costs REAL,
                    entry_reason TEXT,
                    exit_reason TEXT,
                    notes TEXT DEFAULT '',
                    tags TEXT DEFAULT '',
                    emotion TEXT DEFAULT ''
                )
            """)
            # Migration: add the columns introduced after the first release to
            # an existing journal file. SQLite has no "ADD COLUMN IF NOT
            # EXISTS", so the table is inspected first.
            cols = {r[1] for r in conn.execute("PRAGMA table_info(trades)").fetchall()}
            for name, decl in EXTRA_COLUMNS:
                if name not in cols:
                    conn.execute(f"ALTER TABLE trades ADD COLUMN {name} {decl}")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_trades_exit_time ON trades(exit_time)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_trades_run ON trades(run_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_trades_strategy ON trades(strategy)")
            # Risk / engine events — deliberately NOT trades.
            conn.execute("""
                CREATE TABLE IF NOT EXISTS events (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    event_type TEXT,
                    reason TEXT DEFAULT '',
                    detail TEXT DEFAULT '',
                    run_id TEXT,
                    dataset_id TEXT,
                    symbol TEXT,
                    timeframe TEXT,
                    strategy TEXT,
                    bar INTEGER,
                    equity REAL,
                    net_pnl REAL,
                    open_position TEXT DEFAULT ''
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_events_created ON events(created_at)")

    def add(self, trade: dict) -> str:
        tid = trade.get("id") or f"j_{uuid.uuid4().hex[:16]}"
        row = {k: trade.get(k) for k in JOURNAL_FIELDS}
        row["id"] = tid
        row["created_at"] = trade.get("created_at") or datetime.now(timezone.utc).isoformat(timespec="seconds")
        row["notes"] = row.get("notes") or ""
        row["tags"] = tags_to_text(trade.get("tags"))
        row["emotion"] = normalize_emotion(trade.get("emotion"))
        with self.lock, self._conn() as conn:
            conn.execute(
                f"INSERT OR REPLACE INTO trades ({','.join(JOURNAL_FIELDS)}) VALUES ({','.join('?' for _ in JOURNAL_FIELDS)})",
                [row[k] for k in JOURNAL_FIELDS],
            )
        return tid

    def list(self, limit: int = 500, run_id: str | None = None,
             symbol: str | None = None, strategy: str | None = None,
             tag: str | None = None, emotion: str | None = None) -> list[dict]:
        q = "SELECT * FROM trades"
        clauses, args = [], []
        if run_id:
            clauses.append("run_id = ?"); args.append(run_id)
        if symbol:
            clauses.append("symbol = ?"); args.append(symbol)
        if strategy:
            clauses.append("strategy = ?"); args.append(strategy)
        if emotion:
            clauses.append("emotion = ?"); args.append(normalize_emotion(emotion))
        if tag:
            # Tag filter: match the whole tag, not a substring, so "news"
            # does not also return "news-gap". Tags are stored comma-separated
            # with no spaces, so a LIKE on ",tag," plus the two ends is exact.
            t = normalize_tags(tag)
            if t:
                t = t[0]
                clauses.append("(',' || COALESCE(tags,'') || ',') LIKE ?")
                args.append(f"%,{t},%")
        if clauses:
            q += " WHERE " + " AND ".join(clauses)
        q += " ORDER BY exit_time DESC, created_at DESC LIMIT ?"
        args.append(int(limit))
        with self.lock, self._conn() as conn:
            rows = conn.execute(q, args).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["tag_list"] = text_to_tags(d.get("tags"))
            out.append(d)
        return out

    def update_note(self, trade_id: str, note: str) -> bool:
        note = str(note)[:2000]
        with self.lock, self._conn() as conn:
            cur = conn.execute("UPDATE trades SET notes=? WHERE id=?", (note, trade_id))
            return cur.rowcount > 0

    def update_annotation(self, trade_id: str, notes: str | None = None,
                          tags=None, emotion: str | None = None) -> bool:
        """Update the notes / tags / emotional state of one trade.

        Only the fields that are actually supplied are written, so a tag-only
        edit never wipes the trader's notes and an emotion-only edit never
        wipes the tags.
        """
        sets, args = [], []
        if notes is not None:
            sets.append("notes = ?"); args.append(str(notes)[:2000])
        if tags is not None:
            sets.append("tags = ?"); args.append(tags_to_text(tags))
        if emotion is not None:
            sets.append("emotion = ?"); args.append(normalize_emotion(emotion))
        if not sets:
            return False
        args.append(trade_id)
        with self.lock, self._conn() as conn:
            cur = conn.execute(f"UPDATE trades SET {', '.join(sets)} WHERE id = ?", args)
            return cur.rowcount > 0

    def bulk_tag(self, tag: str, trade_ids: list[str] | None = None,
                 run_id: str | None = None, symbol: str | None = None,
                 strategy: str | None = None, mode: str = "add") -> int:
        """Add / remove / replace a tag on many trades at once.

        Tagging is per-trade and per-row by nature — a trader normally reviews
        each trade — but a bulk action is genuinely useful for the common case
        of "everything in this run was a mistake".
        """
        tag = (normalize_tags(tag) or [""])[0]
        if not tag:
            return 0
        rows = self.list(limit=100000, run_id=run_id, symbol=symbol, strategy=strategy)
        if trade_ids:
            wanted = set(str(t) for t in trade_ids)
            rows = [r for r in rows if r["id"] in wanted]
        changed = 0
        for r in rows:
            current = text_to_tags(r.get("tags"))
            if mode == "remove":
                new = [t for t in current if t != tag]
            elif mode == "replace":
                new = [tag]
            else:
                new = list(current)
                if tag not in new:
                    new.append(tag)
            new = normalize_tags(new)
            if new == current:
                continue
            if self.update_annotation(r["id"], tags=new):
                changed += 1
        return changed

    def summaries(self, period: str = "daily") -> list[dict]:
        if period not in ("daily", "weekly", "monthly"):
            raise ValueError("period must be daily, weekly or monthly")
        rows = self.list(limit=100000)
        if not rows:
            return []
        df = pd.DataFrame(rows)
        df["exit_dt"] = pd.to_datetime(df["exit_time"], utc=True, errors="coerce").dt.tz_convert("Asia/Kolkata")
        df = df.dropna(subset=["exit_dt"])
        if period == "daily":
            df["bucket"] = df["exit_dt"].dt.strftime("%Y-%m-%d")
        elif period == "weekly":
            iso = df["exit_dt"].dt.isocalendar()
            df["bucket"] = iso["year"].astype(str) + "-W" + iso["week"].astype(str).str.zfill(2)
        else:
            df["bucket"] = df["exit_dt"].dt.strftime("%Y-%m")
        out = []
        for bucket, g in df.groupby("bucket", sort=True):
            pnl = g["pnl"].astype(float)
            wins = int((pnl > 0).sum())
            losses = int((pnl < 0).sum())
            n = len(g)
            out.append({
                "bucket": bucket, "period": period, "trades": n,
                "wins": wins, "losses": losses,
                "win_rate_pct": wins / n * 100 if n else 0.0,
                "net_pnl": float(pnl.sum()), "avg_pnl": float(pnl.mean()),
                "gross_profit": float(pnl[pnl > 0].sum()),
                "gross_loss": float(pnl[pnl < 0].sum()),
                "total_costs": float(g["costs"].astype(float).sum()),
            })
        return sorted(out, key=lambda x: x["bucket"], reverse=True)

    # ------------------------------------------------------------------
    # Breakdowns
    # ------------------------------------------------------------------
    @staticmethod
    def _breakdown_rows(rows: list[dict], key_fn) -> list[dict]:
        """Group trades by a key and compute the same stats for every group."""
        groups: dict[str, list[dict]] = {}
        for r in rows:
            k = key_fn(r)
            if not k:
                continue
            groups.setdefault(k, []).append(r)
        out = []
        for key, g in groups.items():
            pnls = [float(t.get("pnl") or 0.0) for t in g]
            wins = [p for p in pnls if p > 0]
            losses = [p for p in pnls if p < 0]
            n = len(pnls)
            gross_profit = sum(wins)
            gross_loss = abs(sum(losses))
            out.append({
                "key": key,
                "trades": n,
                "wins": len(wins),
                "losses": len(losses),
                "breakeven": n - len(wins) - len(losses),
                "win_rate_pct": len(wins) / n * 100.0 if n else 0.0,
                "net_pnl": float(sum(pnls)),
                "avg_pnl": float(sum(pnls) / n) if n else 0.0,
                "gross_profit": float(gross_profit),
                "gross_loss": float(gross_loss),
                "profit_factor": (gross_profit / gross_loss) if gross_loss > 0 else None,
                "avg_win": float(gross_profit / len(wins)) if wins else None,
                "avg_loss": float(gross_loss / len(losses)) if losses else None,
                "expectancy_per_trade": float(sum(pnls) / n) if n else 0.0,
                "total_costs": float(sum(float(t.get("costs") or 0.0) for t in g)),
            })
        out.sort(key=lambda x: (-x["trades"], -x["net_pnl"]))
        return out

    def breakdown(self, dimension: str = "strategy", limit: int = 100000) -> list[dict]:
        """Strategy-wise / emotion-wise / tag-wise breakdown of the journal.

        A single trade can carry several tags, so the tag breakdown counts a
        trade once per tag it carries. That means the tag rows do NOT sum to
        the journal total — the UI says so explicitly.
        """
        dimension = (dimension or "strategy").lower()
        if dimension not in ("strategy", "emotion", "tag", "symbol"):
            raise ValueError("dimension must be strategy, emotion, tag or symbol")
        rows = self.list(limit=limit)
        if not rows:
            return []
        if dimension == "strategy":
            return self._breakdown_rows(rows, lambda r: (r.get("strategy") or "unknown").lower())
        if dimension == "emotion":
            return self._breakdown_rows(rows, lambda r: (r.get("emotion") or "").lower() or "not recorded")
        if dimension == "symbol":
            return self._breakdown_rows(rows, lambda r: (r.get("symbol") or "").upper())
        if dimension == "tag":
            out = []
            per_tag: dict[str, list[dict]] = {}
            for r in rows:
                for t in text_to_tags(r.get("tags")):
                    per_tag.setdefault(t, []).append(r)
            for tag, g in per_tag.items():
                pnls = [float(t.get("pnl") or 0.0) for t in g]
                wins = [p for p in pnls if p > 0]
                losses = [p for p in pnls if p < 0]
                gross_profit = sum(wins)
                gross_loss = abs(sum(losses))
                n = len(pnls)
                out.append({
                    "key": tag, "trades": n, "wins": len(wins), "losses": len(losses),
                    "breakeven": n - len(wins) - len(losses),
                    "win_rate_pct": len(wins) / n * 100.0 if n else 0.0,
                    "net_pnl": float(sum(pnls)),
                    "avg_pnl": float(sum(pnls) / n) if n else 0.0,
                    "gross_profit": float(gross_profit), "gross_loss": float(gross_loss),
                    "profit_factor": (gross_profit / gross_loss) if gross_loss > 0 else None,
                    "avg_win": float(gross_profit / len(wins)) if wins else None,
                    "avg_loss": float(gross_loss / len(losses)) if losses else None,
                    "expectancy_per_trade": float(sum(pnls) / n) if n else 0.0,
                    "total_costs": float(sum(float(t.get("costs") or 0.0) for t in g)),
                })
            out.sort(key=lambda x: (-x["trades"], -x["net_pnl"]))
            return out
        raise ValueError("dimension must be strategy, emotion, tag or symbol")

    def overview(self, limit: int = 100000) -> dict:
        """Whole-journal totals, plus the strategy/emotion/tag breakdowns."""
        rows = self.list(limit=limit)
        pnls = [float(r.get("pnl") or 0.0) for r in rows]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p < 0]
        gross_profit = sum(wins)
        gross_loss = abs(sum(losses))
        n = len(pnls)
        return {
            "trades": n,
            "wins": len(wins),
            "losses": len(losses),
            "breakeven": n - len(wins) - len(losses),
            "win_rate_pct": len(wins) / n * 100.0 if n else 0.0,
            "net_pnl": float(sum(pnls)),
            "avg_pnl": float(sum(pnls) / n) if n else 0.0,
            "gross_profit": float(gross_profit),
            "gross_loss": float(gross_loss),
            "profit_factor": (gross_profit / gross_loss) if gross_loss > 0 else None,
            "expectancy_per_trade": float(sum(pnls) / n) if n else 0.0,
            "total_costs": float(sum(float(r.get("costs") or 0.0) for r in rows)),
            "tagged_trades": sum(1 for r in rows if text_to_tags(r.get("tags"))),
            "emotion_recorded": sum(1 for r in rows if (r.get("emotion") or "").strip()),
            "by_strategy": self.breakdown("strategy", limit=limit),
            "by_emotion": self.breakdown("emotion", limit=limit),
            "by_tag": self.breakdown("tag", limit=limit),
            "by_symbol": self.breakdown("symbol", limit=limit),
            "suggested_tags": list(SUGGESTED_TAGS),
            "emotion_states": list(EMOTION_STATES),
        }

    def to_csv(self, limit: int = 100000) -> str:
        rows = self.list(limit=limit)
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=JOURNAL_FIELDS)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in JOURNAL_FIELDS})
        return buf.getvalue()

    def breakdown_csv(self, dimension: str = "strategy", limit: int = 100000) -> str:
        """CSV of one breakdown dimension, ready for export."""
        rows = self.breakdown(dimension, limit=limit)
        cols = ["key", "trades", "wins", "losses", "breakeven", "win_rate_pct",
                "net_pnl", "avg_pnl", "gross_profit", "gross_loss", "profit_factor",
                "avg_win", "avg_loss", "expectancy_per_trade", "total_costs"]
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in cols})
        return buf.getvalue()

    def count(self) -> int:
        with self.lock, self._conn() as conn:
            return int(conn.execute("SELECT COUNT(*) FROM trades").fetchone()[0])

    # ------------------------------------------------------------------
    # Risk / engine events (NOT trades)
    # ------------------------------------------------------------------
    def add_event(self, event: dict) -> str:
        """Record a risk or engine event — a kill switch, a limit breach."""
        eid = event.get("id") or f"e_{uuid.uuid4().hex[:16]}"
        row = {k: event.get(k) for k in JOURNAL_EVENT_FIELDS}
        row["id"] = eid
        row["created_at"] = event.get("created_at") or datetime.now(timezone.utc).isoformat(timespec="seconds")
        row["event_type"] = str(event.get("event_type") or "event")
        row["reason"] = str(event.get("reason") or "")[:2000]
        row["detail"] = str(event.get("detail") or "")[:4000]
        row["open_position"] = str(event.get("open_position") or "")[:2000]
        with self.lock, self._conn() as conn:
            conn.execute(
                f"INSERT OR REPLACE INTO events ({','.join(JOURNAL_EVENT_FIELDS)}) "
                f"VALUES ({','.join('?' for _ in JOURNAL_EVENT_FIELDS)})",
                [row[k] for k in JOURNAL_EVENT_FIELDS],
            )
        return eid

    def events(self, limit: int = 200, event_type: str | None = None,
               run_id: str | None = None) -> list[dict]:
        q = "SELECT * FROM events"
        clauses, args = [], []
        if event_type:
            clauses.append("event_type = ?"); args.append(event_type)
        if run_id:
            clauses.append("run_id = ?"); args.append(run_id)
        if clauses:
            q += " WHERE " + " AND ".join(clauses)
        q += " ORDER BY created_at DESC, id DESC LIMIT ?"
        args.append(int(limit))
        with self.lock, self._conn() as conn:
            rows = conn.execute(q, args).fetchall()
        return [dict(r) for r in rows]

    def events_csv(self, limit: int = 100000) -> str:
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=JOURNAL_EVENT_FIELDS, extrasaction="ignore")
        w.writeheader()
        for r in self.events(limit=limit):
            w.writerow({k: r.get(k) for k in JOURNAL_EVENT_FIELDS})
        return buf.getvalue()

    def event_count(self) -> int:
        with self.lock, self._conn() as conn:
            return int(conn.execute("SELECT COUNT(*) FROM events").fetchone()[0])
