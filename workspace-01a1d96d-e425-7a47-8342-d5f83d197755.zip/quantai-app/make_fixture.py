"""Generate a clearly-labelled SYNTHETIC fixture to smoke-test the pipeline.

This is NOT market data. It is stamped TEST_FIXTURE so it can never be
mistaken for real NSE history.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def make_fixture(bars: int, timeframe: str, seed: int = 7) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    step = {"1m": "1min", "5m": "5min", "15m": "15min", "1D": "1D"}[timeframe]
    if timeframe == "1D":
        idx = pd.bdate_range("2015-01-01", periods=bars, freq="B", tz="Asia/Kolkata")
    else:
        per_day = {"1m": 375, "5m": 75, "15m": 25}[timeframe]
        days = int(np.ceil(bars / per_day))
        idx = []
        for d in pd.bdate_range("2024-01-01", periods=days, freq="B", tz="Asia/Kolkata"):
            start = d.normalize() + pd.Timedelta(hours=9, minutes=15)
            idx.extend(pd.date_range(start, periods=per_day, freq=step))
        idx = pd.DatetimeIndex(idx[:bars])

    price = 1000.0
    rows = []
    for i, t in enumerate(idx):
        drift = 0.0002 * np.sin(i / 40.0)
        shock = rng.normal(0, 0.008)
        o = price
        c = max(o * (1 + drift + shock), 1.0)
        h = max(o, c) * (1 + abs(rng.normal(0, 0.003)))
        l = min(o, c) * (1 - abs(rng.normal(0, 0.003)))
        v = int(rng.integers(50_000, 500_000))
        rows.append((t.strftime("%Y-%m-%d %H:%M:%S"), round(o, 2), round(h, 2), round(l, 2), round(c, 2), v))
        price = c
    return pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bars", type=int, default=2000)
    ap.add_argument("--timeframe", default="1D", choices=["1m", "5m", "15m", "1D"])
    ap.add_argument("--out", default="data/TEST_FIXTURE_1D.csv")
    args = ap.parse_args()
    p = Path(args.out)
    p.parent.mkdir(parents=True, exist_ok=True)
    df = make_fixture(args.bars, args.timeframe)
    header = ("# SYNTHETIC TEST_FIXTURE - NOT REAL MARKET DATA - DO NOT USE FOR TRADING DECISIONS\n")
    p.write_text(header + df.to_csv(index=False), encoding="utf-8")
    print(f"Wrote {len(df)} synthetic bars to {p}")
    print("This file is NOT market data. Run it with --source-type TEST_FIXTURE.")


if __name__ == "__main__":
    main()
