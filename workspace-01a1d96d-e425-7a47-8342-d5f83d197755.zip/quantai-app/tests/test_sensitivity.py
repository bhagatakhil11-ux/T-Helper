"""Parameter sensitivity: grid coverage, neighbour logic, independent re-check
of one grid point against a direct backtest, and overfit-flag behaviour."""
import numpy as np
import pandas as pd
import pytest

from quantai.backtest import run_backtest
from quantai.config import CostModel, RiskConfig
from quantai.features import build_features
from quantai.sensitivity import _neighbours, run_sensitivity


def _df(seed=11, n=500):
    rng = np.random.default_rng(seed)
    ts = pd.date_range("2021-01-04", periods=n, freq="B", tz="Asia/Kolkata") + pd.Timedelta(hours=15)
    close = 100 * np.exp(np.cumsum(rng.normal(0.0002, 0.013, n)))
    open_ = np.concatenate([[100.0], close[:-1]])
    return pd.DataFrame({"timestamp": ts, "open": open_,
                         "high": np.maximum(open_, close) * 1.005,
                         "low": np.minimum(open_, close) * 0.995,
                         "close": close, "volume": rng.integers(1e5, 1e6, n)})


def test_neighbours_hand_checked():
    axes = [[1.0, 2.0, 3.0], [10.0, 20.0]]
    assert set(_neighbours((2.0, 10.0), axes)) == {(1.0, 10.0), (3.0, 10.0), (2.0, 20.0)}
    assert set(_neighbours((1.0, 10.0), axes)) == {(2.0, 10.0), (1.0, 20.0)}  # corner


def test_grid_covers_all_combinations():
    df = _df()
    feats = build_features(df)
    res = run_sensitivity(df, feats, 350, CostModel(), RiskConfig(), "1D",
                          mode="rules_only", thresholds=[0.3, 0.5],
                          stop_mults=[1.5, 2.0], target_mults=[3.0])
    assert res["grid_size"] == 4
    seen = {(r["threshold"], r["stop_atr_mult"], r["target_atr_mult"]) for r in res["results"]}
    assert seen == {(0.3, 1.5, 3.0), (0.3, 2.0, 3.0), (0.5, 1.5, 3.0), (0.5, 2.0, 3.0)}


def test_grid_point_matches_direct_backtest():
    """Independent verification: one grid row must equal a direct run_backtest."""
    df = _df()
    feats = build_features(df)
    risk = RiskConfig()
    cost = CostModel()
    res = run_sensitivity(df, feats, 350, cost, risk, "1D", mode="rules_only",
                          thresholds=[0.4], stop_mults=[1.8], target_mults=[3.6])
    row = res["results"][0]
    from dataclasses import replace
    direct = run_backtest(df, feats, 350, cost, replace(risk, stop_atr_mult=1.8, target_atr_mult=3.6),
                          "1D", mode="rules_only", entry_threshold=0.4)
    assert row["net_return_pct"] == direct.net_return_pct
    assert row["total_trades"] == direct.total_trades
    assert row["max_drawdown_pct"] == direct.max_drawdown_pct


def test_grid_limit_enforced():
    df = _df()
    feats = build_features(df)
    with pytest.raises(ValueError, match="combinations"):
        run_sensitivity(df, feats, 350, CostModel(), RiskConfig(), "1D",
                        thresholds=[0.1 * i for i in range(1, 8)],
                        stop_mults=[0.5 * i for i in range(1, 8)],
                        target_mults=[0.5 * i for i in range(1, 8)],
                        max_combinations=100)


def test_deterministic_and_summary_consistent():
    df = _df()
    feats = build_features(df)
    a = run_sensitivity(df, feats, 350, CostModel(), RiskConfig(), "1D", mode="rules_only",
                        thresholds=[0.3, 0.5], stop_mults=[1.8], target_mults=[3.6])
    b = run_sensitivity(df, feats, 350, CostModel(), RiskConfig(), "1D", mode="rules_only",
                        thresholds=[0.3, 0.5], stop_mults=[1.8], target_mults=[3.6])
    assert a["results"] == b["results"]
    s = a["summary"]
    returns = [r["net_return_pct"] for r in a["results"]]
    assert s["profitable_combinations"] == sum(r > 0 for r in returns)
    assert abs(s["median_return_pct"] - float(np.median(returns))) < 1e-12
    assert s["best"]["net_return_pct"] == max(returns)
    assert a["stability"] in ("STABLE", "MIXED", "FRAGILE")


def test_random_walk_is_not_called_stable():
    """A cost-losing random walk must NOT be labelled STABLE (no fake robustness)."""
    df = _df(seed=99)
    feats = build_features(df)
    res = run_sensitivity(df, feats, 350, CostModel(), RiskConfig(), "1D", mode="rules_only",
                          thresholds=[0.3, 0.42, 0.55], stop_mults=[1.2, 1.8], target_mults=[2.4, 3.6])
    if res["summary"]["fraction_profitable"] < 0.7:
        assert res["stability"] != "STABLE"
    assert isinstance(res["flags"], list)
