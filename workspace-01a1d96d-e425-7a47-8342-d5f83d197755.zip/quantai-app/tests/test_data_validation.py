"""Data validation: abnormal volume, preview, timezone handling, provenance."""
import numpy as np
import pandas as pd
import pytest

from quantai.config import DataOrigin, VerificationStatus
from quantai.data import load_csv, preview_csv
from make_fixture import make_fixture


def test_abnormal_volume_flagged_not_rejected(tmp_path):
    df = make_fixture(120, "1D", seed=1)
    df.loc[60, "volume"] = df["volume"].median() * 50   # huge spike
    df.loc[70, "volume"] = 0                            # zero volume
    p = tmp_path / "vol.csv"; p.write_text(df.to_csv(index=False))
    candles, meta = load_csv(p, "X", "1D")
    assert meta.abnormal_volume_bars >= 1
    assert meta.zero_volume_bars == 1
    assert len(candles) == 120                          # warnings, not rejections
    assert any("zero-volume" in w for w in meta.warnings)


def test_preview_does_not_import_and_reports_quality(tmp_path):
    p = tmp_path / "p.csv"; p.write_text(make_fixture(100, "1D").to_csv(index=False))
    rep = preview_csv(p, "X", "1D")
    assert rep["meta"]["candle_count"] == 100
    assert len(rep["head"]) == 8 and len(rep["tail"]) == 8
    assert len(rep["sha256"]) == 64


def test_naive_timestamps_are_ist_not_utc(tmp_path):
    rows = [("2024-01-01 09:15:00", 100, 101, 99, 100.5, 1000),
            ("2024-01-01 09:20:00", 100, 101, 99, 100.5, 1000)]
    p = tmp_path / "naive.csv"
    p.write_text(pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"]).to_csv(index=False))
    df, _ = load_csv(p, "X", "5m")
    assert str(df["timestamp"].iloc[0].tz) == "Asia/Kolkata"
    assert df["timestamp"].iloc[0].hour == 9


def test_explicit_utc_offset_converted_to_ist(tmp_path):
    rows = [("2024-01-01T03:45:00Z", 100, 101, 99, 100.5, 1000),   # 09:15 IST
            ("2024-01-01T03:50:00Z", 100, 101, 99, 100.5, 1000)]
    p = tmp_path / "utc.csv"
    p.write_text(pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"]).to_csv(index=False))
    df, meta = load_csv(p, "X", "5m")
    assert meta.rows_rejected == 0
    assert df["timestamp"].iloc[0].hour == 9 and df["timestamp"].iloc[0].minute == 15


def test_epoch_millis_supported(tmp_path):
    base = pd.Timestamp("2024-01-01 09:15:00", tz="Asia/Kolkata")
    rows = [(int(base.timestamp() * 1000), 100, 101, 99, 100.5, 1000),
            (int((base + pd.Timedelta(minutes=5)).timestamp() * 1000), 100, 101, 99, 100.5, 1000)]
    p = tmp_path / "epoch.csv"
    p.write_text(pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"]).to_csv(index=False))
    df, meta = load_csv(p, "X", "5m")
    assert meta.rows_rejected == 0 and len(df) == 2


def test_broker_vendor_origin_cannot_be_set_via_upload_api(tmp_path):
    """The HTTP layer must refuse to label uploaded bytes as verified exchange data."""
    from app import create_app
    from engine import AppState
    state = AppState(store_root=tmp_path / "store")
    app = create_app(state)
    client = app.test_client()
    p = tmp_path / "x.csv"; p.write_text(make_fixture(100, "1D").to_csv(index=False))
    with open(p, "rb") as f:
        r = client.post("/api/import", data={"file": (f, "x.csv"), "symbol": "X", "timeframe": "1D",
                                             "source_type": "BROKER_VENDOR"}, content_type="multipart/form-data")
    assert r.status_code == 400
    assert "verified" in r.get_json()["error"].lower()
