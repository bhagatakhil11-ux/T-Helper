"""Exact Indian transaction-cost calculations (assumption-based, dated model)."""
import pytest

from quantai.config import CostModel, ExecutionConfig


def test_delivery_buy_leg_components():
    c = CostModel(is_intraday=False)
    leg = c.leg_cost(100000.0, is_buy=True)
    assert leg["stt"] == pytest.approx(100.0)            # 0.10%
    assert leg["brokerage"] == pytest.approx(20.0)       # min(20, 30)
    assert leg["exchange"] == pytest.approx(3.25)        # 0.00325%
    assert leg["sebi"] == pytest.approx(0.1)             # Rs10/cr
    assert leg["stamp"] == pytest.approx(15.0)           # 0.015% buy
    assert leg["gst"] == pytest.approx((20 + 3.25 + 0.1) * 0.18)
    assert leg["total"] == pytest.approx(sum(leg[k] for k in ("stt", "brokerage", "exchange", "sebi", "stamp", "gst")))


def test_delivery_sell_leg_no_stamp():
    c = CostModel(is_intraday=False)
    leg = c.leg_cost(100000.0, is_buy=False)
    assert leg["stt"] == pytest.approx(100.0)
    assert leg["stamp"] == 0.0


def test_intraday_stt_sell_only():
    c = CostModel(is_intraday=True)
    buy = c.leg_cost(100000.0, is_buy=True)
    sell = c.leg_cost(100000.0, is_buy=False)
    assert buy["stt"] == 0.0
    assert sell["stt"] == pytest.approx(25.0)            # 0.025%
    assert buy["stamp"] == pytest.approx(3.0)            # 0.003%
    assert sell["stamp"] == 0.0


def test_brokerage_percentage_cap_for_small_turnover():
    c = CostModel()
    leg = c.leg_cost(10000.0, is_buy=True)               # 0.03% = Rs3 < Rs20
    assert leg["brokerage"] == pytest.approx(3.0)


def test_zero_turnover_zero_cost():
    leg = CostModel().leg_cost(0.0, is_buy=True)
    assert leg["total"] == 0.0


def test_execution_config_maps_to_cost_model():
    e = ExecutionConfig(slippage_bps=5.0, brokerage_flat_inr=15.0, brokerage_pct_cap=0.0005)
    c = e.to_cost_model(is_intraday=True)
    assert c.slippage_pct == pytest.approx(0.0005)
    assert c.brokerage_flat_inr == 15.0
    assert c.is_intraday is True
