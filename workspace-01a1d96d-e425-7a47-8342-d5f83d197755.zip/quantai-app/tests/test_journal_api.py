"""API-level tests for the journal annotations and the live replay readout."""
from __future__ import annotations

import pytest

from engine import AppState


@pytest.fixture()
def client(tmp_path):
    from app import create_app
    state = AppState(store_root=tmp_path / "store")
    app = create_app(state=state)
    app.config["TESTING"] = True
    with app.test_client() as c:
        c.state = state
        yield c


def _add(state, tid, strategy="ensemble", pnl=100.0, **extra):
    state.journal.add({
        "id": tid, "run_id": "r1", "symbol": "TEST", "timeframe": "1D",
        "strategy": strategy, "direction": "LONG", "qty": 10,
        "entry_time": "2024-01-01T10:00:00+05:30", "entry_price": 100,
        "exit_time": "2024-01-01T15:00:00+05:30", "exit_price": 110,
        "pnl": pnl, "costs": 5, "entry_reason": "signal", "exit_reason": "target",
        **extra,
    })


def test_annotate_endpoint_writes_tags_and_emotion(client):
    _add(client.state, "t1")
    r = client.post("/api/journal/annotate",
                    json={"id": "t1", "tags": ["Breakout", "news"], "emotion": "Calm"})
    assert r.status_code == 200 and r.get_json()["ok"] is True
    row = client.state.journal.list()[0]
    assert row["tag_list"] == ["breakout", "news"]
    assert row["emotion"] == "calm"


def test_annotate_endpoint_requires_an_id_and_a_field(client):
    assert client.post("/api/journal/annotate", json={"tags": ["x"]}).status_code == 400
    assert client.post("/api/journal/annotate", json={"id": "t1"}).status_code == 400


def test_annotate_endpoint_404s_on_an_unknown_trade(client):
    r = client.post("/api/journal/annotate", json={"id": "nope", "tags": ["x"]})
    assert r.status_code == 404


def test_journal_filters_by_tag_and_emotion(client):
    _add(client.state, "t1", tags=["news"])
    _add(client.state, "t2", tags=["mistake"], emotion="revenge")
    assert [t["id"] for t in client.get("/api/journal?tag=news").get_json()["trades"]] == ["t1"]
    assert [t["id"] for t in client.get("/api/journal?emotion=revenge").get_json()["trades"]] == ["t2"]


def test_bulk_tag_endpoint(client):
    _add(client.state, "t1")
    _add(client.state, "t2")
    r = client.post("/api/journal/bulk_tag", json={"tag": "mistake", "run_id": "r1"})
    assert r.get_json()["changed"] == 2
    assert client.post("/api/journal/bulk_tag", json={"tag": ""}).status_code == 400
    assert client.post("/api/journal/bulk_tag",
                       json={"tag": "x", "mode": "nonsense"}).status_code == 400


def test_vocabulary_endpoint_lists_tags_and_emotions(client):
    body = client.get("/api/journal/vocabulary").get_json()
    assert "breakout" in body["suggested_tags"]
    assert set(body["emotion_states"]) == {"calm", "fomo", "revenge", "neutral"}


def test_overview_endpoint_carries_the_strategy_breakdown(client):
    _add(client.state, "t1", strategy="ensemble", pnl=100.0)
    _add(client.state, "t2", strategy="ml_only", pnl=-40.0)
    body = client.get("/api/journal/overview").get_json()["overview"]
    assert body["trades"] == 2
    assert {r["key"] for r in body["by_strategy"]} == {"ensemble", "ml_only"}


def test_breakdown_endpoint_rejects_an_unknown_dimension(client):
    assert client.get("/api/journal/breakdown?dimension=nope").status_code == 400
    assert client.get("/api/journal/breakdown?dimension=strategy").status_code == 200


def test_exports_include_the_new_fields(client):
    _add(client.state, "t1", tags=["breakout"], emotion="calm")
    csv_text = client.get("/api/export/journal").data.decode()
    assert "tags" in csv_text.splitlines()[0]
    assert "emotion" in csv_text.splitlines()[0]

    bd = client.get("/api/export/journal_breakdown?dimension=emotion").data.decode()
    assert "emotion" in bd.lower() or "key" in bd.splitlines()[0]
    assert client.get("/api/export/journal_breakdown?dimension=nope").status_code == 400


def test_replay_snapshot_exposes_the_live_stats(client):
    """The live readout must be present even before any trade has closed."""
    snap = client.get("/api/state").get_json()
    live = snap["replay"]["live"]
    assert live["trades"] == 0
    assert live["win_rate_pct"] is None
    assert live["profit_factor"] is None
    assert "No closed trade" in live["status_reason"]


def test_a_real_replay_populates_the_live_stats_and_the_journal(tmp_path):
    """End to end: the replay closes trades -> live stats move -> the journal
    rows exist -> they can be tagged afterwards."""
    import time

    import numpy as np
    import pandas as pd

    from make_fixture import make_fixture

    state = AppState(store_root=tmp_path / "store")
    # A sawtooth price series so that stops and targets actually get hit.
    n = 400
    closes, opens, highs, lows = [], [], [], []
    price = 100.0
    for i in range(n):
        drift = 0.03 if (i // 4) % 2 == 0 else -0.03
        o = price
        c = price * (1 + drift + 0.003 * np.sin(i))
        opens.append(o)
        closes.append(c)
        highs.append(max(o, c) * 1.004)
        lows.append(min(o, c) * 0.996)
        price = c
    ts = pd.date_range("2021-01-04", periods=n, freq="B", tz="Asia/Kolkata") + pd.Timedelta(hours=15)
    df = pd.DataFrame({"timestamp": ts, "open": opens, "high": highs,
                       "low": lows, "close": closes, "volume": 1_000_000})
    p = tmp_path / "saw.csv"
    df.to_csv(p, index=False)
    state.import_csv(p, "SAW", "1D", "TEST_FIXTURE", "UNKNOWN_UNVERIFIED")

    state.start_replay(speed_ms=5, use_test_window=False, mode="rules_only")
    t0 = time.time()
    while time.time() - t0 < 45 and state.replay["bar"] < state.replay["total_bars"] - 3:
        time.sleep(0.05)
    state.stop_replay()

    live = state.snapshot()["replay"]["live"]
    assert live["trades"] > 0, "the sawtooth series must produce closed trades"
    assert live["wins"] + live["losses"] + live["breakeven"] == live["trades"]
    assert live["win_rate_pct"] is not None
    assert live["max_drawdown_pct"] > 0
    assert live["total_costs"] > 0

    rows = state.journal.list()
    assert len(rows) == live["trades"], "every closed replay trade lands in the journal"
    assert all(r["tags"] == "" and r["emotion"] == "" for r in rows)

    # And now the trader annotates them.
    tid = rows[0]["id"]
    assert state.journal.update_annotation(tid, tags=["breakout"], emotion="calm")
    assert state.journal.list(tag="breakout")[0]["id"] == tid
    ov = state.journal.overview()
    assert ov["tagged_trades"] == 1
    assert ov["emotion_recorded"] == 1
