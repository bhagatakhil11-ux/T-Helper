"""Regime detection: causal labelling (no look-ahead), hand-checked trend/flat
cases, and per-regime trade/return bucketing verified independently."""
import numpy as np
import pandas as pd

from quantai.regime import detect_regimes, regime_distribution, regime_performance


def _trend_df(prices):
    n = len(prices)
    ts = pd.date_range("2022-01-03", periods=n, freq="B", tz="Asia/Kolkata")
    p = np.asarray(prices, dtype=float)
    return pd.DataFrame({"timestamp": ts, "open": p, "high": p * 1.001,
                         "low": p * 0.999, "close": p, "volume": np.full(n, 100000)})


def test_uptrend_labelled_bullish():
    df = _trend_df(100 * np.exp(np.linspace(0, 0.5, 200)))
    r = detect_regimes(df, ema_span=20, slope_lookback=5)
    assert (r.iloc[60:] == "BULLISH").all()


def test_downtrend_labelled_bearish():
    df = _trend_df(100 * np.exp(np.linspace(0, -0.5, 200)))
    r = detect_regimes(df, ema_span=20, slope_lookback=5)
    assert (r.iloc[60:] == "BEARISH").all()


def test_flat_is_sideways():
    df = _trend_df(np.full(200, 100.0))
    r = detect_regimes(df, ema_span=20, slope_lookback=5)
    assert (r == "SIDEWAYS").all()


def test_no_lookahead_prefix_stability():
    """Labels on df[:k] must equal the first k labels on the full df (causal)."""
    rng = np.random.default_rng(3)
    df = _trend_df(100 * np.exp(np.cumsum(rng.normal(0, 0.01, 300))))
    full = detect_regimes(df, ema_span=30, slope_lookback=10)
    for k in (80, 150, 250):
        prefix = detect_regimes(df.iloc[:k].reset_index(drop=True), ema_span=30, slope_lookback=10)
        assert prefix.tolist() == full.iloc[:k].tolist()


def test_distribution_counts_hand_checked():
    s = pd.Series(["BULLISH"] * 5 + ["BEARISH"] * 3 + ["SIDEWAYS"] * 2)
    d = regime_distribution(s)
    assert d["counts"] == {"BEARISH": 3, "SIDEWAYS": 2, "BULLISH": 5}
    assert abs(d["fractions"]["BULLISH"] - 0.5) < 1e-12


def test_per_regime_bucketing_hand_checked():
    # 6 bars; force regimes by construction: bars 0-1 SIDEWAYS (warm-up),
    # then a strong up-leg (BULLISH) and down-leg (BEARISH).
    prices = [100, 100, 101, 104, 108, 113, 118, 112, 105, 98, 92, 86]
    df = _trend_df(prices)
    regimes = pd.Series(["SIDEWAYS", "SIDEWAYS", "BULLISH", "BULLISH", "BULLISH", "BULLISH",
                         "BULLISH", "BEARISH", "BEARISH", "BEARISH", "BEARISH", "BEARISH"])
    trades = [
        {"entry_bar": 3, "pnl": 500.0},    # BULLISH win
        {"entry_bar": 5, "pnl": -200.0},   # BULLISH loss
        {"entry_bar": 8, "pnl": -300.0},   # BEARISH loss
        {"entry_bar": 99, "pnl": 999.0},   # out of range -> ignored
    ]
    # equity aligned: start_bar=2, eq[k] <-> bar 1+k. 11 points for bars 1..11.
    eq = [1000, 1000, 1100, 1100, 1100, 1100, 990, 990, 990, 990, 990]
    out = regime_performance(df, regimes, trades, eq, start_bar=2, initial_capital=1000)
    bull = out["per_regime"]["BULLISH"]
    bear = out["per_regime"]["BEARISH"]
    side = out["per_regime"]["SIDEWAYS"]
    assert bull["trades"] == 2 and bull["wins"] == 1 and bull["losses"] == 1
    assert bull["net_pnl"] == 300.0
    assert abs(bull["win_rate_pct"] - 50.0) < 1e-9
    assert bear["trades"] == 1 and bear["net_pnl"] == -300.0
    assert side["trades"] == 0
    assert "BEARISH" in out["losing_regimes"]
    assert "BULLISH" in out["profitable_regimes"]
    assert any("fewer than 2" not in f for f in out["flags"]) or out["flags"]
    # MTM bucketing: bar 3 return +10% lands in BULLISH; bar 7 return -10% in BEARISH.
    assert bull["bars"] >= 1 and bear["bars"] >= 1
    assert bull["annualised_bar_sharpe"] is None or np.isfinite(bull["annualised_bar_sharpe"])


def test_untested_regime_flagged():
    df = _trend_df(np.full(50, 100.0))
    regimes = pd.Series(["SIDEWAYS"] * 50)
    out = regime_performance(df, regimes, [], [1000] * 49, start_bar=2, initial_capital=1000)
    assert out["tested_regimes"] == []
    assert any("fewer than 2 regimes" in f for f in out["flags"])
    assert any("unknown" in f for f in out["flags"])
