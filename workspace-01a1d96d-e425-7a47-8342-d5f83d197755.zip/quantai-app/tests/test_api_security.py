"""HTTP API security, exports, preview/confirm flow, benchmark honesty."""
import io
import json

import pytest

from app import create_app
from engine import AppState
from make_fixture import make_fixture
from quantai.benchmark import nifty_benchmark
import pandas as pd


@pytest.fixture()
def client(tmp_path):
    state = AppState(store_root=tmp_path / "store")
    app = create_app(state)
    app.config["TESTING"] = True
    return app.test_client(), state, tmp_path


def _upload(client, tmp_path, name="x.csv", source="IMPORTED_CSV", symbol="X"):
    p = tmp_path / name
    p.write_text(make_fixture(150, "1D", seed=2).to_csv(index=False))
    with open(p, "rb") as f:
        return client.post("/api/import", data={"file": (f, name), "symbol": symbol,
                                                "timeframe": "1D", "source_type": source},
                           content_type="multipart/form-data")


def test_rejects_non_csv_extension(client):
    c, s, tmp = client
    with io.BytesIO(b"timestamp,open,high,low,close,volume\n") as f:
        r = c.post("/api/import", data={"file": (f, "evil.exe"), "symbol": "X", "timeframe": "1D"},
                   content_type="multipart/form-data")
    assert r.status_code == 400


def test_rejects_path_traversal_filename(client):
    c, s, tmp = client
    with io.BytesIO(b"timestamp,open,high,low,close,volume\n") as f:
        r = c.post("/api/import", data={"file": (f, "../../etc/passwd.csv"), "symbol": "X", "timeframe": "1D"},
                   content_type="multipart/form-data")
    # Filename is sanitised to a generated name; the CSV itself is invalid (no rows) -> 400,
    # but crucially nothing is written outside uploads/.
    assert r.status_code == 400
    assert not (tmp / "etc").exists()


def test_rejects_bad_symbol_and_timeframe(client):
    c, s, tmp = client
    p = tmp / "x.csv"; p.write_text(make_fixture(100, "1D").to_csv(index=False))
    with open(p, "rb") as f:
        r = c.post("/api/import", data={"file": (f, "x.csv"), "symbol": "../evil", "timeframe": "1D"},
                   content_type="multipart/form-data")
    assert r.status_code == 400
    with open(p, "rb") as f:
        r = c.post("/api/import", data={"file": (f, "x.csv"), "symbol": "X", "timeframe": "2D"},
                   content_type="multipart/form-data")
    assert r.status_code == 400


def test_preview_then_confirm_flow(client):
    c, s, tmp = client
    p = tmp / "p.csv"; p.write_text(make_fixture(120, "1D", seed=8).to_csv(index=False))
    with open(p, "rb") as f:
        r = c.post("/api/preview", data={"file": (f, "p.csv"), "symbol": "PRE", "timeframe": "1D"},
                   content_type="multipart/form-data")
    assert r.status_code == 200
    token = r.get_json()["preview_token"]
    assert len(r.get_json()["head"]) == 8
    assert s.active() is None                     # preview must NOT import
    r2 = c.post("/api/preview/confirm", json={"preview_token": token})
    assert r2.status_code == 200
    assert s.active()["meta"].symbol == "PRE"
    r3 = c.post("/api/preview/confirm", json={"preview_token": token})
    assert r3.status_code == 400                  # token single-use


def test_exports_after_research(client):
    c, s, tmp = client
    r = _upload(c, tmp, source="TEST_FIXTURE", symbol="EXP")
    assert r.status_code == 200
    s.run_research(horizon=5)
    for path in ("/api/export/research", "/api/export/backtests", "/api/export/performance",
                 "/api/export/trades?mode=ensemble", "/api/export/journal"):
        r = c.get(path)
        assert r.status_code == 200, path
        assert len(r.data) > 0
    r = c.get("/api/dataset/quality?key=EXP|1D")
    assert r.status_code == 200 and r.get_json()["quality"]["symbol"] == "EXP"
    r = c.get("/api/dataset/export?key=EXP|1D")
    assert r.status_code == 200 and b"timestamp" in r.data


def test_risk_and_execution_clamped_by_backend(client):
    c, s, tmp = client
    r = c.post("/api/risk", json={"risk_per_trade_pct": 99, "max_total_drawdown_pct": 999,
                                  "max_open_positions": 100})
    risk = r.get_json()["risk"]
    assert risk["risk_per_trade_pct"] == 2.0
    assert risk["max_total_drawdown_pct"] == 50.0
    assert risk["max_open_positions"] == 5
    r = c.post("/api/execution", json={"slippage_bps": 9999})
    assert r.get_json()["execution"]["slippage_bps"] == 50.0


def test_benchmark_missing_is_honest_not_fabricated():
    df = make_fixture(100, "1D")
    df["timestamp"] = pd.to_datetime(df["timestamp"]).dt.tz_localize("Asia/Kolkata")
    b = nifty_benchmark(None, df, 50, 500000, "1D")
    assert b["status"] == "missing"
    assert b["net_return_pct"] is None
    assert "No NIFTY 50 dataset" in b["message"]


def test_benchmark_computed_from_real_overlap():
    strat = make_fixture(100, "1D", seed=1)
    strat["timestamp"] = pd.to_datetime(strat["timestamp"]).dt.tz_localize("Asia/Kolkata")
    nifty = make_fixture(100, "1D", seed=2)
    nifty["timestamp"] = pd.to_datetime(nifty["timestamp"]).dt.tz_localize("Asia/Kolkata")
    b = nifty_benchmark(nifty, strat, 50, 500000, "1D")
    assert b["status"] == "ok"
    assert b["overlap_bars"] == 50
    expected = (float(nifty["close"].iloc[-1]) / float(nifty["close"].iloc[50]) - 1) * 100
    assert b["net_return_pct"] == pytest.approx(expected, abs=1e-6)


def test_health_reports_live_disabled(client):
    c, s, tmp = client
    r = c.get("/api/health")
    assert r.status_code == 200
    assert r.get_json()["live_trading_enabled"] is False
