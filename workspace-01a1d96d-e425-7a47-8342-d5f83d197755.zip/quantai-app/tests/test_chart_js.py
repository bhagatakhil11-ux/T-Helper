"""Runs the headless chart-JS harness (tests/chart_js_harness.js) against the
live Flask test client.

The harness executes the REAL inline JavaScript from static/index.html under a
minimal DOM shim with a recording canvas context, so the drawing / zoom / pan /
crosshair code paths are actually executed rather than merely syntax-checked.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app import create_app
from engine import AppState

HARNESS = ROOT / "tests" / "chart_js_harness.js"


def _csv_bytes(seed, n=600, intraday=False):
    rng = np.random.default_rng(seed)
    if intraday:
        ts = pd.date_range("2024-01-01 09:15", periods=n, freq="15min", tz="Asia/Kolkata")
    else:
        ts = pd.date_range("2021-01-04", periods=n, freq="B", tz="Asia/Kolkata") + pd.Timedelta(hours=15)
    close = 100 * np.exp(np.cumsum(rng.normal(0.0003, 0.012, n)))
    open_ = np.concatenate([[100.0], close[:-1]])
    df = pd.DataFrame({"timestamp": ts, "open": open_,
                       "high": np.maximum(open_, close) * 1.004,
                       "low": np.minimum(open_, close) * 0.996,
                       "close": close, "volume": rng.integers(1e5, 1e6, n)})
    return df.to_csv(index=False).encode()


@pytest.mark.skipif(shutil.which("node") is None, reason="node is required for the chart JS harness")
def test_chart_javascript_runs_and_draws(tmp_path):
    st = AppState(store_root=tmp_path / "store")
    app = create_app(state=st)
    app.config["TESTING"] = True
    p = tmp_path / "JS.csv"
    p.write_bytes(_csv_bytes(21))
    st.import_csv(p, "DEMOFIX", "1D", "IMPORTED_CSV", "UNKNOWN_UNVERIFIED")
    key = st.key("DEMOFIX", "1D")
    # A SECOND timeframe for the same symbol so timeframe switching is real.
    p2 = tmp_path / "JS15.csv"
    p2.write_bytes(_csv_bytes(22, n=300, intraday=True))
    st.import_csv(p2, "DEMOFIX", "15m", "IMPORTED_CSV", "UNKNOWN_UNVERIFIED")
    key15 = st.key("DEMOFIX", "15m")

    with app.test_client() as c:
        assert c.get("/api/health").status_code == 200
        payload = c.get(f"/api/chart/data?key={key}").get_json()
        syms = c.get("/api/chart/symbols").get_json()
        assert len(payload["candles"]) == 600
        assert {s["key"] for s in syms["symbols"]} == {key, key15}
        # the bare request now returns the LAST VIEWED dataset
        assert c.get("/api/chart/data").get_json()["meta"]["timeframe"] == "1D"

        # Serve the harness through a tiny local HTTP shim that PROXIES the
        # real Flask endpoints, so the harness exercises the live API
        # (including as-of truncation and the timeframe routes).
        import http.server
        import threading

        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                with app.test_client() as tc:
                    r = tc.get(self.path)
                    body = r.get_data()
                    code = r.status_code
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        httpd = http.server.HTTPServer(("127.0.0.1", 0), Handler)
        port = httpd.server_address[1]
        t = threading.Thread(target=httpd.serve_forever, daemon=True)
        t.start()
        try:
            env = dict(os.environ, QAI_API=f"http://127.0.0.1:{port}")
            res = subprocess.run(["node", str(HARNESS)], capture_output=True, text=True,
                                 timeout=180, env=env, cwd=str(ROOT))
        finally:
            httpd.shutdown()

    out = res.stdout + res.stderr
    assert res.returncode == 0, f"chart JS harness failed:\n{out}"
    assert "ALL CHART JS CHECKS PASSED" in out, out
    assert "FAIL" not in out, out
    assert key15
