"""ML reproducibility, model versioning, overfit diagnostics, leakage guards."""
import numpy as np
import pytest

from make_fixture import make_fixture
from quantai.config import CostModel, DataOrigin, RiskConfig
from quantai.data import load_csv
from quantai.features import FEATURE_NAMES, build_dataset, build_features, purged_split
from quantai.model import evaluate, fit_forest, momentum_baseline, overfit_diagnostics


@pytest.fixture()
def dataset(tmp_path):
    p = tmp_path / "ml.csv"
    p.write_text(make_fixture(500, "1D", seed=4).to_csv(index=False))
    df, meta = load_csv(p, "ML", "1D", source_type=DataOrigin.TEST_FIXTURE)
    X, y, candles, feats = build_dataset(df, 5, 0.003, 0.002, 35)
    return df, X, y, candles, feats


def test_same_seed_same_model_predictions(dataset):
    _, X, y, candles, _ = dataset
    s = purged_split(candles, 5)
    pos = {int(c): i for i, c in enumerate(candles)}
    tr = np.array([pos[int(c)] for c in s.train_idx])
    te = np.array([pos[int(c)] for c in s.test_idx])
    a = fit_forest(X[tr], y[tr], 100, 6, 20, 42)
    b = fit_forest(X[tr], y[tr], 100, 6, 20, 42)
    np.testing.assert_array_equal(a.predict(X[te]), b.predict(X[te]))
    np.testing.assert_allclose(a.predict_proba(X[te]), b.predict_proba(X[te]))


def test_labels_use_only_future_bars_and_are_purged(dataset):
    df, X, y, candles, _ = dataset
    s = purged_split(candles, 5)
    # No label overlap across the purge boundary.
    assert s.val_idx.min() - s.train_idx.max() > 5
    assert s.test_idx.min() - s.val_idx.max() > 5
    # Features at bar i must not change when future bars are altered.
    full = build_features(df)
    mutated = df.copy()
    mutated.loc[300:, "close"] = mutated.loc[300:, "close"] * 2
    mut_feats = build_features(mutated)
    for i in (50, 100, 200):
        np.testing.assert_allclose(full[FEATURE_NAMES].iloc[i].to_numpy(),
                                   mut_feats[FEATURE_NAMES].iloc[i].to_numpy(), atol=1e-12)


def test_overfit_diagnostics_flags_gap_and_baseline():
    train = {"accuracy": 0.95, "samples": 500}
    val = {"accuracy": 0.70, "samples": 100}
    test = {"accuracy": 0.45, "samples": 80, "baseline_majority_accuracy": 0.55,
            "baseline_momentum_accuracy": 0.50, "class_counts": {"DOWN": 10, "SIDE": 60, "UP": 10}}
    d = overfit_diagnostics(train, val, test, [])
    assert d["reliability"] == "LOW"
    assert any("overfitting" in f for f in d["flags"])
    assert any("baseline" in f for f in d["flags"])
    assert d["beats_better_baseline"] is False


def test_research_saves_model_and_report_with_seed(tmp_path):
    from engine import AppState
    state = AppState(store_root=tmp_path / "store")
    p = tmp_path / "r.csv"
    p.write_text(make_fixture(400, "1D", seed=6).to_csv(index=False))
    state.import_csv(p, "RES", "1D", "TEST_FIXTURE", "UNKNOWN_UNVERIFIED")
    rep = state.run_research(horizon=5, entry_threshold=0.42)
    assert rep["verdict"] == "PLUMBING_ONLY"          # synthetic data, never an edge claim
    assert rep["model_id"].startswith("model_")
    assert rep["config"]["random_state"] == 42
    assert "overfit" in rep and "benchmark" in rep
    models = state.store.list_models()
    assert len(models) == 1
    assert models[0]["random_state"] == 42
    assert models[0]["sklearn_version"]
    loaded = state.store.load_model(rep["model_id"])
    assert loaded is not None
    runs = state.store.list_research()
    assert len(runs) == 1 and runs[0]["verdict"] == "PLUMBING_ONLY"


def test_backtest_future_mutation_does_not_change_past_trades(dataset):
    """Changing bars after the test window must not alter earlier fills (no look-ahead)."""
    from quantai.backtest import run_backtest
    df, X, y, candles, feats = dataset
    res1 = run_backtest(df, feats, 60, CostModel(), RiskConfig(), "1D",
                        mode="rules_only", entry_threshold=-99)
    mutated = df.copy()
    mutated.loc[350:, "close"] = mutated.loc[350:, "close"] * 0.5
    mutated.loc[350:, "open"] = mutated.loc[350:, "close"]
    mutated.loc[350:, "high"] = mutated.loc[350:, "close"] * 1.01
    mutated.loc[350:, "low"] = mutated.loc[350:, "close"] * 0.99
    feats2 = build_features(mutated)
    res2 = run_backtest(mutated, feats2, 60, CostModel(), RiskConfig(), "1D",
                        mode="rules_only", entry_threshold=-99)
    past1 = [t for t in res1.trade_log if t["exit_bar"] < 340]
    past2 = [t for t in res2.trade_log if t["exit_bar"] < 340]
    assert len(past1) == len(past2)
    for a, b in zip(past1, past2):
        assert a["entry"] == pytest.approx(b["entry"])
        assert a["exit"] == pytest.approx(b["exit"])
        assert a["qty"] == b["qty"]
