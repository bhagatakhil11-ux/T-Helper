"""Authorized data feeds: SSRF guard, fetch contract, append-only merge
(hand-checked), provenance labelling, and engine-level feed/update integration.
All network behaviour is injected or uses literal IPs — no real network needed."""
import numpy as np
import pandas as pd
import pytest

from quantai.data_sources import (FeedSource, _NoRedirect, fetch_feed_csv,
                                  merge_append_only, validate_feed_url)


# ---------------- SSRF guard ----------------
@pytest.mark.parametrize("url", [
    "http://example.com/data.csv",            # not https
    "https://127.0.0.1/data.csv",             # loopback
    "https://localhost/data.csv",             # loopback by name
    "https://10.0.0.5/data.csv",              # private
    "https://192.168.1.10/data.csv",          # private
    "https://169.254.169.254/latest/meta-data",  # cloud metadata
    "https://[::1]/data.csv",                 # IPv6 loopback
    "https://user:pass@example.com/data.csv",    # embedded credentials
    "ftp://example.com/data.csv",             # wrong scheme
    "https:///data.csv",                      # no host
])
def test_unsafe_urls_rejected(url):
    with pytest.raises(ValueError):
        validate_feed_url(url)


def test_public_literal_ip_accepted():
    # Literal public IP: getaddrinfo needs no DNS, so this works offline.
    assert validate_feed_url("https://93.184.216.34/feed.csv") == "https://93.184.216.34/feed.csv"


def test_unresolvable_host_rejected():
    with pytest.raises(ValueError, match="resolve"):
        validate_feed_url("https://nonexistent-host.invalid/data.csv")


def test_redirect_to_private_is_blocked():
    import urllib.request
    handler = _NoRedirect()
    req = urllib.request.Request("https://93.184.216.34/a.csv")
    with pytest.raises(ValueError):
        handler.redirect_request(req, None, 302, "Found", {}, "https://127.0.0.1/steal")
    with pytest.raises(ValueError):
        handler.redirect_request(req, None, 302, "Found", {}, "http://93.184.216.34/downgrade")


# ---------------- fetch contract (injected fetcher) ----------------
def test_fetch_with_injected_fetcher():
    data, retrieved_at = fetch_feed_csv("https://93.184.216.34/feed.csv",
                                        fetcher=lambda url: b"timestamp,open\n")
    assert data == b"timestamp,open\n"
    assert retrieved_at.endswith("+00:00")


def test_fetch_rejects_non_bytes_and_oversize():
    with pytest.raises(ValueError, match="bytes"):
        fetch_feed_csv("https://93.184.216.34/f.csv", fetcher=lambda url: "not bytes")
    with pytest.raises(ValueError, match="64 MB"):
        fetch_feed_csv("https://93.184.216.34/f.csv", fetcher=lambda url: b"x" * (64 * 1024 * 1024 + 1))


# ---------------- append-only merge (hand-checked) ----------------
def _bars(start_day, n, price=100.0):
    ts = pd.date_range(start_day, periods=n, freq="B", tz="Asia/Kolkata") + pd.Timedelta(hours=15)
    return pd.DataFrame({"timestamp": ts, "open": np.full(n, price),
                         "high": np.full(n, price + 1), "low": np.full(n, price - 1),
                         "close": np.full(n, price), "volume": np.full(n, 1000, dtype=int)})


def test_merge_appends_only_newer():
    existing = _bars("2024-01-01", 5)
    incoming = _bars("2024-01-04", 5)  # 2 overlapping (identical) + 3 new
    merged, rep = merge_append_only(existing, incoming)
    assert rep["appended"] == 3
    assert rep["overlap_identical"] == 2
    assert len(merged) == 8
    assert merged["timestamp"].is_monotonic_increasing


def test_merge_conflicting_overlap_rejected():
    existing = _bars("2024-01-01", 5)
    incoming = _bars("2024-01-04", 3, price=999.0)  # overlap with DIFFERENT prices
    with pytest.raises(ValueError, match="conflict"):
        merge_append_only(existing, incoming)


def test_merge_older_only_appends_nothing():
    existing = _bars("2024-01-01", 10)
    incoming = _bars("2024-01-01", 5)
    merged, rep = merge_append_only(existing, incoming)
    assert rep["appended"] == 0
    assert len(merged) == 10


def test_merge_never_fills_gaps():
    existing = _bars("2024-01-01", 3)
    # Incoming jumps 10 business days ahead: the gap must remain a gap.
    incoming = _bars("2024-01-20", 2)
    merged, rep = merge_append_only(existing, incoming)
    assert len(merged) == 5  # 3 + 2, nothing interpolated
    gaps = merged["timestamp"].diff().dt.days.dropna()
    assert gaps.max() > 5


def test_merge_empty_existing():
    incoming = _bars("2024-01-01", 4)
    merged, rep = merge_append_only(pd.DataFrame(), incoming)
    assert len(merged) == 4 and rep["appended"] == 4


# ---------------- engine integration ----------------
def _csv_bytes(start_day, n, price=100.0):
    df = _bars(start_day, n, price)
    return df.to_csv(index=False).encode()


def test_feed_registration_requires_authorization_note(tmp_path):
    from engine import AppState
    st = AppState(store_root=tmp_path / "store")
    with pytest.raises(ValueError, match="license"):
        st.add_feed("bad", "https://93.184.216.34/f.csv", "TEST", "1D", "short")
    feed = st.add_feed("ok", "https://93.184.216.34/f.csv", "TEST", "1D",
                       "Licensed vendor export, account #123, personal research use.")
    assert feed["symbol"] == "TEST"
    assert st.list_feeds()[0]["name"] == "ok"


def test_feed_fetch_labels_provenance(tmp_path):
    from engine import AppState
    st = AppState(store_root=tmp_path / "store")
    st.add_feed("vendor", "https://93.184.216.34/f.csv", "FEEDTEST", "1D",
                "Licensed vendor CSV export for research.")
    meta = st.fetch_feed("vendor", fetcher=lambda url: _csv_bytes("2022-01-03", 120))
    assert meta["source_type"] == "DATA_FEED"
    assert meta["verification_status"] == "DATA_FEED_UNVERIFIED"
    assert meta["acquisition"] == "AUTHORIZED_FEED"
    assert meta["feed_url"] == "https://93.184.216.34/f.csv"
    assert meta["retrieved_at"] is not None
    assert meta["license_note"].startswith("Licensed vendor")
    assert any("NOT independently verified" in w for w in meta["warnings"])
    # Persisted feed status survives reload.
    st2 = AppState(store_root=tmp_path / "store")
    assert st2.list_feeds()[0]["last_status"].startswith("ok")


def test_manual_import_acquisition_label(tmp_path):
    from engine import AppState
    st = AppState(store_root=tmp_path / "store")
    p = tmp_path / "manual.csv"
    p.write_bytes(_csv_bytes("2022-01-03", 120))
    meta = st.import_csv(p, "MANUAL", "1D", "IMPORTED_CSV", "UNKNOWN_UNVERIFIED")
    assert meta["acquisition"] == "MANUAL_IMPORT"
    assert meta["feed_url"] is None


def test_append_update_via_engine(tmp_path):
    from engine import AppState
    st = AppState(store_root=tmp_path / "store")
    p = tmp_path / "base.csv"
    p.write_bytes(_csv_bytes("2022-01-03", 120))
    st.import_csv(p, "APPEND", "1D", "IMPORTED_CSV", "UNKNOWN_UNVERIFIED")
    key = st.active_key
    old_id = st.datasets[key]["meta"].dataset_id
    upd = tmp_path / "update.csv"
    # last 10 identical bars + 10 new bars
    base = _bars("2022-01-03", 120)
    tail = base.tail(10)
    extra = _bars("2022-06-27", 10)
    upd.write_bytes(pd.concat([tail, extra]).to_csv(index=False).encode())
    rep = st.update_dataset_append(key, upd)
    assert rep["appended"] == 10
    assert st.datasets[key]["meta"].candle_count == 130
    assert st.datasets[key]["meta"].dataset_id != old_id  # new content hash
    # Conflicting update must be refused.
    bad = tmp_path / "bad.csv"
    bad.write_bytes(_bars("2022-01-03", 5, price=555.0).to_csv(index=False).encode())
    with pytest.raises(ValueError, match="conflict"):
        st.update_dataset_append(key, bad)
