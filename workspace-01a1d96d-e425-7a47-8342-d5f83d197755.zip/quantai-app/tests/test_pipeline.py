"""Regression tests for the rules we refused to compromise on."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from make_fixture import make_fixture
from quantai.backtest import run_backtest
from quantai.config import CostModel, DataOrigin, RiskConfig, VerificationStatus
from quantai.data import load_csv
from quantai.features import FEATURE_NAMES, build_dataset, build_features, purged_split


@pytest.fixture()
def fixture_csv(tmp_path):
    p = tmp_path / "fixture.csv"
    df = make_fixture(400, "1D", seed=3)
    p.write_text("# SYNTHETIC TEST_FIXTURE\n" + df.to_csv(index=False), encoding="utf-8")
    return p


def test_fixture_is_never_real_market_data(fixture_csv):
    _, meta = load_csv(fixture_csv, "TEST", "1D", source_type=DataOrigin.TEST_FIXTURE)
    assert meta.source_type is DataOrigin.TEST_FIXTURE
    assert meta.verification_status is VerificationStatus.TEST_FIXTURE_NOT_MARKET_DATA
    assert not meta.is_real_market_claim
    assert any("NOT REAL MARKET DATA" in w for w in meta.warnings)


def test_imported_csv_is_unverified_not_verified(tmp_path):
    p = tmp_path / "real.csv"
    p.write_text(make_fixture(120, "1D").to_csv(index=False), encoding="utf-8")
    _, meta = load_csv(p, "RELIANCE", "1D")
    assert meta.verification_status is VerificationStatus.IMPORTED_CSV_UNVERIFIED
    assert len(meta.sha256) == 64
    assert meta.dataset_id.startswith("RELIANCE_1D_")


def test_checksum_changes_when_file_changes(tmp_path):
    p = tmp_path / "a.csv"
    df = make_fixture(120, "1D")
    p.write_text(df.to_csv(index=False), encoding="utf-8")
    _, m1 = load_csv(p, "X", "1D")
    df.loc[5, "close"] = df.loc[5, "close"] + 1
    df.loc[5, "high"] = max(df.loc[5, "high"], df.loc[5, "close"])
    p.write_text(df.to_csv(index=False), encoding="utf-8")
    _, m2 = load_csv(p, "X", "1D")
    assert m1.sha256 != m2.sha256
    assert m1.dataset_id != m2.dataset_id


def test_invalid_rows_rejected_not_repaired(tmp_path):
    p = tmp_path / "dirty.csv"
    good = make_fixture(60, "1D")
    bad = good.iloc[[10]].copy(); bad["close"] = -5
    frac = good.iloc[[20]].copy(); frac["volume"] = 123.5
    inverted = good.iloc[[30]].copy()
    inverted["high"] = inverted["low"] - 10
    dup = good.iloc[[40]].copy()
    out = pd.concat([good, bad, frac, inverted, dup], ignore_index=True)
    p.write_text(out.to_csv(index=False), encoding="utf-8")
    df, meta = load_csv(p, "X", "1D")
    assert meta.rows_rejected >= 3
    assert meta.duplicates >= 2          # both copies of the ambiguous duplicate go
    assert (df["close"] > 0).all()
    assert (df["volume"] % 1 == 0).all()


def test_intraday_timestamp_must_align_to_grid(tmp_path):
    p = tmp_path / "misaligned.csv"
    rows = []
    base = pd.Timestamp("2024-01-01 09:15:00", tz="Asia/Kolkata")
    for k in range(40):
        t = base + pd.Timedelta(minutes=5 * k)
        if k == 7:
            t = t + pd.Timedelta(minutes=2)   # 09:52 is not on the 5m grid
        rows.append((t.strftime("%Y-%m-%d %H:%M:%S"), 100, 101, 99, 100.5, 1000))
    p.write_text(pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"]).to_csv(index=False), encoding="utf-8")
    _, meta = load_csv(p, "X", "5m")
    assert meta.rows_rejected == 1
    assert any("not aligned" in s for s in meta.rejection_samples)


def test_features_are_causal(fixture_csv):
    df, _ = load_csv(fixture_csv, "TEST", "1D", source_type=DataOrigin.TEST_FIXTURE)
    full = build_features(df)
    for i in (60, 120, 250):
        prefix = build_features(df.iloc[: i + 1])
        a = full[FEATURE_NAMES].iloc[i].to_numpy(dtype=float)
        b = prefix[FEATURE_NAMES].iloc[i].to_numpy(dtype=float)
        assert np.allclose(a, b, atol=1e-12, equal_nan=True), f"look-ahead at bar {i}"


def test_split_is_chronological_and_purged(fixture_csv):
    df, _ = load_csv(fixture_csv, "TEST", "1D", source_type=DataOrigin.TEST_FIXTURE)
    X, y, candles, _ = build_dataset(df, 5, 0.003, 0.002, 35)
    s = purged_split(candles, 5)
    assert s.train_idx.max() < s.val_idx.min() < s.val_idx.max() < s.test_idx.min()
    assert s.val_idx.min() - s.train_idx.max() > 5
    assert s.test_idx.min() - s.val_idx.max() > 5
    assert len(set(s.train_idx) & set(s.test_idx)) == 0
    assert len(s.purged_idx) == 10


def test_entry_is_next_bar_open_not_signal_close(fixture_csv):
    df, _ = load_csv(fixture_csv, "TEST", "1D", source_type=DataOrigin.TEST_FIXTURE)
    feats = build_features(df)
    cost = CostModel(is_intraday=False, slippage_pct=0.001)
    res = run_backtest(df, feats, start_bar=60, cost=cost, risk=RiskConfig(),
                       timeframe="1D", mode="rules_only", entry_threshold=-99)
    assert res.total_trades >= 1
    first = res.trade_log[0]
    expected = float(df["open"].iloc[61]) * (1 + cost.slippage_pct)
    assert first["entry"] == pytest.approx(expected, rel=1e-9)
    assert first["entry"] != pytest.approx(float(df["close"].iloc[60]), rel=1e-9)


def test_gap_down_stop_fills_at_open_worse_than_stop(tmp_path):
    p = tmp_path / "gap.csv"
    rows = []
    base = pd.Timestamp("2024-01-01", tz="Asia/Kolkata")
    for k in range(80):
        t = base + pd.Timedelta(days=k)
        if t.dayofweek >= 5:
            continue
        if k == 62:
            o, h, l, c = 80.0, 81.0, 79.0, 80.0     # gaps far below any stop
        else:
            o, h, l, c = 100.0, 101.0, 99.0, 100.5
        rows.append((t.strftime("%Y-%m-%d %H:%M:%S"), o, h, l, c, 10000))
    p.write_text(pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"]).to_csv(index=False), encoding="utf-8")
    df, _ = load_csv(p, "X", "1D")
    feats = build_features(df)
    res = run_backtest(df, feats, 40, CostModel(), RiskConfig(), "1D",
                       mode="rules_only", entry_threshold=-99)
    gap_trades = [t for t in res.trade_log if t["reason"] == "gap_stop_at_open"]
    if gap_trades:
        assert gap_trades[0]["exit"] < 85.0   # filled at the bad open, not at a cosy stop


def test_sharpe_is_na_when_too_few_trades(fixture_csv):
    df, _ = load_csv(fixture_csv, "TEST", "1D", source_type=DataOrigin.TEST_FIXTURE)
    feats = build_features(df)
    res = run_backtest(df, feats, start_bar=len(df) - 20, cost=CostModel(),
                       risk=RiskConfig(), timeframe="1D", mode="rules_only",
                       entry_threshold=99)  # never signals
    assert res.total_trades == 0
    assert res.sharpe is None
    assert "N/A" in res.sharpe_reason


def test_no_forced_minimum_quantity(fixture_csv):
    df, _ = load_csv(fixture_csv, "TEST", "1D", source_type=DataOrigin.TEST_FIXTURE)
    feats = build_features(df)
    tiny_risk = RiskConfig(risk_per_trade_pct=0.000001, initial_capital=1000.0)
    res = run_backtest(df, feats, 60, CostModel(), tiny_risk, "1D",
                       mode="rules_only", entry_threshold=-99)
    assert res.total_trades == 0
    assert res.rejected_signals["risk_qty_zero"] > 0


def test_daily_drawdown_breaker_blocks_entries(fixture_csv):
    df, _ = load_csv(fixture_csv, "TEST", "1D", source_type=DataOrigin.TEST_FIXTURE)
    feats = build_features(df)
    strict = RiskConfig(max_daily_drawdown_pct=0.0001)
    res = run_backtest(df, feats, 60, CostModel(), strict, "1D",
                       mode="rules_only", entry_threshold=-99)
    assert res.rejected_signals["daily_drawdown"] > 0


def test_costs_are_charged_on_both_legs(fixture_csv):
    df, _ = load_csv(fixture_csv, "TEST", "1D", source_type=DataOrigin.TEST_FIXTURE)
    feats = build_features(df)
    res = run_backtest(df, feats, 60, CostModel(), RiskConfig(), "1D",
                       mode="rules_only", entry_threshold=-99)
    assert res.total_trades > 0
    assert res.total_costs > 0
    assert res.total_slippage > 0
    assert all(t["costs"] > 0 for t in res.trade_log)


def test_equity_conservation_with_zero_costs(tmp_path):
    """Flat prices + zero costs must leave equity exactly unchanged."""
    p = tmp_path / "flat.csv"
    rows = []
    for k, t in enumerate(pd.bdate_range("2024-01-01", periods=120, freq="B", tz="Asia/Kolkata")):
        # small symmetric wick gives ATR > 0 but never reaches stop or target
        rows.append((t.strftime("%Y-%m-%d %H:%M:%S"), 100.0, 100.5, 99.5, 100.0, 10000))
    p.write_text(pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"]).to_csv(index=False), encoding="utf-8")
    df, _ = load_csv(p, "X", "1D")
    feats = build_features(df)
    zero = CostModel(delivery_stt=0.0, intraday_stt_sell=0.0, exchange_turnover=0.0,
                     sebi_fee=0.0, stamp_delivery_buy=0.0, stamp_intraday_buy=0.0,
                     brokerage_flat_inr=0.0, brokerage_pct_cap=0.0, gst=0.0, slippage_pct=0.0)
    res = run_backtest(df, feats, 60, zero, RiskConfig(), "1D",
                       mode="rules_only", entry_threshold=-99)
    assert res.total_trades > 0
    assert res.final_equity == pytest.approx(RiskConfig().initial_capital, abs=1e-6)
    assert res.net_profit == pytest.approx(0.0, abs=1e-6)
    assert max(res.equity_curve) == pytest.approx(RiskConfig().initial_capital, abs=1e-6)


def test_buy_and_hold_matches_price_move(tmp_path):
    p = tmp_path / "up.csv"
    rows = []
    for k, t in enumerate(pd.bdate_range("2024-01-01", periods=120, freq="B", tz="Asia/Kolkata")):
        px = 100.0 + k
        rows.append((t.strftime("%Y-%m-%d %H:%M:%S"), px, px + 1, px - 1, px + 0.5, 10000))
    p.write_text(pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"]).to_csv(index=False), encoding="utf-8")
    df, _ = load_csv(p, "X", "1D")
    feats = build_features(df)
    zero = CostModel(delivery_stt=0.0, exchange_turnover=0.0, sebi_fee=0.0,
                     stamp_delivery_buy=0.0, brokerage_flat_inr=0.0,
                     brokerage_pct_cap=0.0, gst=0.0, slippage_pct=0.0)
    res = run_backtest(df, feats, 60, zero, RiskConfig(max_cash_fraction=1.0), "1D", mode="buy_and_hold")
    start_px = float(df["open"].iloc[60]); end_px = float(df["close"].iloc[-1])
    expected_pct = (end_px / start_px - 1) * 100
    assert res.net_return_pct == pytest.approx(expected_pct, abs=0.5)


def test_intraday_never_carries_position_or_pending_overnight(tmp_path):
    p = tmp_path / "intraday.csv"
    df = make_fixture(150, "5m", seed=11)  # two sessions
    p.write_text(df.to_csv(index=False), encoding="utf-8")
    candles, _ = load_csv(p, "X", "5m")
    feats = build_features(candles)
    cost = CostModel(is_intraday=True)
    res = run_backtest(candles, feats, start_bar=40, cost=cost, risk=RiskConfig(),
                       timeframe="5m", mode="rules_only", entry_threshold=-99)
    days = candles["timestamp"].dt.tz_convert("Asia/Kolkata").dt.normalize()
    assert res.total_trades > 0
    for t in res.trade_log:
        assert days.iloc[t["entry_bar"]] == days.iloc[t["exit_bar"]], t
        assert t["reason"] != "final_liquidation"
    assert res.rejected_signals["intraday_no_overnight"] > 0
