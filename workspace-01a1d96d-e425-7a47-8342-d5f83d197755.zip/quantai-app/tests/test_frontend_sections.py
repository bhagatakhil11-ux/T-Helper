"""Guards the structure of the single-file frontend.

The UI must stay ONE self-contained HTML file: the JavaScript stays INLINE
(no external ``.js`` files), but it is organised into clearly delimited,
comment-separated logical sections so a reader can navigate it.

These tests are deliberately structural rather than behavioural — behaviour is
covered by ``tests/chart_js_harness.js`` (real inline JS executed headless).
"""
from __future__ import annotations

import re
import subprocess
import shutil
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / "static" / "index.html"

SECTIONS = [
    "BOOTSTRAP & SHARED STATE",
    "THEME & TAB NAVIGATION",
    "API & DOM HELPERS",
    "CANVAS PRIMITIVES",
    "RENDER HELPERS",
    "MAIN RENDERER",
    "ADVANCED RESEARCH RENDERERS",
    "TRADING JOURNAL",
    "CHARTS & TECHNICAL ANALYSIS",
    "EVENT HANDLERS & API ACTIONS",
    "BOOT",
]


@pytest.fixture(scope="module")
def html() -> str:
    return HTML.read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def inline_js(html: str) -> str:
    m = re.search(r"<script>([\s\S]*?)</script>", html)
    assert m, "inline <script> block not found in static/index.html"
    return m.group(1)


def test_single_html_file_no_external_js(html: str):
    """The frontend must not be split into separate JS files."""
    assert not re.search(r"<script[^>]*\ssrc\s*=", html), (
        "external <script src=...> found — the JS must stay inline"
    )
    assert len(re.findall(r"<script\b", html)) == 1, "expected exactly one inline script block"


def test_no_extra_js_files_on_disk():
    """Guard against a stray extracted JS file sneaking into static/."""
    stray = [p.name for p in (ROOT / "static").glob("*.js")]
    assert not stray, f"unexpected JS files in static/: {stray}"


def test_all_sections_present_and_ordered(inline_js: str):
    positions = []
    for title in SECTIONS:
        # anchor on the end of the title so "BOOT" cannot match "BOOTSTRAP ..."
        m = re.search(rf"SECTION \d+ — {re.escape(title)}\n", inline_js)
        assert m, f"missing section banner: {title}"
        positions.append(m.start())
    assert positions == sorted(positions), (
        "section banners are out of order: " + str(list(zip(SECTIONS, positions)))
    )


def test_every_section_has_a_description(inline_js: str):
    """Each banner must explain what the section contains, not just name it."""
    banners = re.findall(
        r"/\* [═]+\n   SECTION \d+ — [^\n]+\n   [═]+\n   ([^\n]+)\n   [═]+ \*/",
        inline_js,
    )
    assert len(banners) == len(SECTIONS), (
        f"expected {len(SECTIONS)} described banners, found {len(banners)}"
    )
    for desc in banners:
        assert len(desc.strip()) > 20, f"banner description too thin: {desc!r}"


def test_section_map_toc_present(inline_js: str):
    assert "SECTION MAP" in inline_js, "script is missing its section table of contents"


def test_inline_js_is_syntactically_valid(inline_js: str, tmp_path: Path):
    """Parse the inline JS with a real JS engine when node is available."""
    node = shutil.which("node")
    if not node:
        pytest.skip("node is not installed")
    f = tmp_path / "inline.js"
    f.write_text(inline_js, encoding="utf-8")
    r = subprocess.run([node, "--check", str(f)], capture_output=True, text=True)
    assert r.returncode == 0, f"inline JS failed to parse:\n{r.stderr}"


def test_no_tdz_risk_from_section_reordering(inline_js: str):
    """Moving blocks between sections must not create a temporal-dead-zone error.

    Any top-level ``const``/``let`` must be declared before the first
    load-time statement that reads it.
    """
    lines = inline_js.split("\n")

    decls: dict[str, int] = {}
    for i, line in enumerate(lines):
        m = re.match(r"^(?:const|let|var)\s+([A-Za-z_$][\w$]*)", line)
        if m:
            decls.setdefault(m.group(1), i)
        m2 = re.match(r"^(?:const|let|var)\s*\[([^\]]*)\]", line)
        if m2:
            for nm in m2.group(1).split(","):
                nm = nm.strip()
                if nm:
                    decls.setdefault(nm, i)

    def strip_code(text: str) -> str:
        text = re.sub(r"//.*$", "", text)
        text = re.sub(r"'(\\.|[^'\\])*'", "''", text)
        text = re.sub(r'"(\\.|[^"\\])*"', '""', text)
        text = re.sub(r"`(\\.|[^`\\])*`", "``", text)
        return text

    problems = []
    for i, line in enumerate(lines):
        if not line.strip():
            continue
        if line[0] in " \t}":
            continue  # nested / continuation
        if re.match(r"^(const|let|var|function|async function|class)\b", line):
            continue
        code = strip_code(line)
        for name, decl_line in decls.items():
            if decl_line <= i:
                continue
            if re.search(r"(?<![\w$.])" + re.escape(name) + r"(?![\w$])", code):
                problems.append(f"line {i + 1} reads '{name}' declared at line {decl_line + 1}")
    assert not problems, "temporal dead zone risk: " + "; ".join(problems)


def test_chart_entrypoints_still_present(inline_js: str):
    """The chart API surface the harness relies on must survive sectioning."""
    for symbol in [
        "chLoad", "chRender", "chRenderPanels", "chIdxAt", "chGeom",
        "CH", "chSelectBar", "chSetView", "chEnsureSymbols", "chIndicatorBox",
    ]:
        assert re.search(rf"\b{re.escape(symbol)}\b", inline_js), f"missing {symbol}"
