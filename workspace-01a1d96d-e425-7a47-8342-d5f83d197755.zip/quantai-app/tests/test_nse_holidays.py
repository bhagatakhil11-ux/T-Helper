"""NSE trading-holiday calendar: it explains gaps, it never invents bars.

The calendar lets the quality layer tell "the market was shut" apart from
"the file is missing a session". These tests pin down both halves of that
promise:

* a genuine hole is still reported when the calendar is supplied, and
* the number of candles is identical with and without the calendar.

The expectations are hand-checked against published NSE holiday dates --
none of them are read back out of the implementation.
"""
from __future__ import annotations

import pandas as pd
import pytest

from quantai.config import DataOrigin
from quantai.data import load_csv, preview_csv
from quantai.nse_holidays import NSE_HOLIDAYS, nse_holidays


# ------------------------------------------------------------------ the set
def test_calendar_is_a_set_of_iso_dates_on_weekdays():
    assert len(NSE_HOLIDAYS) >= 150, "a decade of NSE holidays is more than 150 days"
    for d in NSE_HOLIDAYS:
        assert isinstance(d, str)
        assert len(d) == 10 and d[4] == "-" and d[7] == "-"
        ts = pd.Timestamp(d)
        assert ts.weekday() < 5, f"{d} is a weekend day and cannot be a trading holiday"


@pytest.mark.parametrize("d", [
    "2016-01-26",   # Republic Day
    "2016-03-24",   # Holi
    "2016-08-15",   # Independence Day
    "2017-10-20",   # Diwali
    "2018-10-18",   # Dussehra
    "2019-10-28",   # Diwali (Balipratipada)
    "2020-04-10",   # Mahavir Jayanti
    "2021-11-05",   # Muharram
    "2022-10-26",   # Diwali (Balipratipada)
    "2023-10-24",   # Dussehra
    "2024-11-15",   # Guru Nanak Jayanti
    "2025-11-05",   # Diwali (Balipratipada)
])
def test_known_published_nse_holidays_are_present(d):
    assert d in NSE_HOLIDAYS


def test_a_partial_session_holiday_is_not_claimed_as_a_full_holiday():
    """2021-11-04 (Diwali) has a short bar in Yahoo's feed, so it is not in
    the calendar. Claiming it would be wrong in the dangerous direction: a
    genuine hole on that date could then be hidden."""
    assert "2021-11-04" not in NSE_HOLIDAYS
    assert "2021-11-05" in NSE_HOLIDAYS       # the next, fully closed day


def test_clipping_returns_only_the_requested_window():
    window = nse_holidays("2024-01-01", "2024-12-31")
    assert window
    assert all(d.startswith("2024-") for d in window)
    assert nse_holidays() == set(NSE_HOLIDAYS)


# ------------------------------------------------------------------ the effect
def _series_with_one_real_gap(tmp_path):
    """Ten consecutive trading days with ONE day removed (a genuine hole)."""
    days = pd.bdate_range("2026-03-02", periods=10)
    days = days[days != pd.Timestamp("2026-03-05")]      # leave a real gap
    n = len(days)
    df = pd.DataFrame({
        "timestamp": days.strftime("%Y-%m-%d 00:00:00"),
        "open": [100.0 + i for i in range(n)],
        "high": [101.0 + i for i in range(n)],
        "low": [99.0 + i for i in range(n)],
        "close": [100.5 + i for i in range(n)],
        "volume": [1000 + i for i in range(n)],
    })
    p = tmp_path / "gap.csv"
    p.write_text(df.to_csv(index=False))
    return p


def test_a_genuine_gap_is_still_reported_when_the_calendar_is_supplied(tmp_path):
    """The calendar must not paper over a hole that the market did open for."""
    path = _series_with_one_real_gap(tmp_path)
    _, meta = load_csv(path, "TEST", "1D", source_type=DataOrigin.IMPORTED_CSV,
                       holidays=nse_holidays())
    assert meta.rows_rejected == 0
    gaps = meta.data_quality_components
    continuity = [c for c in gaps if c["key"] == "continuity"][0]
    assert "missing session" in continuity["detail"]
    assert meta.serious_issues, "a real hole must still raise a serious issue"


def test_a_market_holiday_is_not_counted_as_a_missing_session(tmp_path):
    """The same series, but the removed day is a listed NSE holiday."""
    days = pd.bdate_range("2026-01-01", periods=10)
    days = days[days != pd.Timestamp("2026-01-26")]      # Republic Day
    n = len(days)
    df = pd.DataFrame({
        "timestamp": days.strftime("%Y-%m-%d 00:00:00"),
        "open": [100.0 + i for i in range(n)],
        "high": [101.0 + i for i in range(n)],
        "low": [99.0 + i for i in range(n)],
        "close": [100.5 + i for i in range(n)],
        "volume": [1000 + i for i in range(n)],
    })
    p = tmp_path / "holiday.csv"
    p.write_text(df.to_csv(index=False))
    _, meta = load_csv(p, "TEST", "1D", source_type=DataOrigin.IMPORTED_CSV,
                       holidays=nse_holidays())
    continuity = [c for c in meta.data_quality_components if c["key"] == "continuity"][0]
    assert "0 missing session(s)" in continuity["detail"]
    assert not meta.serious_issues


def test_the_calendar_never_adds_or_removes_a_candle(tmp_path):
    """Same file, calendar on and off -> identical candles, only the report differs."""
    path = _series_with_one_real_gap(tmp_path)
    df_no, meta_no = load_csv(path, "TEST", "1D", source_type=DataOrigin.IMPORTED_CSV)
    df_yes, meta_yes = load_csv(path, "TEST", "1D", source_type=DataOrigin.IMPORTED_CSV,
                                 holidays=nse_holidays())
    assert len(df_no) == len(df_yes)
    assert df_no["timestamp"].tolist() == df_yes["timestamp"].tolist()
    assert df_no["close"].tolist() == df_yes["close"].tolist()


def test_preview_accepts_the_calendar(tmp_path):
    path = _series_with_one_real_gap(tmp_path)
    rep = preview_csv(path, "TEST", "1D", source_type=DataOrigin.IMPORTED_CSV,
                      holidays=nse_holidays())
    assert "meta" in rep and "head" in rep
    assert rep["meta"]["rows_rejected"] == 0


# ------------------------------------------------------------------ the HTTP API
@pytest.fixture()
def client(tmp_path):
    from app import create_app
    from engine import AppState
    state = AppState(store_root=tmp_path / "store")
    app = create_app(state)
    app.config["TESTING"] = True
    return app.test_client(), state, tmp_path


def _csv_with_holiday_gap(tmp_path):
    days = pd.bdate_range("2026-01-01", periods=10)
    days = days[days != pd.Timestamp("2026-01-26")]          # Republic Day
    n = len(days)
    df = pd.DataFrame({
        "timestamp": days.strftime("%Y-%m-%d 00:00:00"),
        "open": [100.0 + i for i in range(n)],
        "high": [101.0 + i for i in range(n)],
        "low": [99.0 + i for i in range(n)],
        "close": [100.5 + i for i in range(n)],
        "volume": [1000 + i for i in range(n)],
    })
    p = tmp_path / "hol.csv"
    p.write_text(df.to_csv(index=False))
    return p


def test_api_rejects_an_unknown_market_calendar(client):
    c, s, tmp = client
    p = _csv_with_holiday_gap(tmp)
    with open(p, "rb") as f:
        r = c.post("/api/import", data={"file": (f, "hol.csv"), "symbol": "X",
                                        "timeframe": "1D",
                                        "market_calendar": "NYSE"},
                   content_type="multipart/form-data")
    assert r.status_code == 400


def test_api_import_with_the_nse_calendar_reports_no_missing_session(client):
    c, s, tmp = client
    p = _csv_with_holiday_gap(tmp)
    with open(p, "rb") as f:
        r = c.post("/api/import", data={"file": (f, "hol.csv"), "symbol": "X",
                                        "timeframe": "1D",
                                        "market_calendar": "NSE"},
                   content_type="multipart/form-data")
    assert r.status_code == 200
    body = r.get_json()
    assert body["ok"] is True
    meta = body["dataset"]
    continuity = [x for x in meta["data_quality_components"] if x["key"] == "continuity"][0]
    assert "0 missing session(s)" in continuity["detail"]


def test_the_calendar_survives_the_preview_confirm_round_trip(client):
    c, s, tmp = client
    p = _csv_with_holiday_gap(tmp)
    with open(p, "rb") as f:
        r = c.post("/api/preview", data={"file": (f, "hol.csv"), "symbol": "X",
                                         "timeframe": "1D",
                                         "market_calendar": "NSE"},
                   content_type="multipart/form-data")
    assert r.status_code == 200
    token = r.get_json()["preview_token"]
    r2 = c.post("/api/preview/confirm", json={"preview_token": token})
    assert r2.status_code == 200
    meta = r2.get_json()["dataset"]
    continuity = [x for x in meta["data_quality_components"] if x["key"] == "continuity"][0]
    assert "0 missing session(s)" in continuity["detail"]
