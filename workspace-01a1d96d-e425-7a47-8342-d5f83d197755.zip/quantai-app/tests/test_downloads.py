"""The downloadable build archives.

The terminal publishes itself: the user must be able to download the whole
project as a ready-to-run ZIP. These tests pin the route, the manifest and
— importantly — that the route can NOT be used to read arbitrary files from
the machine.
"""
from __future__ import annotations

import io
import zipfile

import pytest

from app import create_app
from engine import AppState


@pytest.fixture()
def client(tmp_path):
    st = AppState(store_root=tmp_path / "store")
    app = create_app(state=st)
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c, st


def test_download_manifest_lists_the_archives(client):
    c, st = client
    r = c.get("/api/downloads")
    assert r.status_code == 200
    j = r.get_json()
    assert j["ok"] is True
    names = {d["name"] for d in j["downloads"]}
    assert "quantai-app.zip" in names
    assert "quantai-research.zip" in names
    for d in j["downloads"]:
        assert d["url"] == f"/download/{d['name']}"
        assert "note" in d and d["note"]


def test_download_manifest_reports_size_and_readiness(client):
    c, st = client
    j = c.get("/api/downloads").get_json()
    for d in j["downloads"]:
        if d["ready"]:
            assert d["size_bytes"] and d["size_bytes"] > 0
        else:
            assert d["size_bytes"] is None


def test_downloading_a_zip_returns_an_attachment(client):
    c, st = client
    r = c.get("/download/quantai-app.zip")
    if r.status_code == 404:
        pytest.skip("the build archive has not been built in this environment")
    assert r.status_code == 200
    assert "attachment" in r.headers.get("Content-Disposition", "")
    assert r.headers.get("Content-Type") == "application/zip"
    body = r.get_data()
    assert len(body) > 1000
    # it must be a real, readable zip
    with zipfile.ZipFile(io.BytesIO(body)) as z:
        names = z.namelist()
        assert "app.py" in names
        assert "static/index.html" in names
        assert "quantai/charting.py" in names
        assert z.testzip() is None


def test_downloading_the_research_archive(client):
    c, st = client
    r = c.get("/download/quantai-research.zip")
    if r.status_code == 404:
        pytest.skip("the research archive has not been built in this environment")
    assert r.status_code == 200
    with zipfile.ZipFile(io.BytesIO(r.get_data())) as z:
        assert "run_research.py" in z.namelist()
        assert z.testzip() is None


def test_downloading_the_readme(client):
    c, st = client
    r = c.get("/download/README.md")
    assert r.status_code == 200
    assert "QuantAI" in r.get_data(as_text=True)


def test_unknown_download_is_refused(client):
    c, st = client
    assert c.get("/download/nope.zip").status_code == 404


def test_the_download_route_cannot_read_arbitrary_files(client):
    """A path-traversal attempt must not escape the whitelist.

    The route only ever serves names from a fixed allow-list, so a traversal
    payload is simply an unknown name.
    """
    c, st = client
    for bad in ("../app.py", "../../etc/passwd", "..%2F..%2Fetc%2Fpasswd",
                "quantai-app.zip/../../etc/passwd", ".env", "data_store/settings.json"):
        r = c.get(f"/download/{bad}")
        assert r.status_code in (400, 404), f"{bad} returned {r.status_code}"
        body = r.get_data(as_text=True)
        assert "root:" not in body
        assert "kill_reason" not in body


def test_the_downloaded_app_archive_has_no_personal_data(client):
    """The archive must not ship the operator's data store."""
    c, st = client
    r = c.get("/download/quantai-app.zip")
    if r.status_code == 404:
        pytest.skip("the build archive has not been built in this environment")
    with zipfile.ZipFile(io.BytesIO(r.get_data())) as z:
        for name in z.namelist():
            assert not name.startswith("data_store/"), f"{name} leaks the data store"
            assert not name.endswith(".pyc")
            assert "__pycache__" not in name
