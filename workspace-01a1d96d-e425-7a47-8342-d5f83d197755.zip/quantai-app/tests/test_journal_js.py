"""Runs the headless journal / live-stats JS harness.

``tests/journal_js_harness.js`` executes the REAL inline JavaScript from
``static/index.html`` under a minimal DOM with a mocked fetch, so the journal
rendering (tags, emotional state, breakdowns) and the live replay readout are
actually executed rather than merely syntax-checked.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
HARNESS = ROOT / "tests" / "journal_js_harness.js"


@pytest.mark.skipif(shutil.which("node") is None, reason="node is required for the journal JS harness")
def test_journal_javascript_renders_tags_emotions_and_breakdowns():
    res = subprocess.run(["node", str(HARNESS)], capture_output=True, text=True,
                         timeout=180, cwd=str(ROOT))
    out = res.stdout + res.stderr
    assert res.returncode == 0, f"journal JS harness failed:\n{out}"
    assert "ALL JOURNAL JS CHECKS PASSED" in out, out
    assert "FAIL" not in out, out
