"""The five risk-engine improvements.

* a WEEKLY loss limit (alongside the daily one)
* a PROGRESSIVE cooldown that lengthens with the loss streak
* an OPTIONAL volatility-adjusted risk per trade
* a refusal + warning when the risk limits change with a paper position OPEN
* the kill switch reason saved in the persistent journal

Every rule is enforced in the BACKEND. The frontend only displays it.
"""
from __future__ import annotations

import time

import numpy as np
import pandas as pd
import pytest

from engine import AppState
from make_fixture import make_fixture
from quantai.backtest import run_backtest
from quantai.config import CostModel, RiskConfig
from quantai.features import build_features
from quantai.risk_rules import (MAX_COOLDOWN_BARS, daily_drawdown_pct,
                                effective_risk_pct, iso_week_key,
                                progressive_cooldown_bars, weekly_drawdown_pct)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _sawtooth(n=400, seed=0):
    """A price series whose bars actually hit stops and targets."""
    closes, opens, highs, lows = [], [], [], []
    price = 100.0
    for i in range(n):
        drift = 0.03 if (i // 4) % 2 == 0 else -0.03
        o = price
        c = price * (1 + drift + 0.003 * np.sin(i + seed))
        opens.append(o); closes.append(c)
        highs.append(max(o, c) * 1.004); lows.append(min(o, c) * 0.996)
        price = c
    ts = pd.date_range("2021-01-04", periods=n, freq="B", tz="Asia/Kolkata") + pd.Timedelta(hours=15)
    return pd.DataFrame({"timestamp": ts, "open": opens, "high": highs,
                         "low": lows, "close": closes, "volume": 1_000_000})


def _state(tmp_path, name="RISK", n=400):
    st = AppState(store_root=tmp_path / "store")
    p = tmp_path / "saw.csv"
    p.write_text(_sawtooth(n).to_csv(index=False))
    st.import_csv(p, name, "1D", "TEST_FIXTURE", "UNKNOWN_UNVERIFIED")
    return st


# ---------------------------------------------------------------------------
# 1. Weekly loss limit
# ---------------------------------------------------------------------------

def test_iso_week_key_groups_by_iso_week():
    assert iso_week_key(pd.Timestamp("2024-01-01")) == "2024-W01"   # Monday
    assert iso_week_key(pd.Timestamp("2024-01-07")) == "2024-W01"   # Sunday
    assert iso_week_key(pd.Timestamp("2024-01-08")) == "2024-W02"   # next Monday
    assert iso_week_key(pd.Timestamp("2023-12-31")) == "2023-W52"


def test_weekly_drawdown_pct_is_measured_from_the_week_start():
    assert weekly_drawdown_pct(100000.0, 100000.0) == 0.0
    assert weekly_drawdown_pct(100000.0, 95000.0) == pytest.approx(5.0)
    assert weekly_drawdown_pct(0.0, 95000.0) == 0.0


def test_weekly_limit_blocks_new_entries(tmp_path):
    """A weekly breach must block NEW ENTRIES (like the daily limit), not
    silently let the strategy keep trading through the loss."""
    st = _state(tmp_path, "WK")
    st.update_risk({"max_weekly_drawdown_pct": 1.0, "max_daily_drawdown_pct": 10.0,
                    "max_total_drawdown_pct": 50.0})
    st.start_replay(speed_ms=60, use_test_window=False, mode="rules_only", threshold=-99)
    t0 = time.time()
    while time.time() - t0 < 30 and st.replay["weekly_drawdown_pct"] <= 0:
        time.sleep(0.05)
    st.stop_replay()
    snap = st.snapshot()["replay"]
    assert snap["weekly_drawdown_pct"] > 0
    assert snap["current_week"], "the replay must know which ISO week it is in"
    if snap["week_blocked"]:
        assert snap["rejected"]["weekly_drawdown"] > 0, \
            "a blocked week must block entries, and the reason must be counted"


def test_weekly_limit_is_in_the_risk_config_and_reaches_the_backtest(tmp_path):
    st = _state(tmp_path, "WK2")
    st.update_risk({"max_weekly_drawdown_pct": 7.5})
    assert st.risk.max_weekly_drawdown_pct == 7.5
    df = st.active()["df"]
    feats = build_features(df)
    res = run_backtest(df, feats, 60, CostModel(), st.risk, "1D",
                       mode="rules_only", entry_threshold=-99)
    assert res.risk_config["max_weekly_drawdown_pct"] == 7.5
    assert "weekly_drawdown" in res.rejected_signals


def test_weekly_limit_is_clamped_to_the_allowed_range(tmp_path):
    st = _state(tmp_path, "WK3")
    st.update_risk({"max_weekly_drawdown_pct": 999.0})
    assert st.risk.max_weekly_drawdown_pct <= 25.0
    st.update_risk({"max_weekly_drawdown_pct": 0.0})
    assert st.risk.max_weekly_drawdown_pct >= 0.5


def test_daily_and_weekly_limits_are_independent(tmp_path):
    """The daily limit must not be silently replaced by the weekly one."""
    st = _state(tmp_path, "WK4")
    st.update_risk({"max_daily_drawdown_pct": 3.0, "max_weekly_drawdown_pct": 9.0})
    assert st.risk.max_daily_drawdown_pct == 3.0
    assert st.risk.max_weekly_drawdown_pct == 9.0
    assert daily_drawdown_pct(100000.0, 97000.0) == pytest.approx(3.0)


# ---------------------------------------------------------------------------
# 2. Progressive cooldown
# ---------------------------------------------------------------------------

def test_progressive_cooldown_matches_the_stated_schedule():
    """3 losses -> 15 bars, 5 losses -> 30 bars, 7+ losses -> 50 bars."""
    assert progressive_cooldown_bars(3, 3, 15, True) == 15
    assert progressive_cooldown_bars(4, 3, 15, True) == 15
    assert progressive_cooldown_bars(5, 3, 15, True) == 30
    assert progressive_cooldown_bars(6, 3, 15, True) == 30
    assert progressive_cooldown_bars(7, 3, 15, True) == 50
    assert progressive_cooldown_bars(8, 3, 15, True) == 50


def test_progressive_cooldown_third_band_is_flat():
    """7+ losses -> 50 bars, and it does NOT keep growing after that."""
    for losses in (7, 8, 9, 10, 11, 25, 99, 500):
        assert progressive_cooldown_bars(losses, 3, 15, True) == 50


def test_progressive_cooldown_bands_are_configurable():
    """The three bands come from the settings, not from hard-coded numbers."""
    assert progressive_cooldown_bars(3, 3, 10, True, level2_bars=20, level3_bars=40) == 10
    assert progressive_cooldown_bars(5, 3, 10, True, level2_bars=20, level3_bars=40) == 20
    assert progressive_cooldown_bars(7, 3, 10, True, level2_bars=20, level3_bars=40) == 40


def test_progressive_cooldown_bands_never_shrink():
    """A mis-configured band can not make the pause SHORTER after a longer streak."""
    assert progressive_cooldown_bars(5, 3, 15, True, level2_bars=5, level3_bars=1) == 15
    assert progressive_cooldown_bars(7, 3, 15, True, level2_bars=5, level3_bars=1) == 15


def test_progressive_cooldown_bands_follow_the_threshold():
    """The bands are anchored on the configured threshold."""
    # threshold 5 -> 5-6 losses band 1, 7-8 band 2, 9+ band 3
    assert progressive_cooldown_bars(5, 5, 15, True) == 15
    assert progressive_cooldown_bars(6, 5, 15, True) == 15
    assert progressive_cooldown_bars(7, 5, 15, True) == 30
    assert progressive_cooldown_bars(8, 5, 15, True) == 30
    assert progressive_cooldown_bars(9, 5, 15, True) == 50
    assert progressive_cooldown_bars(12, 5, 15, True) == 50


def test_progressive_cooldown_does_not_apply_below_the_threshold():
    assert progressive_cooldown_bars(1, 3, 15, True) == 15
    assert progressive_cooldown_bars(2, 3, 15, True) == 15


def test_the_fixed_cooldown_is_unchanged_when_progressive_is_off():
    for losses in (3, 5, 7, 11, 25):
        assert progressive_cooldown_bars(losses, 3, 15, False) == 15


def test_progressive_cooldown_is_capped():
    """A long losing streak must not lock the engine out forever.

    The third band is FLAT (50 bars), so the cooldown can never exceed it —
    which is a much stronger guarantee than the old growing schedule.
    """
    assert progressive_cooldown_bars(500, 3, 15, True) == 50
    assert progressive_cooldown_bars(10_000, 3, 15, True) == 50
    # and it can never exceed the hard cap even if band 3 is configured huge
    assert progressive_cooldown_bars(500, 3, 15, True, level2_bars=100,
                                     level3_bars=10_000) <= MAX_COOLDOWN_BARS


def test_progressive_cooldown_is_recorded_in_the_backtest(tmp_path):
    st = _state(tmp_path, "PC")
    st.update_risk({"progressive_cooldown": True, "max_consecutive_losses": 2,
                    "cooldown_bars": 10})
    df = st.active()["df"]
    feats = build_features(df)
    res = run_backtest(df, feats, 60, CostModel(), st.risk, "1D",
                       mode="rules_only", entry_threshold=-99)
    assert res.risk_config["progressive_cooldown"] is True
    for ev in res.cooldown_events:
        assert ev["cooldown_bars"] >= 10
        assert ev["until_bar"] == ev["bar"] + ev["cooldown_bars"]
    # Every cooldown is at least the base length.
    assert all(ev["cooldown_bars"] >= 10 for ev in res.cooldown_events)


def test_progressive_cooldown_shows_up_in_the_replay(tmp_path):
    st = _state(tmp_path, "PC2")
    st.update_risk({"progressive_cooldown": True, "max_consecutive_losses": 2,
                    "cooldown_bars": 8, "max_total_drawdown_pct": 50.0})
    st.start_replay(speed_ms=60, use_test_window=False, mode="rules_only", threshold=-99)
    t0 = time.time()
    while time.time() - t0 < 30 and not st.replay["cooldown_events"]:
        time.sleep(0.05)
    st.stop_replay()
    events = st.snapshot()["replay"]["cooldown_events"]
    assert events, "the losing streak must have produced cooldown events"
    for ev in events:
        assert ev["cooldown_bars"] >= 8
        assert ev["consecutive_losses"] >= 2


def test_the_cooldown_lengthens_as_the_streak_grows(tmp_path):
    st = _state(tmp_path, "PC3")
    st.update_risk({"progressive_cooldown": True, "max_consecutive_losses": 2,
                    "cooldown_bars": 5, "max_total_drawdown_pct": 50.0})
    st.start_replay(speed_ms=60, use_test_window=False, mode="rules_only", threshold=-99)
    t0 = time.time()
    while time.time() - t0 < 30 and len(st.replay["cooldown_events"]) < 3:
        time.sleep(0.05)
    st.stop_replay()
    events = st.snapshot()["replay"]["cooldown_events"]
    if len(events) >= 3:
        lengths = [e["cooldown_bars"] for e in events]
        assert lengths[-1] >= lengths[0], "the cooldown must never shrink"


# ---------------------------------------------------------------------------
# 3. Volatility-adjusted risk per trade
# ---------------------------------------------------------------------------

def test_the_volatility_adjustment_is_off_by_default():
    """Off by default so an existing research run keeps its sizing."""
    eff, detail = effective_risk_pct(0.5, 4.0, 100.0, auto=False)
    assert eff == 0.5
    assert detail["auto"] is False
    assert "OFF" in detail["note"]


def test_the_volatility_adjustment_scales_the_risk_down_when_vol_is_high():
    eff, detail = effective_risk_pct(0.5, 4.0, 100.0, auto=True, target_atr_pct=2.0)
    assert detail["atr_pct"] == pytest.approx(4.0)
    assert detail["factor"] == pytest.approx(0.5)
    assert eff == pytest.approx(0.25)


def test_the_volatility_adjustment_scales_the_risk_up_when_vol_is_low():
    eff, detail = effective_risk_pct(0.5, 0.5, 100.0, auto=True, target_atr_pct=2.0)
    assert detail["factor"] == pytest.approx(2.0)
    assert eff == pytest.approx(1.0)


def test_at_the_target_volatility_nothing_changes():
    eff, detail = effective_risk_pct(0.5, 2.0, 100.0, auto=True, target_atr_pct=2.0)
    assert eff == pytest.approx(0.5)
    assert detail["factor"] == pytest.approx(1.0)


def test_the_volatility_factor_is_clamped():
    eff, _ = effective_risk_pct(0.5, 100.0, 100.0, auto=True, target_atr_pct=2.0,
                                 min_factor=0.25, max_factor=2.0)
    assert eff == pytest.approx(0.5 * 0.25)
    eff, _ = effective_risk_pct(0.5, 0.001, 100.0, auto=True, target_atr_pct=2.0,
                                 min_factor=0.25, max_factor=2.0)
    assert eff == pytest.approx(0.5 * 2.0)


def test_a_missing_atr_falls_back_to_the_base_risk():
    eff, detail = effective_risk_pct(0.5, 0.0, 100.0, auto=True)
    assert eff == 0.5
    assert "unavailable" in detail["note"]


def test_the_backtest_sizes_the_trade_with_the_adjusted_risk(tmp_path):
    """With the adjustment ON, a high-volatility bar must risk LESS money."""
    df = _sawtooth(400)
    feats = build_features(df)
    base = run_backtest(df, feats, 60, CostModel(),
                        RiskConfig(auto_risk_by_volatility=False),
                        "1D", mode="rules_only", entry_threshold=-99)
    auto = run_backtest(df, feats, 60, CostModel(),
                        RiskConfig(auto_risk_by_volatility=True, risk_vol_target_pct=0.05),
                        "1D", mode="rules_only", entry_threshold=-99)
    assert base.total_trades > 0 and auto.total_trades > 0
    base_qty = sum(t["qty"] for t in base.trade_log)
    auto_qty = sum(t["qty"] for t in auto.trade_log)
    assert auto_qty < base_qty, "a high ATR% must reduce the position size"
    for t in auto.trade_log:
        assert t["risk_pct_used"] is not None
        assert t["atr_pct"] is not None


def test_the_volatility_toggle_round_trips_through_the_api(tmp_path):
    from app import create_app
    st = _state(tmp_path, "VOL")
    app = create_app(state=st)
    app.config["TESTING"] = True
    with app.test_client() as c:
        r = c.post("/api/risk", json={"auto_risk_by_volatility": True,
                                       "risk_vol_target_pct": 3.0})
        assert r.status_code == 200
        assert r.get_json()["risk"]["auto_risk_by_volatility"] is True
        assert r.get_json()["risk"]["risk_vol_target_pct"] == 3.0


# ---------------------------------------------------------------------------
# 4. Risk change with an open paper position
# ---------------------------------------------------------------------------

def test_a_risk_change_is_refused_while_a_position_is_open(tmp_path):
    st = _state(tmp_path, "OPEN")
    st.start_replay(speed_ms=20, use_test_window=False, mode="rules_only", threshold=-99)
    t0 = time.time()
    while time.time() - t0 < 25 and st.replay.get("position") is None:
        time.sleep(0.05)
    assert st.replay.get("position") is not None, "the fixture must open a position"
    try:
        res = st.update_risk({"risk_per_trade_pct": 1.0})
        assert res["applied"] is False
        w = res["warning"]
        assert w["requires_acknowledgement"] is True
        assert w["open_position"]["qty"] > 0
        assert "risk_per_trade_pct" in [f["field"] for f in w["changed_fields"]]
        # The limits must NOT have changed.
        assert st.risk.risk_per_trade_pct == 0.5
    finally:
        st.stop_replay()


def test_the_change_goes_through_once_the_open_position_is_acknowledged(tmp_path):
    st = _state(tmp_path, "ACK")
    st.start_replay(speed_ms=20, use_test_window=False, mode="rules_only", threshold=-99)
    t0 = time.time()
    while time.time() - t0 < 25 and st.replay.get("position") is None:
        time.sleep(0.05)
    assert st.replay.get("position") is not None
    try:
        res = st.update_risk({"risk_per_trade_pct": 1.0, "acknowledge_open_position": True})
        assert res["applied"] is True
        assert res["warning"] is None
        assert st.risk.risk_per_trade_pct == 1.0
        assert "risk_per_trade_pct" in res["changed"]
    finally:
        st.stop_replay()


def test_the_api_answers_409_with_the_warning(tmp_path):
    from app import create_app
    st = _state(tmp_path, "API409")
    app = create_app(state=st)
    app.config["TESTING"] = True
    with app.test_client() as c:
        st.start_replay(speed_ms=20, use_test_window=False, mode="rules_only", threshold=-99)
        t0 = time.time()
        while time.time() - t0 < 25 and st.replay.get("position") is None:
            time.sleep(0.05)
        try:
            r = c.post("/api/risk", json={"risk_per_trade_pct": 1.0})
            assert r.status_code == 409
            body = r.get_json()
            assert body["ok"] is False
            assert body["requires_acknowledgement"] is True
            assert body["warning"]["open_position"]["qty"] > 0
            # The limits must still be unchanged.
            assert st.risk.risk_per_trade_pct == 0.5

            r2 = c.post("/api/risk", json={"risk_per_trade_pct": 1.0,
                                           "acknowledge_open_position": True})
            assert r2.status_code == 200
            assert st.risk.risk_per_trade_pct == 1.0
        finally:
            st.stop_replay()


def test_a_risk_change_without_an_open_position_is_applied_immediately(tmp_path):
    st = _state(tmp_path, "NOOPEN")
    res = st.update_risk({"risk_per_trade_pct": 0.9})
    assert res["applied"] is True
    assert res["warning"] is None
    assert st.risk.risk_per_trade_pct == 0.9


def test_the_open_position_endpoint_reports_the_position(tmp_path):
    from app import create_app
    st = _state(tmp_path, "OPEP")
    app = create_app(state=st)
    app.config["TESTING"] = True
    with app.test_client() as c:
        body = c.get("/api/risk/open_position").get_json()
        assert body["has_open_position"] is False
        st.start_replay(speed_ms=20, use_test_window=False, mode="rules_only", threshold=-99)
        t0 = time.time()
        while time.time() - t0 < 25 and st.replay.get("position") is None:
            time.sleep(0.05)
        try:
            body = c.get("/api/risk/open_position").get_json()
            assert body["has_open_position"] is True
            assert body["open_position"]["qty"] > 0
        finally:
            st.stop_replay()


def test_a_risk_change_is_recorded_in_the_journal(tmp_path):
    st = _state(tmp_path, "JRNL")
    st.update_risk({"risk_per_trade_pct": 0.75})
    events = st.journal.events()
    assert any(e["event_type"] == "risk_settings_changed" for e in events)
    ev = [e for e in events if e["event_type"] == "risk_settings_changed"][0]
    assert "risk_per_trade_pct" in ev["reason"]
    assert "0.5" in ev["detail"] and "0.75" in ev["detail"]


# ---------------------------------------------------------------------------
# 5. The kill switch reason is saved in the journal
# ---------------------------------------------------------------------------

def test_the_kill_switch_reason_is_saved_as_a_journal_event(tmp_path):
    st = _state(tmp_path, "KILL")
    st.set_kill(True, reason="Revenge trading after 3 losses — stepping away for the day")
    events = st.journal.events()
    assert len(events) == 1
    ev = events[0]
    assert ev["event_type"] == "kill_switch_engaged"
    assert "Revenge trading" in ev["reason"]
    assert ev["created_at"]


def test_a_kill_switch_without_a_reason_is_still_recorded(tmp_path):
    st = _state(tmp_path, "KILL2")
    st.set_kill(True)
    events = st.journal.events()
    assert len(events) == 1
    assert events[0]["event_type"] == "kill_switch_engaged"
    assert events[0]["reason"]


def test_a_kill_switch_is_NOT_a_trade(tmp_path):
    """The journal trade count must stay a trade count."""
    st = _state(tmp_path, "KILL3")
    st.set_kill(True, reason="stop")
    assert st.journal.count() == 0
    assert st.journal.event_count() == 1
    ov = st.journal.overview()
    assert ov["trades"] == 0


def test_the_kill_switch_square_off_trade_carries_the_reason(tmp_path):
    st = _state(tmp_path, "KILL4")
    st.start_replay(speed_ms=20, use_test_window=False, mode="rules_only", threshold=-99)
    t0 = time.time()
    while time.time() - t0 < 25 and st.replay.get("position") is None:
        time.sleep(0.05)
    assert st.replay.get("position") is not None
    st.set_kill(True, reason="Data looked wrong")
    trades = st.journal.list()
    assert len(trades) == 1
    assert trades[0]["exit_reason"] == "kill_switch_square_off"
    assert "Data looked wrong" in trades[0]["notes"]


def test_releasing_the_kill_switch_is_also_recorded(tmp_path):
    st = _state(tmp_path, "KILL5")
    st.set_kill(True, reason="stop")
    st.set_kill(False, reason="calm again")
    types = [e["event_type"] for e in st.journal.events()]
    assert "kill_switch_engaged" in types and "kill_switch_released" in types


def test_the_kill_api_accepts_a_reason(tmp_path):
    from app import create_app
    st = _state(tmp_path, "KILLAPI")
    app = create_app(state=st)
    app.config["TESTING"] = True
    with app.test_client() as c:
        r = c.post("/api/kill", json={"on": True, "reason": "need a break"})
        assert r.status_code == 200
        assert r.get_json()["reason"] == "need a break"
        evs = c.get("/api/journal/events").get_json()["events"]
        assert any("need a break" in e["reason"] for e in evs)


def test_the_events_export_carries_the_reason(tmp_path):
    from app import create_app
    st = _state(tmp_path, "KILLEX")
    app = create_app(state=st)
    app.config["TESTING"] = True
    with app.test_client() as c:
        c.post("/api/kill", json={"on": True, "reason": "exported reason"})
        text = c.get("/api/export/journal_events").data.decode()
        header = text.splitlines()[0]
        assert "event_type" in header and "reason" in header
        assert "exported reason" in text
