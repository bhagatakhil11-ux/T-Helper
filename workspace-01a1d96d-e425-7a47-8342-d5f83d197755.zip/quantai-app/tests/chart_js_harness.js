/* Headless DOM shim + chart-logic harness.
 *
 * Runs the real inline JavaScript from static/index.html under a minimal DOM so
 * the chart drawing / zoom / pan / crosshair code paths are actually executed
 * (not just syntax-checked). The canvas 2D context is a recorder, so we can
 * assert WHAT was drawn.
 */
const fs = require('fs');
const path = require('path');
const http = require('http');

const ROOT = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(ROOT, 'static', 'index.html'), 'utf8');
const js = html.match(/<script>([\s\S]*?)<\/script>/)[1];

let failures = 0;
function check(name, cond, extra) {
  if (cond) console.log('  PASS ' + name);
  else { failures++; console.log('  FAIL ' + name + (extra !== undefined ? ' :: ' + JSON.stringify(extra) : '')); }
}

// ------------------------------------------------------------------ DOM shim
const calls = [];
const byCanvas = {};
function makeCtx(id) {
  const rec = { id, ops: [] };
  byCanvas[id] = rec;
  const push = (op) => { rec.ops.push(op); calls.push({ canvasId: id, op }); };
  return {
    canvasId: id,
    set fillStyle(v) { push(['fillStyle', v]); }, get fillStyle() { return '#000'; },
    set strokeStyle(v) { push(['strokeStyle', v]); }, get strokeStyle() { return '#000'; },
    set lineWidth(v) { push(['lineWidth', v]); }, get lineWidth() { return 1; },
    set font(v) { push(['font', v]); }, get font() { return ''; },
    set globalAlpha(v) { push(['globalAlpha', v]); }, get globalAlpha() { return 1; },
    set textAlign(v) { push(['textAlign', v]); }, get textAlign() { return 'left'; },
    setLineDash(a) { push(['setLineDash', a]); },
    clearRect() { push(['clearRect']); },
    beginPath() { push(['beginPath']); },
    moveTo(x, y) { push(['moveTo', x, y]); },
    lineTo(x, y) { push(['lineTo', x, y]); },
    arc() { push(['arc']); },
    closePath() { push(['closePath']); },
    stroke() { push(['stroke']); },
    fill() { push(['fill']); },
    fillRect(x, y, w, h) { push(['fillRect', x, y, w, h]); },
    strokeRect(x, y, w, h) { push(['strokeRect', x, y, w, h]); },
    fillText(t, x, y) { push(['fillText', String(t), x, y]); },
    measureText(t) { return { width: String(t).length * 6 }; },
    save() { push(['save']); },
    restore() { push(['restore']); },
    translate() {}, scale() {}, setTransform() {},
  };
}

const elements = {};
/* Build stub elements for the data-* hooks the app attaches handlers to,
 * so the harness can actually CLICK a zone row / timeframe row. */
function stubNodes(html) {
  const out = [];
  const re = /data-(zone|tfkey)="([^"]*)"/g;
  let m;
  while ((m = re.exec(String(html || ''))) !== null) {
    const n = makeEl('node');
    n.dataset = { zone: m[1], tfkey: m[1], zoneid: m[1] };
    n.dataset[m[2]] = m[1];
    out.push(n);
  }
  return out;
}
function makeEl(id) {
  const el = {
    id, _html: '', _text: '', value: '', style: {}, dataset: {}, clientWidth: 900,
    width: 900, height: 380, className: '', checked: false, options: [],
    classList: { add() {}, remove() {}, contains() { return false; } },
    addEventListener(ev, fn) { (this._ev = this._ev || {})[ev] = fn; },
    removeEventListener() {},
    getBoundingClientRect() { return { left: 0, top: 0, width: 900, height: this.height || 300, right: 900, bottom: 300 }; },
    getContext() { return (this._ctx = this._ctx || makeCtx(id)); },
    querySelectorAll() { return el._nodes || []; },
    appendChild() {}, removeChild() {},
    focus() {}, blur() {},
    scrollIntoView() {},
  };
  Object.defineProperty(el, 'innerHTML', {
    get() { return el._html; },
    set(v) { el._html = v; el._nodes = stubNodes(v); },
  });
  Object.defineProperty(el, 'textContent', { get() { return el._text; }, set(v) { el._text = v; } });
  el.offsetWidth = 200; el.offsetHeight = 100;
  return el;
}
function getEl(sel) {
  const id = sel.replace(/^#/, '');
  if (!elements[id]) elements[id] = makeEl(id);
  return elements[id];
}

global.document = {
  body: { classList: { add() {}, remove() {}, contains() { return false; } } },
  documentElement: {},
  querySelector: (s) => getEl(s),
  querySelectorAll: (s) => {
    if (s === 'nav button') return [makeEl('nav1'), makeEl('nav2')];
    if (s === '.panel') return [makeEl('p1')];
    return [];
  },
  addEventListener() {},
  createElement: () => makeEl('tmp'),
};
global.window = {
  devicePixelRatio: 1,
  addEventListener() {},
  location: { href: '' },
  getComputedStyle: () => ({ getPropertyValue: () => '#123456' }),
};
global.getComputedStyle = global.window.getComputedStyle;
/* A real (in-memory) localStorage so the "remember the last view" logic is
 * actually exercised rather than stubbed out. */
const _lsStore = new Map();
global.localStorage = {
  getItem: (k) => (_lsStore.has(String(k)) ? _lsStore.get(String(k)) : null),
  setItem: (k, v) => { _lsStore.set(String(k), String(v)); },
  removeItem: (k) => { _lsStore.delete(String(k)); },
  clear: () => { _lsStore.clear(); },
};
global.setInterval = () => 0;
global.clearInterval = () => {};
global.setTimeout = (fn) => { try { fn(); } catch (e) {} return 0; };
global.alert = () => {};
global.fetch = () => Promise.reject(new Error('no network in harness'));

// ------------------------------------------------------------------ payload
function get(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ ok: res.statusCode < 400, status: res.statusCode, json: () => Promise.resolve(JSON.parse(body)) }));
    }).on('error', reject);
  });
}

// ------------------------------------------------------------------ run
(async () => {
  console.log('== chart JS harness ==');
  const api = process.env.QAI_API || 'http://127.0.0.1:8000';

  /* Proxy every request to the REAL server so the harness exercises the
   * live endpoints (as-of truncation, timeframe routes, groups, compare). */
  global.fetch = async (url) => {
    const u = String(url);
    const path = u.replace(/^https?:\/\/[^/]+/, '').replace(/^\/api/, '/api');
    if (path.startsWith('/api/')) {
      const r = await get(api + path);
      const body = await r.json();
      return { ok: r.status < 400, status: r.status, json: async () => body };
    }
    return { ok: true, status: 200, json: async () => ({}) };
  };

  const fn = new Function(js + '\n;return {chLoad:chLoad,chRender:chRender,chRenderPanels:chRenderPanels,chIdxAt:chIdxAt,chGeom:chGeom,CH:CH,chSelectBar:chSelectBar,chSetView:chSetView,chEnsureSymbols:chEnsureSymbols,chIndicatorBox:chIndicatorBox,chApplyTimeframes:chApplyTimeframes,chSwitchTimeframe:chSwitchTimeframe,chRenderCompare:chRenderCompare,chRenderLevels:chRenderLevels,chRenderZoneDetail:chRenderZoneDetail,chSelectZone:chSelectZone,chRenderSummary:chRenderSummary,chRenderPatterns:chRenderPatterns,chZoneAt:chZoneAt,chSaveView:chSaveView,chSavedView:chSavedView,chRowsFor:chRowsFor};');
  const api2 = fn();

  await api2.chLoad('DEMOFIX|1D', null, false);
  check('chart loaded', api2.CH.data && api2.CH.data.candles.length > 0, api2.CH.data && api2.CH.data.candles.length);
  check('indicators present', api2.CH.data && Object.keys(api2.CH.data.indicators).length === 18);

  const before = calls.length;
  api2.chRenderPanels();
  const drawn = calls.slice(before);
  const on = (cid, op) => drawn.some((c) => c.canvasId === cid && c.op[0] === op);
  const onText = (cid, re) => drawn.some((c) => c.canvasId === cid && c.op[0] === 'fillText' && re.test(c.op[1]));
  const rectOf = (cid, minH) => drawn.some((c) => c.canvasId === cid && c.op[0] === 'fillRect' && c.op[4] > minH);
  check('candles drawn', drawn.some((c) => c.op[0] === 'fillRect'), 'no fillRect');
  check('volume bars drawn on #chVol', on('chVol', 'fillRect'));
  check('rsi line drawn on #chRsi', on('chRsi', 'stroke'));
  check('macd drawn on #chMacd', on('chMacd', 'fillRect'));
  check('support/resistance zone drawn', rectOf('chPrice', 1.5));
  check('date axis labels drawn', onText('chPrice', /^\d{4}-\d{2}-\d{2}/));
  check('indicator legend drawn', onText('chPrice', /^— EMA/));

  // ---- zoom (wheel) changes the visible window
  const g0 = api2.chGeom();
  const canvas = getEl('#chPrice');
  const wheelEvt = { clientX: 450, clientY: 100, deltaY: -120, preventDefault() {} };
  const wheelHandler = canvas._ev && canvas._ev.wheel;
  check('wheel handler bound', !!wheelHandler);
  if (wheelHandler) {
    wheelHandler(wheelEvt);
    const g1 = api2.chGeom();
    check('wheel zoom shrinks the window', g1.span < g0.span, { before: g0.span, after: g1.span });
  }

  // ---- crosshair index mapping
  const idx = api2.chIdxAt(getEl('#chPrice'), 450);
  const g2 = api2.chGeom();
  check('crosshair index inside the visible window', idx !== null && idx >= g2.s && idx < g2.e, { idx, s: g2.s, e: g2.e });
  check('crosshair index moves with the mouse', api2.chIdxAt(getEl('#chPrice'), 120) !== api2.chIdxAt(getEl('#chPrice'), 800));

  // ---- hover tooltip shows OHLCV
  api2.CH.hover = g2.s;
  const tip = getEl('#chTip');
  check('tooltip element exists', !!tip);

  // ---- indicator toggles change what is drawn
  const n0 = calls.length;
  api2.CH.enabled['ema_9'] = false;
  api2.chRenderPanels();
  const noEma = calls.slice(n0).some((c) => c.canvasId === 'chPrice' &&
    c.op[0] === 'fillText' && c.op[1] === '— EMA 9');
  check('chart price canvas id used', calls.some((c) => c.canvasId === 'chPrice'));
  check('disabling an indicator removes its legend', !noEma);
  api2.CH.enabled['ema_9'] = true;

  // ---- as-of selection truncates
  await api2.chSelectBar(500, true);
  check('as-of selection truncates the payload', api2.CH.data.candles.length === 501, api2.CH.data.candles.length);
  check('as-of selection marks truncation', api2.CH.data.truncated === true);

  // ---- timeframe switching ------------------------------------------------
  await api2.chEnsureSymbols();
  check('symbol groups loaded', Object.keys(api2.CH.groups).length > 0, Object.keys(api2.CH.groups));
  const symsAvailable = Object.keys(api2.CH.groups);
  const firstSym = symsAvailable[0];
  const tfRows = api2.chRowsFor(firstSym);
  check('more than one timeframe is offered for the symbol', tfRows.length >= 2, tfRows.map(r => r.timeframe));
  const tfSel = getEl('#chTimeframe');
  check('timeframe picker populated', tfSel.innerHTML.indexOf('<option') >= 0, tfSel.innerHTML.slice(0, 80));

  const otherTf = tfRows.find(r => r.key !== api2.CH.key);
  if (otherTf) {
    await api2.chSwitchTimeframe(otherTf.key);
    check('switching timeframe reloads the chart', api2.CH.key === otherTf.key, api2.CH.key);
    check('switched timeframe is shown in the meta', api2.CH.data.meta.timeframe === otherTf.timeframe, api2.CH.data.meta.timeframe);
    check('switched symbol stays the same', api2.CH.data.meta.symbol === api2.CH.symbol, api2.CH.data.meta.symbol);
    check('view was remembered', (api2.chSavedView() || {}).key === otherTf.key, api2.chSavedView());
    check('view memory records the timeframe', (api2.chSavedView() || {}).timeframe === otherTf.timeframe, api2.chSavedView());
  }

  // ---- cross-timeframe comparison table ----------------------------------
  await api2.chRenderCompare();
  const cmp = getEl('#chCompare');
  check('cross-timeframe comparison rendered', cmp.innerHTML.indexOf('Timeframe') >= 0, cmp.innerHTML.slice(0, 120));
  check('comparison lists more than one timeframe', (cmp.innerHTML.match(/data-tfkey/g) || []).length >= 2,
        (cmp.innerHTML.match(/data-tfkey/g) || []).length);

  // ---- confluence ---------------------------------------------------------
  api2.chRenderSummary();
  const sum = getEl('#chSummary');
  check('confluence section is rendered', sum.innerHTML.indexOf('Confluence') >= 0, sum.innerHTML.slice(0, 200));
  check('confluence counts bullish readings', /pointing up/.test(sum.innerHTML));
  check('confluence counts bearish readings', /pointing down/.test(sum.innerHTML));
  check('confluence states it is not a signal', /not a/i.test(sum.innerHTML) && /signal/i.test(sum.innerHTML));
  check('confluence never shows a BUY button', sum.innerHTML.indexOf('BUY') < 0 && sum.innerHTML.indexOf('>Buy<') < 0);

  // ---- clickable zones ----------------------------------------------------
  api2.chRenderLevels();
  const lvl = getEl('#chLevels');
  const zoneRows = lvl.querySelectorAll('[data-zone]');
  check('zone rows are clickable', zoneRows.length > 0, zoneRows.length);
  check('zone rows carry touch counts', /Touches/.test(lvl.innerHTML));
  check('zone rows carry reaction counts', /Reactions/.test(lvl.innerHTML));
  const firstZone = api2.CH.data.levels.zones[0];
  if (firstZone && zoneRows.length) {
    api2.chSelectZone(firstZone.zone_id);
    const det = getEl('#chZoneDetail');
    check('zone detail opens on click', det.innerHTML.length > 0);
    check('zone detail shows the touch count', det.innerHTML.indexOf('price touches') >= 0, det.innerHTML.slice(0, 200));
    check('zone detail shows the reaction rate', det.innerHTML.indexOf('reaction rate') >= 0);
    check('zone detail shows the touch history table', det.innerHTML.indexOf('Touch &amp; reaction history') >= 0);
    check('zone detail shows a strength label', /(strong|moderate|weak|failed|untested)/.test(det.innerHTML));
    check('zone detail card becomes visible', getEl('#chZoneCard').style.display === '', getEl('#chZoneCard').style.display);
    check('selected zone is remembered in state', api2.CH.zone === firstZone.zone_id, api2.CH.zone);
    // clicking the band on the chart finds the same zone
    const hit = api2.chZoneAt(300);
    check('chart band hit-test finds a zone or nothing', hit === null || !!hit.zone_id);
  }

  // ---- pattern strength ----------------------------------------------------
  api2.chRenderPatterns();
  const pat = getEl('#chPatterns');
  check('patterns table has a strength column', /Strength/.test(pat.innerHTML));
  check('patterns show a weak/medium/strong label', /(weak|medium|strong)/.test(pat.innerHTML));
  check('patterns explain the strength', /volume/i.test(pat.innerHTML));

  console.log(failures === 0 ? 'ALL CHART JS CHECKS PASSED' : failures + ' CHART JS CHECK(S) FAILED');
  process.exit(failures === 0 ? 0 : 1);
})().catch((e) => { console.error('HARNESS ERROR', e); process.exit(1); });
