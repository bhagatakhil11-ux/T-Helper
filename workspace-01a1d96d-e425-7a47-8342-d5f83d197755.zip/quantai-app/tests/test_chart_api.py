"""Charting API surface + indicator-strategy integration.

Covers: /api/chart/symbols, /api/chart/data (incl. historical as-of views),
/api/chart/export, and the indicator strategy running on the SAME purged split
and unseen test window as the ML / rules strategies.
"""
from __future__ import annotations

import json
import time

import numpy as np
import pandas as pd
import pytest

from app import create_app
from engine import AppState


@pytest.fixture()
def client(tmp_path):
    st = AppState(store_root=tmp_path / "store")
    app = create_app(state=st)
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c, st


def _csv_bytes(seed, n=500, intraday=False):
    rng = np.random.default_rng(seed)
    if intraday:
        ts = pd.date_range("2024-01-01 09:15", periods=n, freq="15min", tz="Asia/Kolkata")
    else:
        ts = pd.date_range("2021-01-04", periods=n, freq="B", tz="Asia/Kolkata") + pd.Timedelta(hours=15)
    close = 100 * np.exp(np.cumsum(rng.normal(0.0003, 0.012, n)))
    open_ = np.concatenate([[100.0], close[:-1]])
    df = pd.DataFrame({"timestamp": ts, "open": open_,
                       "high": np.maximum(open_, close) * 1.004,
                       "low": np.minimum(open_, close) * 0.996,
                       "close": close, "volume": rng.integers(1e5, 1e6, n)})
    return df.to_csv(index=False).encode()


def _import(st, tmp_path, sym, seed, tf="1D", intraday=False, n=500):
    p = tmp_path / f"{sym}.csv"
    p.write_bytes(_csv_bytes(seed, n=n, intraday=intraday))
    st.import_csv(p, sym, tf, "IMPORTED_CSV", "UNKNOWN_UNVERIFIED")
    return st.key(sym, tf)


# ---------------------------------------------------------------- symbols
def test_chart_symbols_lists_imported_datasets(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "RELIANCE", 1)
    r = c.get("/api/chart/symbols")
    assert r.status_code == 200
    j = r.get_json()
    assert j["ok"] is True
    assert "1m" in j["timeframes"] and "15m" in j["timeframes"] and "1D" in j["timeframes"]
    syms = j["symbols"]
    assert len(syms) == 1
    assert syms[0]["symbol"] == "RELIANCE"
    assert syms[0]["timeframe"] == "1D"
    assert syms[0]["is_real_market_data"] is True
    assert syms[0]["bars"] == 500


def test_chart_symbols_empty_when_nothing_imported(client):
    c, st = client
    j = c.get("/api/chart/symbols").get_json()
    assert j["symbols"] == []


def test_chart_symbols_marks_test_fixture_as_not_real_market_data(client, tmp_path):
    c, st = client
    p = tmp_path / "fx.csv"
    p.write_bytes(_csv_bytes(2))
    st.import_csv(p, "FIX", "1D", "TEST_FIXTURE", "UNKNOWN_UNVERIFIED")
    j = c.get("/api/chart/symbols").get_json()
    assert j["symbols"][0]["is_real_market_data"] is False
    assert j["symbols"][0]["verification_status"] == "TEST_FIXTURE_NOT_MARKET_DATA"


# ---------------------------------------------------------------- chart data
def test_chart_data_returns_full_payload(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "TCS", 3)
    r = c.get("/api/chart/data")
    assert r.status_code == 200
    j = r.get_json()
    assert j["status"] == "ok"
    assert len(j["candles"]) == 500
    assert len(j["indicators"]) == 18
    assert isinstance(j["patterns"], list)
    assert j["levels"]["zones"] is not None
    assert j["summary"]["trend"]
    assert j["meta"]["is_real_market_data"] is True


def test_chart_data_as_of_truncates_history(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "INFY", 4)
    j = c.get("/api/chart/data?as_of_bar=300").get_json()
    assert j["truncated"] is True
    assert len(j["candles"]) == 301
    assert j["as_of_bar"] == 300
    assert j["meta"]["total_bars"] == 500
    assert all(p["bar"] <= 300 for p in j["patterns"])


def test_chart_data_for_a_specific_symbol_key(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "HDFC", 5)
    _import(st, tmp_path, "SBIN", 6)
    j = c.get("/api/chart/data?key=SBIN%7C1D").get_json()
    assert j["meta"]["symbol"] == "SBIN"
    assert len(j["candles"]) == 500


def test_chart_data_unknown_key_is_a_clean_error(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "AAA", 7)
    r = c.get("/api/chart/data?key=NOPE%7C1D")
    assert r.status_code == 400
    assert "error" in r.get_json()


def test_chart_data_without_any_dataset_is_a_clean_error(client):
    c, st = client
    r = c.get("/api/chart/data")
    assert r.status_code == 400
    assert "error" in r.get_json()


def test_chart_data_reports_missing_bars(client, tmp_path):
    c, st = client
    p = tmp_path / "gap.csv"
    df = pd.read_csv(pd.io.common.StringIO(_csv_bytes(8).decode()))
    # remove 3 bars in the middle -> a real gap, never interpolated
    df = df.drop(index=[100, 101, 102]).reset_index(drop=True)
    p.write_bytes(df.to_csv(index=False).encode())
    st.import_csv(p, "GAP", "1D", "IMPORTED_CSV", "UNKNOWN_UNVERIFIED")
    j = c.get("/api/chart/data").get_json()
    assert j["meta"]["missing_bars"] >= 1
    assert any("missing" in n for n in j["data_notes"])
    assert len(j["candles"]) == len(df)


def test_chart_export_downloads_json(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "LT", 9)
    r = c.get("/api/chart/export")
    assert r.status_code == 200
    assert "application/json" in r.headers["Content-Type"]
    body = json.loads(r.data.decode())
    assert body["status"] == "ok"
    assert len(body["candles"]) == 500
    assert "indicators" in body and "patterns" in body and "levels" in body


def test_intraday_dataset_gives_a_valid_vwap(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "INTR", 10, tf="15m", intraday=True)
    j = c.get("/api/chart/data").get_json()
    assert j["meta"]["vwap_valid"] is True
    assert j["indicators"]["vwap"][-1] is not None


# ---------------------------------------------------------------- indicator strategy
def test_indicator_strategy_runs_on_the_same_purged_split(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "STRAT", 11, n=900)
    st.run_research(horizon=5, entry_threshold=0.42)
    rep = st.research
    assert rep is not None
    bt = rep["backtests"]
    assert "indicators" in bt
    # every strategy is evaluated on the same unseen test window
    assert rep["test_start_bar"] > 0
    for mode in ("ensemble", "rules_only", "ml_only", "indicators", "buy_and_hold"):
        assert mode in bt
        assert "net_return_pct" in bt[mode]
        assert "total_trades" in bt[mode]
        assert rep["equity_curves"][mode], f"{mode} produced no equity curve"
        assert rep["trade_logs"][mode] is not None


def test_indicator_strategy_is_causal_uses_no_future_bars(client, tmp_path):
    """Truncating the dataset must not change the trades that already happened.

    A backtest run on the full series and a run on a shortened series must
    produce identical trades for every trade that closes inside the shortened
    window — otherwise a signal had read a future bar.
    """
    from quantai.backtest import run_backtest
    from quantai.config import CostModel, RiskConfig
    from quantai.features import build_features
    from quantai.indicators import compute_indicators

    df = pd.read_csv(pd.io.common.StringIO(_csv_bytes(12, n=400).decode()))
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True).dt.tz_convert("Asia/Kolkata")
    df["volume"] = df["volume"].astype("int64")
    cost = CostModel(slippage_pct=0.0005, brokerage_flat_inr=20.0, brokerage_pct_cap=0.0003)
    risk = RiskConfig()

    def run(frame):
        feats = build_features(frame)
        ind = compute_indicators(frame, "1D")
        return run_backtest(frame, feats, 300, cost, risk, "1D", mode="indicators",
                            entry_threshold=0.42, indicator_df=ind)

    full = run(df)
    cut = 360
    short = run(df.iloc[:cut].reset_index(drop=True))

    short_trades = short.trade_log
    assert short_trades, "the shortened run produced no trades to compare"
    # every trade that closed inside the shortened window must be identical
    full_inside = [t for t in full.trade_log if t["exit_bar"] < cut]
    # The shortened run force-liquidates any open position on its last bar, so
    # it may hold one extra trade that the full run kept open.
    assert len(full_inside) in (len(short_trades), len(short_trades) - 1)
    common = min(len(full_inside), len(short_trades))
    for a, b in zip(full_inside[:common], short_trades[:common]):
        assert a["entry_bar"] == b["entry_bar"]
        assert a["exit_bar"] == b["exit_bar"]
        assert a["entry"] == pytest.approx(b["entry"])
        assert a["exit"] == pytest.approx(b["exit"])
        assert a["qty"] == b["qty"]
        assert a["entry_reason"] == b["entry_reason"]


def test_replay_accepts_indicators_mode(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "REP", 13, n=400)
    st.start_replay(speed_ms=60, use_test_window=False, mode="indicators", threshold=0.0)
    assert st.replay["strategy_mode"] == "indicators"
    time.sleep(0.4)
    st.stop_replay()


def test_unknown_replay_mode_falls_back_to_ensemble(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "REP2", 14, n=400)
    st.start_replay(speed_ms=60, use_test_window=False, mode="nonsense")
    assert st.replay["strategy_mode"] == "ensemble"
    st.stop_replay()


def test_research_mode_allowlist_includes_indicators(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "MODE", 15, n=400)
    # an invalid mode must be rejected before any worker is started
    r = c.post("/api/research", json={"mode": "not_a_mode"})
    assert r.status_code == 400
    assert "mode must be" in r.get_json()["error"]
    assert st.research_busy is False


def test_research_accepts_indicators_mode(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "MODE2", 16, n=500)
    r = c.post("/api/research", json={"mode": "indicators", "horizon": 5})
    assert r.status_code == 200
    t0 = time.time()
    while time.time() - t0 < 120 and st.research_busy:
        time.sleep(0.2)
    assert st.research is not None
    assert "indicators" in st.research["backtests"]
    # the requested mode must be reported back and must NOT be shadowed by the
    # backtest loop variable (it used to report "buy_and_hold")
    assert st.research["selected_mode"] == "indicators"
