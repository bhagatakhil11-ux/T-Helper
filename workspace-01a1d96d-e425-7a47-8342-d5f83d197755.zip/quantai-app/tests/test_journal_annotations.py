"""Journal tags, emotional state, strategy breakdown and live replay stats.

These tests pin down the guarantees the new features are supposed to give:

* a tag is normalised (lower-case, hyphenated, de-duplicated) and never
  silently eats the trader's notes,
* an emotional state is stored and can be filtered on,
* the strategy / emotion / tag breakdowns are computed from real journal rows
  and never invent a profit factor when there is no losing trade,
* the live replay readout is derived from realised fills, updates after every
  closed trade, and reports "not enough data" instead of a fake 0.0,
* the exports carry the new fields.
"""
from __future__ import annotations

import csv
import io
import sqlite3

import pytest

from journal import (EMOTION_STATES, JOURNAL_FIELDS, SUGGESTED_TAGS, Journal,
                     normalize_emotion, normalize_tags, text_to_tags,
                     tags_to_text)
from quantai.metrics import (new_live_stats, replay_live_stats,
                             update_live_stats)


@pytest.fixture()
def journal(tmp_path):
    return Journal(tmp_path / "journal.db")


def _trade(j, tid, strategy="ensemble", pnl=100.0, costs=5.0, day=1, **extra):
    j.add({
        "id": tid, "run_id": "r1", "dataset_id": "d", "symbol": "TEST",
        "timeframe": "1D", "strategy": strategy, "direction": "LONG", "qty": 10,
        "entry_time": f"2024-01-0{day}T10:00:00+05:30", "entry_price": 100,
        "exit_time": f"2024-01-0{day}T15:00:00+05:30", "exit_price": 110,
        "pnl": pnl, "costs": costs, "entry_reason": "signal",
        "exit_reason": "target", **extra,
    })


# ---------------------------------------------------------------------------
# Tag normalisation
# ---------------------------------------------------------------------------

def test_tags_are_normalised_lowercased_and_deduplicated():
    assert normalize_tags("Breakout") == ["breakout"]
    assert normalize_tags(["Breakout", "breakout"]) == ["breakout"]
    assert normalize_tags(["Mean Reversion"]) == ["mean-reversion"]
    assert normalize_tags("  a , B ,, a ") == ["a", "b"]
    assert normalize_tags([]) == []
    assert normalize_tags(None) == []
    assert normalize_tags("") == []


def test_tag_count_and_length_are_capped():
    many = normalize_tags([f"tag{i}" for i in range(50)])
    assert len(many) <= 8
    assert all(len(t) <= 32 for t in many)


def test_tags_round_trip_through_the_stored_text():
    assert text_to_tags(tags_to_text(["breakout", "news"])) == ["breakout", "news"]
    assert text_to_tags("") == []


def test_emotion_is_normalised_and_capped():
    assert normalize_emotion("Calm") == "calm"
    assert normalize_emotion("REVENGE") == "revenge"
    assert normalize_emotion("") == ""
    assert normalize_emotion(None) == ""
    assert len(normalize_emotion("x" * 100)) <= 24


def test_suggested_vocabulary_contains_the_examples_the_user_asked_for():
    for t in ("breakout", "mean-reversion", "news", "mistake"):
        assert t in SUGGESTED_TAGS
    for e in ("calm", "fomo", "revenge", "neutral"):
        assert e in EMOTION_STATES


# ---------------------------------------------------------------------------
# Storing and annotating
# ---------------------------------------------------------------------------

def test_trade_stores_tags_and_emotion(journal):
    _trade(journal, "t1", tags=["Breakout", "news"], emotion="Calm")
    row = journal.list()[0]
    assert row["tags"] == "breakout,news"
    assert row["tag_list"] == ["breakout", "news"]
    assert row["emotion"] == "calm"


def test_annotating_one_field_does_not_wipe_the_others(journal):
    _trade(journal, "t1", tags=["news"], emotion="calm")
    journal.update_note("t1", "my note")
    assert journal.update_annotation("t1", tags=["news", "mistake"])
    row = journal.list()[0]
    assert row["notes"] == "my note", "a tag edit must not erase the notes"
    assert row["tag_list"] == ["news", "mistake"]
    assert row["emotion"] == "calm", "a tag edit must not erase the emotion"

    assert journal.update_annotation("t1", emotion="revenge")
    row = journal.list()[0]
    assert row["emotion"] == "revenge"
    assert row["tag_list"] == ["news", "mistake"], "an emotion edit must not erase the tags"
    assert row["notes"] == "my note"


def test_annotating_an_unknown_trade_returns_false(journal):
    _trade(journal, "t1")
    assert journal.update_annotation("nope", tags=["x"]) is False
    assert journal.update_annotation("t1") is False   # nothing to change


def test_journal_migrates_a_legacy_database_file(tmp_path):
    """An existing journal file gains the new columns without losing rows."""
    db = tmp_path / "legacy.db"
    conn = sqlite3.connect(db)
    conn.execute("""
        CREATE TABLE trades (
            id TEXT PRIMARY KEY, created_at TEXT NOT NULL, run_id TEXT,
            dataset_id TEXT, symbol TEXT, timeframe TEXT, strategy TEXT,
            direction TEXT, qty INTEGER, entry_time TEXT, entry_price REAL,
            exit_time TEXT, exit_price REAL, stop REAL, target REAL, pnl REAL,
            costs REAL, entry_reason TEXT, exit_reason TEXT, notes TEXT DEFAULT '')
    """)
    conn.execute("INSERT INTO trades (id, created_at, symbol, strategy, pnl, costs, "
                 "exit_time, notes) VALUES ('old','2024-01-01','OLD','ensemble',75,3,"
                 "'2024-01-01T10:00:00+05:30','legacy note')")
    conn.commit()
    conn.close()

    j = Journal(db)
    cols = {r[1] for r in sqlite3.connect(db).execute("PRAGMA table_info(trades)")}
    assert "tags" in cols and "emotion" in cols
    assert j.count() == 1
    assert j.list()[0]["notes"] == "legacy note"
    assert j.update_annotation("old", tags=["news"], emotion="neutral")
    assert j.list()[0]["tag_list"] == ["news"]


# ---------------------------------------------------------------------------
# Filtering
# ---------------------------------------------------------------------------

def test_filter_by_tag_matches_whole_tags_only(journal):
    _trade(journal, "t1", tags=["news"])
    _trade(journal, "t2", tags=["news-gap"])
    assert [r["id"] for r in journal.list(tag="news")] == ["t1"]
    assert len(journal.list(tag="news-gap")) == 1


def test_filter_by_emotion(journal):
    _trade(journal, "t1", emotion="calm")
    _trade(journal, "t2", emotion="revenge")
    _trade(journal, "t3")
    assert [r["id"] for r in journal.list(emotion="revenge")] == ["t2"]
    assert len(journal.list()) == 3


def test_bulk_tag_add_remove_and_replace(journal):
    _trade(journal, "t1")
    _trade(journal, "t2")
    assert journal.bulk_tag("mistake", run_id="r1") == 2
    assert all("mistake" in r["tag_list"] for r in journal.list())
    assert journal.bulk_tag("mistake", run_id="r1", mode="remove") == 2
    assert all(r["tag_list"] == [] for r in journal.list())
    _trade(journal, "t3", tags=["breakout"])
    journal.bulk_tag("news", trade_ids=["t3"], mode="replace")
    assert journal.list(tag="news")[0]["id"] == "t3"


# ---------------------------------------------------------------------------
# Breakdowns
# ---------------------------------------------------------------------------

def test_strategy_breakdown_splits_the_trades(journal):
    _trade(journal, "t1", strategy="ensemble", pnl=100.0, day=1)
    _trade(journal, "t2", strategy="ensemble", pnl=-40.0, day=2)
    _trade(journal, "t3", strategy="ml_only", pnl=250.0, day=3)
    rows = journal.breakdown("strategy")
    by = {r["key"]: r for r in rows}
    assert set(by) == {"ensemble", "ml_only"}
    assert by["ensemble"]["trades"] == 2
    assert by["ensemble"]["wins"] == 1 and by["ensemble"]["losses"] == 1
    assert by["ensemble"]["net_pnl"] == 60.0
    assert by["ensemble"]["win_rate_pct"] == 50.0
    assert by["ml_only"]["net_pnl"] == 250.0
    assert by["ml_only"]["profit_factor"] is None, \
        "no losing trade -> the profit factor is undefined, not 0 and not infinite"


def test_emotion_breakdown_includes_not_recorded(journal):
    _trade(journal, "t1", emotion="calm", pnl=100.0)
    _trade(journal, "t2")
    rows = {r["key"]: r for r in journal.breakdown("emotion")}
    assert "calm" in rows and "not recorded" in rows
    assert rows["not recorded"]["trades"] == 1


def test_tag_breakdown_counts_a_multi_tagged_trade_once_per_tag(journal):
    _trade(journal, "t1", tags=["breakout", "news"], pnl=100.0)
    _trade(journal, "t2", tags=["news"], pnl=-50.0)
    rows = {r["key"]: r for r in journal.breakdown("tag")}
    assert rows["news"]["trades"] == 2
    assert rows["news"]["net_pnl"] == 50.0
    assert rows["breakout"]["trades"] == 1
    # The tag rows deliberately do NOT add up to the journal total.
    assert rows["news"]["trades"] + rows["breakout"]["trades"] == 3


def test_overview_carries_the_totals_and_the_breakdowns(journal):
    _trade(journal, "t1", strategy="ensemble", pnl=100.0, tags=["news"], emotion="calm")
    _trade(journal, "t2", strategy="ml_only", pnl=-40.0, tags=["news"], emotion="revenge")
    ov = journal.overview()
    assert ov["trades"] == 2
    assert ov["wins"] == 1 and ov["losses"] == 1
    assert ov["net_pnl"] == 60.0
    assert ov["win_rate_pct"] == 50.0
    assert ov["profit_factor"] == 100.0 / 40.0
    assert ov["tagged_trades"] == 2
    assert ov["emotion_recorded"] == 2
    assert len(ov["by_strategy"]) == 2
    assert len(ov["by_emotion"]) == 2
    assert len(ov["by_tag"]) == 1


def test_breakdown_rejects_an_unknown_dimension(journal):
    with pytest.raises(ValueError):
        journal.breakdown("nonsense")


# ---------------------------------------------------------------------------
# Exports
# ---------------------------------------------------------------------------

def test_journal_csv_export_carries_the_new_fields(journal):
    _trade(journal, "t1", tags=["breakout"], emotion="calm")
    text = journal.to_csv()
    header = text.splitlines()[0].split(",")
    assert "tags" in header and "emotion" in header
    assert "tags" in JOURNAL_FIELDS and "emotion" in JOURNAL_FIELDS
    row = list(csv.DictReader(io.StringIO(text)))[0]
    assert row["tags"] == "breakout"
    assert row["emotion"] == "calm"


def test_breakdown_csv_export_is_well_formed(journal):
    _trade(journal, "t1", strategy="ensemble", pnl=100.0)
    _trade(journal, "t2", strategy="ml_only", pnl=-40.0)
    text = journal.breakdown_csv("strategy")
    rows = list(csv.DictReader(io.StringIO(text)))
    assert len(rows) == 2
    assert {r["key"] for r in rows} == {"ensemble", "ml_only"}
    assert "profit_factor" in rows[0]


# ---------------------------------------------------------------------------
# Live replay statistics
# ---------------------------------------------------------------------------

def test_live_stats_start_empty_and_say_so():
    lv = replay_live_stats(new_live_stats())
    assert lv["trades"] == 0
    assert lv["win_rate_pct"] is None
    assert lv["profit_factor"] is None
    assert lv["expectancy_per_trade"] is None
    assert "No closed trade" in lv["status_reason"]


def test_live_stats_update_after_every_closed_trade():
    s = new_live_stats()
    update_live_stats(s, 100.0, 10.0)
    lv = replay_live_stats(s)
    assert lv["trades"] == 1 and lv["wins"] == 1
    assert lv["win_rate_pct"] == 100.0
    assert lv["realized_pnl"] == 100.0
    assert lv["total_costs"] == 10.0
    # No losing trade yet -> the profit factor is undefined, NOT 0 and NOT 1.
    assert lv["profit_factor"] is None

    update_live_stats(s, -40.0, 10.0)
    lv = replay_live_stats(s)
    assert lv["trades"] == 2 and lv["wins"] == 1 and lv["losses"] == 1
    assert lv["win_rate_pct"] == 50.0
    assert lv["profit_factor"] == 2.5
    assert lv["expectancy_per_trade"] == 30.0
    assert lv["avg_win"] == 100.0 and lv["avg_loss"] == 40.0
    assert lv["payoff_ratio"] == 2.5
    assert lv["best_trade"] == 100.0 and lv["worst_trade"] == -40.0


def test_breakeven_is_not_counted_as_a_loss():
    s = new_live_stats()
    update_live_stats(s, 100.0)
    update_live_stats(s, 0.0)
    update_live_stats(s, -50.0)
    lv = replay_live_stats(s)
    assert lv["breakeven"] == 1
    assert lv["wins"] == 1 and lv["losses"] == 1
    assert lv["win_rate_pct"] == 50.0, "the breakeven must not be in the denominator"


def test_streaks_track_consecutive_wins_and_losses():
    s = new_live_stats()
    for pnl in (10, 20, -5, -6, -7):
        update_live_stats(s, pnl)
    lv = replay_live_stats(s)
    assert lv["current_streak"] == 3 and lv["streak_kind"] == "loss"
    assert lv["max_win_streak"] == 2 and lv["max_loss_streak"] == 3


def test_a_breakeven_breaks_the_streak():
    s = new_live_stats()
    for pnl in (10, 10, 0.0, 10):
        update_live_stats(s, pnl)
    lv = replay_live_stats(s)
    assert lv["current_streak"] == 1, "the breakeven must have ended the win streak"
    assert lv["streak_kind"] == "win"
    assert lv["max_win_streak"] == 2


def test_live_stats_include_the_open_position_and_the_drawdown():
    s = new_live_stats()
    update_live_stats(s, 100.0)
    lv = replay_live_stats(s, [500000, 501000, 498000], 500000, 2.0, 30.0)
    assert lv["unrealized_pnl"] == 30.0
    assert lv["total_pnl"] == 130.0
    assert lv["max_drawdown_pct"] == 2.0
    assert lv["current_drawdown_pct"] > 0
    assert lv["peak_equity"] == 501000.0
