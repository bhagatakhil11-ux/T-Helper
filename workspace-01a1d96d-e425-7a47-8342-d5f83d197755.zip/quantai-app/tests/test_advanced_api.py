"""Advanced API surface: input validation, feed management, background analysis
workers end-to-end, exports, and append-only dataset updates."""
import io
import time

import numpy as np
import pandas as pd
import pytest

from app import create_app
from engine import AppState


@pytest.fixture()
def client(tmp_path):
    st = AppState(store_root=tmp_path / "store")
    app = create_app(state=st)
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c, st


def _csv_bytes(seed, n=400):
    rng = np.random.default_rng(seed)
    ts = pd.date_range("2021-01-04", periods=n, freq="B", tz="Asia/Kolkata") + pd.Timedelta(hours=15)
    close = 100 * np.exp(np.cumsum(rng.normal(0.0003, 0.012, n)))
    open_ = np.concatenate([[100.0], close[:-1]])
    df = pd.DataFrame({"timestamp": ts, "open": open_,
                       "high": np.maximum(open_, close) * 1.004,
                       "low": np.minimum(open_, close) * 0.996,
                       "close": close, "volume": rng.integers(1e5, 1e6, n)})
    return df.to_csv(index=False).encode()


def _import(st, tmp_path, sym, seed):
    p = tmp_path / f"{sym}.csv"
    p.write_bytes(_csv_bytes(seed))
    st.import_csv(p, sym, "1D", "IMPORTED_CSV", "UNKNOWN_UNVERIFIED")
    return st.key(sym, "1D")


def _wait_analysis(client, kind, timeout=60):
    t0 = time.time()
    while time.time() - t0 < timeout:
        r = client.get(f"/api/analysis/{kind}").get_json()
        if not r["busy"]:
            return r
        time.sleep(0.2)
    raise AssertionError(f"{kind} analysis did not finish in {timeout}s")


# ---------------- validation ----------------
def test_portfolio_requires_two_known_symbols(client):
    c, st = client
    assert c.post("/api/portfolio/run", json={"keys": ["A|1D"]}).status_code == 400
    assert c.post("/api/portfolio/run", json={"keys": ["NOPE|1D", "NADA|1D"]}).status_code == 400


def test_portfolio_bad_params_rejected(client, tmp_path):
    c, st = client
    k1 = _import(st, tmp_path, "V1", 1)
    k2 = _import(st, tmp_path, "V2", 2)
    assert c.post("/api/portfolio/run", json={"keys": [k1, k2], "allocation_method": "magic"}).status_code == 400
    assert c.post("/api/portfolio/run", json={"keys": [k1, k2], "max_symbol_weight_pct": 1}).status_code == 400


def test_sensitivity_bad_grid_rejected(client):
    c, st = client
    assert c.post("/api/sensitivity/run", json={"thresholds": [1.5]}).status_code == 400
    assert c.post("/api/sensitivity/run", json={"stop_mults": [1.0, 1.0]}).status_code == 400
    assert c.post("/api/sensitivity/run", json={"mode": "yolo"}).status_code == 400


def test_regime_and_mc_bad_params_rejected(client):
    c, st = client
    assert c.post("/api/regime/run", json={"ema_span": 5}).status_code == 400
    assert c.post("/api/montecarlo/run", json={"n_simulations": 5}).status_code == 400
    assert c.post("/api/montecarlo/run", json={"method": "magic"}).status_code == 400
    assert c.post("/api/montecarlo/run", json={"source": "crystal_ball"}).status_code == 400


def test_unknown_analysis_kind_404(client):
    c, _ = client
    assert c.get("/api/analysis/astrology").status_code == 404
    assert c.get("/api/analysis/portfolio/export").status_code == 404  # nothing ran yet


def test_data_feed_not_manually_selectable(client):
    c, _ = client
    r = c.post("/api/import", data={"file": (io.BytesIO(b"x"), "f.csv"),
                                    "symbol": "X", "timeframe": "1D",
                                    "source_type": "DATA_FEED"},
               content_type="multipart/form-data")
    assert r.status_code == 400


# ---------------- feeds ----------------
def test_feed_lifecycle(client):
    c, st = client
    assert c.post("/api/feeds", json={"name": "v", "url": "https://93.184.216.34/f.csv",
                                      "symbol": "TEST", "timeframe": "1D",
                                      "license_note": "tiny"}).status_code == 400
    assert c.post("/api/feeds", json={"name": "v", "url": "http://93.184.216.34/f.csv",
                                      "symbol": "TEST", "timeframe": "1D",
                                      "license_note": "Licensed vendor export for research."}).status_code == 400
    r = c.post("/api/feeds", json={"name": "v", "url": "https://93.184.216.34/f.csv",
                                   "symbol": "TEST", "timeframe": "1D",
                                   "license_note": "Licensed vendor export for research."})
    assert r.status_code == 200
    assert c.get("/api/feeds").get_json()["feeds"][0]["name"] == "v"
    assert c.delete("/api/feeds/v").status_code == 200
    assert c.get("/api/feeds").get_json()["feeds"] == []


# ---------------- end-to-end background analyses ----------------
def test_portfolio_end_to_end(client, tmp_path):
    c, st = client
    k1 = _import(st, tmp_path, "PORA", 21)
    k2 = _import(st, tmp_path, "PORB", 22)
    r = c.post("/api/portfolio/run", json={"keys": [k1, k2], "allocation_method": "equal",
                                           "max_symbol_weight_pct": 60.0, "mode": "rules_only"})
    assert r.status_code == 200 and r.get_json()["started"]
    res = _wait_analysis(c, "portfolio")
    assert res["error"] is None
    p = res["result"]
    assert p["status"] == "ok"
    assert abs(sum(p["allocations_inr"].values()) - st.risk.initial_capital) < 1e-6
    assert p["correlation"]["status"] == "ok"
    # Snapshot carries the summary; export works.
    snap = c.get("/api/state").get_json()
    assert snap["analyses"]["portfolio"]["run_id"] == p["run_id"]
    exp = c.get("/api/analysis/portfolio/export")
    assert exp.status_code == 200 and b"PORA" in exp.data


def test_sensitivity_and_regime_end_to_end(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "SENS", 31)
    r = c.post("/api/sensitivity/run", json={"thresholds": [0.3, 0.5], "stop_mults": [1.8],
                                             "target_mults": [3.6], "mode": "rules_only"})
    assert r.status_code == 200
    res = _wait_analysis(c, "sensitivity")
    assert res["error"] is None
    assert res["result"]["grid_size"] == 2
    assert res["result"]["stability"] in ("STABLE", "MIXED", "FRAGILE")
    assert c.get("/api/analysis/sensitivity/export").status_code == 200

    r = c.post("/api/regime/run", json={"mode": "rules_only"})
    assert r.status_code == 200
    res = _wait_analysis(c, "regime")
    assert res["error"] is None
    assert set(res["result"]["per_regime"]) == {"BULLISH", "BEARISH", "SIDEWAYS"}
    assert c.get("/api/analysis/regime/export").status_code == 200


def test_montecarlo_from_journal_end_to_end(client, tmp_path):
    c, st = client
    for i in range(30):
        st.journal.add({"symbol": "MC", "pnl": 100.0 if i % 3 else -150.0, "costs": 20.0})
    r = c.post("/api/montecarlo/run", json={"source": "journal", "n_simulations": 500,
                                            "method": "block", "block_size": 4, "seed": 7})
    assert r.status_code == 200
    res = _wait_analysis(c, "montecarlo")
    assert res["error"] is None
    mc = res["result"]
    assert mc["status"] == "ok" and mc["n_trades"] == 30
    assert 0 <= mc["probability_of_loss"] <= 1
    assert c.get("/api/analysis/montecarlo/export").status_code == 200


def test_montecarlo_empty_journal_is_insufficient_not_fake(client):
    c, st = client
    r = c.post("/api/montecarlo/run", json={"source": "journal"})
    assert r.status_code == 200
    res = _wait_analysis(c, "montecarlo")
    assert res["error"] is None
    assert res["result"]["status"] == "insufficient"
    assert res["result"]["n_trades"] == 0
    assert "probability_of_loss" not in res["result"]  # no fabricated distribution


def test_montecarlo_research_without_trades_errors(client):
    c, st = client
    r = c.post("/api/montecarlo/run", json={"source": "research"})
    assert r.status_code == 200  # started, then fails honestly
    res = _wait_analysis(c, "montecarlo")
    assert res["error"] and "No trades" in res["error"]


def test_append_update_via_api(client, tmp_path):
    c, st = client
    key = _import(st, tmp_path, "UPD", 41)
    base = pd.read_csv(io.BytesIO(_csv_bytes(41)))
    base["timestamp"] = pd.to_datetime(base["timestamp"])
    tail = base.tail(5)
    ts = pd.date_range("2023-01-02", periods=5, freq="B", tz="Asia/Kolkata") + pd.Timedelta(hours=15)
    extra = tail.copy()
    extra["timestamp"] = ts
    upd = pd.concat([tail, extra]).to_csv(index=False).encode()
    r = c.post("/api/dataset/update", data={"key": key, "file": (io.BytesIO(upd), "upd.csv")},
               content_type="multipart/form-data")
    assert r.status_code == 200
    assert r.get_json()["appended"] == 5
    assert st.datasets[key]["meta"].candle_count == 405
