"""Dataset quality layer: corporate actions, gap reporting, volume anomalies,
the 0-100 quality score and import-time serious-issue warnings.

Every test here is hand-checked against a deliberately constructed CSV — no
expectation is derived from the implementation itself.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from quantai.config import DataOrigin
from quantai.data import load_csv, preview_csv
from quantai.quality import (
    analyse_gaps, analyse_volume, assess_quality, detect_corporate_actions,
)
from make_fixture import make_fixture


def _write(tmp_path, df, name="d.csv"):
    p = tmp_path / name
    p.write_text(df.to_csv(index=False))
    return p


# ---------------------------------------------------------------- corporate actions
def test_split_ratio_is_detected_as_suspected_corporate_action(tmp_path):
    """A 1:2 split (price halves and the new level sticks) must be found."""
    df = make_fixture(200, "1D", seed=3)
    df.loc[100:, ["open", "high", "low", "close"]] = df.loc[100:, ["open", "high", "low", "close"]] / 2.0
    _, meta = load_csv(_write(tmp_path, df, "split.csv"), "X", "1D")

    assert meta.corporate_action_count == 1
    ev = meta.corporate_actions[0]
    assert ev["kind"] == "CORPORATE_ACTION_SUSPECTED"
    assert ev["implied_ratio"] == "1:2"
    assert ev["implied_factor"] == pytest.approx(0.5, rel=1e-3)
    assert ev["gap_pct"] == pytest.approx(-0.5, abs=0.02)
    assert ev["confidence_label"] == "HIGH"
    assert ev["confidence"] >= 0.7
    assert ev["level_reset"] is True
    assert ev["evidence"], "the event must carry its evidence"
    # honesty: the caveat must travel with the event
    assert "corporate-action register" in ev["caveat"]


def test_plain_crash_is_not_reported_as_a_corporate_action(tmp_path):
    """A -30% move with no canonical ratio is a price discontinuity, not a split."""
    df = make_fixture(200, "1D", seed=3)
    df.loc[100:, ["open", "high", "low", "close"]] = df.loc[100:, ["open", "high", "low", "close"]] * 0.70
    _, meta = load_csv(_write(tmp_path, df, "crash.csv"), "X", "1D")

    assert meta.corporate_action_count == 0
    assert meta.discontinuity_count == 1
    ev = meta.corporate_actions[0]
    assert ev["kind"] == "PRICE_DISCONTINUITY"


def test_clean_series_has_no_discontinuities(tmp_path):
    _, meta = load_csv(_write(tmp_path, make_fixture(200, "1D")), "X", "1D")
    assert meta.discontinuity_count == 0
    assert meta.corporate_actions == []


def test_claimed_adjusted_but_split_present_is_a_serious_issue(tmp_path):
    """The label on the file must be cross-checked against the file's content."""
    df = make_fixture(200, "1D", seed=3)
    df.loc[100:, ["open", "high", "low", "close"]] = df.loc[100:, ["open", "high", "low", "close"]] / 2.0
    _, meta = load_csv(_write(tmp_path, df, "split.csv"), "X", "1D",
                       adjustment_policy="SPLIT_AND_BONUS_ADJUSTED")
    assert any("claims to be split & bonus adjusted" in s for s in meta.serious_issues)


def test_prices_are_never_adjusted_by_the_detector(tmp_path):
    """Detection must not touch a single price."""
    df = make_fixture(200, "1D", seed=3)
    before = df[["open", "high", "low", "close"]].copy()
    df.loc[100:, ["open", "high", "low", "close"]] = df.loc[100:, ["open", "high", "low", "close"]] / 2.0
    out, _ = load_csv(_write(tmp_path, df, "split.csv"), "X", "1D")
    assert out["close"].iloc[100] == pytest.approx(before["close"].iloc[100] / 2.0)
    assert out["close"].iloc[99] == pytest.approx(before["close"].iloc[99])


def test_detector_ignores_tiny_gaps(tmp_path):
    df = make_fixture(120, "1D", seed=5)
    df.loc[60, "open"] = df.loc[60, "open"] * 0.99
    df.loc[60, "high"] = max(df.loc[60, "high"], df.loc[60, "open"])
    _, meta = load_csv(_write(tmp_path, df, "tiny.csv"), "X", "1D")
    assert meta.discontinuity_count == 0


# ---------------------------------------------------------------- gaps
def test_missing_daily_session_is_reported(tmp_path):
    """Removing one trading day must show up as a missing session, not just a count."""
    df = make_fixture(60, "1D", seed=2)
    df = df.drop(index=30).reset_index(drop=True)
    _, meta = load_csv(_write(tmp_path, df, "gap.csv"), "X", "1D")

    gr = meta.gap_report
    assert gr["missing_sessions"] >= 1
    assert gr["missing_bars"] >= 1
    assert meta.missing_bars == gr["missing_bars"]
    kinds = {e["kind"] for e in gr["events"]}
    assert "MISSING_SESSION" in kinds
    ev = [e for e in gr["events"] if e["kind"] == "MISSING_SESSION"][0]
    assert ev["missing_sessions"] >= 1
    assert "no data" in ev["detail"]


def test_holiday_gap_is_separated_from_missing_data(tmp_path):
    """A date on the holiday list is an EXPECTED skip, not missing data."""
    df = make_fixture(60, "1D", seed=2)
    dropped_date = str(df.loc[30, "timestamp"])[:10]
    df = df.drop(index=30).reset_index(drop=True)

    _, meta = load_csv(_write(tmp_path, df, "gap.csv"), "X", "1D",
                       holidays={dropped_date})
    gr = meta.gap_report
    assert gr["holiday_sessions"] >= 1
    assert gr["missing_sessions"] == 0
    assert any(e["kind"] == "HOLIDAY_SESSION" for e in gr["events"])


def test_intra_session_hole_is_detected(tmp_path):
    """A hole inside one intraday session must be reported as such."""
    df = make_fixture(120, "5m", seed=4)
    df = df.drop(index=40).reset_index(drop=True)
    _, meta = load_csv(_write(tmp_path, df, "hole.csv"), "X", "5m")
    gr = meta.gap_report
    assert gr["intra_session_missing_bars"] >= 1
    assert any(e["kind"] == "INTRA_SESSION" for e in gr["events"])


def test_gap_numbers_match_the_legacy_counter(tmp_path):
    """The headline missing/holiday numbers must stay identical to the old ones."""
    from quantai.data import _count_gaps

    df = make_fixture(200, "1D", seed=6)
    df = df.drop(index=50).reset_index(drop=True)
    ts = pd.Series(pd.to_datetime(df["timestamp"]))
    legacy_missing, legacy_skipped, _ = _count_gaps(ts, "1D", set())
    rep = analyse_gaps(ts, "1D", set())
    assert rep.missing_bars == legacy_missing
    assert rep.holiday_skips == legacy_skipped


# ---------------------------------------------------------------- volume
def test_volume_spike_is_flagged_but_not_rejected(tmp_path):
    df = make_fixture(200, "1D", seed=1)
    df.loc[60, "volume"] = df["volume"].median() * 50
    df.loc[70, "volume"] = 0
    out, meta = load_csv(_write(tmp_path, df, "vol.csv"), "X", "1D")

    assert len(out) == 200                       # warnings, never rejections
    assert meta.abnormal_volume_bars >= 1
    assert meta.zero_volume_bars == 1
    assert any("zero-volume" in w for w in meta.warnings)
    vp = meta.volume_profile
    assert vp["spike_bars"] >= 1
    assert vp["zero_bars"] == 1
    assert vp["median"] > 0


def test_volume_zscore_detects_a_spike_the_ratio_rule_misses(tmp_path):
    """A 5x spike stays under the 8x ratio threshold but must still be caught
    by the rolling-median z-score."""
    df = make_fixture(300, "1D", seed=11)
    base = df["volume"].median()
    df.loc[150, "volume"] = int(base * 5)
    _, meta = load_csv(_write(tmp_path, df, "z.csv"), "X", "1D")
    vp = meta.volume_profile
    assert vp["ratio_alert_bars"] == 0            # legacy rule did not fire
    assert vp["zscore_alerts"] >= 1               # the z-score did
    assert vp["abnormal_bars"] >= 1


def test_volume_dry_up_is_detected(tmp_path):
    df = make_fixture(300, "1D", seed=12)
    df.loc[120, "volume"] = 10                    # almost nothing traded
    _, meta = load_csv(_write(tmp_path, df, "dry.csv"), "X", "1D")
    assert meta.volume_profile["dry_bars"] >= 1


def test_volume_profile_reports_its_method():
    """The report must say how it computed the numbers."""
    v = pd.Series([100] * 40 + [100000])
    prof = analyse_volume(v)
    assert "rolling" in prof.method.lower()
    assert "z-score" in prof.method.lower()


# ---------------------------------------------------------------- quality score
def test_quality_score_is_between_0_and_100_and_has_breakdown(tmp_path):
    _, meta = load_csv(_write(tmp_path, make_fixture(300, "1D")), "X", "1D")
    assert 0 <= meta.data_quality_score <= 100
    assert meta.data_quality_grade in ("A", "B", "C", "D", "F")
    assert meta.data_quality_verdict
    keys = {c["key"] for c in meta.data_quality_components}
    assert keys == {"row_integrity", "continuity", "volume_sanity",
                    "price_consistency", "sufficiency"}
    assert abs(sum(c["points"] for c in meta.data_quality_components)
               - meta.data_quality_score) < 1.0


def test_clean_file_scores_higher_than_a_damaged_file(tmp_path):
    clean = make_fixture(400, "1D", seed=8)
    _, ok_meta = load_csv(_write(tmp_path, clean, "clean.csv"), "X", "1D")

    damaged = clean.copy()
    damaged.loc[100, "volume"] = 0
    damaged.loc[150, "volume"] = int(damaged["volume"].median() * 60)
    damaged = damaged.drop(index=200).reset_index(drop=True)
    _, bad_meta = load_csv(_write(tmp_path, damaged, "bad.csv"), "X", "1D")

    assert ok_meta.data_quality_score > bad_meta.data_quality_score
    assert bad_meta.serious_issues


def test_short_history_is_flagged_as_sufficiency_not_as_a_defect(tmp_path):
    _, meta = load_csv(_write(tmp_path, make_fixture(100, "1D")), "X", "1D")
    suffic = [c for c in meta.data_quality_components if c["key"] == "sufficiency"][0]
    assert suffic["points"] < suffic["weight"]
    assert any("sufficiency limit" in n for n in meta.data_quality_notes)
    assert not any("sufficiency limit" in s for s in meta.serious_issues)


def test_fixture_score_is_labelled_as_about_the_file_only(tmp_path):
    _, meta = load_csv(_write(tmp_path, make_fixture(300, "1D")), "X", "1D",
                       source_type=DataOrigin.TEST_FIXTURE)
    assert any("NOT market data" in n for n in meta.data_quality_notes)


# ---------------------------------------------------------------- serious issues
def test_serious_issues_are_reported_for_missing_sessions(tmp_path):
    df = make_fixture(200, "1D", seed=9).drop(index=100).reset_index(drop=True)
    _, meta = load_csv(_write(tmp_path, df, "gap.csv"), "X", "1D")
    assert any("session(s) are missing" in s for s in meta.serious_issues)


def test_rejected_rows_over_ten_percent_is_serious(tmp_path):
    df = make_fixture(200, "1D", seed=9)
    df.loc[0:40, "high"] = df.loc[0:40, "low"] * 0.5      # invalid OHLC
    _, meta = load_csv(_write(tmp_path, df, "bad.csv"), "X", "1D")
    assert meta.rows_rejected >= 30
    assert any("rejected" in s for s in meta.serious_issues)


def test_serious_issues_also_appear_in_the_warnings_list(tmp_path):
    df = make_fixture(200, "1D", seed=9).drop(index=100).reset_index(drop=True)
    _, meta = load_csv(_write(tmp_path, df, "gap.csv"), "X", "1D")
    for s in meta.serious_issues:
        assert s in meta.warnings


def test_clean_file_has_no_serious_issues(tmp_path):
    _, meta = load_csv(_write(tmp_path, make_fixture(400, "1D", seed=13)), "X", "1D")
    assert meta.serious_issues == []


def test_a_serious_issue_can_never_be_graded_clean(tmp_path):
    """A HIGH-severity issue must cap the grade at C, a MEDIUM one at B."""
    df = make_fixture(2000, "1D", seed=3)
    df.loc[100:, ["open", "high", "low", "close"]] = df.loc[100:, ["open", "high", "low", "close"]] / 2.0
    _, high = load_csv(_write(tmp_path, df, "split.csv"), "X", "1D")
    assert high.data_quality_grade in ("C", "D", "F")
    assert high.data_quality_score <= 70
    assert any("capped" in n for n in high.data_quality_notes)

    df2 = make_fixture(2000, "1D", seed=3).drop(index=100).reset_index(drop=True)
    _, med = load_csv(_write(tmp_path, df2, "gap.csv"), "X", "1D")
    assert med.data_quality_grade in ("B", "C", "D", "F")
    assert med.data_quality_score <= 80


def test_penalty_is_reported_separately_from_the_component_points(tmp_path):
    df = make_fixture(2000, "1D", seed=3)
    df.loc[100:, ["open", "high", "low", "close"]] = df.loc[100:, ["open", "high", "low", "close"]] / 2.0
    _, meta = load_csv(_write(tmp_path, df, "split.csv"), "X", "1D")
    assert meta.data_quality_penalty > 0
    assert any("penalty applied" in n for n in meta.data_quality_notes)


# ---------------------------------------------------------------- API / flow
def test_preview_reports_quality_and_serious_issues(tmp_path):
    df = make_fixture(200, "1D", seed=3)
    df.loc[100:, ["open", "high", "low", "close"]] = df.loc[100:, ["open", "high", "low", "close"]] / 2.0
    rep = preview_csv(_write(tmp_path, df, "split.csv"), "X", "1D")
    assert rep["meta"]["data_quality_score"] >= 0
    assert rep["meta"]["corporate_action_count"] == 1
    assert rep["meta"]["serious_issues"]


def test_import_endpoint_returns_the_quality_report(tmp_path):
    from app import create_app
    from engine import AppState

    state = AppState(store_root=tmp_path / "store")
    client = create_app(state).test_client()
    df = make_fixture(200, "1D", seed=3)
    df.loc[100:, ["open", "high", "low", "close"]] = df.loc[100:, ["open", "high", "low", "close"]] / 2.0
    p = _write(tmp_path, df, "split.csv")
    with open(p, "rb") as f:
        r = client.post("/api/import", data={
            "file": (f, "split.csv"), "symbol": "X", "timeframe": "1D",
            "source_type": "IMPORTED_CSV"}, content_type="multipart/form-data")
    assert r.status_code == 200
    meta = r.get_json()["dataset"]
    assert meta["data_quality_score"] > 0
    assert meta["corporate_action_count"] == 1
    assert meta["serious_issues"]


def test_dataset_quality_endpoint_exposes_the_report(tmp_path):
    from app import create_app
    from engine import AppState

    state = AppState(store_root=tmp_path / "store")
    client = create_app(state).test_client()
    p = _write(tmp_path, make_fixture(200, "1D"), "x.csv")
    with open(p, "rb") as f:
        client.post("/api/import", data={
            "file": (f, "x.csv"), "symbol": "X", "timeframe": "1D",
            "source_type": "TEST_FIXTURE"}, content_type="multipart/form-data")
    key = next(iter(state.datasets))
    j = client.get(f"/api/dataset/quality?key={key}").get_json()
    q = j["quality"]
    assert "data_quality_score" in q
    assert "gap_report" in q
    assert "volume_profile" in q
    assert q["gap_report"]["observed_bars"] == 200


def test_old_provenance_files_still_load(tmp_path):
    """A provenance file written before the quality layer must still load."""
    from storage import meta_from_dict

    m = meta_from_dict({
        "symbol": "X", "timeframe": "1D", "source_name": "old.csv",
        "source_type": DataOrigin.IMPORTED_CSV.value,
        "verification_status": "IMPORTED_CSV_UNVERIFIED",
        "dataset_id": "X_1D_abc", "sha256": "0" * 64,
        "imported_at": "2024-01-01T00:00:00+00:00", "timezone": "Asia/Kolkata",
        "candle_count": 10, "start": "2024-01-01", "end": "2024-01-10",
        "adjustment_policy": "UNKNOWN_UNVERIFIED", "rows_read": 10,
        "rows_rejected": 0, "duplicates": 0, "missing_bars": 0,
        "holiday_or_weekend_skips": 0, "research_quality": "LOW_CONFIDENCE_INSUFFICIENT_DATA",
        "required_research_bars": 1500,
    })
    assert m.data_quality_score == 0
    assert m.data_quality_grade == "F"
    assert m.serious_issues == []
    assert m.gap_report == {}


def test_restart_recomputes_the_quality_report_for_old_datasets(tmp_path):
    """A dataset imported before the quality layer must get its report on restart,
    without re-importing and without touching a single price."""
    from engine import AppState

    root = tmp_path / "store"
    state = AppState(store_root=root)
    df = make_fixture(400, "1D", seed=3)
    df.loc[100:, ["open", "high", "low", "close"]] = df.loc[100:, ["open", "high", "low", "close"]] / 2.0
    p = _write(tmp_path, df, "split.csv")
    state.import_csv(p, "X", "1D", "IMPORTED_CSV", "UNKNOWN_UNVERIFIED")
    key = next(iter(state.datasets))
    meta = state.datasets[key]["meta"]

    # simulate a provenance file written before the quality layer existed
    meta.data_quality_score = 0
    meta.data_quality_grade = "F"
    meta.serious_issues = []
    meta.gap_report = {}
    meta.corporate_actions = []
    meta.corporate_action_count = 0
    state.store.save_dataset(state.datasets[key]["df"], meta)

    restored = AppState(store_root=root)
    rmeta = restored.datasets[key]["meta"]
    assert rmeta.data_quality_score > 0
    assert rmeta.data_quality_grade in ("A", "B", "C", "D", "F")
    assert rmeta.gap_report["observed_bars"] == 400
    assert rmeta.corporate_action_count == 1
    # the stored candles are untouched
    assert restored.datasets[key]["df"]["close"].iloc[100] == pytest.approx(
        state.datasets[key]["df"]["close"].iloc[100])
