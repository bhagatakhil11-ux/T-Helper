"""Risk Engine — the four limits, end to end.

This file covers the *completion* pass over the risk engine:

1. Weekly loss limit — ISO-week based, default 5%, range **1–15%**, enforced
   together with the daily limit, with a clear message on breach.
2. Progressive cooldown — 3 losses -> 15 bars, 5 -> 30 bars, 7+ -> 50 bars,
   and configurable from the settings.
3. Volatility-adjusted position sizing — optional toggle, **off by default**,
   with a warning when it is on.
4. Kill-switch reason — optional, saved to the journal **and** to the
   settings; "No reason provided" when it is left blank.

Everything is asserted on the BACKEND. The frontend is only ever a view of
these values; no test here depends on the UI existing.
"""
from __future__ import annotations

import json
import time

import numpy as np
import pandas as pd
import pytest

from engine import AppState
from quantai.backtest import run_backtest
from quantai.config import CostModel, RiskConfig
from quantai.features import build_features
from quantai.risk_rules import iso_week_key, progressive_cooldown_bars
from risk_engine import NO_KILL_REASON, RISK_LIMITS


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _sawtooth(n=400, seed=0):
    """A price series whose bars actually hit stops and targets."""
    closes, opens, highs, lows = [], [], [], []
    price = 100.0
    for i in range(n):
        drift = 0.03 if (i // 4) % 2 == 0 else -0.03
        o = price
        c = price * (1 + drift + 0.003 * np.sin(i + seed))
        opens.append(o); closes.append(c)
        highs.append(max(o, c) * 1.004); lows.append(min(o, c) * 0.996)
        price = c
    ts = pd.date_range("2021-01-04", periods=n, freq="B", tz="Asia/Kolkata") + pd.Timedelta(hours=15)
    return pd.DataFrame({"timestamp": ts, "open": opens, "high": highs,
                         "low": lows, "close": closes, "volume": 1_000_000})


def _falling(n=220, drift=-0.004, noise=0.0015, seed=3):
    """A steady bleed after the warm-up bars.

    The weekly loss limit is measured from the START of an ISO week, and a
    daily series only has ~5 bars per ISO week, so the fixture has to lose
    money FAST for a weekly limit to be reachable in a test.
    """
    rng = np.random.default_rng(seed)
    ts = pd.date_range("2021-01-04", periods=n, freq="B", tz="Asia/Kolkata") + pd.Timedelta(hours=15)
    price = 100.0
    opens, highs, lows, closes = [], [], [], []
    for i in range(n):
        o = price
        d = 0.0 if i < 34 else drift + rng.normal(0, noise)
        c = price * (1 + d)
        opens.append(o); closes.append(c)
        highs.append(max(o, c) * 1.002); lows.append(min(o, c) * 0.998)
        price = c
    return pd.DataFrame({"timestamp": ts, "open": opens, "high": highs,
                         "low": lows, "close": closes, "volume": 1_000_000})


def _falling_state(tmp_path, name="FALL"):
    st = AppState(store_root=tmp_path / "store")
    p = tmp_path / "fall.csv"
    p.write_text(_falling().to_csv(index=False))
    st.import_csv(p, name, "1D", "TEST_FIXTURE", "UNKNOWN_UNVERIFIED")
    return st


def _state(tmp_path, name="RISK2", n=400):
    st = AppState(store_root=tmp_path / "store")
    p = tmp_path / "saw.csv"
    p.write_text(_sawtooth(n).to_csv(index=False))
    st.import_csv(p, name, "1D", "TEST_FIXTURE", "UNKNOWN_UNVERIFIED")
    return st


def _app(tmp_path):
    from app import create_app
    st = _state(tmp_path)
    app = create_app(state=st)
    app.config["TESTING"] = True
    return app, st


def _start_without_thread(st, **kw):
    """Start a replay and stop its background loop, so the test can step
    the engine DETERMINISTICALLY (no sleeping, no races)."""
    st.start_replay(speed_ms=60, use_test_window=False, mode="rules_only",
                    threshold=-99, **kw)
    st.replay["running"] = False
    t = getattr(st, "_thread", None)
    if t is not None:
        t.join(timeout=3)
    return st.replay


def _drive(st, steps=80, until=None):
    """Step the replay engine `steps` times, by hand.

    ``until`` is an optional predicate on the replay state — the drive stops
    as soon as it becomes true, so a test can observe the FIRST breach
    instead of a later state after the ISO week has rolled over.
    """
    r = st.replay
    for _ in range(steps):
        if r["bar"] >= r["total_bars"] - 1:
            break
        with st.lock:
            st._step()
        if until is not None and until(r):
            break
    return r


# ===========================================================================
# 1. Weekly loss limit
# ===========================================================================
def test_weekly_limit_defaults_to_five_percent():
    assert RiskConfig().max_weekly_drawdown_pct == 5.0


def test_weekly_limit_range_is_one_to_fifteen_percent():
    """The stated range is 1%–15%."""
    lo, hi = RISK_LIMITS["max_weekly_drawdown_pct"]
    assert (lo, hi) == (1.0, 15.0)


def test_weekly_limit_is_clamped_to_1_15_by_the_backend(tmp_path):
    st = _state(tmp_path, "WKL")
    st.update_risk({"max_weekly_drawdown_pct": 999.0})
    assert st.risk.max_weekly_drawdown_pct == 15.0
    st.update_risk({"max_weekly_drawdown_pct": 0.0})
    assert st.risk.max_weekly_drawdown_pct == 1.0
    st.update_risk({"max_weekly_drawdown_pct": -50.0})
    assert st.risk.max_weekly_drawdown_pct == 1.0


def test_weekly_limit_is_clamped_by_the_api_not_only_the_frontend(tmp_path):
    """The backend must refuse a value outside the range even if the UI
    sends it. This is the 'backend-enforced' requirement."""
    app, st = _app(tmp_path)
    with app.test_client() as c:
        r = c.post("/api/risk", json={"max_weekly_drawdown_pct": 40.0})
        assert r.status_code == 200
        assert r.get_json()["risk"]["max_weekly_drawdown_pct"] == 15.0
        r = c.post("/api/risk", json={"max_weekly_drawdown_pct": 0.2})
        assert r.get_json()["risk"]["max_weekly_drawdown_pct"] == 1.0


def test_a_hand_edited_settings_file_cannot_widen_the_weekly_limit(tmp_path):
    """The clamp is applied on LOAD as well as on save."""
    st = _state(tmp_path, "WKH")
    st.update_risk({"max_weekly_drawdown_pct": 9.0})
    st2 = AppState(store_root=tmp_path / "store")
    assert st2.risk.max_weekly_drawdown_pct == 9.0

    # Tamper with the persisted settings, exactly as a hand-edit would.
    settings_file = tmp_path / "store" / "settings.json"
    data = json.loads(settings_file.read_text())
    data["risk"]["max_weekly_drawdown_pct"] = 80.0
    settings_file.write_text(json.dumps(data))

    st3 = AppState(store_root=tmp_path / "store")
    assert st3.risk.max_weekly_drawdown_pct == 15.0


def test_weekly_limit_is_enforced_together_with_the_daily_limit(tmp_path):
    """Both limits are live at the same time; neither replaces the other."""
    st = _state(tmp_path, "WKB")
    st.update_risk({"max_daily_drawdown_pct": 2.0, "max_weekly_drawdown_pct": 6.0,
                    "max_total_drawdown_pct": 50.0})
    df = st.active()["df"]
    feats = build_features(df)
    res = run_backtest(df, feats, 60, CostModel(), st.risk, "1D",
                       mode="rules_only", entry_threshold=-99)
    assert res.risk_config["max_daily_drawdown_pct"] == 2.0
    assert res.risk_config["max_weekly_drawdown_pct"] == 6.0
    # both counters exist, so a blocked signal knows which limit stopped it
    assert "daily_drawdown" in res.rejected_signals
    assert "weekly_drawdown" in res.rejected_signals


def test_weekly_breach_produces_a_clear_message(tmp_path):
    """A breach must say WHAT happened, not just set a flag."""
    st = _falling_state(tmp_path, "FALL1")
    st.update_risk({"max_weekly_drawdown_pct": 1.0, "max_daily_drawdown_pct": 50.0,
                    "max_total_drawdown_pct": 50.0})
    _start_without_thread(st)
    r = _drive(st, 60, until=lambda x: bool(x.get("weekly_block_reason")))
    reason = r.get("weekly_block_reason") or ""
    assert reason, "the falling fixture must breach a 1% weekly limit"
    assert "WEEKLY LOSS LIMIT BREACHED" in reason
    assert "%" in reason
    assert r.get("current_week") in reason
    # the message must say what happens next
    assert "next ISO week" in reason
    # the breach is recorded for the report
    snap = st.snapshot()["replay"]
    assert snap["weekly_breaches"]
    b = snap["weekly_breaches"][0]
    assert b["weekly_drawdown_pct"] >= b["limit_pct"]
    assert b["week"] == r["current_week"]


def test_weekly_breach_is_written_to_the_journal(tmp_path):
    st = _falling_state(tmp_path, "FALL2")
    st.update_risk({"max_weekly_drawdown_pct": 1.0, "max_daily_drawdown_pct": 50.0,
                    "max_total_drawdown_pct": 50.0})
    _start_without_thread(st)
    r = _drive(st, 60, until=lambda x: bool(x.get("weekly_block_reason")))
    assert r.get("weekly_block_reason")
    events = st.journal.events(limit=200, event_type="weekly_loss_limit_breached")
    assert events, "a weekly breach must be written to the journal"
    assert "WEEKLY LOSS LIMIT BREACHED" in events[0]["reason"]


def test_weekly_breach_blocks_entries_and_is_counted(tmp_path):
    st = _falling_state(tmp_path, "FALL3")
    st.update_risk({"max_weekly_drawdown_pct": 1.0, "max_daily_drawdown_pct": 50.0,
                    "max_total_drawdown_pct": 50.0})
    _start_without_thread(st)
    r = _drive(st, 60, until=lambda x: x.get("week_blocked"))
    assert r["week_blocked"] is True
    # keep stepping inside the SAME week until a signal is actually refused
    _drive(st, 10, until=lambda x: x["rejected"]["weekly_drawdown"] > 0)
    assert r["rejected"]["weekly_drawdown"] > 0, \
        "a blocked week must block entries, and the reason must be counted"
    # the block is a NEW-ENTRY block: the engine keeps running
    assert r["bar"] < r["total_bars"] - 1
    assert r.get("halted_reason") is None


def test_weekly_block_clears_at_the_next_iso_week(tmp_path):
    """The weekly block is a per-ISO-week block, not a permanent one."""
    st = _falling_state(tmp_path, "FALL4")
    st.update_risk({"max_weekly_drawdown_pct": 1.0, "max_daily_drawdown_pct": 50.0,
                    "max_total_drawdown_pct": 50.0})
    _start_without_thread(st)
    r = st.replay
    # drive to the FIRST breach
    _drive(st, 60, until=lambda x: x.get("week_blocked"))
    assert r["week_blocked"] is True
    first_week = r["current_week"]
    assert r["weekly_breaches"], "the breach is recorded"
    # the ISO-week boundary is the bar where the week key changes
    df = r["candles"]
    weeks = [iso_week_key(t) for t in df["timestamp"]]
    nxt = next((i for i, w in enumerate(weeks) if w != first_week and i > r["bar"]), None)
    assert nxt is not None, "the fixture must contain a second ISO week"
    while r["bar"] < nxt:
        with st.lock:
            st._step()
    assert r["current_week"] != first_week
    assert r["week_blocked"] is False, "the weekly block lifts with the new ISO week"
    assert r["weekly_block_reason"] == ""
    assert r["weekly_breaches"] == []


# ===========================================================================
# 2. Progressive cooldown
# ===========================================================================
def test_progressive_cooldown_bands_are_3_15_5_30_7_50():
    assert progressive_cooldown_bars(3, 3, 15, True) == 15
    assert progressive_cooldown_bars(5, 3, 15, True) == 30
    assert progressive_cooldown_bars(7, 3, 15, True) == 50
    assert progressive_cooldown_bars(12, 3, 15, True) == 50


def test_cooldown_bands_are_configurable_from_the_settings(tmp_path):
    st = _state(tmp_path, "CDB")
    st.update_risk({"max_consecutive_losses": 3, "cooldown_bars": 20,
                    "cooldown_bars_level2": 45, "cooldown_bars_level3": 90})
    assert st.risk.cooldown_bars == 20
    assert st.risk.cooldown_bars_level2 == 45
    assert st.risk.cooldown_bars_level3 == 90
    assert progressive_cooldown_bars(3, 3, 20, True,
                                     level2_bars=45, level3_bars=90) == 20
    assert progressive_cooldown_bars(5, 3, 20, True,
                                     level2_bars=45, level3_bars=90) == 45
    assert progressive_cooldown_bars(7, 3, 20, True,
                                     level2_bars=45, level3_bars=90) == 90


def test_cooldown_bands_are_clamped_and_kept_ordered(tmp_path):
    st = _state(tmp_path, "CDC")
    st.update_risk({"cooldown_bars": 9999, "cooldown_bars_level2": 9999,
                    "cooldown_bars_level3": 9999})
    assert st.risk.cooldown_bars == 500
    assert st.risk.cooldown_bars_level2 == 500
    assert st.risk.cooldown_bars_level3 == 500
    # band 2 can not be shorter than band 1, band 3 not shorter than band 2
    st.update_risk({"cooldown_bars": 100, "cooldown_bars_level2": 10,
                    "cooldown_bars_level3": 5})
    assert st.risk.cooldown_bars_level2 >= st.risk.cooldown_bars
    assert st.risk.cooldown_bars_level3 >= st.risk.cooldown_bars_level2


def test_the_backtest_uses_the_configured_cooldown_bands(tmp_path):
    st = _state(tmp_path, "CDT")
    st.update_risk({"progressive_cooldown": True, "max_consecutive_losses": 2,
                    "cooldown_bars": 10, "cooldown_bars_level2": 20,
                    "cooldown_bars_level3": 40})
    df = st.active()["df"]
    feats = build_features(df)
    res = run_backtest(df, feats, 60, CostModel(), st.risk, "1D",
                       mode="rules_only", entry_threshold=-99)
    assert res.risk_config["cooldown_bars_level2"] == 20
    assert res.risk_config["cooldown_bars_level3"] == 40
    for ev in res.cooldown_events:
        assert ev["cooldown_bars"] in (10, 20, 40)
        assert ev["until_bar"] == ev["bar"] + ev["cooldown_bars"]


def test_progressive_cooldown_is_on_by_default():
    assert RiskConfig().progressive_cooldown is True


def test_the_fixed_cooldown_still_works_when_progressive_is_off(tmp_path):
    st = _state(tmp_path, "CDF")
    st.update_risk({"progressive_cooldown": False, "cooldown_bars": 15})
    df = st.active()["df"]
    feats = build_features(df)
    res = run_backtest(df, feats, 60, CostModel(), st.risk, "1D",
                       mode="rules_only", entry_threshold=-99)
    for ev in res.cooldown_events:
        assert ev["cooldown_bars"] == 15


# ===========================================================================
# 3. Volatility-adjusted position sizing
# ===========================================================================
def test_volatility_sizing_is_off_by_default():
    cfg = RiskConfig()
    assert cfg.auto_risk_by_volatility is False
    assert cfg.risk_vol_target_pct == 2.0


def test_the_volatility_toggle_is_persisted(tmp_path):
    st = _state(tmp_path, "VOL")
    st.update_risk({"auto_risk_by_volatility": True, "risk_vol_target_pct": 1.5})
    assert st.risk.auto_risk_by_volatility is True
    assert st.risk.risk_vol_target_pct == 1.5
    st2 = AppState(store_root=tmp_path / "store")
    assert st2.risk.auto_risk_by_volatility is True
    assert st2.risk.risk_vol_target_pct == 1.5


def test_the_volatility_toggle_is_reachable_through_the_api(tmp_path):
    app, st = _app(tmp_path)
    with app.test_client() as c:
        r = c.post("/api/risk", json={"auto_risk_by_volatility": True,
                                      "risk_vol_target_pct": 1.5})
        assert r.status_code == 200
        body = r.get_json()
        assert body["risk"]["auto_risk_by_volatility"] is True
        assert body["risk"]["risk_vol_target_pct"] == 1.5


def test_the_risk_summary_states_the_volatility_setting():
    """The warning text the operator reads must name the formula."""
    off = RiskConfig().summary()
    assert "off" in off
    on = RiskConfig(auto_risk_by_volatility=True).summary()
    assert "ATR% target 2.00%" in on


def test_volatility_sizing_shrinks_the_position_when_volatility_is_high(tmp_path):
    """With the toggle ON, a volatile instrument must be sized smaller."""
    st = _state(tmp_path, "VOL2")
    df = st.active()["df"]
    feats = build_features(df)
    st.update_risk({"auto_risk_by_volatility": True, "risk_vol_target_pct": 0.1,
                    "risk_vol_min_factor": 0.25, "risk_vol_max_factor": 2.0})
    res_on = run_backtest(df, feats, 60, CostModel(), st.risk, "1D",
                          mode="rules_only", entry_threshold=-99)
    st.update_risk({"auto_risk_by_volatility": False})
    res_off = run_backtest(df, feats, 60, CostModel(), st.risk, "1D",
                           mode="rules_only", entry_threshold=-99)
    assert res_on.risk_config["auto_risk_by_volatility"] is True
    assert res_off.risk_config["auto_risk_by_volatility"] is False
    # with a tiny target ATR% the measured ATR% is far above it, so the
    # factor is clamped at the MINIMUM -> smaller or equal position
    if res_on.trade_log and res_off.trade_log:
        on_qty = sum(t["qty"] for t in res_on.trade_log)
        off_qty = sum(t["qty"] for t in res_off.trade_log)
        assert on_qty <= off_qty


def test_volatility_sizing_is_off_means_the_sizes_are_identical(tmp_path):
    """With the toggle OFF the sizing must be EXACTLY the old behaviour."""
    st = _state(tmp_path, "VOL3")
    df = st.active()["df"]
    feats = build_features(df)
    st.update_risk({"auto_risk_by_volatility": False})
    a = run_backtest(df, feats, 60, CostModel(), st.risk, "1D",
                     mode="rules_only", entry_threshold=-99)
    b = run_backtest(df, feats, 60, CostModel(), st.risk, "1D",
                     mode="rules_only", entry_threshold=-99)
    assert [t["qty"] for t in a.trade_log] == [t["qty"] for t in b.trade_log]


# ===========================================================================
# 4. Kill-switch reason
# ===========================================================================
def test_kill_switch_reason_is_saved_to_the_journal(tmp_path):
    st = _state(tmp_path, "KILL")
    st.set_kill(True, reason="Revenge trading after 3 losses — stepping away")
    events = st.journal.events(limit=50, event_type="kill_switch_engaged")
    assert events
    assert "Revenge trading" in events[0]["reason"]


def test_kill_switch_reason_is_saved_to_the_settings(tmp_path):
    st = _state(tmp_path, "KILL2")
    st.set_kill(True, reason="Bad data feed")
    settings = json.loads((tmp_path / "store" / "settings.json").read_text())
    assert settings["kill_reason"] == "Bad data feed"
    assert settings["kill_switch"] is True


def test_kill_switch_reason_survives_a_restart(tmp_path):
    st = _state(tmp_path, "KILL3")
    st.set_kill(True, reason="Overnight gap risk")
    st2 = AppState(store_root=tmp_path / "store")
    assert st2.kill_switch is True
    assert st2.kill_reason == "Overnight gap risk"
    assert st2.snapshot()["kill_reason"] == "Overnight gap risk"


def test_a_blank_reason_is_recorded_as_no_reason_provided(tmp_path):
    st = _state(tmp_path, "KILL4")
    st.set_kill(True, reason="")
    assert st.kill_reason == NO_KILL_REASON == "No reason provided"
    settings = json.loads((tmp_path / "store" / "settings.json").read_text())
    assert settings["kill_reason"] == "No reason provided"
    events = st.journal.events(limit=50, event_type="kill_switch_engaged")
    assert events
    assert events[0]["reason"] == "No reason provided"


def test_the_reason_is_optional_through_the_api(tmp_path):
    app, st = _app(tmp_path)
    with app.test_client() as c:
        r = c.post("/api/kill", json={"on": True})
        assert r.status_code == 200
        assert r.get_json()["reason"] == "No reason provided"
        r = c.post("/api/kill", json={"on": True, "reason": "Taking a break"})
        assert r.get_json()["reason"] == "Taking a break"


def test_releasing_the_kill_switch_clears_the_active_reason(tmp_path):
    st = _state(tmp_path, "KILL5")
    st.set_kill(True, reason="Later")
    st.set_kill(False)
    assert st.kill_switch is False
    assert st.kill_reason == ""
    # but the history is kept in the journal
    events = st.journal.events(limit=50, event_type="kill_switch_engaged")
    assert events and "Later" in events[0]["reason"]


def test_the_kill_switch_still_blocks_a_replay_from_starting(tmp_path):
    """The reason is an addition — it must not weaken the switch."""
    st = _state(tmp_path, "KILL6")
    st.set_kill(True, reason="Testing")
    assert st.kill_switch is True
    with pytest.raises(ValueError, match="Kill switch"):
        st.start_replay(speed_ms=60, use_test_window=False, mode="rules_only",
                        threshold=-99)


def test_the_kill_switch_blocks_entries_of_a_running_replay(tmp_path):
    st = _state(tmp_path, "KILL7")
    _start_without_thread(st)
    r = st.replay
    _drive(st, 5)
    st.set_kill(True, reason="Testing")
    before = r["rejected"].get("kill_switch", 0)
    _drive(st, 40)
    assert r["rejected"].get("kill_switch", 0) > before, \
        "once engaged, the kill switch must block new entries"


# ===========================================================================
# 5. Existing behaviour is untouched
# ===========================================================================
def test_the_existing_risk_limits_are_unchanged(tmp_path):
    st = _state(tmp_path, "OLD")
    st.update_risk({"max_daily_drawdown_pct": 2.0, "max_total_drawdown_pct": 15.0,
                    "max_exposure_pct": 50.0, "max_open_positions": 1,
                    "stop_atr_mult": 1.8, "target_atr_mult": 3.6})
    assert st.risk.max_daily_drawdown_pct == 2.0
    assert st.risk.max_total_drawdown_pct == 15.0
    assert st.risk.max_exposure_pct == 50.0
    assert st.risk.max_open_positions == 1
    assert st.risk.stop_atr_mult == 1.8
    assert st.risk.target_atr_mult == 3.6


def test_the_risk_summary_still_reports_the_old_limits():
    s = RiskConfig().summary()
    assert "day DD 2.00%" in s
    assert "week DD 5.00%" in s
    assert "total DD 15.00%" in s
    assert "exposure 50.0%" in s


def test_an_open_position_still_refuses_a_risk_change(tmp_path):
    """The 409 guard must survive the new fields."""
    app, st = _app(tmp_path)
    with app.test_client() as c:
        st.start_replay(speed_ms=60, use_test_window=False, mode="rules_only", threshold=-99)
        t0 = time.time()
        while time.time() - t0 < 20 and st.replay.get("position") is None:
            time.sleep(0.05)
        if st.replay.get("position") is not None:
            r = c.post("/api/risk", json={"cooldown_bars_level2": 99})
            assert r.status_code == 409
            r = c.post("/api/risk", json={"cooldown_bars_level2": 99,
                                          "acknowledge_open_position": True})
            assert r.status_code == 200
            assert r.get_json()["risk"]["cooldown_bars_level2"] == 99
        st.stop_replay()


def test_the_state_payload_exposes_every_new_field(tmp_path):
    st = _state(tmp_path, "EXPOSE")
    snap = st.snapshot()
    risk = snap["risk"]
    assert "max_weekly_drawdown_pct" in risk
    assert "cooldown_bars_level2" in risk
    assert "cooldown_bars_level3" in risk
    assert "progressive_cooldown" in risk
    assert "auto_risk_by_volatility" in risk
    assert "kill_reason" in snap
