"""Tests for the new performance analytics module."""
import numpy as np
import pytest

from quantai.metrics import (cagr_pct, max_drawdown_pct, performance_metrics,
                             risk_adjusted, _streaks)


def test_cagr_known_value():
    # 100 -> 200 over exactly 365.25 days => 100% CAGR
    v, reason = cagr_pct(100.0, 200.0, "2020-01-01", "2021-01-01")
    assert v == pytest.approx(100.0, abs=0.5)
    assert "CAGR" in reason


def test_cagr_na_for_short_window():
    v, reason = cagr_pct(100.0, 110.0, "2020-01-01", "2020-01-10")
    assert v is None
    assert "N/A" in reason


def test_max_drawdown():
    assert max_drawdown_pct([100, 120, 90, 110]) == pytest.approx(25.0)
    assert max_drawdown_pct([100, 110, 120]) == 0.0


def test_streaks():
    w, l = _streaks([1, 2, -1, -2, -3, 4, -1])
    assert w == 2
    assert l == 3


def test_sharpe_sortino_na_when_few_trades():
    r = risk_adjusted(np.array([0.01, -0.01, 0.02]), "1D", n_trades=2)
    assert r["sharpe"] is None
    assert r["sortino"] is None
    assert "N/A" in r["sharpe_reason"]


def test_sortino_uses_downside_only():
    # Mostly positive returns with one small negative bar: Sortino > Sharpe
    rets = np.array([0.02] * 40 + [-0.001] + [0.02] * 40)
    r = risk_adjusted(rets, "1D", n_trades=10)
    assert r["sharpe"] is not None and r["sortino"] is not None
    assert r["sortino"] > r["sharpe"]


def test_sortino_downside_deviation_uses_all_bars():
    """Regression: downside deviation must divide by N (all bars), not the count
    of negative bars. Hand-computed expected value guards the formula."""
    rets = np.array([0.01, -0.02, 0.03, -0.04, 0.02, 0.01, -0.01, 0.02])
    r = risk_adjusted(rets, "1D", n_trades=10, min_bars=2, min_trades=1)
    mean = float(np.mean(rets))
    dd = float(np.sqrt(np.mean(np.minimum(rets, 0.0) ** 2)))   # over all 8 bars
    expected = mean / dd * np.sqrt(252.0)
    assert r["sortino"] == pytest.approx(expected, rel=1e-9)
    # The non-standard neg-only variant divides by 3 (negative bars) instead of 8,
    # giving a larger downside deviation and therefore a SMALLER ratio. Guard that
    # our value matches the all-bar form and differs from the neg-only variant.
    neg_only_dd = float(np.sqrt(np.mean(rets[rets < 0] ** 2)))
    neg_only = mean / neg_only_dd * np.sqrt(252.0)
    assert r["sortino"] > neg_only
    assert r["sortino"] != pytest.approx(neg_only, rel=1e-6)


def test_performance_metrics_full_block():
    eq = [100000, 101000, 99000, 103000, 102000]
    trades = [{"pnl": 1000}, {"pnl": -2000}, {"pnl": 4000}, {"pnl": -1000}]
    ts = ["2020-01-01", "2020-06-01", "2020-09-01", "2021-01-01", "2021-06-01"]
    m = performance_metrics(eq, trades, 100000, "1D", timestamps=ts)
    assert m["total_return_pct"] == pytest.approx(2.0)
    assert m["total_trades"] == 4
    assert m["winning_trades"] == 2 and m["losing_trades"] == 2
    assert m["win_rate_pct"] == pytest.approx(50.0)
    assert m["profit_factor"] == pytest.approx(5000 / 3000)
    assert m["avg_profit_per_trade"] == pytest.approx(2500)
    assert m["avg_loss_per_trade"] == pytest.approx(1500)
    assert m["risk_reward_ratio"] == pytest.approx(2500 / 1500)
    assert m["max_consecutive_wins"] == 1
    assert m["max_consecutive_losses"] == 1
    assert m["max_drawdown_pct"] > 0


def test_profit_factor_none_when_no_trades():
    m = performance_metrics([100, 100], [], 100, "1D")
    assert m["profit_factor"] is None
    assert m["risk_reward_ratio"] is None
    assert m["total_trades"] == 0
