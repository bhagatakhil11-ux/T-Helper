"""Candlestick pattern detection: each pattern fires on hand-built candles,
detections are causal (no future bars), and none of them is presented as a
guaranteed buy/sell signal."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantai.patterns import PATTERN_NAMES, detect_patterns


def _df(rows, start="2024-01-01"):
    """rows: list of (open, high, low, close)"""
    df = pd.DataFrame(rows, columns=["open", "high", "low", "close"])
    df["timestamp"] = pd.date_range(start, periods=len(df), freq="B", tz="Asia/Kolkata")
    df["volume"] = 1000
    return df


def _names(pats):
    return [p["pattern"] for p in pats]


def test_pattern_name_registry_is_complete():
    for n in ("Doji", "Hammer", "Inverted Hammer", "Shooting Star",
              "Bullish Engulfing", "Bearish Engulfing", "Morning Star",
              "Evening Star", "Marubozu"):
        assert n in PATTERN_NAMES


# ---------------------------------------------------------------- single candle patterns
def test_doji_detected_on_equal_open_close():
    pats = detect_patterns(_df([(10.0, 11.0, 9.0, 10.0)]))
    assert "Doji" in _names(pats)
    assert pats[0]["bias"] == "neutral"


def test_doji_not_detected_on_a_large_body():
    pats = detect_patterns(_df([(10.0, 12.0, 9.0, 11.8)]))
    assert "Doji" not in _names(pats)


def test_hammer_detected_after_a_decline():
    rows = [
        (13.0, 13.1, 12.5, 12.6),
        (12.0, 12.1, 11.5, 11.6),
        (11.0, 11.1, 10.5, 10.6),
        (10.00, 10.15, 8.00, 10.10),   # small body at the top, long lower shadow
    ]
    pats = detect_patterns(_df(rows))
    assert "Hammer" in _names(pats)
    h = [p for p in pats if p["pattern"] == "Hammer"][0]
    assert h["bar"] == 3
    assert h["bias"] == "bullish"
    assert "long lower shadow" in h["explanation"]


def test_inverted_hammer_detected_after_a_decline():
    rows = [
        (13.0, 13.1, 12.5, 12.6),
        (12.0, 12.1, 11.5, 11.6),
        (10.50, 12.00, 10.40, 10.60),   # small body at the low, long upper shadow
    ]
    pats = detect_patterns(_df(rows))
    assert "Inverted Hammer" in _names(pats)
    ih = [p for p in pats if p["pattern"] == "Inverted Hammer"][0]
    assert ih["bias"] == "bullish"


def test_shooting_star_detected_after_an_advance():
    rows = [
        (8.0, 8.1, 7.5, 7.6),
        (9.0, 9.1, 8.5, 8.6),
        (10.0, 10.1, 9.5, 9.6),
        (10.50, 12.00, 10.40, 10.60),   # small body at the low, long upper shadow
    ]
    pats = detect_patterns(_df(rows))
    assert "Shooting Star" in _names(pats)
    ss = [p for p in pats if p["pattern"] == "Shooting Star"][0]
    assert ss["bias"] == "bearish"


def test_marubozu_bullish_and_bearish():
    bull = detect_patterns(_df([(10.0, 11.0, 9.98, 11.0)]))
    assert "Marubozu" in _names(bull)
    assert [p for p in bull if p["pattern"] == "Marubozu"][0]["bias"] == "bullish"
    bear = detect_patterns(_df([(11.0, 11.02, 10.0, 10.0)]))
    assert "Marubozu" in _names(bear)
    assert [p for p in bear if p["pattern"] == "Marubozu"][0]["bias"] == "bearish"


# ---------------------------------------------------------------- two candle patterns
def test_bullish_engulfing():
    rows = [(10.0, 10.5, 9.5, 9.6), (9.5, 11.0, 9.4, 10.8)]
    pats = detect_patterns(_df(rows))
    assert "Bullish Engulfing" in _names(pats)
    be = [p for p in pats if p["pattern"] == "Bullish Engulfing"][0]
    assert be["bar"] == 1
    assert be["bias"] == "bullish"


def test_bearish_engulfing():
    rows = [(10.0, 11.0, 9.8, 10.8), (11.2, 11.3, 9.5, 9.6)]
    pats = detect_patterns(_df(rows))
    assert "Bearish Engulfing" in _names(pats)
    assert [p for p in pats if p["pattern"] == "Bearish Engulfing"][0]["bias"] == "bearish"


def test_engulfing_needs_a_prior_candle():
    pats = detect_patterns(_df([(9.5, 11.0, 9.4, 10.8)]))
    assert "Bullish Engulfing" not in _names(pats)


# ---------------------------------------------------------------- three candle patterns
def test_morning_star_detected():
    rows = [
        (10.0, 10.5, 9.5, 10.0),
        (12.0, 12.2, 11.8, 12.0),
        (11.0, 11.2, 10.0, 10.2),    # long red
        (9.6, 9.8, 9.4, 9.7),        # small star gapping lower
        (9.8, 11.2, 9.7, 11.0),      # long green closing into the first body
    ]
    pats = detect_patterns(_df(rows))
    assert "Morning Star" in _names(pats)
    ms = [p for p in pats if p["pattern"] == "Morning Star"][0]
    assert ms["bar"] == 4
    assert ms["bias"] == "bullish"


def test_evening_star_detected():
    rows = [
        (10.0, 10.5, 9.5, 10.0),
        (10.0, 11.0, 9.8, 10.8),     # long green
        (12.4, 12.6, 12.2, 12.3),    # small star gapping up
        (11.8, 12.2, 10.2, 10.3),    # long red closing below the first body mid
    ]
    pats = detect_patterns(_df(rows))
    assert "Evening Star" in _names(pats)
    es = [p for p in pats if p["pattern"] == "Evening Star"][0]
    assert es["bar"] == 3
    assert es["bias"] == "bearish"


# ---------------------------------------------------------------- integrity
def test_every_detection_carries_timestamp_explanation_and_no_signal_warning():
    rng = np.random.default_rng(5)
    close = 100 + np.cumsum(rng.normal(0, 1, 200))
    df = pd.DataFrame({"open": close, "high": close * 1.01, "low": close * 0.99,
                       "close": close, "volume": 1000})
    df["timestamp"] = pd.date_range("2024-01-01", periods=200, freq="B", tz="Asia/Kolkata")
    pats = detect_patterns(df)
    assert pats
    for p in pats:
        assert p["pattern"] in PATTERN_NAMES
        assert p["timestamp"]
        assert len(p["explanation"]) > 25
        assert "not guaranteed buy/sell signals" in p["note"]
        assert p["bias"] in ("bullish", "bearish", "neutral")
        assert p["confirmed_at_bar"] == p["bar"]


def test_detection_is_causal_no_future_bars_used():
    """Changing a later candle must not change earlier detections."""
    rng = np.random.default_rng(6)
    close = 100 + np.cumsum(rng.normal(0, 1, 150))
    df1 = pd.DataFrame({"open": close, "high": close * 1.01, "low": close * 0.99,
                        "close": close, "volume": 1000})
    df1["timestamp"] = pd.date_range("2024-01-01", periods=150, freq="B", tz="Asia/Kolkata")
    df2 = df1.copy()
    df2.loc[100:, ["open", "high", "low", "close"]] *= 2.5
    a = [p for p in detect_patterns(df1) if p["bar"] < 100]
    b = [p for p in detect_patterns(df2) if p["bar"] < 100]
    assert [(p["bar"], p["pattern"]) for p in a] == [(p["bar"], p["pattern"]) for p in b]


def test_detections_are_sorted_by_bar():
    rng = np.random.default_rng(8)
    close = 100 + np.cumsum(rng.normal(0, 1, 120))
    df = pd.DataFrame({"open": close, "high": close * 1.01, "low": close * 0.99,
                       "close": close, "volume": 1000})
    df["timestamp"] = pd.date_range("2024-01-01", periods=120, freq="B", tz="Asia/Kolkata")
    bars = [p["bar"] for p in detect_patterns(df)]
    assert bars == sorted(bars)


def test_doji_is_suppressed_when_a_more_specific_pattern_fires():
    rows = [
        (13.0, 13.1, 12.5, 12.6),
        (12.0, 12.1, 11.5, 11.6),
        (11.0, 11.1, 10.5, 10.6),
        (10.00, 10.15, 8.00, 10.10),
    ]
    pats = detect_patterns(_df(rows))
    assert "Hammer" in _names(pats)
    assert "Doji" not in _names(pats)
