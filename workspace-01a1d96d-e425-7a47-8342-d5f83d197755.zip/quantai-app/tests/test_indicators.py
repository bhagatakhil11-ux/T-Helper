"""Technical indicator correctness: hand-computed values, causality (no look-ahead),
warm-up handling and VWAP validity rules."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantai.indicators import (INDICATOR_COLUMNS, SMA_PERIODS, EMA_PERIODS, atr, bollinger,
                                compute_indicators, ema, indicator_score, macd, rsi, sma, vwap)


def _df(close, volume=None, start="2024-01-01", freq="B", tz="Asia/Kolkata"):
    close = np.asarray(close, dtype=float)
    n = len(close)
    open_ = np.concatenate([[close[0]], close[:-1]]) if n > 1 else close
    df = pd.DataFrame({
        "timestamp": pd.date_range(start, periods=n, freq=freq, tz=tz),
        "open": open_, "high": close * 1.01, "low": close * 0.99,
        "close": close, "volume": volume if volume is not None else np.full(n, 1000.0),
    })
    return df


# ---------------------------------------------------------------- EMA / SMA
def test_ema_is_sma_seeded_recursive():
    close = pd.Series([1.0, 2.0, 3.0, 4.0, 5.0, 6.0])
    out = ema(close, 3)
    assert np.isnan(out.iloc[0]) and np.isnan(out.iloc[1])
    # seed = SMA of first 3 values
    assert out.iloc[2] == pytest.approx(2.0)
    alpha = 2 / 4
    assert out.iloc[3] == pytest.approx(alpha * 4 + (1 - alpha) * 2.0)
    assert out.iloc[5] == pytest.approx(alpha * 6 + (1 - alpha) * out.iloc[4])


def _sma_seeded_ema_ref(values, period):
    """Independent SMA-seeded recursive EMA reference (written from the definition)."""
    out = [np.nan] * len(values)
    if len(values) < period:
        return np.array(out)
    alpha = 2 / (period + 1)
    out[period - 1] = float(np.mean(values[:period]))
    for i in range(period, len(values)):
        out[i] = alpha * values[i] + (1 - alpha) * out[i - 1]
    return np.array(out)


def test_ema_matches_independent_sma_seeded_reference():
    rng = np.random.default_rng(7)
    close = 100 + np.cumsum(rng.normal(0, 1, 60))
    ours = ema(pd.Series(close), 10).to_numpy()
    ref = _sma_seeded_ema_ref(close, 10)
    np.testing.assert_allclose(ours, ref, rtol=1e-12, equal_nan=True)


def test_ema_leading_nan_window_is_not_seeded_from_nan():
    close = pd.Series([np.nan] * 5 + [float(x) for x in range(1, 21)])
    out = ema(close, 10)
    assert out.iloc[:14].isna().all()
    assert np.isfinite(out.iloc[14])


def test_sma_warmup_is_nan_not_filled():
    close = pd.Series(np.arange(1, 11, dtype=float))
    out = sma(close, 5)
    assert out.iloc[:4].isna().all()
    assert out.iloc[4] == pytest.approx(3.0)
    assert out.iloc[-1] == pytest.approx(8.0)


def test_sma_and_ema_period_sets_match_spec():
    assert EMA_PERIODS == (9, 20, 50, 200)
    assert SMA_PERIODS == (20, 50, 200)
    for p in EMA_PERIODS:
        assert f"ema_{p}" in INDICATOR_COLUMNS
    for p in SMA_PERIODS:
        assert f"sma_{p}" in INDICATOR_COLUMNS


# ---------------------------------------------------------------- RSI
def test_rsi_all_gains_is_100_and_all_losses_is_0():
    up = rsi(pd.Series(np.arange(1, 40, dtype=float)), 14)
    assert up.iloc[-1] == pytest.approx(100.0)
    dn = rsi(pd.Series(np.arange(40, 1, -1, dtype=float)), 14)
    assert dn.iloc[-1] == pytest.approx(0.0)


def test_rsi_flat_series_is_50_not_nan():
    out = rsi(pd.Series([100.0] * 40), 14)
    assert out.iloc[14] == pytest.approx(50.0)
    assert out.iloc[-1] == pytest.approx(50.0)


def test_rsi_warmup_and_bounds():
    rng = np.random.default_rng(3)
    close = pd.Series(100 + np.cumsum(rng.normal(0, 1, 80)))
    out = rsi(close, 14)
    assert out.iloc[:14].isna().all()
    valid = out.dropna()
    assert valid.between(0, 100).all()


def test_rsi_wilder_reference_value():
    """Wilder's worked example (S&P closes). The first RSI(14) is computed
    independently here from the definition and must match exactly."""
    close = pd.Series([44.34, 44.09, 44.15, 43.61, 44.33, 44.83, 45.10, 45.42,
                       45.84, 46.08, 45.89, 46.03, 45.61, 46.28, 46.28])
    out = rsi(close, 14)
    d = np.diff(close.to_numpy())
    gains = np.where(d > 0, d, 0.0)
    losses = np.where(d < 0, -d, 0.0)
    avg_gain = gains[:14].mean()
    avg_loss = losses[:14].mean()
    expected = 100 - 100 / (1 + avg_gain / avg_loss)
    assert out.iloc[14] == pytest.approx(expected, rel=1e-12)
    assert out.iloc[14] == pytest.approx(70.46, abs=0.05)


# ---------------------------------------------------------------- ATR
def test_atr_hand_computed_on_constant_range():
    # every bar has high-low = 2 and previous close inside the range
    df = _df([100.0] * 20)
    df["high"] = 101.0
    df["low"] = 99.0
    out = atr(df, 14)
    assert np.isnan(out.iloc[12])
    assert out.iloc[13] == pytest.approx(2.0)
    assert out.iloc[-1] == pytest.approx(2.0)


def test_true_range_uses_previous_close():
    df = _df([100.0, 120.0])
    df["high"] = [101.0, 121.0]
    df["low"] = [99.0, 119.0]
    a = atr(df, 2)
    # bar 1 true range = max(2, |121-100|, |119-100|) = 21
    assert a.iloc[1] == pytest.approx((21.0 + 2.0) / 2)


# ---------------------------------------------------------------- MACD
def test_macd_is_ema12_minus_ema26_and_hist_is_line_minus_signal():
    rng = np.random.default_rng(11)
    close = pd.Series(100 + np.cumsum(rng.normal(0, 1, 120)))
    line, sig, hist = macd(close)
    e12 = ema(close, 12)
    e26 = ema(close, 26)
    assert line.iloc[-1] == pytest.approx((e12.iloc[-1] - e26.iloc[-1]))
    assert hist.iloc[-1] == pytest.approx(line.iloc[-1] - sig.iloc[-1])


def test_macd_warmup_nan():
    rng = np.random.default_rng(5)
    close = pd.Series(100 + np.cumsum(rng.normal(0, 1, 60)))
    line, sig, hist = macd(close)
    assert line.iloc[:25].isna().all()
    assert sig.iloc[:33].isna().all()


# ---------------------------------------------------------------- Bollinger
def test_bollinger_population_std_and_percent_b():
    close = pd.Series([10.0] * 25)
    mid, up, lo, pb, bw = bollinger(close, 20, 2.0)
    assert mid.iloc[:19].isna().all()
    assert mid.iloc[-1] == pytest.approx(10.0)
    assert up.iloc[-1] == pytest.approx(10.0)
    # A flat series has a zero-width band: %B is undefined (NaN), not a fake number.
    assert np.isnan(pb.iloc[-1])


def test_bollinger_percent_b_is_nan_when_band_is_flat():
    close = pd.Series([10.0] * 25)
    _, _, _, pb, bw = bollinger(close, 20, 2.0)
    assert np.isnan(pb.iloc[-1])
    assert bw.iloc[-1] == 0.0


def test_bollinger_percent_b_is_zero_at_lower_band_and_one_at_upper():
    rng = np.random.default_rng(31)
    close = pd.Series(100 + rng.normal(0, 1, 60))
    mid, up, lo, pb, _ = bollinger(close, 20, 2.0)
    i = -1
    # reconstruct what %B must be from the band definition
    expected = (close.iloc[i] - lo.iloc[i]) / (up.iloc[i] - lo.iloc[i])
    assert pb.iloc[i] == pytest.approx(expected, rel=1e-12)
    assert pb.iloc[i] == pytest.approx(0.5, abs=0.25)
    assert 0.0 <= pb.iloc[i] <= 1.0


def test_bollinger_bands_are_two_population_std_away():
    rng = np.random.default_rng(2)
    close = pd.Series(100 + rng.normal(0, 2, 60))
    mid, up, lo, pb, bw = bollinger(close, 20, 2.0)
    i = -1
    expected_sd = close.iloc[-20:].std(ddof=0)
    assert up.iloc[i] == pytest.approx(mid.iloc[i] + 2 * expected_sd)
    assert lo.iloc[i] == pytest.approx(mid.iloc[i] - 2 * expected_sd)


# ---------------------------------------------------------------- VWAP
def test_vwap_is_invalid_for_daily_timeframe():
    df = _df(np.arange(1, 30, dtype=float))
    s, valid = vwap(df, "1D")
    assert valid is False
    assert s.isna().all()


def test_vwap_invalid_when_volume_is_zero():
    df = _df(np.arange(1, 30, dtype=float), volume=np.zeros(29))
    s, valid = vwap(df, "15m")
    assert valid is False
    assert s.isna().all()


def test_vwap_session_anchored_resets_each_day():
    ts = pd.date_range("2024-01-01 09:15", periods=6, freq="15min", tz="Asia/Kolkata")
    ts = ts.append(ts + pd.Timedelta(days=1))
    df = pd.DataFrame({"timestamp": ts, "open": [10.0] * 12, "high": [10.0] * 12,
                       "low": [10.0] * 12, "close": [10.0] * 12,
                       "volume": [100.0] * 12})
    s, valid = vwap(df, "15m")
    assert valid is True
    assert s.iloc[0] == pytest.approx(10.0)
    # second session restarts the cumulative sum
    assert s.iloc[6] == pytest.approx(10.0)


def test_vwap_uses_typical_price():
    ts = pd.date_range("2024-01-01 09:15", periods=2, freq="15min", tz="Asia/Kolkata")
    df = pd.DataFrame({"timestamp": ts, "open": [10.0, 10.0], "high": [12.0, 12.0],
                       "low": [8.0, 8.0], "close": [10.0, 10.0], "volume": [100.0, 100.0]})
    s, valid = vwap(df, "15m")
    assert valid is True
    assert s.iloc[-1] == pytest.approx((10 + 12 + 8) / 3)


# ---------------------------------------------------------------- composite
def test_compute_indicators_returns_expected_columns_and_null_warmup():
    rng = np.random.default_rng(4)
    df = _df(100 + np.cumsum(rng.normal(0, 1, 300)))
    ind = compute_indicators(df, "1D")
    assert list(ind.columns) == list(INDICATOR_COLUMNS)
    assert len(ind.columns) == 18
    assert ind["ema_200"].iloc[:198].isna().all()
    assert np.isfinite(ind["ema_200"].iloc[-1])
    assert ind["vwap"].isna().all()


def test_indicators_are_causal_no_lookahead():
    """Changing a FUTURE bar must not change any earlier indicator value."""
    rng = np.random.default_rng(9)
    close = 100 + np.cumsum(rng.normal(0, 1, 200))
    df1 = _df(close)
    df2 = _df(close.copy())
    df2.loc[150:, "close"] *= 3.0
    df2.loc[150:, "high"] = df2.loc[150:, "close"] * 1.01
    df2.loc[150:, "low"] = df2.loc[150:, "close"] * 0.99
    df2.loc[150:, "open"] = df2.loc[150:, "close"]
    i1 = compute_indicators(df1, "1D")
    i2 = compute_indicators(df2, "1D")
    for col in INDICATOR_COLUMNS:
        a = i1[col].iloc[:150].to_numpy()
        b = i2[col].iloc[:150].to_numpy()
        np.testing.assert_allclose(a, b, rtol=1e-12, equal_nan=True)


def test_indicator_score_is_bounded_and_needs_warmup():
    rng = np.random.default_rng(21)
    df = _df(100 + np.cumsum(rng.normal(0, 1, 400)))
    ind = compute_indicators(df, "1D")
    s = indicator_score(ind.iloc[-1])
    assert -1.0 <= s <= 1.0
    assert np.isnan(indicator_score(ind.iloc[0]))
    scores = [indicator_score(ind.iloc[i]) for i in range(60, len(ind))]
    assert all(np.isfinite(scores))
    assert max(abs(x) for x in scores) <= 1.0


def test_indicator_score_is_undefined_on_a_perfectly_flat_market():
    # %B is mathematically undefined for a zero-width band, so the score is NaN
    # rather than a fabricated neutral number. No signal is produced.
    ind = compute_indicators(_df([100.0] * 300), "1D")
    assert np.isnan(indicator_score(ind.iloc[-1]))


def test_indicator_score_sign_follows_uptrend():
    rng = np.random.default_rng(33)
    up = compute_indicators(_df(100 + np.arange(300) * 0.5 + rng.normal(0, 0.2, 300)), "1D")
    dn = compute_indicators(_df(100 + np.arange(300) * -0.5 + rng.normal(0, 0.2, 300)), "1D")
    assert indicator_score(up.iloc[-1]) > 0.2
    assert indicator_score(dn.iloc[-1]) < -0.2
