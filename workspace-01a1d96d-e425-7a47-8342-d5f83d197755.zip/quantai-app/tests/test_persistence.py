"""Persistence across restarts, path-traversal safety, journal summaries."""
import json

import pytest

from engine import AppState
from make_fixture import make_fixture
from storage import Store


@pytest.fixture()
def state(tmp_path):
    s = AppState(store_root=tmp_path / "store")
    p = tmp_path / "x.csv"
    p.write_text("# SYNTHETIC\n" + make_fixture(200, "1D", seed=9).to_csv(index=False))
    s.import_csv(p, "PERSIST", "1D", "TEST_FIXTURE", "UNKNOWN_UNVERIFIED")
    return s


def test_dataset_and_settings_survive_restart(state, tmp_path):
    state.update_risk({"risk_per_trade_pct": 1.0, "max_total_drawdown_pct": 20.0})
    state.update_execution({"slippage_bps": 7.0})
    ds_id = state.active()["meta"].dataset_id
    # Simulate restart: brand-new AppState on the same store root.
    s2 = AppState(store_root=tmp_path / "store")
    assert s2.active() is not None
    assert s2.active()["meta"].dataset_id == ds_id
    assert s2.risk.risk_per_trade_pct == 1.0
    assert s2.risk.max_total_drawdown_pct == 20.0
    assert s2.execution.slippage_bps == 7.0
    assert s2.replay["running"] is False          # never auto-resumes


def test_journal_persists_and_summarises(state, tmp_path):
    state.journal.add({"run_id": "r1", "dataset_id": "d", "symbol": "PERSIST", "timeframe": "1D",
                       "strategy": "ensemble", "direction": "LONG", "qty": 10,
                       "entry_time": "2024-01-01T10:00:00+05:30", "entry_price": 100,
                       "exit_time": "2024-01-01T15:00:00+05:30", "exit_price": 110,
                       "pnl": 100, "costs": 5, "entry_reason": "test", "exit_reason": "target"})
    state.journal.add({"run_id": "r1", "symbol": "PERSIST", "strategy": "ensemble", "direction": "LONG",
                       "qty": 10, "entry_time": "2024-01-02T10:00:00+05:30", "entry_price": 100,
                       "exit_time": "2024-01-02T15:00:00+05:30", "exit_price": 90,
                       "pnl": -100, "costs": 5, "entry_reason": "test", "exit_reason": "stop_loss"})
    s2 = AppState(store_root=tmp_path / "store")
    assert s2.journal.count() == 2
    daily = s2.journal.summaries("daily")
    assert len(daily) == 2
    assert daily[0]["net_pnl"] in (100, -100)
    monthly = s2.journal.summaries("monthly")
    assert len(monthly) == 1 and monthly[0]["trades"] == 2 and monthly[0]["net_pnl"] == 0
    weekly = s2.journal.summaries("weekly")
    assert len(weekly) >= 1
    tid = s2.journal.list()[0]["id"]
    assert s2.journal.update_note(tid, "reviewed")
    assert s2.journal.list()[0]["notes"] == "reviewed"
    assert "entry_price" in s2.journal.to_csv()


def test_store_rejects_path_traversal_ids(tmp_path):
    store = Store(tmp_path / "store")
    for bad in ("../../etc", "X_1D_zzz", "..\\windows", "X_1D_000000000000/../../y"):
        with pytest.raises(ValueError):
            store.dataset_dir(bad)
    with pytest.raises(ValueError):
        store.model_dir("../evil")
    with pytest.raises(ValueError):
        store.research_path("run_../../evil")


def test_non_finite_values_are_json_safe(tmp_path):
    from storage import json_safe
    out = json_safe({"a": float("inf"), "b": float("nan"), "c": [1, float("-inf")]})
    assert out == {"a": None, "b": None, "c": [1, None]}
    json.dumps(out, allow_nan=False)   # must not raise


def test_delete_dataset_removes_files_and_invalidates_model(state, tmp_path):
    key = state.active_key
    ds_id = state.active()["meta"].dataset_id
    state.delete_dataset(key)
    assert key not in state.datasets
    assert not (tmp_path / "store" / "datasets" / ds_id).exists()
    s2 = AppState(store_root=tmp_path / "store")
    assert s2.active() is None or s2.active()["meta"].dataset_id != ds_id
