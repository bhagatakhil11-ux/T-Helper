/* Headless DOM shim + journal / live-stats harness.
 *
 * Runs the REAL inline JavaScript from static/index.html under a minimal DOM
 * and a mocked fetch, so the journal rendering and the live replay readout
 * are actually executed (not just syntax-checked).
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(ROOT, 'static', 'index.html'), 'utf8');
const js = html.match(/<script>([\s\S]*?)<\/script>/)[1];

let failures = 0;
function check(name, cond, extra) {
  if (cond) console.log('  PASS ' + name);
  else { failures++; console.log('  FAIL ' + name + (extra !== undefined ? ' :: ' + JSON.stringify(extra) : '')); }
}

// ------------------------------------------------------------------ DOM shim
const elements = {};
function makeEl(id) {
  const el = {
    id, _html: '', _text: '', value: '', style: {}, dataset: {}, clientWidth: 900,
    width: 900, height: 380, className: '', checked: false,
    classList: { add() {}, remove() {}, contains() { return false; } },
    addEventListener(ev, fn) { (this._ev = this._ev || {})[ev] = fn; },
    removeEventListener() {},
    getBoundingClientRect() { return { left: 0, top: 0, width: 900, height: 300, right: 900, bottom: 300 }; },
    getContext() { return { fillRect() {}, strokeRect() {}, clearRect() {}, beginPath() {}, moveTo() {}, lineTo() {}, stroke() {}, fill() {}, fillText() {}, measureText() { return { width: 10 }; }, save() {}, restore() {}, set fillStyle(v) {}, set strokeStyle(v) {}, set lineWidth(v) {}, set font(v) {}, set textAlign(v) {}, set globalAlpha(v) {} }; },
    querySelectorAll() { return []; },
    querySelector() { return makeEl('sub'); },
    appendChild() {}, removeChild() {},
    focus() {}, blur() {},
  };
  Object.defineProperty(el, 'innerHTML', { get() { return el._html; }, set(v) { el._html = v; } });
  Object.defineProperty(el, 'textContent', { get() { return el._text; }, set(v) { el._text = v; } });
  Object.defineProperty(el, 'options', { get() { return this._options || []; }, set(v) { this._options = v; } });
  el.offsetWidth = 200; el.offsetHeight = 100;
  return el;
}
function getEl(sel) {
  const id = String(sel).replace(/^#/, '');
  if (!elements[id]) elements[id] = makeEl(id);
  return elements[id];
}

global.document = {
  body: { classList: { add() {}, remove() {}, contains() { return false; } } },
  documentElement: {},
  querySelector: (s) => getEl(s),
  getElementById: (id) => getEl('#' + id),
  querySelectorAll: (s) => {
    if (s === 'nav button') return [makeEl('nav1'), makeEl('nav2')];
    if (s === '.panel') return [makeEl('p1')];
    return [];
  },
  addEventListener(ev, fn) { (this._ev = this._ev || {})[ev] = fn; },
  createElement: (tag) => makeEl('new-' + tag),
};
global.window = {
  devicePixelRatio: 1,
  addEventListener() {},
  location: { href: '' },
  getComputedStyle: () => ({ getPropertyValue: () => '#123456' }),
};
global.getComputedStyle = global.window.getComputedStyle;
global.localStorage = { getItem: () => null, setItem() {} };
global.setInterval = () => 0;
global.clearInterval = () => {};
global.setTimeout = (fn) => { try { fn(); } catch (e) {} return 0; };
global.alert = () => {};

// ------------------------------------------------------------- mocked payloads
const TRADES = [
  { id: 't1', symbol: 'AAA', strategy: 'ensemble', direction: 'LONG', qty: 10,
    entry_price: 100, exit_price: 110, stop: 95, target: 120, pnl: 500, costs: 12,
    entry_reason: 'signal', exit_reason: 'target', exit_time: '2024-01-02T15:00:00+05:30',
    notes: 'clean entry', tags: 'breakout,news', tag_list: ['breakout', 'news'], emotion: 'calm' },
  { id: 't2', symbol: 'AAA', strategy: 'ml_only', direction: 'LONG', qty: 10,
    entry_price: 100, exit_price: 95, stop: 95, target: 120, pnl: -220, costs: 12,
    entry_reason: 'signal', exit_reason: 'stop_loss', exit_time: '2024-01-03T15:00:00+05:30',
    notes: '', tags: 'mistake', tag_list: ['mistake'], emotion: 'revenge' },
];
const OVERVIEW = {
  trades: 2, wins: 1, losses: 1, breakeven: 0, win_rate_pct: 50.0,
  net_pnl: 280, avg_pnl: 140, gross_profit: 500, gross_loss: 220, profit_factor: 2.27,
  expectancy_per_trade: 140, total_costs: 24, tagged_trades: 2, emotion_recorded: 2,
  by_strategy: [
    { key: 'ensemble', trades: 1, wins: 1, losses: 0, breakeven: 0, win_rate_pct: 100,
      net_pnl: 500, avg_pnl: 500, gross_profit: 500, gross_loss: 0, profit_factor: null,
      avg_win: 500, avg_loss: null, expectancy_per_trade: 500, total_costs: 12 },
    { key: 'ml_only', trades: 1, wins: 0, losses: 1, breakeven: 0, win_rate_pct: 0,
      net_pnl: -220, avg_pnl: -220, gross_profit: 0, gross_loss: 220, profit_factor: 0,
      avg_win: null, avg_loss: 220, expectancy_per_trade: -220, total_costs: 12 },
  ],
  by_emotion: [
    { key: 'calm', trades: 1, wins: 1, losses: 0, breakeven: 0, win_rate_pct: 100,
      net_pnl: 500, avg_pnl: 500, gross_profit: 500, gross_loss: 0, profit_factor: null,
      avg_win: 500, avg_loss: null, expectancy_per_trade: 500, total_costs: 12 },
    { key: 'revenge', trades: 1, wins: 0, losses: 1, breakeven: 0, win_rate_pct: 0,
      net_pnl: -220, avg_pnl: -220, gross_profit: 0, gross_loss: 220, profit_factor: 0,
      avg_win: null, avg_loss: 220, expectancy_per_trade: -220, total_costs: 12 },
  ],
  by_tag: [
    { key: 'breakout', trades: 1, wins: 1, losses: 0, breakeven: 0, win_rate_pct: 100,
      net_pnl: 500, avg_pnl: 500, gross_profit: 500, gross_loss: 0, profit_factor: null,
      avg_win: 500, avg_loss: null, expectancy_per_trade: 500, total_costs: 12 },
    { key: 'news', trades: 1, wins: 1, losses: 0, breakeven: 0, win_rate_pct: 100,
      net_pnl: 500, avg_pnl: 500, gross_profit: 500, gross_loss: 0, profit_factor: null,
      avg_win: 500, avg_loss: null, expectancy_per_trade: 500, total_costs: 12 },
    { key: 'mistake', trades: 1, wins: 0, losses: 1, breakeven: 0, win_rate_pct: 0,
      net_pnl: -220, avg_pnl: -220, gross_profit: 0, gross_loss: 220, profit_factor: 0,
      avg_win: null, avg_loss: 220, expectancy_per_trade: -220, total_costs: 12 },
  ],
  by_symbol: [],
  suggested_tags: ['breakout', 'mean-reversion', 'news', 'mistake'],
  emotion_states: ['calm', 'fomo', 'revenge', 'neutral'],
};
const LIVE = {
  trades: 12, wins: 7, losses: 4, breakeven: 1, win_rate_pct: 63.6,
  profit_factor: 1.85, expectancy_per_trade: 120.5, avg_win: 900, avg_loss: 480,
  payoff_ratio: 1.87, gross_profit: 6300, gross_loss: 1920, realized_pnl: 1446,
  unrealized_pnl: 220, total_pnl: 1666, best_trade: 1400, worst_trade: -700,
  current_streak: 2, streak_kind: 'win', max_win_streak: 4, max_loss_streak: 3,
  max_drawdown_pct: 3.21, current_drawdown_pct: 1.1, peak_equity: 512000,
  equity: 506000, total_costs: 380, cost_drag_pct: 0.076, status_reason: '',
};

const apiCalls = [];
global.fetch = async (url, opts) => {
  const u = String(url);
  apiCalls.push(u);
  if (u.includes('/api/journal/overview')) return { ok: true, status: 200, json: async () => ({ ok: true, overview: OVERVIEW }) };
  if (u.includes('/api/journal/events')) return { ok: true, status: 200, json: async () => ({ ok: true, events: [
    { id: 'e1', created_at: '2024-01-02T10:00:00+00:00', event_type: 'kill_switch_engaged',
      reason: 'Revenge trading after 3 losses', detail: 'all entries blocked', bar: 42, equity: 500000 },
    { id: 'e2', created_at: '2024-01-02T11:00:00+00:00', event_type: 'risk_settings_changed',
      reason: 'Changed: risk_per_trade_pct', detail: 'risk_per_trade_pct: 0.5 -> 1.0', bar: null, equity: null },
  ] }) };
  if (u.includes('/api/journal/vocabulary')) return { ok: true, status: 200, json: async () => ({ ok: true, suggested_tags: OVERVIEW.suggested_tags, emotion_states: OVERVIEW.emotion_states }) };
  if (u.includes('/api/journal/summary')) return { ok: true, status: 200, json: async () => ({ ok: true, period: 'daily', summaries: [{ bucket: '2024-01-02', trades: 2, wins: 1, losses: 1, win_rate_pct: 50, net_pnl: 280, avg_pnl: 140, total_costs: 24 }] }) };
  if (u.includes('/api/journal?')) return { ok: true, status: 200, json: async () => ({ ok: true, trades: TRADES }) };
  return { ok: true, status: 200, json: async () => ({ ok: true }) };
};
global.api = async (url, body) => {
  apiCalls.push('POST ' + url + ' ' + JSON.stringify(body));
  return { ok: true };
};

(async () => {
  console.log('== journal JS harness ==');
  const fn = new Function(js + '\n;return {liveStatsBlock:liveStatsBlock, breakdownTable:breakdownTable, tagChips:tagChips, emotionBadge:emotionBadge, loadJournal:loadJournal, EMOTION_LABEL:EMOTION_LABEL, riskStateBlock:riskStateBlock, renderOpenPositionWarning:renderOpenPositionWarning, riskPayload:riskPayload};');
  const A = fn();

  // ---- live stats block
  const live = A.liveStatsBlock(LIVE);
  check('live block shows the running win rate', live.includes('63.6'), live.slice(0, 200));
  check('live block shows the profit factor', live.includes('1.85'));
  check('live block shows the drawdown', live.includes('3.21'));
  check('live block shows the expectancy', live.includes('120'));
  check('live block shows the current streak', live.includes('2 win'), live.match(/Current streak[\s\S]{0,120}/));
  check('live block shows the cost drag', live.includes('0.08'));
  check('live block shows the best and worst trade', live.includes('1,400') && live.includes('-700'), live.match(/Best trade[\s\S]{0,160}/));

  // ---- an empty live block must not print fake numbers
  const emptyLive = A.liveStatsBlock({ trades: 0, wins: 0, losses: 0, win_rate_pct: null, profit_factor: null, expectancy_per_trade: null, max_drawdown_pct: 0, current_drawdown_pct: 0, total_costs: 0 });
  check('empty live block shows no fake win rate', !emptyLive.includes('0.0%'), emptyLive.match(/Running win rate[\s\S]{0,120}/));
  check('empty live block shows a dash for the win rate', emptyLive.includes('—'), emptyLive.match(/Running win rate[\s\S]{0,140}/));
  check('empty live block shows no profit factor', !/Profit factor[\s\S]{0,200}1\.00/.test(emptyLive));

  // ---- breakdown table
  const bd = A.breakdownTable(OVERVIEW.by_strategy, 'Strategy');
  check('breakdown table lists the strategy', bd.includes('ensemble') && bd.includes('ml_only'));
  check('breakdown table shows the win rate', bd.includes('100.0'));
  check('breakdown table shows the net P&L', bd.includes('500') && bd.includes('-220'));
  check('breakdown table marks an undefined profit factor as a dash', bd.includes('—'), bd.match(/Profit factor[\s\S]{0,200}/));

  // ---- tag chips + emotion badge
  check('tag chips render the tag names', A.tagChips(['breakout', 'news']).includes('breakout'));
  check('tag chips render "none" for an empty list', A.tagChips([]).includes('none'));
  check('emotion badge renders the label', A.emotionBadge('revenge').includes('Revenge'));
  check('emotion badge says "not recorded" when empty', A.emotionBadge('').includes('not recorded'));

  // ---- the journal loader wires everything up
  await A.loadJournal();
  const tradesHtml = getEl('#jTrades').innerHTML;
  check('journal table renders the trades', tradesHtml.includes('2024-01-02'), tradesHtml.slice(0, 200));
  check('journal table renders the tag chips', tradesHtml.includes('jtag'));
  check('journal table renders the tag input', tradesHtml.includes('tagIn_t1'));
  check('journal table renders the emotion select', tradesHtml.includes('saveEmotion'));
  check('journal table renders the notes input', tradesHtml.includes('saveNote'));

  const strategyHtml = getEl('#jByStrategy').innerHTML;
  check('strategy breakdown is rendered', strategyHtml.includes('ensemble') && strategyHtml.includes('ml_only'));
  const emotionHtml = getEl('#jByEmotion').innerHTML;
  check('emotion breakdown is rendered', emotionHtml.includes('calm') && emotionHtml.includes('revenge'));
  const tagHtml = getEl('#jByTag').innerHTML;
  check('tag breakdown is rendered', tagHtml.includes('breakout') && tagHtml.includes('mistake'));
  const overviewHtml = getEl('#jOverview').innerHTML;
  check('journal totals are rendered', overviewHtml.includes('280'), overviewHtml.slice(0, 300));

  const eventsHtml = getEl('#jEvents').innerHTML;
  check('risk events are rendered', eventsHtml.includes('kill_switch_engaged'), eventsHtml.slice(0, 200));
  check('the kill switch reason is shown', eventsHtml.includes('Revenge trading after 3 losses'));
  check('the risk change event is shown', eventsHtml.includes('risk_settings_changed'));
  check('the events say a kill switch is not a trade', eventsHtml.includes('NOT a trade'));

  check('the loader fetched the overview', apiCalls.some((u) => u.includes('/api/journal/overview')));
  check('the loader fetched the events', apiCalls.some((u) => u.includes('/api/journal/events')));
  check('the loader fetched the vocabulary', apiCalls.some((u) => u.includes('/api/journal/vocabulary')));

  // ---- the tag / emotion filters are sent to the API
  getEl('#jTag').value = 'news';
  getEl('#jEmotion').value = 'revenge';
  apiCalls.length = 0;
  await A.loadJournal();
  check('the tag filter is sent to the API', apiCalls.some((u) => u.includes('tag=news')), apiCalls);
  check('the emotion filter is sent to the API', apiCalls.some((u) => u.includes('emotion=revenge')), apiCalls);

  // ---- the risk engine state block
  const RP = { weekly_drawdown_pct: 4.2, current_week: '2024-W03', week_blocked: true,
    cooldown_until_bar: 120, bar: 100, consec_losses: 5, cooldown_events: [
      { bar: 40, consecutive_losses: 3, cooldown_bars: 15, until_bar: 55 },
      { bar: 60, consecutive_losses: 5, cooldown_bars: 30, until_bar: 90 }],
    rejected: { daily_drawdown: 2, weekly_drawdown: 7 }, halted_reason: null, mode: 'HISTORICAL_REPLAY' };
  const RISK = { max_daily_drawdown_pct: 2, max_weekly_drawdown_pct: 5, max_total_drawdown_pct: 15,
    cooldown_bars: 15, max_consecutive_losses: 3 };
  const rs = A.riskStateBlock(RP, RISK);
  check('risk state shows the weekly drawdown', rs.includes('4.20'), rs.slice(0, 300));
  check('risk state shows the week', rs.includes('2024-W03'));
  check('risk state flags the blocked week', rs.includes('BLOCKED'));
  check('risk state shows the cooldown countdown', rs.includes('bar 20'), rs.match(/Cooldown[\s\S]{0,200}/));
  check('risk state shows the cooldown history', rs.includes('30 bars'));
  check('risk state lists the daily limit', rs.includes('Daily loss limit'));

  // ---- the open-position warning
  const warn = A.renderOpenPositionWarning({ message: 'A paper position is OPEN.',
    open_position: { qty: 344, entry: 111.44, stop: 104.18, target: 125.96, last: 104.29, unrealized: -2517, bar: 37 },
    changed_fields: [{ field: 'risk_per_trade_pct', from: 0.5, to: 1.0 }] });
  check('the warning names the open position', warn.includes('A paper position is OPEN'));
  check('the warning shows the position details', warn.includes('344') && warn.includes('111.44'));
  check('the warning lists the changed fields', warn.includes('risk_per_trade_pct'));
  check('the warning offers both apply and cancel', warn.includes('btnRiskAnyway') && warn.includes('btnRiskCancel'));

  // ---- the risk payload carries every new field
  const payload = A.riskPayload();
  for (const k of ['max_weekly_drawdown_pct', 'progressive_cooldown', 'auto_risk_by_volatility',
                   'risk_vol_target_pct', 'risk_vol_min_factor', 'risk_vol_max_factor']) {
    check('the risk payload carries ' + k, k in payload);
  }

  console.log(failures === 0 ? 'ALL JOURNAL JS CHECKS PASSED' : (failures + ' JOURNAL JS CHECKS FAILED'));
  process.exit(failures === 0 ? 0 : 1);
})().catch((e) => {
  console.log('HARNESS ERROR ' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
