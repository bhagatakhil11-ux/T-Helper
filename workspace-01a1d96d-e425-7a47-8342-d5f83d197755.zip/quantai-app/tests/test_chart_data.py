"""Chart payload, support/resistance zones and the technical-analysis summary.

These tests guard the three integrity promises of the charting module:
  1. only real imported candles are used and nothing is fabricated,
  2. historical views never use a future candle,
  3. support/resistance separates confirmed from developing levels.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantai.charting import build_chart_payload, technical_summary
from quantai.indicators import INDICATOR_COLUMNS
from quantai.levels import detect_pivots, support_resistance


def _frame(n=300, seed=3, start="2020-01-01", freq="B", volume=None):
    rng = np.random.default_rng(seed)
    close = 100 * np.exp(np.cumsum(rng.normal(0.0002, 0.011, n)))
    open_ = np.concatenate([[close[0]], close[:-1]])
    df = pd.DataFrame({
        "timestamp": pd.date_range(start, periods=n, freq=freq, tz="Asia/Kolkata"),
        "open": open_, "high": np.maximum(open_, close) * 1.004,
        "low": np.minimum(open_, close) * 0.996,
        "close": close,
        "volume": rng.integers(1e5, 1e6, n) if volume is None else volume,
    })
    return df


# ---------------------------------------------------------------- payload shape
def test_chart_payload_contains_candles_indicators_patterns_levels_summary():
    df = _frame()
    p = build_chart_payload(df, {"symbol": "TEST", "timeframe": "1D", "source_type": "IMPORTED_CSV"})
    assert p["status"] == "ok"
    assert len(p["candles"]) == len(df)
    assert set(p["indicator_columns"]) == set(INDICATOR_COLUMNS)
    assert len(p["indicators"]) == len(INDICATOR_COLUMNS)
    for col in INDICATOR_COLUMNS:
        assert len(p["indicators"][col]) == len(df)
    assert isinstance(p["patterns"], list)
    assert "zones" in p["levels"]
    assert p["summary"]["as_of_bar"] == len(df) - 1
    assert p["truncated"] is False


def test_chart_payload_never_fabricates_candles():
    df = _frame(120)
    p = build_chart_payload(df, {"symbol": "T", "timeframe": "1D"})
    for c, (_, row) in zip(p["candles"], df.iterrows()):
        assert c["o"] == pytest.approx(row["open"])
        assert c["h"] == pytest.approx(row["high"])
        assert c["l"] == pytest.approx(row["low"])
        assert c["c"] == pytest.approx(row["close"])
        assert c["v"] == int(row["volume"])
        assert c["t"] == str(row["timestamp"])


def test_indicator_warmup_is_null_not_backfilled():
    df = _frame(300)
    p = build_chart_payload(df, {"symbol": "T", "timeframe": "1D"})
    ema200 = p["indicators"]["ema_200"]
    assert all(v is None for v in ema200[:198])
    assert ema200[199] is not None and ema200[299] is not None
    rsi = p["indicators"]["rsi_14"]
    assert all(v is None for v in rsi[:14])


def test_missing_data_is_reported_not_interpolated():
    df = _frame(100)
    p = build_chart_payload(df, {"symbol": "T", "timeframe": "1D",
                                 "missing_bars": 7, "zero_volume_bars": 2})
    assert any("7 expected bar(s) missing" in n for n in p["data_notes"])
    assert any("2 zero-volume bar(s)" in n for n in p["data_notes"])
    assert len(p["candles"]) == 100  # nothing inserted


def test_zero_volume_bars_are_flagged_on_the_candles():
    vol = np.full(50, 1000.0)
    vol[10] = 0.0
    df = _frame(50, volume=vol)
    p = build_chart_payload(df, {"symbol": "T", "timeframe": "1D"})
    assert p["candles"][10]["zero_volume"] is True
    assert p["candles"][11]["zero_volume"] is False


# ---------------------------------------------------------------- historical view
def test_historical_view_is_truncated_and_uses_no_future_candle():
    df = _frame(300)
    p = build_chart_payload(df, {"symbol": "T", "timeframe": "1D"}, as_of_bar=150)
    assert p["truncated"] is True
    assert len(p["candles"]) == 151
    assert p["as_of_bar"] == 150
    assert p["candles"][-1]["t"] == str(df["timestamp"].iloc[150])
    assert all(p["patterns"][i]["bar"] <= 150 for i in range(len(p["patterns"])))
    assert p["levels"]["as_of_bar"] == 150
    assert any("truncated" in n for n in p["data_notes"])


def test_historical_view_is_stable_when_future_data_changes():
    df = _frame(300)
    df2 = df.copy()
    df2.loc[200:, ["open", "high", "low", "close"]] *= 3.0
    a = build_chart_payload(df, {"symbol": "T", "timeframe": "1D"}, as_of_bar=150)
    b = build_chart_payload(df2, {"symbol": "T", "timeframe": "1D"}, as_of_bar=150)
    assert a["candles"] == b["candles"]
    assert a["indicators"] == b["indicators"]
    assert [p["pattern"] for p in a["patterns"]] == [p["pattern"] for p in b["patterns"]]
    assert a["summary"]["trend"] == b["summary"]["trend"]


def test_full_view_indicators_equal_truncated_prefix():
    df = _frame(300)
    full = build_chart_payload(df, {"symbol": "T", "timeframe": "1D"})
    cut = build_chart_payload(df, {"symbol": "T", "timeframe": "1D"}, as_of_bar=150)
    assert full["indicators"]["ema_20"][:151] == cut["indicators"]["ema_20"]


# ---------------------------------------------------------------- support / resistance
def test_pivots_need_right_side_bars_before_confirmation():
    df = _frame(120)
    pivots = detect_pivots(df, left=3, right=3)
    assert pivots
    for p in pivots:
        assert p["confirmation_bar"] == p["bar"] + 3
        assert p["confirmation_bar"] < len(df)


def test_levels_separate_confirmed_from_developing():
    df = _frame(300)
    res = support_resistance(df)
    assert "confirmed" in res and "developing" in res
    for z in res["confirmed"]:
        assert z["confirmed"] is True
    for z in res["developing"]:
        assert z["confirmed"] is False
    assert len(res["confirmed"]) + len(res["developing"]) == len(res["zones"])


def test_historical_levels_ignore_future_bars():
    df = _frame(300)
    df2 = df.copy()
    df2.loc[200:, ["open", "high", "low", "close"]] *= 4.0
    a = support_resistance(df, as_of_bar=180)
    b = support_resistance(df2, as_of_bar=180)
    assert [(z["kind"], round(z["mid"], 6), z["strength"]) for z in a["zones"]] == \
           [(z["kind"], round(z["mid"], 6), z["strength"]) for z in b["zones"]]


def test_nearby_support_is_below_price_and_resistance_above():
    df = _frame(400)
    res = support_resistance(df)
    price = res["current_price"]
    if res["nearby_support"]:
        assert res["nearby_support"]["price_high"] <= price + 1e-9
    if res["nearby_resistance"]:
        assert res["nearby_resistance"]["price_low"] >= price - 1e-9


def test_level_zones_are_ordered_and_bounded():
    df = _frame(300)
    res = support_resistance(df)
    for z in res["zones"]:
        assert z["price_low"] <= z["price_high"]
        assert z["strength"] >= 1
        assert z["kind"] in ("support", "resistance", "in_zone")


# ---------------------------------------------------------------- summary panel
def test_summary_reports_individual_readings_not_a_buy_sell_verdict():
    df = _frame(300)
    p = build_chart_payload(df, {"symbol": "T", "timeframe": "1D"})
    s = p["summary"]
    assert s["trend"] in ("UPTREND", "DOWNTREND", "MIXED", "INSUFFICIENT_DATA")
    assert s["momentum"] in ("BULLISH", "BEARISH", "MIXED", "INSUFFICIENT_DATA")
    assert s["rsi"]["condition"] in ("OVERBOUGHT", "OVERSOLD", "NEUTRAL", "WARM_UP")
    assert s["macd"]["condition"] in ("BULLISH", "BEARISH", "FLAT", "WARM_UP")
    for k in ("ema_20", "ema_50", "ema_200"):
        assert k in s["price_vs_ema"]
        assert s["price_vs_ema"][k]["position"] in ("ABOVE", "BELOW", "WARM_UP")
    # The panel must not expose an unexplained action verdict.
    for banned in ("verdict", "action", "recommendation", "signal", "buy", "sell"):
        assert banned not in {k.lower() for k in s.keys()}
    assert "not a buy/sell recommendation" in s["disclaimer"].lower()
    # Individual readings must be present, not just a verdict.
    assert isinstance(s["indicator_readings"], dict)
    assert len(s["indicator_readings"]) >= len(INDICATOR_COLUMNS)
    assert s["indicator_readings"]["rsi_14"] is not None


def test_summary_flags_warmup_instead_of_faking_readings():
    df = _frame(40)
    p = build_chart_payload(df, {"symbol": "T", "timeframe": "1D"})
    s = p["summary"]
    assert s["price_vs_ema"]["ema_200"]["position"] == "WARM_UP"
    assert s["price_vs_ema"]["ema_200"]["value"] is None


def test_summary_lists_recent_patterns_with_timestamps():
    df = _frame(200)
    p = build_chart_payload(df, {"symbol": "T", "timeframe": "1D"})
    pats = p["summary"]["recent_patterns"]
    assert pats
    for x in pats:
        assert x["timestamp"]
        assert x["explanation"]
        assert "not guaranteed buy/sell" in x["note"]


def test_vwap_absent_for_daily_and_present_for_valid_intraday():
    daily = build_chart_payload(_frame(100, freq="B"), {"symbol": "T", "timeframe": "1D"})
    assert daily["meta"]["vwap_valid"] is False
    assert all(v is None for v in daily["indicators"]["vwap"])

    intraday = build_chart_payload(
        _frame(120, freq="15min", start="2024-01-01 09:15"), {"symbol": "T", "timeframe": "15m"})
    assert intraday["meta"]["vwap_valid"] is True
    assert intraday["indicators"]["vwap"][-1] is not None


def test_vwap_invalid_when_intraday_volume_is_zero():
    vol = np.zeros(120)
    p = build_chart_payload(_frame(120, freq="15min", start="2024-01-01 09:15", volume=vol),
                             {"symbol": "T", "timeframe": "15m"})
    assert p["meta"]["vwap_valid"] is False
    assert all(v is None for v in p["indicators"]["vwap"])
    assert any("VWAP unavailable" in n for n in p["data_notes"])
