"""Architecture guard: the application state is split into focused modules.

This test file locks the refactored layout so it cannot silently regress:
  * every new module imports cleanly on its own
  * AppState is composed from the three mixins (no copy-paste of methods)
  * no method is defined twice across modules
  * every public name that used to live in engine.py is still importable there
  * app.py is wired to the concrete modules, not to a private copy
"""
from __future__ import annotations

import ast
import importlib
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

MODULES = {
    "state_manager": "AppState core: data, persistence, feeds, snapshot",
    "research_orchestrator": "model training + advanced analyses",
    "paper_replay": "historical paper replay engine",
    "risk_engine": "kill switch + risk/execution limits",
    "engine": "public façade (backwards-compatible entry point)",
}


@pytest.mark.parametrize("name", sorted(MODULES))
def test_module_imports_cleanly(name):
    mod = importlib.import_module(name)
    assert mod is not None
    assert (ROOT / f"{name}.py").exists()


def test_app_state_is_composed_from_the_mixins():
    from paper_replay import PaperReplayMixin
    from research_orchestrator import ResearchOrchestratorMixin
    from risk_engine import RiskEngineMixin
    from state_manager import AppState

    for mixin in (RiskEngineMixin, PaperReplayMixin, ResearchOrchestratorMixin):
        assert issubclass(AppState, mixin)
    # mixins must stay mixins: they are never instantiated on their own
    for mixin in (RiskEngineMixin, PaperReplayMixin, ResearchOrchestratorMixin):
        assert mixin.__name__.endswith("Mixin")


def _module_functions(path: Path) -> dict:
    tree = ast.parse(path.read_text())
    out: dict = {}

    def walk(body):
        for node in body:
            if isinstance(node, ast.ClassDef):
                walk(node.body)
            elif isinstance(node, ast.FunctionDef):
                out[node.name] = node

    walk(tree.body)
    return out


def test_no_method_is_defined_in_two_modules():
    seen: dict[str, str] = {}
    for name in MODULES:
        if name == "engine":
            continue  # the façade only re-exports
        for fn in _module_functions(ROOT / f"{name}.py"):
            assert fn not in seen, f"{fn} is defined in both {seen.get(fn)} and {name}"
            seen[fn] = name
    assert len(seen) >= 40, f"expected the full method set, found only {len(seen)}"


def test_every_expected_method_is_still_on_app_state():
    from state_manager import AppState

    expected = {
        # state / persistence / data / charting / feeds / snapshot
        "__init__", "_restore", "_persist_settings", "_persist_registry",
        "_load_latest_model_for", "_load_latest_research_for", "_fresh_replay",
        "log", "key", "active", "preview", "confirm_preview", "import_csv",
        "select_dataset", "delete_dataset", "dataset_view", "dataset_history",
        "chart_symbols", "chart_payload",
        "list_feeds", "add_feed", "remove_feed", "fetch_feed", "update_dataset_append",
        "snapshot",
        # research
        "run_research", "_sleeve_for", "begin_analysis", "_run_analysis",
        "run_portfolio_analysis", "run_sensitivity_analysis",
        "run_regime_analysis", "run_montecarlo_analysis",
        # replay
        "start_replay", "_replay_loop", "_finish_replay", "_close", "_step", "stop_replay",
        # risk
        "set_kill", "update_risk", "update_execution",
    }
    missing = sorted(m for m in expected if not hasattr(AppState, m))
    assert not missing, f"AppState lost methods: {missing}"


def test_engine_facade_exports_the_historical_public_names():
    import engine

    for name in ("AppState", "STATE", "DATA_DIR", "STORE_ROOT", "LIVE_TRADING_ENABLED",
                 "RISK_LIMITS", "EXEC_LIMITS", "_verdict"):
        assert hasattr(engine, name), f"engine no longer exports {name}"
    assert engine.LIVE_TRADING_ENABLED is False
    assert isinstance(engine.RISK_LIMITS, dict) and engine.RISK_LIMITS
    assert isinstance(engine.EXEC_LIMITS, dict) and engine.EXEC_LIMITS


def test_facade_and_state_manager_share_one_state_instance():
    import engine
    from state_manager import STATE

    assert engine.STATE is STATE, "the façade must not create a second AppState"


def test_app_is_wired_to_the_concrete_modules():
    src = (ROOT / "app.py").read_text()
    assert "from state_manager import" in src, "app.py must import the app state from state_manager"
    assert "from engine import" not in src, "app.py should not depend on the façade"


def test_modules_do_not_import_each_other_in_a_cycle():
    """state_manager imports the three mixins; the mixins must not import it back."""
    for name in ("research_orchestrator", "paper_replay", "risk_engine"):
        src = (ROOT / f"{name}.py").read_text()
        assert "import state_manager" not in src
        assert "from state_manager import" not in src


def test_new_modules_are_not_dead_code():
    """Each new module must actually be reachable from the running app."""
    import engine
    from paper_replay import PaperReplayMixin
    from research_orchestrator import ResearchOrchestratorMixin
    from risk_engine import RiskEngineMixin

    mro = set(type(engine.STATE).__mro__)
    assert PaperReplayMixin in mro
    assert ResearchOrchestratorMixin in mro
    assert RiskEngineMixin in mro


def test_each_module_stays_reasonably_small():
    """The point of the refactor: no single module should be huge again."""
    for name in MODULES:
        lines = len((ROOT / f"{name}.py").read_text().splitlines())
        assert lines < 700, f"{name}.py is {lines} lines — too big again"
    # and the split must actually be balanced
    sizes = {n: len((ROOT / f"{n}.py").read_text().splitlines()) for n in MODULES}
    assert sizes["engine"] < 80, "engine.py should be a thin façade"
