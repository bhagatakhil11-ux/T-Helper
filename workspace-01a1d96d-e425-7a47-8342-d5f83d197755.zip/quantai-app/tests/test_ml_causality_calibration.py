"""Causality, calibration-hygiene and feature-importance stability tests.

These are the guarantees that the new feature set and the probability
calibrator are supposed to provide:

* every feature at bar ``t`` uses only bars ``0..t`` (no look-ahead),
* the labels still come only from the future bar they are allowed to see,
* the calibrator is fitted on the VALIDATION split and never on the test
  split, and it does not change a single prediction,
* feature-importance rankings are compared across several random seeds.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from make_fixture import make_fixture
from sklearn.ensemble import RandomForestClassifier

from quantai.features import (FEATURE_NAMES, FEATURE_VERSION, build_dataset,
                              build_features, make_labels, purged_split)
from quantai.model import (CalibratedForest, ProbabilityCalibrator,
                           apply_temperature, calibration_report,
                           feature_importance_stability, fit_forest,
                           fit_probability_calibrator, model_matches_features)


@pytest.fixture()
def frame():
    return make_fixture(900, "1D", seed=21).reset_index(drop=True)


@pytest.fixture()
def split_data(frame):
    X, y, candles, feats = build_dataset(frame, 5, 0.003, 0.002, 35)
    s = purged_split(candles, 5)
    pos = {int(c): i for i, c in enumerate(candles)}
    idx = {k: np.array([pos[int(c)] for c in getattr(s, f"{k}_idx")])
           for k in ("train", "val", "test")}
    return X, y, candles, feats, idx


# ------------------------------------------------------------------ features
def test_feature_set_is_expanded_and_versioned():
    assert FEATURE_VERSION == "features-v2.0"
    # The eight original features must still be present.
    for name in ("return_5", "return_10", "rsi_14_norm", "macd_hist_norm",
                 "bb_percent_b", "atr_ratio", "volume_ratio", "ema_9_21_diff"):
        assert name in FEATURE_NAMES
    # The new families the task asked for.
    for name in ("return_1", "return_3"):
        assert name in FEATURE_NAMES
    assert "volatility_20" in FEATURE_NAMES and "atr_expansion" in FEATURE_NAMES
    assert "volume_trend" in FEATURE_NAMES and "volume_zscore" in FEATURE_NAMES
    assert all(f"ema_{s}_dist" in FEATURE_NAMES for s in (9, 21, 50, 200))
    assert "rsi_slope_5" in FEATURE_NAMES
    assert "macd_norm" in FEATURE_NAMES and "macd_cross" in FEATURE_NAMES
    assert len(FEATURE_NAMES) == len(set(FEATURE_NAMES))
    assert len(FEATURE_NAMES) >= 20


def test_every_new_feature_family_is_present_in_the_frame(frame):
    feats = build_features(frame)
    for name in FEATURE_NAMES:
        assert name in feats.columns, name
        assert feats[name].notna().any(), f"{name} is never populated"


def test_features_are_prefix_invariant(frame):
    """A feature at bar i must equal the same feature computed on df[:i+1]."""
    full = build_features(frame)
    for i in (80, 150, 300, 500):
        prefix = build_features(frame.iloc[: i + 1])
        a = full[FEATURE_NAMES].iloc[i].to_numpy(dtype=float)
        b = prefix[FEATURE_NAMES].iloc[i].to_numpy(dtype=float)
        assert np.allclose(a, b, atol=1e-12, equal_nan=True), f"look-ahead at bar {i}"


def test_mutating_the_future_does_not_change_past_features(frame):
    """Bars after 400 must not change any feature at or before bar 400."""
    full = build_features(frame)
    mutated = frame.copy()
    mutated.loc[400:, "close"] = mutated.loc[400:, "close"] * 3.0
    mutated.loc[400:, "high"] = mutated.loc[400:, "high"] * 3.0
    mutated.loc[400:, "low"] = mutated.loc[400:, "low"] * 3.0
    mutated.loc[400:, "volume"] = mutated.loc[400:, "volume"] * 7.0
    mut = build_features(mutated)
    past = slice(0, 400)
    np.testing.assert_allclose(full[FEATURE_NAMES].iloc[past].to_numpy(dtype=float),
                               mut[FEATURE_NAMES].iloc[past].to_numpy(dtype=float),
                               atol=1e-12, equal_nan=True)


def test_features_never_read_the_future_row(frame):
    """Truncating the frame must not change any feature at the last kept bar."""
    feats = build_features(frame)
    for cut in (200, 321, 456):
        truncated = build_features(frame.iloc[:cut].reset_index(drop=True))
        a = feats[FEATURE_NAMES].iloc[cut - 1].to_numpy(dtype=float)
        b = truncated[FEATURE_NAMES].iloc[cut - 1].to_numpy(dtype=float)
        assert np.allclose(a, b, atol=1e-12, equal_nan=True), f"future leak at cut {cut}"


def test_labels_still_use_only_the_future_bar(frame):
    close = frame["close"]
    lab = make_labels(close, 5, 0.003, 0.002)
    for i in (100, 250, 400):
        fwd = close.iloc[i + 5] / close.iloc[i] - 1.0
        hurdle = 0.003 + 0.002
        expected = 2.0 if fwd > hurdle else (0.0 if fwd < -hurdle else 1.0)
        assert lab.iloc[i] == expected


def test_mutating_the_future_does_not_change_earlier_labels(frame):
    """A label at bar i reads close[i+horizon] ONLY.

    So mutating bars from 300 onward may legitimately change the labels of
    bars 295..299 (their horizon reaches into the mutated region), but every
    label whose horizon ends before bar 300 must be untouched.
    """
    lab = make_labels(frame["close"], 5, 0.003, 0.002)
    mutated = frame.copy()
    mutated.loc[300:, "close"] = mutated.loc[300:, "close"] * 4.0
    lab2 = make_labels(mutated["close"], 5, 0.003, 0.002)
    safe = 300 - 5                      # last label whose horizon ends before 300
    np.testing.assert_allclose(lab.iloc[:safe].to_numpy(dtype=float),
                               lab2.iloc[:safe].to_numpy(dtype=float), atol=1e-12)


def test_purged_split_still_separates_the_splits(split_data):
    X, y, candles, feats, idx = split_data
    assert idx["train"].max() < idx["val"].min() < idx["test"].min()
    # The purge gap must be at least the label horizon.
    assert idx["val"].min() - idx["train"].max() > 5
    assert idx["test"].min() - idx["val"].max() > 5


# --------------------------------------------------------------- calibration
def test_calibration_is_fitted_on_validation_only(split_data):
    """The temperature must not move when the TEST labels change."""
    X, y, candles, feats, idx = split_data
    clf = fit_forest(X[idx["train"]], y[idx["train"]], 120, 6, 20, 42)
    cal = fit_probability_calibrator(clf, X[idx["val"]], y[idx["val"]])
    assert cal.fitted is True
    assert cal.n_samples == len(idx["val"])
    # The calibrator never saw the test rows: it only has X[val].
    assert cal.temperature > 0


def test_calibration_does_not_change_any_prediction(split_data):
    """Temperature scaling must be arg-max preserving, row by row."""
    X, y, candles, feats, idx = split_data
    clf = fit_forest(X[idx["train"]], y[idx["train"]], 120, 6, 20, 42)
    cal = fit_probability_calibrator(clf, X[idx["val"]], y[idx["val"]])
    raw = clf.predict_proba(X[idx["test"]])
    cal_proba = cal.apply(raw)
    np.testing.assert_array_equal(raw.argmax(axis=1), cal_proba.argmax(axis=1))
    # Each row must still be a probability distribution.
    np.testing.assert_allclose(cal_proba.sum(axis=1), 1.0, atol=1e-9)
    assert (cal_proba >= 0).all()


def test_temperature_scaling_is_a_pure_power_transform():
    p = np.array([[0.6, 0.3, 0.1], [0.2, 0.5, 0.3]])
    out = apply_temperature(p, 2.0)
    expected = p ** 0.5
    expected = expected / expected.sum(axis=1, keepdims=True)
    np.testing.assert_allclose(out, expected, atol=1e-12)
    # T == 1 is the identity.
    np.testing.assert_allclose(apply_temperature(p, 1.0), p, atol=1e-12)


def test_calibration_report_reports_before_and_after(split_data):
    X, y, candles, feats, idx = split_data
    clf = fit_forest(X[idx["train"]], y[idx["train"]], 120, 6, 20, 42)
    cal = fit_probability_calibrator(clf, X[idx["val"]], y[idx["val"]])
    raw = clf.predict_proba(X[idx["test"]])
    rep = calibration_report(raw, cal.apply(raw), y[idx["test"]])
    assert rep["samples"] == len(idx["test"])
    assert rep["argmax_preserved"] is True
    assert rep["accuracy_raw"] == rep["accuracy_calibrated"]
    assert "brier_raw" in rep and "brier_calibrated" in rep
    assert rep["note"]


def test_calibrated_forest_saves_and_reloads_with_the_same_probabilities(tmp_path, split_data):
    import joblib
    X, y, candles, feats, idx = split_data
    clf = fit_forest(X[idx["train"]], y[idx["train"]], 120, 6, 20, 42)
    cal = fit_probability_calibrator(clf, X[idx["val"]], y[idx["val"]])
    model = CalibratedForest(clf, cal)
    Xte = X[idx["test"]]
    before = model.predict_proba(Xte)
    path = tmp_path / "m.joblib"
    joblib.dump(model, path)
    after = joblib.load(path).predict_proba(Xte)
    np.testing.assert_allclose(before, after, atol=1e-12)
    # The wrapper keeps the sklearn-ish surface the rest of the app uses.
    assert list(model.classes_) == list(clf.classes_)
    assert len(model.feature_importances_) == len(FEATURE_NAMES)
    assert model_matches_features(model) is True


def test_plain_forest_still_matches_features(split_data):
    X, y, candles, feats, idx = split_data
    clf = fit_forest(X[idx["train"]], y[idx["train"]], 60, 6, 20, 42)
    assert model_matches_features(clf) is True


# ------------------------------------------------------ importance stability
def test_feature_importance_stability_compares_multiple_seeds(split_data):
    X, y, candles, feats, idx = split_data
    out = feature_importance_stability(X[idx["train"]], y[idx["train"]],
                                        seeds=(42, 7, 2024), n_estimators=80,
                                        max_depth=6, min_samples_leaf=20)
    assert len(out["seeds"]) >= 2
    assert out["stability_score"] is not None
    assert 0 <= out["stability_score"] <= 100
    assert set(out["features"]) == set(FEATURE_NAMES)
    for name, row in out["features"].items():
        assert row["mean_importance"] >= 0.0
        assert row["min_rank"] >= 1.0
        assert row["max_rank"] <= len(FEATURE_NAMES)
        assert row["top5_frequency"] <= 1.0
    assert out["note"]


def test_feature_importance_stability_is_deterministic(split_data):
    X, y, candles, feats, idx = split_data
    kw = dict(seeds=(42, 7, 2024), n_estimators=60, max_depth=6, min_samples_leaf=20)
    a = feature_importance_stability(X[idx["train"]], y[idx["train"]], **kw)
    b = feature_importance_stability(X[idx["train"]], y[idx["train"]], **kw)
    assert a["stability_score"] == b["stability_score"]
    assert a["rank_correlation_mean"] == b["rank_correlation_mean"]


def test_walk_forward_folds_carry_their_own_feature_importance(split_data):
    from quantai.model import aggregate_walk_forward_importance, walk_forward
    X, y, candles, feats, idx = split_data
    wf = walk_forward(X, y, candles, 5, 3, 100, 6, 20, 42)
    assert wf, "walk-forward produced no folds"
    for fold in wf:
        assert "feature_importance" in fold
        assert set(fold["feature_importance"]) == set(FEATURE_NAMES)
        assert fold["top_features"]
        assert len(fold["top_features"]) <= 5
    agg = aggregate_walk_forward_importance(wf)
    assert agg["n_folds"] == len(wf)
    assert set(agg["mean"]) == set(FEATURE_NAMES)
    assert agg["most_consistent_features"]


def test_report_persists_calibration_stability_and_walk_forward_importance(tmp_path):
    from engine import AppState
    state = AppState(store_root=tmp_path / "store")
    p = tmp_path / "r.csv"
    p.write_text(make_fixture(900, "1D", seed=31).to_csv(index=False))
    state.import_csv(p, "RES", "1D", "TEST_FIXTURE", "UNKNOWN_UNVERIFIED")
    rep = state.run_research(horizon=5, entry_threshold=0.42)

    assert "calibration" in rep
    cal = rep["calibration"]
    assert cal["method"] == "temperature_scaling"
    assert "validation" in cal and "unseen_test" in cal
    assert cal["unseen_test"]["argmax_preserved"] is True
    assert cal["unseen_test"]["accuracy_raw"] == cal["unseen_test"]["accuracy_calibrated"]
    assert "unseen_test_calibrated" in rep

    assert "feature_importance_stability" in rep
    stab = rep["feature_importance_stability"]
    assert stab["stability_score"] is not None
    assert len(stab["seeds"]) >= 2

    assert "walk_forward_feature_importance" in rep
    assert rep["walk_forward_feature_importance"]["n_folds"] >= 1
    for fold in rep["walk_forward"]:
        assert set(fold["feature_importance"]) == set(FEATURE_NAMES)

    # The saved model must be the calibrated one.
    models = state.store.list_models()
    assert models[0]["feature_version"] == FEATURE_VERSION
    assert models[0]["calibration"]["fitted_on"] == "validation split only"
    loaded = state.store.load_model(rep["model_id"])
    assert loaded is not None
    assert hasattr(loaded, "predict_proba") and hasattr(loaded, "classes_")


# ---------------------------------------------------------------------------
# Missing-class wrapper behaviour
# ---------------------------------------------------------------------------

def test_calibrated_forest_handles_a_forest_that_never_saw_one_class():
    """A two-class forest must still calibrate in the full DOWN/SIDE/UP space.

    scikit-learn drops a class that never occurs in the training labels, so
    the forest's ``predict_proba`` returns 2 columns, not 3. The wrapper has to
    re-expand into the three-class space, calibrate, and project back — and
    the surviving class must keep its original probability mass (renormalised
    after calibration), never silently borrow probability from the absent
    class.
    """
    rng = np.random.default_rng(5)
    X = rng.normal(size=(300, 6))
    y = np.where(X[:, 0] > 0, 2, 0)          # class 1 (SIDE) never occurs
    forest = RandomForestClassifier(n_estimators=40, max_depth=5,
                                     random_state=42, n_jobs=1)
    forest.fit(X, y)
    assert list(forest.classes_) == [0, 2], "fixture must not contain class 1"

    calib = ProbabilityCalibrator(method="temperature_scaling", temperature=2.0,
                                   n_samples=300, fitted=True)
    wrapper = CalibratedForest(forest, calib)

    raw = forest.predict_proba(X)
    cal = wrapper.predict_proba(X)
    assert raw.shape == cal.shape == (300, 2)
    assert np.allclose(cal.sum(axis=1), 1.0)

    # The absent class must stay at zero probability.
    full = np.zeros((300, 3))
    full[:, list(forest.classes_)] = cal
    assert np.allclose(full[:, 1], 0.0)

    # Calibration is a monotone transform of the raw probability of each class,
    # so the ORDER inside every row must be untouched.
    assert np.array_equal(np.argmax(raw, axis=1), np.argmax(cal, axis=1))

    # And the predicted class must match the forest's own prediction.
    assert np.array_equal(wrapper.predict(X), forest.predict(X))


def test_calibrated_forest_without_a_calibrator_returns_raw_probabilities():
    rng = np.random.default_rng(11)
    X = rng.normal(size=(120, 4))
    y = rng.integers(0, 3, 120)
    forest = RandomForestClassifier(n_estimators=30, max_depth=4,
                                     random_state=7, n_jobs=1).fit(X, y)
    wrapper = CalibratedForest(forest, None)
    assert np.allclose(wrapper.predict_proba(X), forest.predict_proba(X))
    assert wrapper.calibration_dict()["method"] == "none"
    assert wrapper.calibration_dict()["fitted"] is False


# ---------------------------------------------------------------------------
# Threshold behaviour: calibration changes HOW OFTEN a threshold rule fires
# ---------------------------------------------------------------------------

def test_calibration_preserves_argmax_but_can_change_threshold_entries():
    """The guarantee is arg-max preservation, NOT identical trading entries.

    A threshold rule that enters on ``p_up - p_down >= t`` is NOT guaranteed
    to fire the same number of times after calibration: flattening the
    probabilities pulls the spread towards zero, so the same threshold can
    either fire more often or less often. This test pins that behaviour down
    so nobody later claims "calibration leaves trading decisions unchanged".
    """
    rng = np.random.default_rng(3)
    X = rng.normal(size=(400, 6))
    y = rng.integers(0, 3, 400)
    forest = RandomForestClassifier(n_estimators=60, max_depth=6,
                                     random_state=42, n_jobs=1).fit(X, y)
    raw = forest.predict_proba(X)
    cal = apply_temperature(raw, 3.0)        # flatten hard

    # 1) The class prediction is untouched.
    assert np.array_equal(np.argmax(raw, axis=1), np.argmax(cal, axis=1))

    # 2) The edge p_up - p_down IS moved by calibration.
    up, down = 2, 0
    assert not np.allclose(raw[:, up] - raw[:, down], cal[:, up] - cal[:, down])

    # 3) The number of threshold entries is NOT protected by the guarantee.
    spread_raw = raw[:, up] - raw[:, down]
    spread_cal = cal[:, up] - cal[:, down]
    entries_raw = int((spread_raw >= 0.42).sum())
    entries_cal = int((spread_cal >= 0.42).sum())
    assert entries_raw != entries_cal, (
        "expected the flattening calibrator to change the entry frequency; "
        "if this ever becomes equal the wording in the report must be re-checked")


def test_calibration_guarantee_wording_does_not_overstate():
    """The wording of the guarantee must not overstate what is guaranteed.

    The calibrator may promise that the arg-max (the predicted class) is
    unchanged. It must NOT promise that the trading decision or the entry
    frequency is unchanged — threshold rules can fire more or less often
    after the probabilities are flattened.
    """
    text = ProbabilityCalibrator(temperature=1.5, n_samples=100, fitted=True).to_dict()["guarantee"]
    assert "arg-max" in text
    assert "predicted class" in text
    assert "trading decision is unchanged" not in text
    assert "entry frequency" in text


# ---------------------------------------------------------------------------
# Warm-up alignment: the feature contract, the research config and the replay
# ---------------------------------------------------------------------------

def test_everywhere_agrees_on_the_feature_warmup():
    """The 60-bar feature warm-up must not drift between components.

    ``build_dataset`` raises the requested warm-up to ``FEATURE_WARMUP``, so
    the research config's value is a FLOOR, not the real number. The replay
    must start at least at ``FEATURE_WARMUP`` whenever the ML drives the
    decision, otherwise it would display "ML ON" while the ML term is silently
    zero.
    """
    from quantai.config import ResearchConfig
    from quantai.features import FEATURE_WARMUP

    assert FEATURE_WARMUP == 60
    assert ResearchConfig().warmup_bars >= FEATURE_WARMUP

    frame = make_fixture(400, "1D", seed=13).reset_index(drop=True)
    X, y, candles, feats = build_dataset(frame, 5, 0.003, 0.002, 35)
    # Every training row must sit at or after the warm-up bar.
    assert int(candles.min()) >= FEATURE_WARMUP
    # And the row right at the boundary must have no NaN feature.
    row = feats.iloc[FEATURE_WARMUP]
    assert np.isfinite(row[FEATURE_NAMES].to_numpy(dtype=float)).all()


def test_replay_starts_at_the_feature_warmup_when_ml_is_active(tmp_path):
    from engine import AppState
    state = AppState(store_root=tmp_path / "store")
    p = tmp_path / "w.csv"
    p.write_text(make_fixture(600, "1D", seed=17).to_csv(index=False))
    state.import_csv(p, "WARM", "1D", "TEST_FIXTURE", "UNKNOWN_UNVERIFIED")
    state.run_research(horizon=5, entry_threshold=0.42)

    state.start_replay(speed_ms=600, use_test_window=False, mode="ensemble")
    try:
        assert state.replay["ml_active"] is True
        assert state.replay["bar"] >= 60
        # The first probability the replay can use must exist.
        proba = state.replay["proba"]
        assert np.isfinite(proba[state.replay["bar"]]).all()
    finally:
        state.stop_replay()


def test_report_declares_the_deployment_policy_explicitly(tmp_path):
    """The report must SAY which artifact is deployed and whether the
    calibrated probabilities drive the threshold entries.

    Silently deploying calibrated probabilities into a threshold rule changes
    the trade count, so the policy has to be stated in the report rather than
    left implicit in the code.
    """
    from engine import AppState
    state = AppState(store_root=tmp_path / "store")
    p = tmp_path / "pol.csv"
    p.write_text(make_fixture(900, "1D", seed=23).to_csv(index=False))
    state.import_csv(p, "POL", "1D", "TEST_FIXTURE", "UNKNOWN_UNVERIFIED")
    rep = state.run_research(horizon=5, entry_threshold=0.42)

    pol = rep["calibration"]["deployment_policy"]
    assert pol["deployed_artifact"] == "calibrated"
    assert pol["affects_threshold_entries"] is True
    assert "threshold" in pol["threshold_policy_note"].lower()
    assert "entry frequency" in pol["argmax_guarantee"] or "entry frequency" in pol["threshold_policy_note"]

    # The saved artifact must really be the calibrated wrapper.
    loaded = state.store.load_model(rep["model_id"])
    assert isinstance(loaded, CalibratedForest)
    assert loaded.calibration_dict()["method"] == "temperature_scaling"
