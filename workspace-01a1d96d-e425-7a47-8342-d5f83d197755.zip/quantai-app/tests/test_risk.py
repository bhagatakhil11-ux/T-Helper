"""Risk-limit enforcement in the backtest engine and replay kill switch."""
import numpy as np
import pandas as pd
import pytest

from make_fixture import make_fixture
from quantai.backtest import run_backtest
from quantai.config import CostModel, RiskConfig
from quantai.features import build_features


@pytest.fixture()
def df():
    return make_fixture(400, "1D", seed=3)


def test_total_drawdown_halt_squares_off_and_blocks(tmp_path):
    """Deterministic flat-then-crash fixture: a position is held through the flat
    section, then a 50% gap crash breaches the total-DD limit. The breaker must
    halt, square off, and block every subsequent entry."""
    rows = []
    for k, t in enumerate(pd.bdate_range("2020-01-01", periods=260, freq="B", tz="Asia/Kolkata")):
        if k < 200:
            o = h = l = c = 100.0
            h, l = 100.5, 99.5            # small wick -> ATR > 0, no stop/target hit
        else:
            o = h = l = c = 50.0          # 50% crash
            h, l = 50.5, 49.5
        rows.append((t.strftime("%Y-%m-%d %H:%M:%S"), o, h, l, c, 100000))
    p = tmp_path / "crash.csv"
    p.write_text(pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"]).to_csv(index=False))
    from quantai.data import load_csv
    candles, _ = load_csv(p, "X", "1D")
    feats = build_features(candles)
    risk = RiskConfig(max_total_drawdown_pct=5.0, risk_per_trade_pct=0.5)
    res = run_backtest(candles, feats, 60, CostModel(), risk, "1D",
                       mode="rules_only", entry_threshold=-99)
    assert res.halted_reason is not None
    assert "total_drawdown" in res.halted_reason
    assert res.rejected_signals["total_drawdown_halt"] > 0
    # The crash gap fills at the open (worse than stop); loss must exceed the 5% cap.
    assert res.net_return_pct < -5.0
    assert res.final_equity > 0


def test_max_open_positions_zero_blocks_all_entries(df, tmp_path):
    p = tmp_path / "x.csv"; p.write_text(df.to_csv(index=False))
    from quantai.data import load_csv
    candles, _ = load_csv(p, "X", "1D")
    feats = build_features(candles)
    risk = RiskConfig(max_open_positions=0)
    res = run_backtest(candles, feats, 60, CostModel(), risk, "1D",
                       mode="rules_only", entry_threshold=-99)
    assert res.total_trades == 0
    assert res.rejected_signals["max_open_positions"] > 0


def test_volume_participation_cap_limits_quantity(df, tmp_path):
    p = tmp_path / "x.csv"; p.write_text(df.to_csv(index=False))
    from quantai.data import load_csv
    candles, _ = load_csv(p, "X", "1D")
    feats = build_features(candles)
    capped = run_backtest(candles, feats, 60, CostModel(), RiskConfig(), "1D",
                          mode="rules_only", entry_threshold=-99,
                          max_volume_participation_pct=0.01)
    uncapped = run_backtest(candles, feats, 60, CostModel(), RiskConfig(), "1D",
                            mode="rules_only", entry_threshold=-99)
    assert capped.total_trades > 0
    for t in capped.trade_log:
        sig_vol = float(candles["volume"].iloc[t["entry_bar"] - 1])
        assert t["qty"] <= int(sig_vol * 0.0001) + 1


def test_consecutive_loss_cooldown_blocks_entries(df, tmp_path):
    p = tmp_path / "x.csv"; p.write_text(df.to_csv(index=False))
    from quantai.data import load_csv
    candles, _ = load_csv(p, "X", "1D")
    feats = build_features(candles)
    risk = RiskConfig(max_consecutive_losses=1, cooldown_bars=50)
    res = run_backtest(candles, feats, 60, CostModel(), risk, "1D",
                       mode="rules_only", entry_threshold=-99)
    if res.losing_trades > 0:
        assert res.rejected_signals["cooldown"] > 0


def test_kill_switch_squares_off_and_blocks_restart(tmp_path):
    from engine import AppState
    state = AppState(store_root=tmp_path / "store")
    p = tmp_path / "demo.csv"
    p.write_text("# SYNTHETIC\n" + make_fixture(300, "1D", seed=5).to_csv(index=False))
    state.import_csv(p, "TEST", "1D", "TEST_FIXTURE", "UNKNOWN_UNVERIFIED")
    state.start_replay(speed_ms=60, use_test_window=False, mode="rules_only", threshold=-99)
    import time
    time.sleep(1.0)
    state.set_kill(True)
    assert state.kill_switch is True
    assert state.replay["running"] is False
    assert state.replay["position"] is None
    with pytest.raises(ValueError):
        state.start_replay()
    state.set_kill(False)
    state.stop_replay()
