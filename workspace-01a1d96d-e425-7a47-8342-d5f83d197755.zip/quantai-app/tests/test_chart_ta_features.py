"""Charts & TA tab enhancements.

Covers the four features requested for the Charts tab:

1. Timeframe switching for the same symbol + remembering the last view.
2. Clickable support/resistance zones showing strength, touches and reactions.
3. Pattern strength labels (weak / medium / strong) from volume + location.
4. A "Confluence" section in the TA summary counting same-direction
   indicators — descriptive only, never a BUY/SELL signal.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from app import create_app
from engine import AppState
from quantai.charting import chart_compare_rows, chart_symbol_groups, technical_summary
from quantai.indicators import compute_indicators
from quantai.levels import support_resistance, zone_strength_label
from quantai.patterns import detect_patterns


# ------------------------------------------------------------------ fixtures
@pytest.fixture()
def client(tmp_path):
    st = AppState(store_root=tmp_path / "store")
    app = create_app(state=st)
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c, st


def _csv_bytes(seed, n=400, intraday=False):
    rng = np.random.default_rng(seed)
    if intraday:
        ts = pd.date_range("2024-01-01 09:15", periods=n, freq="15min", tz="Asia/Kolkata")
    else:
        ts = pd.date_range("2021-01-04", periods=n, freq="B", tz="Asia/Kolkata") + pd.Timedelta(hours=15)
    close = 100 * np.exp(np.cumsum(rng.normal(0.0003, 0.012, n)))
    open_ = np.concatenate([[100.0], close[:-1]])
    df = pd.DataFrame({"timestamp": ts, "open": open_,
                       "high": np.maximum(open_, close) * 1.004,
                       "low": np.minimum(open_, close) * 0.996,
                       "close": close, "volume": rng.integers(1e5, 1e6, n)})
    return df.to_csv(index=False).encode()


def _import(st, tmp_path, sym, seed, tf="1D", intraday=False, n=400):
    p = tmp_path / f"{sym}-{tf}.csv"
    p.write_bytes(_csv_bytes(seed, n=n, intraday=intraday))
    st.import_csv(p, sym, tf, "IMPORTED_CSV", "UNKNOWN_UNVERIFIED")
    return st.key(sym, tf)


def _frame(seed=7, n=400, intraday=False):
    import io
    return pd.read_csv(io.BytesIO(_csv_bytes(seed, n=n, intraday=intraday)))


# ==================================================================
# 1. Timeframe switching + remembering the last view
# ==================================================================
def test_chart_groups_are_grouped_by_symbol(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "RELIANCE", 1, tf="1D")
    _import(st, tmp_path, "RELIANCE", 2, tf="15m", intraday=True)
    _import(st, tmp_path, "INFY", 3, tf="1D")
    j = c.get("/api/chart/groups").get_json()
    assert j["ok"] is True
    assert j["symbols"] == ["INFY", "RELIANCE"]
    assert {r["timeframe"] for r in j["by_symbol"]["RELIANCE"]} == {"1D", "15m"}
    assert {r["timeframe"] for r in j["by_symbol"]["INFY"]} == {"1D"}
    # every grouped row still carries the fields the picker needs
    for rows in j["by_symbol"].values():
        for r in rows:
            assert r["key"] and r["symbol"] and r["timeframe"]
            assert isinstance(r["bars"], int)


def test_chart_compare_lists_every_timeframe_of_one_symbol(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "RELIANCE", 1, tf="1D")
    _import(st, tmp_path, "RELIANCE", 2, tf="15m", intraday=True)
    _import(st, tmp_path, "INFY", 3, tf="1D")
    j = c.get("/api/chart/compare?symbol=RELIANCE").get_json()
    assert j["ok"] is True
    assert j["symbol"] == "RELIANCE"
    tfs = {r["timeframe"] for r in j["rows"]}
    assert tfs == {"1D", "15m"}
    for r in j["rows"]:
        assert r["close"] is not None
        assert r["bullish_readings"] is not None
        assert r["bearish_readings"] is not None
        assert r["trend"] and r["momentum"]
    # INFY is not mixed in
    assert "INFY" not in {r["symbol"] for r in j["rows"]}


def test_chart_compare_is_empty_for_unknown_symbol(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "RELIANCE", 1)
    j = c.get("/api/chart/compare?symbol=NOSUCH").get_json()
    assert j["ok"] is True
    assert j["rows"] == []


def test_last_viewed_dataset_is_remembered(client, tmp_path):
    c, st = client
    key_d = _import(st, tmp_path, "RELIANCE", 1, tf="1D")
    key_i = _import(st, tmp_path, "RELIANCE", 2, tf="15m", intraday=True)
    # with nothing requested the active dataset is used
    c.get("/api/chart/data")
    # now explicitly view the other timeframe
    r = c.get(f"/api/chart/data?key={key_i}")
    assert r.status_code == 200
    assert r.get_json()["meta"]["timeframe"] == "15m"
    # the next bare request returns the LAST VIEWED dataset, not the active one
    j = c.get("/api/chart/data").get_json()
    assert j["meta"]["timeframe"] == "15m"
    assert st.last_chart_key == key_i


def test_last_view_survives_a_restart(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "RELIANCE", 1, tf="1D")
    key_i = _import(st, tmp_path, "RELIANCE", 2, tf="15m", intraday=True)
    c.get(f"/api/chart/data?key={key_i}")

    st2 = AppState(store_root=tmp_path / "store")
    assert st2.last_chart_key == key_i
    app2 = create_app(state=st2)
    app2.config["TESTING"] = True
    with app2.test_client() as c2:
        j = c2.get("/api/chart/data").get_json()
        assert j["meta"]["timeframe"] == "15m"


def test_chart_symbol_groups_helper_is_pure():
    rows = [
        {"symbol": "A", "timeframe": "1D", "key": "A|1D", "bars": 10},
        {"symbol": "A", "timeframe": "5m", "key": "A|5m", "bars": 10},
        {"symbol": "B", "timeframe": "1D", "key": "B|1D", "bars": 10},
    ]
    g = chart_symbol_groups(rows)
    assert g["symbols"] == ["A", "B"]
    assert len(g["by_symbol"]["A"]) == 2
    assert g["timeframes"] == ["1D", "5m"]


# ==================================================================
# 2. Support / resistance zones: strength, touches, reactions
# ==================================================================
def test_zones_expose_touches_and_reactions():
    df = _frame()
    lv = support_resistance(df)
    zones = lv["zones"]
    assert zones
    for z in zones:
        assert z["touches"] >= 0
        assert z["reactions"] >= 0
        assert z["reactions"] <= z["touches"]
        assert 0.0 <= z["reaction_rate"] <= 1.0
        assert z["reaction_direction"] in ("bullish", "bearish")
        assert z["strength_label"] in ("strong", "moderate", "weak", "failed", "untested", "unrated")
        assert z["zone_id"]
        hist = z["touch_history"]
        assert z["touch_history_shown"] == len(hist)
        assert z["touch_history_truncated"] == (z["touches"] > len(hist))
        assert len(hist) <= z["touches"]
        for h in hist:
            assert "bar" in h and "time" in h
            assert "reacted" in h and "reaction_move" in h


def test_zone_strength_label_reflects_reaction_rate():
    # many touches, most of them bounce -> strong
    assert zone_strength_label({"touches": 6, "reactions": 6, "reaction_rate": 1.0, "strength": 5}) == "strong"
    # many touches, price kept going through -> failed (weak), not strong
    assert zone_strength_label({"touches": 6, "reactions": 1, "reaction_rate": 0.16, "strength": 5}) == "failed"
    # mid
    assert zone_strength_label({"touches": 4, "reactions": 2, "reaction_rate": 0.5, "strength": 3}) == "moderate"
    assert zone_strength_label({"touches": 4, "reactions": 1, "reaction_rate": 0.25, "strength": 3}) == "weak"
    # never touched
    assert zone_strength_label({"touches": 0, "reactions": 0, "reaction_rate": None, "strength": 0}) == "untested"


def test_zone_reactions_are_measured_against_the_zone_band():
    df = _frame()
    lv = support_resistance(df)
    z = lv["zones"][0]
    hist = z["touch_history"]
    reacted = [h for h in hist if h["reacted"]]
    assert len(reacted) == z["reactions"]
    assert z["reaction_rate"] == pytest.approx(z["reactions"] / z["touches"], abs=1e-9)


def test_chart_payload_ships_zone_activity(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "RELIANCE", 5)
    j = c.get("/api/chart/data").get_json()
    zones = j["levels"]["zones"]
    assert zones
    for z in zones:
        assert z["touches"] >= 0
        assert z["reactions"] >= 0
        assert z["reaction_rate"] is not None
        assert "touch_history" in z
        assert z["strength_label"]


# ==================================================================
# 3. Pattern strength labels
# ==================================================================
def test_every_detected_pattern_has_a_strength_label():
    df = _frame(seed=11)
    pats = detect_patterns(df)
    assert pats
    for p in pats:
        assert p["strength"] in ("weak", "medium", "strong")
        assert 0 <= p["strength_score"] <= 4
        assert p["volume_score"] in (0, 1, 2)
        assert p["location_score"] in (0, 1, 2)
        assert p["strength_score"] == p["volume_score"] + p["location_score"]
        assert p["strength_note"]
        assert p["volume_note"] and p["location_note"]


def test_pattern_strength_changes_with_volume():
    """A high-volume pattern must out-score the same pattern on light volume."""
    df = _frame(seed=13)
    pats = detect_patterns(df)
    ratios = [(p["volume_ratio"], p["volume_score"]) for p in pats if p["volume_ratio"] is not None]
    assert ratios
    heavy = [s for r, s in ratios if r >= 1.2]
    light = [s for r, s in ratios if r <= 0.8]
    if heavy and light:
        assert max(heavy) > min(light)


def test_pattern_strength_is_causal_only_uses_past_volume():
    """Rewriting future volume must not change an earlier pattern's score."""
    df = _frame(seed=17)
    base = detect_patterns(df)
    df2 = df.copy()
    df2.loc[300:, "volume"] = df2.loc[300:, "volume"] * 50
    after = detect_patterns(df2)
    early_before = [p for p in base if p["bar"] < 300]
    early_after = [p for p in after if p["bar"] < 300]
    assert len(early_before) == len(early_after)
    for a, b in zip(early_before, early_after):
        assert a["strength"] == b["strength"]
        assert a["strength_score"] == b["strength_score"]


def test_chart_payload_ships_pattern_strength(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "RELIANCE", 9)
    j = c.get("/api/chart/data").get_json()
    pats = j["patterns"]
    assert pats
    for p in pats:
        assert p["strength"] in ("weak", "medium", "strong")
        assert p["strength_note"]


# ==================================================================
# 4. Confluence section (counts, never a BUY/SELL signal)
# ==================================================================
def test_confluence_counts_same_direction_indicators():
    df = _frame(seed=23)
    ind = compute_indicators(df, "1D")
    pats = detect_patterns(df)
    lv = support_resistance(df)
    s = technical_summary(df, ind, pats, lv, len(df) - 1)
    cf = s["confluence"]
    assert cf["bullish_count"] >= 0
    assert cf["bearish_count"] >= 0
    assert cf["neutral_count"] >= 0
    assert cf["bullish_count"] + cf["bearish_count"] + cf["neutral_count"] == cf["total_readings"]
    assert cf["readings_considered"] == cf["bullish_count"] + cf["bearish_count"]
    assert cf["lean"] in ("bullish-leaning", "bearish-leaning", "evenly split", "undetermined")
    # the lists explain the counts
    assert len(cf["bullish"]) == cf["bullish_count"]
    assert len(cf["bearish"]) == cf["bearish_count"]
    assert len(cf["neutral"]) == cf["neutral_count"]


def test_confluence_never_emits_a_buy_sell_signal():
    df = _frame(seed=29)
    ind = compute_indicators(df, "1D")
    pats = detect_patterns(df)
    lv = support_resistance(df)
    s = technical_summary(df, ind, pats, lv, len(df) - 1)
    cf = s["confluence"]
    # The READINGS themselves must never carry a trading instruction.
    readings = " ".join(cf["bullish"] + cf["bearish"] + cf["neutral"]).lower()
    for banned in ("buy", "sell", "long", "short", "enter", "exit", "recommend",
                   "should"):
        assert banned not in readings
    # "MACD above/below signal" names the MACD signal LINE — that is fine.
    assert "buy signal" not in readings
    assert "sell signal" not in readings
    assert cf["lean"].lower() in ("bullish-leaning", "bearish-leaning",
                                   "evenly split", "undetermined")
    # the note explicitly says it is not a signal
    assert "not a" in cf["note"].lower()
    assert "signal" in cf["note"].lower()


def test_chart_payload_confluence_has_no_signal_wording(client, tmp_path):
    c, st = client
    _import(st, tmp_path, "RELIANCE", 31)
    j = c.get("/api/chart/data").get_json()
    cf = j["summary"]["confluence"]
    assert cf["total_readings"] > 0
    readings = " ".join(cf["bullish"] + cf["bearish"] + cf["neutral"]).lower()
    for banned in ("buy", "sell", "long", "short", "recommend", "should"):
        assert banned not in readings
    # the only mention of buy/sell in the whole block is the disclaimer
    assert "not a buy/sell signal" in cf["note"].lower()


def test_confluence_counts_can_disagree():
    """A reading list must be able to contain both directions."""
    df = _frame(seed=37)
    ind = compute_indicators(df, "1D")
    pats = detect_patterns(df)
    lv = support_resistance(df)
    s = technical_summary(df, ind, pats, lv, len(df) - 1)
    cf = s["confluence"]
    assert cf["bullish_count"] > 0 and cf["bearish_count"] > 0


def test_chart_compare_rows_helper_uses_confluence():
    df = _frame(seed=41)
    rows = chart_compare_rows([{
        "key": "RELIANCE|1D", "meta": type("M", (), {
            "symbol": "RELIANCE", "timeframe": "1D", "candle_count": len(df),
            "source_type": "IMPORTED_CSV",
        })(), "df": df,
    }])
    assert len(rows) == 1
    r = rows[0]
    assert r["bullish_readings"] is not None
    assert r["bearish_readings"] is not None
    assert r["confluence_lean"]
