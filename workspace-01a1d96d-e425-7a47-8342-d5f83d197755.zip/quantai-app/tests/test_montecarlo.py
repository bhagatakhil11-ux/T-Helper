"""Monte Carlo: degenerate deterministic cases (independent closed-form checks),
percentile ordering, reproducibility, streak preservation, and honesty guards."""
import numpy as np
import pytest

from quantai.montecarlo import run_monte_carlo


def test_all_identical_wins_is_deterministic():
    # 20 trades of +100 on 10k capital: EVERY resample ends at 12000, DD=0.
    res = run_monte_carlo([100.0] * 20, 10_000, n_simulations=300, method="iid", seed=1)
    assert res["status"] == "ok"
    for q in ("5", "25", "50", "75", "95"):
        assert res["final_equity_percentiles"][q] == 12_000.0
        assert res["max_drawdown_pct_percentiles"][q] == 0.0
        assert res["longest_losing_streak_percentiles"][q] == 0.0
    assert res["probability_of_loss"] == 0.0


def test_all_losses_closed_form():
    # 20 trades of -100 on 10k: final 8000, monotonic decline -> DD = 20%.
    res = run_monte_carlo([-100.0] * 20, 10_000, n_simulations=300, method="block",
                          block_size=5, seed=1, ruin_drawdown_pct=15.0)
    assert res["final_equity_percentiles"]["50"] == 8_000.0
    assert res["probability_of_loss"] == 1.0
    assert abs(res["max_drawdown_pct_percentiles"]["50"] - 20.0) < 1e-9
    assert res["longest_losing_streak_percentiles"]["95"] == 20
    assert res["probability_of_drawdown_ge_threshold"] == 1.0  # 20% >= 15%
    assert res["historical_max_drawdown_pct"] == pytest.approx(20.0)


def test_percentiles_ordered_and_probabilities_bounded():
    rng = np.random.default_rng(5)
    pnls = rng.normal(10, 200, 60).tolist()
    res = run_monte_carlo(pnls, 100_000, n_simulations=1000, seed=7)
    for key in ("final_equity_percentiles", "max_drawdown_pct_percentiles",
                "final_return_pct_percentiles"):
        vals = [res[key][q] for q in ("5", "25", "50", "75", "95")]
        assert vals == sorted(vals)
    assert 0.0 <= res["probability_of_loss"] <= 1.0
    assert 0.0 <= res["probability_of_drawdown_ge_threshold"] <= 1.0
    assert res["disclaimer"]


def test_seed_reproducibility():
    pnls = [(-1) ** i * (50 + i) for i in range(40)]
    a = run_monte_carlo(pnls, 50_000, n_simulations=500, seed=42)
    b = run_monte_carlo(pnls, 50_000, n_simulations=500, seed=42)
    assert a["final_equity_percentiles"] == b["final_equity_percentiles"]
    assert a["sample_paths"] == b["sample_paths"]
    c = run_monte_carlo(pnls, 50_000, n_simulations=500, seed=43)
    assert a["final_equity_percentiles"] != c["final_equity_percentiles"]


def test_block_bootstrap_preserves_streaks():
    # 15 straight losses then 15 wins: blocks keep long streaks; IID shatters them.
    pnls = [-100.0] * 15 + [100.0] * 15
    block = run_monte_carlo(pnls, 10_000, n_simulations=1500, method="block", block_size=5, seed=9)
    iid = run_monte_carlo(pnls, 10_000, n_simulations=1500, method="iid", seed=9)
    assert block["longest_losing_streak_percentiles"]["95"] > iid["longest_losing_streak_percentiles"]["95"]
    assert block["historical_longest_losing_streak"] == 15


def test_insufficient_trades_refuses():
    res = run_monte_carlo([100.0] * 9, 10_000)
    assert res["status"] == "insufficient"
    assert "10" in res["message"]


def test_invalid_method_rejected():
    with pytest.raises(ValueError, match="iid"):
        run_monte_carlo([100.0] * 20, 10_000, method="magic")


def test_sample_paths_start_at_capital():
    res = run_monte_carlo([50.0, -30.0] * 15, 25_000, n_simulations=200, max_paths_shown=10)
    assert len(res["sample_paths"]) == 10
    for p in res["sample_paths"]:
        assert p[0] == 25_000
        assert len(p) == 31  # 30 trades + initial point
