"""Core application state for the QuantAI Terminal.

Owns the in-memory + on-disk state that every other layer reads:
datasets, the active dataset, models, research runs, feeds, settings and the
paper journal. The behaviour-specific layers are composed in as mixins:

* `risk_engine.RiskEngineMixin`      — kill switch, risk/execution limits
* `paper_replay.PaperReplayMixin`    — historical paper replay
* `research_orchestrator.ResearchOrchestratorMixin` — training + analyses

SAFETY CONTRACT
---------------
* No broker connection. No live order routing. Live trading is permanently disabled.
* Simulated data is always labelled SIMULATED/TEST_FIXTURE. Imported CSV is UNVERIFIED
  unless the user explicitly marks it BROKER_VENDOR (and even then it is user-asserted).
* Datasets, models, research runs, settings and the paper journal persist across restarts.
* Charts draw only real imported rows; nothing is ever fabricated.
"""
from __future__ import annotations

import threading
import time
import uuid
from dataclasses import asdict
from pathlib import Path

from quantai.charting import build_chart_payload
from quantai.config import DataOrigin, ExecutionConfig, RiskConfig
from quantai.data import load_csv, preview_csv
from quantai.data_sources import (FeedSource, fetch_feed_csv, merge_append_only,
                                  validate_feed_url)
from quantai.metrics import new_live_stats, performance_metrics, replay_live_stats
from quantai.model import model_matches_features
from journal import Journal
from storage import Store, atomic_write_json, json_safe, read_json

from paper_replay import PaperReplayMixin
from research_orchestrator import ResearchOrchestratorMixin
from risk_engine import RISK_BOOL_FIELDS, RISK_LIMITS, RiskEngineMixin

DATA_DIR = Path(__file__).parent / "uploads"
DATA_DIR.mkdir(exist_ok=True)
STORE_ROOT = Path(__file__).parent / "data_store"

LIVE_TRADING_ENABLED = False  # hard lock, not user-configurable


class AppState(RiskEngineMixin, PaperReplayMixin, ResearchOrchestratorMixin):
    """The single shared application state (one instance per process)."""

    def __init__(self, store_root: str | Path | None = None):
        self.lock = threading.RLock()
        self.store = Store(store_root or STORE_ROOT)
        self.journal = Journal(self.store.root / "journal.sqlite3")
        self.datasets: dict[str, dict] = {}
        self.active_key: str | None = None
        self.risk = RiskConfig()
        self.execution = ExecutionConfig()
        self.kill_switch = False
        self.model = None
        self.model_binding: dict | None = None
        self.research: dict | None = None
        self.research_busy = False
        self.research_error: str | None = None
        self.import_report: dict | None = None
        self.logs: list[dict] = []
        self.replay = self._fresh_replay()
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._previews: dict[str, dict] = {}
        # Advanced research analyses (latest result per kind) + busy/error flags.
        self.analyses: dict[str, dict | None] = {"portfolio": None, "sensitivity": None,
                                                 "regime": None, "montecarlo": None}
        self.analysis_busy: dict[str, bool] = {k: False for k in self.analyses}
        self.analysis_error: dict[str, str | None] = {k: None for k in self.analyses}
        self._analysis_preacquired: dict[str, bool] = {}
        self.feeds: list[dict] = []
        # The dataset the Charts tab was last showing. Restored on restart so
        # the terminal comes back to the view you left.
        self.last_chart_key: str | None = None
        # WHY the kill switch is engaged ("" when it is not). Kept in the
        # settings so it survives a restart.
        self.kill_reason: str = ""
        self._restore()

    # ---------------- persistence ----------------
    # ---------------- persistence ----------------
    def _restore(self):
        reg = self.store.load_registry()
        settings = self.store.load_settings()
        if settings.get("risk"):
            try:
                raw = {k: v for k, v in settings["risk"].items()
                       if k in RiskConfig.__dataclass_fields__}
                # Re-clamp on load: a hand-edited settings.json must not be
                # able to install a limit outside the hard ranges.
                for k, (lo, hi) in RISK_LIMITS.items():
                    if k in raw and raw[k] is not None:
                        raw[k] = type(raw[k])(min(max(raw[k], lo), hi))
                for k in RISK_BOOL_FIELDS:
                    if k in raw:
                        raw[k] = bool(raw[k])
                self.risk = RiskConfig(**raw)
            except Exception:
                pass
        if settings.get("execution"):
            try:
                self.execution = ExecutionConfig(**{k: v for k, v in settings["execution"].items()
                                                    if k in ExecutionConfig.__dataclass_fields__})
            except Exception:
                pass
        self.kill_switch = bool(settings.get("kill_switch", False))
        self.kill_reason = str(settings.get("kill_reason") or "")
        self.last_chart_key = settings.get("last_chart_key") or None
        self.logs = settings.get("logs", [])[:250]
        for key, ds_id in (reg.get("datasets") or {}).items():
            try:
                df, meta = self.store.load_dataset(ds_id)
                self.datasets[key] = {"df": df, "meta": meta}
                self._refresh_quality_if_missing(key)
            except Exception as e:
                self.log("ERROR", f"Could not restore dataset {ds_id}: {e}")
        self.active_key = reg.get("active_key")
        if self.active_key not in self.datasets:
            self.active_key = next(iter(self.datasets), None)
        if self.active_key:
            ds = self.datasets[self.active_key]
            self.import_report = ds["meta"].to_dict()
            self._load_latest_model_for(ds["meta"].dataset_id)
            self._load_latest_research_for(ds["meta"].dataset_id)
        self.feeds = self.store.load_feeds()
        for kind in self.analyses:
            runs = self.store.list_analyses(kind)
            if runs:
                self.analyses[kind] = self.store.load_analysis(kind, runs[0]["run_id"])
        # Replay never auto-resumes after restart. Journal persists.
        self.log("SYSTEM", f"Restored {len(self.datasets)} dataset(s), {self.journal.count()} journal trade(s), "
                           f"{len(self.feeds)} feed(s). Live trading disabled. Replay idle.")

    def _refresh_quality_if_missing(self, key: str) -> None:
        """Recompute the data-quality layer for a dataset saved before it existed.

        The score is derived from the imported rows, so it can be rebuilt from
        the stored CSV without re-importing or altering a single price. The
        upgraded provenance is written back so the next start is instant.
        """
        ds = self.datasets.get(key)
        if ds is None:
            return
        meta = ds["meta"]
        if getattr(meta, "data_quality_score", 0):
            return
        try:
            from quantai.data import compute_quality_layer
            ql = compute_quality_layer(
                ds["df"], rows_read=meta.rows_read, rows_rejected=meta.rows_rejected,
                duplicates=meta.duplicates, timeframe=meta.timeframe,
                adjustment_policy=meta.adjustment_policy,
                source_type=meta.source_type)
            a = ql["assessment"]
            meta.data_quality_score = a.score
            meta.data_quality_grade = a.grade
            meta.data_quality_verdict = a.verdict
            meta.data_quality_components = [c.to_dict() for c in a.components]
            meta.data_quality_notes = list(a.notes)
            meta.data_quality_penalty = a.penalty
            meta.serious_issues = list(a.serious_issues)
            meta.corporate_actions = [x.to_dict() for x in ql["actions"]]
            meta.corporate_action_count = len([x for x in ql["actions"]
                                               if x.kind == "CORPORATE_ACTION_SUSPECTED"])
            meta.discontinuity_count = len(ql["actions"])
            meta.gap_report = ql["gaps"].to_dict()
            meta.volume_profile = ql["volume"].to_dict()
            self.store.save_dataset(ds["df"], meta)
            self.log("DATA", f"Recomputed the data-quality report for {meta.symbol} "
                             f"{meta.timeframe}: {a.score}/100 (grade {a.grade}).")
        except Exception as e:
            self.log("ERROR", f"Could not recompute the quality report for {key}: {e}")

    def _persist_settings(self):
        self.store.save_settings({
            "risk": asdict(self.risk), "execution": asdict(self.execution),
            "kill_switch": self.kill_switch,
            # The kill reason is kept in the settings as well as in the
            # journal, so the terminal can say WHY it is halted without
            # opening the journal first.
            "kill_reason": getattr(self, "kill_reason", "") or "",
            "logs": self.logs[:250],
            "last_chart_key": self.last_chart_key,
        })

    def _persist_registry(self):
        self.store.save_registry({
            "active_key": self.active_key,
            "datasets": {k: v["meta"].dataset_id for k, v in self.datasets.items()},
            "history": self.store.load_registry().get("history", []),
        })

    def _load_latest_model_for(self, dataset_id: str):
        for m in self.store.list_models():
            if m.get("dataset_id") == dataset_id:
                try:
                    loaded = self.store.load_model(m["model_id"])
                    # Skip a model trained on a different feature set: it cannot
                    # consume today's feature matrix.
                    if not model_matches_features(loaded):
                        continue
                    self.model = loaded
                    self.model_binding = {
                        "key": self.active_key, "dataset_id": dataset_id,
                        "symbol": m.get("symbol"), "timeframe": m.get("timeframe"),
                        "feature_version": m.get("feature_version"), "model": m.get("model_version"),
                        "model_id": m.get("model_id"), "trained_on": "train split only",
                    }
                    return
                except Exception:
                    continue

    def _load_latest_research_for(self, dataset_id: str):
        for r in self.store.list_research():
            if r.get("dataset_id") == dataset_id:
                rep = self.store.load_research(r["run_id"])
                if rep:
                    self.research = rep
                    return

    # ---------------- helpers ----------------
    def _fresh_replay(self):
        cap = self.risk.initial_capital if hasattr(self, "risk") else 500_000.0
        return {
            "running": False, "mode": None, "bar": 0, "total_bars": 0,
            "cash": cap, "initial_capital": cap,
            "equity": [], "equity_labels": [], "position": None, "pending": None,
            "orders": [], "trades": [], "wins": 0, "losses": 0,
            "peak": 0.0, "max_dd": 0.0, "consec_losses": 0, "cooldown_until": -1,
            "day_start_equity": 0.0, "current_day": None, "day_blocked": False,
            "total_costs": 0.0, "total_slippage": 0.0, "speed_ms": 600,
            "rejected": {"no_signal": 0, "risk_qty_zero": 0, "daily_drawdown": 0,
                         "weekly_drawdown": 0, "cooldown": 0, "kill_switch": 0,
                         "no_overnight": 0, "total_drawdown_halt": 0,
                         "max_open_positions": 0, "volume_cap": 0},
            # Weekly loss limit state and the progressive-cooldown history.
            "current_week": None, "week_start_equity": 0.0, "week_blocked": False,
            "weekly_drawdown_pct": 0.0, "cooldown_events": [],
            "last_signal": None, "proba": None, "feats": None, "candles": None, "ind": None,
            "days": None, "cost": None, "started_at": None, "finished": False,
            "halted_reason": None, "run_id": None, "dataset_id": None,
            # Running performance accumulator. Updated once per closed trade,
            # so the live readout never depends on the length of the in-memory
            # trade list (which is capped).
            "stats": new_live_stats(),
        }

    def log(self, kind: str, msg: str):
        with self.lock:
            self.logs.insert(0, {"t": time.strftime("%H:%M:%S"), "kind": kind, "msg": msg})
            self.logs = self.logs[:250]
            try:
                self._persist_settings()
            except Exception:
                pass

    @staticmethod
    def key(symbol: str, tf: str) -> str:
        return f"{symbol.upper()}|{tf}"

    # ---------------- data ----------------
    # ---------------- data ----------------
    def _cleanup_previews(self, max_age_seconds: int = 3600):
        """Remove abandoned preview files older than max_age so they cannot pile up."""
        import time as _t
        pdir = self.store.root / "previews"
        now = _t.time()
        for p in pdir.glob("*"):
            try:
                if p.is_file() and now - p.stat().st_mtime > max_age_seconds:
                    p.unlink(missing_ok=True)
            except Exception:
                pass

    def preview(self, path: Path, symbol: str, timeframe: str,
                source_type: str, adjustment: str,
                source_name: str | None = None,
                holidays: set[str] | None = None) -> dict:
        origin = DataOrigin(source_type)
        rep = preview_csv(path, symbol, timeframe, source_type=origin,
                          adjustment_policy=adjustment, holidays=holidays)
        self._cleanup_previews()
        token = uuid.uuid4().hex
        safe = self.store.root / "previews" / f"{token}.csv"
        safe.write_bytes(Path(path).read_bytes())
        atomic_write_json(self.store.root / "previews" / f"{token}.json",
                          {"symbol": symbol, "timeframe": timeframe,
                           "source_type": source_type, "adjustment": adjustment,
                           "source_name": source_name or Path(path).name,
                           "holidays": sorted(holidays or set())})
        self._previews[token] = rep
        return {"preview_token": token, **rep}

    def confirm_preview(self, token: str) -> dict:
        if not token or not token.isalnum() or len(token) != 32:
            raise ValueError("Invalid preview token.")
        meta_path = self.store.root / "previews" / f"{token}.json"
        csv_path = self.store.root / "previews" / f"{token}.csv"
        info = read_json(meta_path)
        if not info or not csv_path.exists():
            raise ValueError("Preview expired or not found. Preview the file again.")
        try:
            return self.import_csv(csv_path, info["symbol"], info["timeframe"],
                                   info["source_type"], info["adjustment"],
                                   source_name=info.get("source_name"),
                                   holidays=set(info.get("holidays") or []))
        finally:
            csv_path.unlink(missing_ok=True)
            meta_path.unlink(missing_ok=True)
            self._previews.pop(token, None)

    def import_csv(self, path: Path, symbol: str, timeframe: str,
                   source_type: str, adjustment: str, feed_url: str | None = None,
                   retrieved_at: str | None = None, license_note: str | None = None,
                   source_name: str | None = None,
                   holidays: set[str] | None = None) -> dict:
        origin = DataOrigin(source_type)
        df, meta = load_csv(path, symbol, timeframe, source_type=origin,
                            adjustment_policy=adjustment,
                            source_name=source_name or Path(path).name,
                            feed_url=feed_url, retrieved_at=retrieved_at,
                            license_note=license_note, holidays=holidays)
        k = self.key(meta.symbol, meta.timeframe)
        with self.lock:
            self.store.save_dataset(df, meta, source_path=path)
            old = self.datasets.get(k)
            self.datasets[k] = {"df": df, "meta": meta}
            self.active_key = k
            if self.model_binding and self.model_binding.get("dataset_id") != meta.dataset_id:
                self.model = None
                self.model_binding = None
                self.log("MODEL", "Model invalidated: active dataset changed.")
            if self.research and self.research.get("dataset", {}).get("dataset_id") != meta.dataset_id:
                self.research = None
            self.stop_replay()
            self.replay = self._fresh_replay()
            self.import_report = meta.to_dict()
            reg = self.store.load_registry()
            hist = reg.get("history", [])
            hist = [h for h in hist if h.get("dataset_id") != meta.dataset_id]
            hist.insert(0, {"dataset_id": meta.dataset_id, "key": k, "symbol": meta.symbol,
                            "timeframe": meta.timeframe, "imported_at": meta.imported_at,
                            "bars": meta.candle_count, "verification": meta.verification_status.value,
                            "source_name": meta.source_name})
            self.store.save_registry({"active_key": k,
                                      "datasets": {kk: vv["meta"].dataset_id for kk, vv in self.datasets.items()},
                                      "history": hist[:200]})
        self.log("DATA", f"Imported {meta.candle_count} bars {meta.symbol} {meta.timeframe} "
                        f"[{meta.verification_status.value}]")
        return meta.to_dict()

    def active(self):
        with self.lock:
            return self.datasets.get(self.active_key) if self.active_key else None

    # ---------------- charting / technical analysis ----------------
    def chart_symbols(self) -> list[dict]:
        """Datasets available for charting, grouped by symbol, with per-timeframe info.

        Only datasets that are actually imported/loaded are offered. Synthetic and
        test-fixture datasets are listed but flagged clearly and are excluded from
        "real market data" claims.
        """
        out = []
        with self.lock:
            for key, ds in self.datasets.items():
                m = ds["meta"]
                real = m.source_type in (DataOrigin.IMPORTED_CSV, DataOrigin.BROKER_VENDOR,
                                         DataOrigin.DATA_FEED)
                out.append({
                    "key": key,
                    "symbol": m.symbol,
                    "timeframe": m.timeframe,
                    "dataset_id": m.dataset_id,
                    "bars": m.candle_count,
                    "start": m.start, "end": m.end,
                    "source_type": m.source_type.value,
                    "verification_status": m.verification_status.value,
                    "research_quality": m.research_quality.value,
                    "acquisition": getattr(m, "acquisition", "MANUAL_IMPORT"),
                    "missing_bars": m.missing_bars,
                    "zero_volume_bars": getattr(m, "zero_volume_bars", 0),
                    "quality_score": getattr(m, "data_quality_score", 0),
                    "quality_grade": getattr(m, "data_quality_grade", "F"),
                    "serious_issues": len(getattr(m, "serious_issues", []) or []),
                    "is_real_market_data": bool(real),
                    "label": f"{m.symbol} · {m.timeframe}",
                })
        out.sort(key=lambda d: (d["symbol"], d["timeframe"]))
        return out

    def chart_symbol_groups(self) -> dict:
        """Datasets available for charting, GROUPED BY SYMBOL.

        The Charts tab uses this to offer a symbol picker plus a timeframe
        picker that only shows the timeframes that actually exist for the
        chosen symbol — no empty dropdowns.
        """
        from quantai.charting import chart_symbol_groups
        return chart_symbol_groups(self.chart_symbols())

    def chart_compare(self, symbol: str) -> list[dict]:
        """A compact TA snapshot of every timeframe available for one symbol.

        This is the cross-timeframe COMPARISON view: one row per timeframe
        with the handful of readings that actually differ between timeframes.
        It is deliberately compact — it is a table to orient yourself, not a
        second chart.
        """
        from quantai.charting import chart_compare_rows
        symbol_u = (symbol or "").strip().upper()
        picked = []
        with self.lock:
            for key, ds in self.datasets.items():
                m = ds["meta"]
                if symbol_u and m.symbol.upper() != symbol_u:
                    continue
                picked.append({"key": key, "meta": m, "df": ds["df"]})
        return chart_compare_rows(picked)

    def chart_payload(self, key: str | None = None, as_of_bar: int | None = None) -> dict:
        """Build the candlestick/TA payload for a loaded dataset.

        With no ``key`` the LAST VIEWED dataset is used, so reopening the
        terminal lands on the chart you were looking at.
        """
        with self.lock:
            k = key or self.last_chart_key or self.active_key
            ds = self.datasets.get(k)
            if ds is None:
                raise ValueError("No dataset selected for charting.")
            df, meta = ds["df"], ds["meta"]
            m = meta
            meta_dict = {
                "dataset_id": m.dataset_id, "symbol": m.symbol, "timeframe": m.timeframe,
                "source_type": m.source_type.value,
                "verification_status": m.verification_status.value,
                "acquisition": getattr(m, "acquisition", "MANUAL_IMPORT"),
                "start": m.start, "end": m.end,
                "missing_bars": m.missing_bars,
                "zero_volume_bars": getattr(m, "zero_volume_bars", 0),
                "research_quality": m.research_quality.value,
                "feed_url": getattr(m, "feed_url", None),
                "retrieved_at": getattr(m, "retrieved_at", None),
                "quality_score": getattr(m, "data_quality_score", 0),
                "quality_grade": getattr(m, "data_quality_grade", "F"),
            }
        with self.lock:
            self.last_chart_key = k
            try:
                self._persist_settings()
            except Exception:
                pass
        payload = build_chart_payload(df, meta_dict, as_of_bar=as_of_bar)
        payload["meta"]["is_real_market_data"] = bool(
            m.source_type in (DataOrigin.IMPORTED_CSV, DataOrigin.BROKER_VENDOR, DataOrigin.DATA_FEED))
        payload["meta"]["warnings"] = list(m.warnings)
        if not payload["meta"]["is_real_market_data"]:
            payload["meta"]["source_notice"] = (
                "This dataset is NOT real market data (" + m.source_type.value +
                "). Charts show the actual imported rows of that file only.")
        return payload

    def select_dataset(self, key: str):
        with self.lock:
            if key not in self.datasets:
                raise ValueError("Unknown dataset.")
            self.active_key = key
            ds = self.datasets[key]
            self.import_report = ds["meta"].to_dict()
            if self.model_binding and self.model_binding.get("dataset_id") != ds["meta"].dataset_id:
                self.model = None
                self.model_binding = None
                self._load_latest_model_for(ds["meta"].dataset_id)
            if self.research and self.research.get("dataset", {}).get("dataset_id") != ds["meta"].dataset_id:
                self.research = None
                self._load_latest_research_for(ds["meta"].dataset_id)
            self.stop_replay()
            self.replay = self._fresh_replay()
            self._persist_registry()

    def delete_dataset(self, key: str):
        with self.lock:
            ds = self.datasets.pop(key, None)
            if ds:
                self.store.delete_dataset(ds["meta"].dataset_id)
            if self.active_key == key:
                self.active_key = next(iter(self.datasets), None)
            if self.model_binding and self.model_binding.get("key") == key:
                self.model = None
                self.model_binding = None
                self.log("MODEL", "Model invalidated: bound dataset deleted.")
            if self.research and self.research.get("dataset", {}).get("symbol") == (ds["meta"].symbol if ds else None):
                self.research = None
            self.stop_replay()
            self.replay = self._fresh_replay()
            self._persist_registry()
            reg = self.store.load_registry()
            if ds:
                reg["history"] = [h for h in reg.get("history", []) if h.get("dataset_id") != ds["meta"].dataset_id]
                self.store.save_registry(reg)

    def dataset_view(self, key: str, rows: int = 10) -> dict:
        ds = self.datasets.get(key)
        if not ds:
            raise ValueError("Unknown dataset.")
        df = ds["df"]
        def conv(d):
            return [{"timestamp": str(r.timestamp), "open": float(r.open), "high": float(r.high),
                     "low": float(r.low), "close": float(r.close), "volume": int(r.volume)}
                    for r in d.itertuples()]
        return {"meta": ds["meta"].to_dict(), "head": conv(df.head(rows)), "tail": conv(df.tail(rows))}

    def dataset_history(self) -> list[dict]:
        return self.store.load_registry().get("history", [])

    # ---------------- authorized data feeds ----------------
    # ---------------- authorized data feeds ----------------
    def list_feeds(self) -> list[dict]:
        return self.feeds

    def add_feed(self, name: str, url: str, symbol: str, timeframe: str, license_note: str) -> dict:
        validate_feed_url(url)
        if not license_note or len(license_note.strip()) < 10:
            raise ValueError("A license/authorization note (>= 10 chars) is required. "
                             "You must assert you are authorized to use this data.")
        if timeframe not in ("1m", "5m", "15m", "1D"):
            raise ValueError("Unsupported timeframe.")
        feed = FeedSource(name=name.strip()[:80], url=url, symbol=symbol.upper(),
                          timeframe=timeframe, license_note=license_note.strip()[:500],
                          added_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"))
        with self.lock:
            self.feeds = [f for f in self.feeds if f["name"] != feed.name]
            self.feeds.append(asdict(feed))
            self.store.save_feeds(self.feeds)
        self.log("DATA", f"Registered authorized feed '{feed.name}' for {feed.symbol} {feed.timeframe}.")
        return asdict(feed)

    def remove_feed(self, name: str):
        with self.lock:
            self.feeds = [f for f in self.feeds if f["name"] != name]
            self.store.save_feeds(self.feeds)

    def fetch_feed(self, name: str, fetcher=None) -> dict:
        feed = next((f for f in self.feeds if f["name"] == name), None)
        if feed is None:
            raise ValueError("Unknown feed.")
        data, retrieved_at = fetch_feed_csv(feed["url"], fetcher=fetcher)
        tmp = self.store.root / "previews" / f"feed_{uuid.uuid4().hex}.csv"
        tmp.write_bytes(data)
        try:
            meta = self.import_csv(tmp, feed["symbol"], feed["timeframe"], "DATA_FEED",
                                   "UNKNOWN_UNVERIFIED", feed_url=feed["url"],
                                   retrieved_at=retrieved_at, license_note=feed["license_note"],
                                   source_name=f"feed:{feed['name']}")
        finally:
            tmp.unlink(missing_ok=True)
        with self.lock:
            for f in self.feeds:
                if f["name"] == name:
                    f["last_fetched_at"] = retrieved_at
                    f["last_status"] = f"ok: {meta['candle_count']} bars"
            self.store.save_feeds(self.feeds)
        self.log("DATA", f"Fetched {meta['candle_count']} bars from authorized feed '{name}' "
                        f"[DATA_FEED_UNVERIFIED].")
        return meta

    def update_dataset_append(self, key: str, path: Path) -> dict:
        """Append-only update of an existing dataset from a new CSV. Never fills gaps."""
        ds = self.datasets.get(key)
        if ds is None:
            raise ValueError("Unknown dataset.")
        meta = ds["meta"]
        incoming, _ = load_csv(path, meta.symbol, meta.timeframe, source_type=meta.source_type,
                               adjustment_policy=meta.adjustment_policy)
        merged, report = merge_append_only(ds["df"], incoming)
        if report["appended"] == 0:
            return {"ok": True, "appended": 0, **report, "dataset": meta.to_dict()}
        # Re-import the merged frame through the validator to refresh provenance/quality.
        tmp = self.store.root / "previews" / f"merge_{uuid.uuid4().hex}.csv"
        merged.to_csv(tmp, index=False)
        try:
            new_meta = self.import_csv(tmp, meta.symbol, meta.timeframe, meta.source_type.value,
                                       meta.adjustment_policy, source_name=f"{meta.source_name}+append",
                                       feed_url=meta.feed_url, license_note=meta.license_note)
        finally:
            tmp.unlink(missing_ok=True)
        self.log("DATA", f"Append-only update {key}: +{report['appended']} bars "
                        f"({report['overlap_identical']} identical overlap, {report['skipped_older']} older skipped).")
        return {"ok": True, **report, "dataset": new_meta}

    # ---------------- snapshot ----------------
    # ---------------- snapshot ----------------
    def snapshot(self) -> dict:
        with self.lock:
            ds = self.datasets.get(self.active_key) if self.active_key else None
            meta = ds["meta"].to_dict() if ds else None
            r = self.replay
            pos = None
            if r.get("position") and r.get("candles") is not None:
                p = r["position"]
                px = float(r["candles"]["close"].iloc[min(r["bar"], r["total_bars"] - 1)])
                pos = {**{k: p[k] for k in ("qty", "entry", "stop", "target", "bar")},
                       "last": px, "unrealized": (px - p["entry"]) * p["qty"] - p["entry_cost"]}
            eq = r.get("equity") or []
            initial = r.get("initial_capital", self.risk.initial_capital)
            net = (eq[-1] - initial) if eq else 0.0
            replay_metrics = performance_metrics(
                eq, r.get("trades", []), initial, r.get("timeframe") or "1D",
                timestamps=r.get("equity_labels") or None, max_dd_override=r.get("max_dd", 0.0)) if eq else None
            # LIVE readout: derived from the running accumulator, so it is
            # correct at any point of the replay — including before the first
            # trade closes and while a position is still open.
            open_pnl = float(pos["unrealized"]) if pos else 0.0
            live = replay_live_stats(r.get("stats") or new_live_stats(), eq, initial,
                                     float(r.get("max_dd", 0.0) or 0.0), open_pnl)
            candles = []
            if ds is not None:
                d = ds["df"].tail(160)
                candles = [{"t": str(x.timestamp), "o": float(x.open), "h": float(x.high),
                            "l": float(x.low), "c": float(x.close), "v": int(x.volume)}
                           for x in d.itertuples()]
            return json_safe({
                "live_trading_enabled": LIVE_TRADING_ENABLED,
                "dataset": meta,
                "datasets": [{"key": k, "symbol": v["meta"].symbol, "timeframe": v["meta"].timeframe,
                              "bars": v["meta"].candle_count,
                              "verification": v["meta"].verification_status.value,
                              "quality_score": getattr(v["meta"], "data_quality_score", 0),
                              "quality_grade": getattr(v["meta"], "data_quality_grade", "F"),
                              "dataset_id": v["meta"].dataset_id}
                             for k, v in self.datasets.items()],
                "dataset_history": self.dataset_history(),
                "active_key": self.active_key,
                "import_report": self.import_report,
                "risk": asdict(self.risk),
                "execution": asdict(self.execution),
                "kill_switch": self.kill_switch,
                # WHY the kill switch is engaged — shown on the dashboard and
                # on the Risk tab without opening the journal.
                "kill_reason": getattr(self, "kill_reason", "") or "",
                "model_binding": self.model_binding,
                "models": self.store.list_models()[:20],
                "research": self.research,
                "research_history": self.store.list_research()[:20],
                "research_busy": self.research_busy,
                "research_error": self.research_error,
                "analyses": {k: ({"run_id": v.get("run_id"), "created_at": v.get("created_at"),
                                  "summary_label": v.get("summary_label", ""),
                                  "status": v.get("status", "ok")} if v else None)
                             for k, v in self.analyses.items()},
                "analysis_busy": dict(self.analysis_busy),
                "analysis_error": dict(self.analysis_error),
                "feeds": self.feeds,
                "candles": candles,
                "journal_count": self.journal.count(),
                "replay": {
                    "running": r.get("running", False), "finished": r.get("finished", False),
                    "mode": r.get("mode"), "bar": r.get("bar", 0), "total_bars": r.get("total_bars", 0),
                    "symbol": r.get("symbol"), "timeframe": r.get("timeframe"),
                    "ml_active": r.get("ml_active", False),
                    "cash": r.get("cash", initial),
                    "equity": eq[-500:], "position": pos,
                    "orders": r.get("orders", [])[:25], "trades": r.get("trades", [])[:25],
                    "wins": r.get("wins", 0), "losses": r.get("losses", 0),
                    "max_dd": r.get("max_dd", 0.0), "net": net,
                    "net_pct": net / initial * 100 if initial else 0.0,
                    "total_costs": r.get("total_costs", 0.0),
                    "total_slippage": r.get("total_slippage", 0.0),
                    "rejected": r.get("rejected", {}), "last_signal": r.get("last_signal"),
                    "current_week": r.get("current_week"),
                    "week_start_equity": r.get("week_start_equity", 0.0),
                    "week_blocked": bool(r.get("week_blocked", False)),
                    "weekly_drawdown_pct": r.get("weekly_drawdown_pct", 0.0),
                    "weekly_block_reason": r.get("weekly_block_reason", "") or "",
                    "weekly_breaches": (r.get("weekly_breaches") or [])[-10:],
                    "cooldown_events": (r.get("cooldown_events") or [])[-20:],
                    "cooldown_until_bar": r.get("cooldown_until", -1),
                    "consec_losses": r.get("consec_losses", 0),
                    "speed_ms": r.get("speed_ms", 600),
                    "strategy_mode": r.get("strategy_mode", "ensemble"),
                    "threshold": r.get("threshold", 0.42),
                    "halted_reason": r.get("halted_reason"),
                    "metrics": replay_metrics,
                    "live": live,
                },
                "logs": self.logs[:60],
            })


# The single shared application state used by the Flask server. `engine.py`
# re-exports it, so `from engine import STATE` keeps working unchanged.
STATE = AppState()
