"""Risk & execution control for the QuantAI Terminal.

SAFETY CONTRACT
---------------
* Every risk limit is clamped to a hard range here — the frontend can never
  widen a limit beyond these bounds.
* The kill switch blocks new entries in BOTH the backend replay engine and the
  backtest engine. It is never a UI-only affordance.
* Changing a risk limit while a paper position is OPEN is refused unless the
  caller explicitly acknowledges it, and the acknowledgement is logged.
* Engaging the kill switch writes an EVENT (with the operator's reason) into
  the persistent journal. A kill switch is not a trade and is never counted
  as one.
* No broker connection, no live order routing, ever.

This module is a mixin: it is composed into ``AppState`` in ``state_manager.py``.
"""
from __future__ import annotations

import json
from dataclasses import asdict

import numpy as np

from quantai.config import ExecutionConfig, RiskConfig

RISK_LIMITS = {
    "risk_per_trade_pct": (0.05, 2.0),
    "max_daily_drawdown_pct": (0.5, 10.0),
    # The weekly loss limit is deliberately capped at 15%: a bigger weekly
    # number would no longer be a weekly limit, it would be the total-DD
    # limit wearing a different name.
    "max_weekly_drawdown_pct": (1.0, 15.0),
    "max_total_drawdown_pct": (2.0, 50.0),
    "max_exposure_pct": (5.0, 100.0),
    "initial_capital": (10_000, 100_000_000),
    "max_open_positions": (1, 5),
    "max_consecutive_losses": (1, 20),
    "cooldown_bars": (1, 500),
    "cooldown_bars_level2": (1, 500),
    "cooldown_bars_level3": (1, 500),
    "stop_atr_mult": (0.5, 10.0),
    "target_atr_mult": (0.5, 20.0),
    "max_cash_fraction": (0.1, 1.0),
    "risk_vol_target_pct": (0.05, 25.0),
    "risk_vol_min_factor": (0.05, 1.0),
    "risk_vol_max_factor": (1.0, 5.0),
}
EXEC_LIMITS = {
    "slippage_bps": (0.0, 50.0),
    "brokerage_flat_inr": (0.0, 100.0),
    "brokerage_pct_cap": (0.0, 0.01),
    "max_volume_participation_pct": (0.0, 25.0),
}

# Fields that are booleans — they must be coerced with bool(), not with the
# type of the current value, because bool("false") is True.
RISK_BOOL_FIELDS = ("progressive_cooldown", "auto_risk_by_volatility")

# The reason stored when the operator engages the kill switch without
# writing one. It is saved verbatim so the record never shows a blank.
NO_KILL_REASON = "No reason provided"


class RiskEngineMixin:
    """Kill switch, risk limits and execution-cost settings."""

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------
    def open_position_snapshot(self) -> dict | None:
        """A plain description of the open paper position, or None.

        Used both by the risk-change guard and by the kill-switch event, so
        the warning and the journal entry describe the same position.
        """
        r = self.replay
        pos = r.get("position")
        if not pos or r.get("candles") is None:
            return None
        try:
            bar = min(int(r.get("bar", 0)), int(r.get("total_bars", 1)) - 1)
            px = float(r["candles"]["close"].iloc[bar])
        except Exception:
            px = float(pos.get("entry", 0.0))
        entry = float(pos.get("entry", 0.0))
        qty = int(pos.get("qty", 0))
        unrealized = (px - entry) * qty - float(pos.get("entry_cost", 0.0))
        return {
            "symbol": r.get("symbol"), "timeframe": r.get("timeframe"),
            "strategy_mode": r.get("strategy_mode", "ensemble"),
            "qty": qty, "entry": entry, "last": px,
            "stop": float(pos.get("stop", 0.0)), "target": float(pos.get("target", 0.0)),
            "unrealized": unrealized, "bar": int(r.get("bar", 0)),
            "run_id": r.get("run_id"), "dataset_id": r.get("dataset_id"),
        }

    def _record_event(self, event_type: str, reason: str, detail: str = "",
                      open_position: dict | None = None):
        """Write a risk/engine event into the persistent journal."""
        r = self.replay
        eq = (r.get("equity") or [None])[-1]
        try:
            self.journal.add_event({
                "event_type": event_type,
                "reason": reason or "",
                "detail": detail or "",
                "run_id": r.get("run_id"),
                "dataset_id": r.get("dataset_id"),
                "symbol": r.get("symbol"),
                "timeframe": r.get("timeframe"),
                "strategy": r.get("strategy_mode"),
                "bar": r.get("bar"),
                "equity": eq,
                "net_pnl": (eq - r.get("initial_capital", 0.0)) if eq is not None else None,
                "open_position": json.dumps(open_position, default=str) if open_position else "",
            })
        except Exception as e:  # never let journaling break the safety path
            self.log("ERROR", f"Could not write the journal event: {e}")

    # ------------------------------------------------------------------
    # kill switch
    # ------------------------------------------------------------------
    def set_kill(self, on: bool, reason: str = ""):
        """Engage or release the kill switch.

        Engaging it squares off any open position, halts the replay, blocks
        every new entry and writes an EVENT into the journal carrying the
        operator's reason. The reason is optional but strongly encouraged:
        "why did I stop?" is the single most useful thing to write down.
        """
        with self.lock:
            reason = str(reason or "").strip()[:2000]
            self.kill_switch = bool(on)
            if on:
                # An empty reason is still recorded — as an explicit
                # "No reason provided" — so the journal and the settings
                # never silently show a blank reason.
                reason = reason or NO_KILL_REASON
                self._stop.set()
                self.replay["running"] = False
                open_pos = self.open_position_snapshot()
                if self.replay.get("position") is not None and self.replay.get("candles") is not None:
                    # The reason goes into the square-off trade's notes too,
                    # so the trade row explains WHY it was closed.
                    self._kill_reason = reason
                    self._close(float(self.replay["candles"]["close"].iloc[self.replay["bar"]]),
                                "kill_switch_square_off")
                self._record_event(
                    "kill_switch_engaged", reason,
                    "All new entries blocked. Any open position was squared off at the "
                    "current bar close. The replay stays stopped until it is started again.",
                    open_pos)
                self.log("RISK", f"KILL SWITCH ENGAGED. Replay halted, position squared off."
                                 f"{' Reason: ' + reason if reason else ''}")
            else:
                self._record_event("kill_switch_released", reason or "Kill switch released.",
                                    "New entries are allowed again, but the replay stays "
                                    "stopped until it is started.")
                self.log("RISK", "Kill switch released. Replay remains stopped until started.")
            # The reason is kept in the settings as well as in the journal,
            # so the terminal can show WHY it is halted even before the
            # journal has been opened.
            self.kill_reason = reason if self.kill_switch else ""
            self._persist_settings()
            return {"kill_switch": self.kill_switch, "reason": reason}

    # ------------------------------------------------------------------
    # limits
    # ------------------------------------------------------------------
    def update_risk(self, payload: dict) -> dict:
        """Apply new risk limits.

        Returns a result dict::

            {"applied": True|False, "warning": None|dict, "risk": {...},
             "changed": ["field", ...]}

        If a paper position is OPEN the change is REFUSED — ``applied`` is
        ``False`` and ``warning`` describes the open position — unless the
        caller passes ``acknowledge_open_position=True``. The refusal is
        enforced here, in the backend, not only in the UI.

        Every applied change is recorded as a journal event, so "why did I
        change the risk mid-trade?" is answerable later.
        """
        with self.lock:
            payload = dict(payload or {})
            acknowledged = bool(payload.pop("acknowledge_open_position", False))
            open_pos = self.open_position_snapshot()
            if open_pos and not acknowledged:
                return {
                    "applied": False,
                    "risk": asdict(self.risk),
                    "changed": [],
                    "warning": {
                        "message": ("A paper position is OPEN. Changing the risk limits now "
                                    "changes the sizing/stops of every future entry."),
                        "open_position": open_pos,
                        "changed_fields": self._changed_fields(payload),
                        "requires_acknowledgement": True,
                    },
                }

            cur = asdict(self.risk)
            before = dict(cur)
            for k in cur:
                if k in payload:
                    if k in RISK_BOOL_FIELDS:
                        cur[k] = bool(payload[k])
                    else:
                        cur[k] = type(cur[k])(payload[k])
            for k, (lo, hi) in RISK_LIMITS.items():
                if k in cur:
                    cur[k] = type(cur[k])(np.clip(cur[k], lo, hi))
            # The volatility clamps must stay consistent: the minimum factor
            # can never exceed the maximum factor.
            if cur.get("risk_vol_min_factor", 0) > cur.get("risk_vol_max_factor", 1):
                cur["risk_vol_min_factor"] = cur["risk_vol_max_factor"]
            # The cooldown bands must not shrink as the loss streak grows:
            # band 2 >= band 1 and band 3 >= band 2.
            cur["cooldown_bars_level2"] = max(int(cur.get("cooldown_bars_level2", 30)),
                                              int(cur.get("cooldown_bars", 15)))
            cur["cooldown_bars_level3"] = max(int(cur.get("cooldown_bars_level3", 50)),
                                              int(cur.get("cooldown_bars_level2", 30)))
            self.risk = RiskConfig(**cur)

            changed = [k for k in cur if before.get(k) != cur[k]]
            self.log("RISK", f"Updated: {self.risk.summary()}")
            if changed:
                self._record_event(
                    "risk_settings_changed",
                    f"Changed: {', '.join(changed)}",
                    " | ".join(f"{k}: {before.get(k)} -> {cur.get(k)}" for k in changed),
                    open_pos)
            self._persist_settings()
            return {"applied": True, "warning": None, "risk": asdict(self.risk),
                    "changed": changed}

    def _changed_fields(self, payload: dict) -> list[dict]:
        """Which limits a payload WOULD change — used by the warning."""
        cur = asdict(self.risk)
        out = []
        for k, v in cur.items():
            if k not in (payload or {}):
                continue
            new = bool(payload[k]) if k in RISK_BOOL_FIELDS else type(v)(payload[k])
            lo, hi = RISK_LIMITS.get(k, (None, None))
            if lo is not None:
                new = type(v)(np.clip(new, lo, hi))
            if new != v:
                out.append({"field": k, "from": v, "to": new})
        return out

    def update_execution(self, payload: dict):
        with self.lock:
            cur = asdict(self.execution)
            for k in cur:
                if k in payload:
                    cur[k] = float(payload[k])
            for k, (lo, hi) in EXEC_LIMITS.items():
                cur[k] = float(np.clip(cur[k], lo, hi))
            self.execution = ExecutionConfig(**cur)
            self.log("EXEC", f"Updated: {self.execution.summary()}")
            self._persist_settings()
            return asdict(self.execution)
