#!/usr/bin/env python3
"""Fetch REAL historical NSE data from Yahoo Finance and write clean CSVs.

What this produces (in ``quantai-app/uploads/``):

    RELIANCE_1D.csv     RELIANCE.NS     daily  2016-01-01 -> today
    TCS_1D.csv          TCS.NS          daily  2016-01-01 -> today
    HDFCBANK_1D.csv     HDFCBANK.NS     daily  2016-01-01 -> today
    INFY_1D.csv         INFY.NS         daily  2016-01-01 -> today
    NIFTY50_1D.csv      ^NSEI           daily  2016-01-01 -> today
    RELIANCE_15m.csv    RELIANCE.NS     15 min, last 60 days, NSE session only

Every file has EXACTLY these columns, in this order:

    timestamp,open,high,low,close,volume

* ``auto_adjust=True`` — OHLC is split- and dividend-adjusted, so a 1:2
  bonus issue does not show up as a 50 % crash.
* Daily timestamps are stamped ``YYYY-MM-DD 00:00:00``.
* Intraday timestamps keep their real bar time (``YYYY-MM-DD HH:MM:SS``,
  IST) — a 15-minute series stamped 00:00:00 would collapse every bar of
  a day onto one timestamp and the file would be useless.
* Volume is an integer (never silently truncated from a fraction).
* No NaNs: rows with any missing value are dropped and counted.
* Weekend bars are dropped. Yahoo emits a few Saturday/Sunday bars for NSE
  symbols whose open is exactly the previous Friday's close; the hourly
  feed shows no trading hours on those dates, only a zero-volume closing
  mark. The NSE cash segment runs Monday to Friday, so those rows are not
  regular trading sessions. Every dropped bar is written to
  ``uploads/AUDIT_dropped_weekend_rows.csv`` with the reason attached --
  nothing is discarded silently.

Run:  python3 fetch_real_nse.py
"""
from __future__ import annotations

import sys
from datetime import datetime, time as _dtime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
import yfinance as yf

# --------------------------------------------------------------------------
# configuration
# --------------------------------------------------------------------------
IST = "Asia/Kolkata"
OUT_DIR = Path(__file__).resolve().parent / "uploads"

START = "2016-01-01"
# Yahoo's `end` is EXCLUSIVE, so ask for tomorrow to include today's bar.
END = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")

DAILY_TICKERS = [
    ("RELIANCE.NS", "RELIANCE_1D.csv"),
    ("TCS.NS", "TCS_1D.csv"),
    ("HDFCBANK.NS", "HDFCBANK_1D.csv"),
    ("INFY.NS", "INFY_1D.csv"),
    ("^NSEI", "NIFTY50_1D.csv"),
]

INTRADAY_TICKER = "RELIANCE.NS"
INTRADAY_INTERVAL = "15m"
INTRADAY_PERIOD = "60d"
INTRADAY_FILE = "RELIANCE_15m.csv"

# NSE regular trading hours, as requested: 09:15 -> 15:15 IST (inclusive).
# NOTE: the real NSE cash session runs to 15:30. Change SESSION_END to
# time(15, 30) to keep the last two bars of the day.
SESSION_START = _dtime(9, 15)
SESSION_END = _dtime(15, 15)

COLUMNS = ["timestamp", "open", "high", "low", "close", "volume"]

_DAILY_FMT = "%Y-%m-%d 00:00:00"
_INTRADAY_FMT = "%Y-%m-%d %H:%M:%S"


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _extract_ohlcv(df: pd.DataFrame) -> pd.DataFrame:
    """Pull Open/High/Low/Close/Volume out of whatever yfinance returned.

    yfinance gives flat columns for a single ticker, but a MultiIndex when
    several are requested. Handle both so the script never depends on that
    detail.
    """
    if df is None or len(df) == 0:
        return pd.DataFrame(columns=["Open", "High", "Low", "Close", "Volume"])
    if isinstance(df.columns, pd.MultiIndex):
        # Take the first level (Open/High/...), whatever the ticker was.
        out = df.copy()
        out.columns = out.columns.get_level_values(0)
        return out[["Open", "High", "Low", "Close", "Volume"]]
    return df[["Open", "High", "Low", "Close", "Volume"]]


def _download(ticker: str, **kw) -> pd.DataFrame:
    """Download one ticker with yfinance, with retries."""
    last_err = None
    for attempt in range(3):
        try:
            raw = yf.download(ticker, auto_adjust=True, actions=False,
                              progress=False, threads=False, **kw)
            return _extract_ohlcv(raw)
        except Exception as e:                       # network / rate limit
            last_err = e
            print(f"    ! attempt {attempt + 1}/3 failed for {ticker}: {e}")
            import time as _t
            _t.sleep(3 * (attempt + 1))
    raise RuntimeError(f"could not download {ticker}: {last_err}")


def _clean(df: pd.DataFrame, *, intraday: bool) -> tuple[pd.DataFrame, int, int, pd.DataFrame]:
    """Turn a raw OHLCV frame into the exact 6-column CSV frame.

    Returns (clean_frame, rows_dropped, weekend_rows_dropped, weekend_rows_kept).
    The dropped weekend bars are returned so they can be audited instead of
    vanishing silently.
    """
    if df is None or len(df) == 0:
        return pd.DataFrame(columns=COLUMNS), 0, 0, pd.DataFrame()

    out = df.copy()
    out.index = pd.DatetimeIndex(out.index)
    # Always work in IST, whatever timezone Yahoo labelled the bars with.
    if out.index.tz is None:
        out.index = out.index.tz_localize(IST)
    out.index = out.index.tz_convert(IST)

    for c in ("Open", "High", "Low", "Close", "Volume"):
        out[c] = pd.to_numeric(out[c], errors="coerce")

    before = len(out)
    # Drop any bar that is not a real, finite, positive-price OHLCV row.
    ohlc = out[["Open", "High", "Low", "Close"]]
    ok = np.isfinite(ohlc.to_numpy(dtype=float)).all(axis=1)
    ok &= (ohlc > 0).to_numpy().all(axis=1)
    ok &= (out["Volume"].notna().to_numpy()) & (out["Volume"] >= 0).to_numpy()
    out = out[ok]
    dropped = before - len(out)

    if intraday:
        minutes = out.index.hour * 60 + out.index.minute
        start_min = SESSION_START.hour * 60 + SESSION_START.minute
        end_min = SESSION_END.hour * 60 + SESSION_END.minute
        out = out[(minutes >= start_min) & (minutes <= end_min)]
        dropped += before - len(out)

    # NSE cash equity trades Monday-Friday only. Yahoo nevertheless emits a
    # handful of phantom weekend bars (e.g. 2019-10-27 Sun, 2020-11-14 Sat,
    # 2025-02-01 Sat): their open is exactly the previous Friday's close and
    # their volume is a duplicate of Friday's tape. The terminal's own NSE
    # session validator rejects such rows, so drop them here instead of
    # shipping a file that the app has to reject.
    n_before_weekend = len(out)
    weekend_rows = out[out.index.dayofweek >= 5].copy()
    out = out[out.index.dayofweek < 5]
    weekend_dropped = n_before_weekend - len(out)
    dropped += weekend_dropped

    out = out[~out.index.duplicated(keep="first")].sort_index()

    ts = (out.index.strftime(_INTRADAY_FMT) if intraday
          else out.index.strftime(_DAILY_FMT))

    clean = pd.DataFrame({
        "timestamp": ts,
        "open": out["Open"].to_numpy(dtype=float),
        "high": out["High"].to_numpy(dtype=float),
        "low": out["Low"].to_numpy(dtype=float),
        "close": out["Close"].to_numpy(dtype=float),
        "volume": out["Volume"].to_numpy(dtype=float),
    })
    # Volume must be an integer for the terminal's validator.
    v = clean["volume"].to_numpy(dtype=float)
    clean["volume"] = np.rint(v).astype("int64")
    clean = clean.reset_index(drop=True)

    audit = pd.DataFrame()
    if len(weekend_rows):
        audit = pd.DataFrame({
            "timestamp": weekend_rows.index.strftime(_DAILY_FMT),
            "open": weekend_rows["Open"].to_numpy(dtype=float),
            "high": weekend_rows["High"].to_numpy(dtype=float),
            "low": weekend_rows["Low"].to_numpy(dtype=float),
            "close": weekend_rows["Close"].to_numpy(dtype=float),
            "volume": np.rint(weekend_rows["Volume"].to_numpy(dtype=float)).astype("int64"),
            "weekday": weekend_rows.index.day_name(),
        })
    return clean, dropped, weekend_dropped, audit


def _verify(clean: pd.DataFrame, label: str) -> list[str]:
    """Check the file the way the terminal's own loader will check it."""
    problems: list[str] = []
    if len(clean) == 0:
        problems.append(f"{label}: no rows")
        return problems
    if list(clean.columns) != COLUMNS:
        problems.append(f"{label}: wrong columns {list(clean.columns)}")
    if clean.isna().any().any():
        problems.append(f"{label}: contains NaNs")
    if (clean["volume"] < 0).any():
        problems.append(f"{label}: negative volume")
    if not np.allclose(clean["volume"].to_numpy(dtype=float),
                       clean["volume"].to_numpy(dtype=float).round()):
        problems.append(f"{label}: fractional volume")
    hi_ok = clean["high"] >= np.maximum(clean["open"], clean["close"])
    lo_ok = clean["low"] <= np.minimum(clean["open"], clean["close"])
    if not hi_ok.all():
        problems.append(f"{label}: high < max(open,close) on {int((~hi_ok).sum())} row(s)")
    if not lo_ok.all():
        problems.append(f"{label}: low > min(open,close) on {int((~lo_ok).sum())} row(s)")
    if (clean["high"] < clean["low"]).any():
        problems.append(f"{label}: high < low on some row(s)")
    if (clean[["open", "high", "low", "close"]] <= 0).any().any():
        problems.append(f"{label}: non-positive price")
    ts = pd.to_datetime(clean["timestamp"], format="mixed")
    if not ts.is_monotonic_increasing:
        problems.append(f"{label}: timestamps not sorted")
    if ts.duplicated().any():
        problems.append(f"{label}: duplicate timestamps")
    return problems


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------
def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print(f"Yahoo Finance fetch — {START} -> {END} (IST)")
    print(f"Output directory: {OUT_DIR}\n")

    rows: list[dict] = []
    problems: list[str] = []
    audits: list[tuple[str, pd.DataFrame]] = []

    # ---------------- daily ----------------
    for ticker, filename in DAILY_TICKERS:
        print(f"  {ticker:12s} -> {filename}")
        raw = _download(ticker, start=START, end=END, interval="1d")
        clean, dropped, weekend, audit = _clean(raw, intraday=False)
        if weekend:
            print(f"    dropped {weekend} weekend bar(s) (NSE trades Mon-Fri only)")
            audits.append((filename, audit))
        if dropped - weekend:
            print(f"    dropped {dropped - weekend} unusable row(s)")
        if len(clean) == 0:
            problems.append(f"{filename}: no data returned for {ticker}")
            continue
        problems.extend(_verify(clean, filename))
        path = OUT_DIR / filename
        clean.to_csv(path, index=False)
        rows.append({
            "file": filename, "ticker": ticker, "rows": len(clean),
            "first": clean["timestamp"].iloc[0], "last": clean["timestamp"].iloc[-1],
            "size_kb": round(path.stat().st_size / 1024, 1),
        })

    # ---------------- intraday ----------------
    print(f"\n  {INTRADAY_TICKER:12s} -> {INTRADAY_FILE} "
          f"({INTRADAY_INTERVAL}, last {INTRADAY_PERIOD}, "
          f"{SESSION_START:%H:%M}-{SESSION_END:%H:%M} IST)")
    raw = _download(INTRADAY_TICKER, interval=INTRADAY_INTERVAL, period=INTRADAY_PERIOD)
    clean, dropped, weekend, audit = _clean(raw, intraday=True)
    if weekend:
        print(f"    dropped {weekend} weekend bar(s) (NSE trades Mon-Fri only)")
        audits.append((INTRADAY_FILE, audit))
    if dropped - weekend:
        print(f"    dropped {dropped - weekend} out-of-session / unusable row(s)")
    if len(clean) == 0:
        problems.append(f"{INTRADAY_FILE}: no data returned for {INTRADAY_TICKER}")
    else:
        problems.extend(_verify(clean, INTRADAY_FILE))
        path = OUT_DIR / INTRADAY_FILE
        clean.to_csv(path, index=False)
        rows.append({
            "file": INTRADAY_FILE, "ticker": INTRADAY_TICKER, "rows": len(clean),
            "first": clean["timestamp"].iloc[0], "last": clean["timestamp"].iloc[-1],
            "size_kb": round(path.stat().st_size / 1024, 1),
        })

    # ---------------- audit trail ----------------
    # Nothing is discarded silently: every weekend bar that was removed from
    # the daily files is written out with the reason attached.
    if audits:
        audit = pd.concat([a for _, a in audits if len(a)], ignore_index=True)
        audit.insert(0, "source_file", [f for f, a in audits for _ in range(len(a))])
        audit["reason"] = "weekend bar — NSE cash segment trades Mon-Fri; Yahoo emits "\
                          "irregular/phantom weekend sessions (open == previous close, "\
                          "no intraday trading hours)"
        audit_path = OUT_DIR / "AUDIT_dropped_weekend_rows.csv"
        audit.to_csv(audit_path, index=False)
        print(f"\nAudit trail: {len(audit)} dropped weekend bar(s) written to "
              f"{audit_path.name}")

    # ---------------- summary ----------------
    print("\n" + "=" * 84)
    print(f"{'file':22s} {'ticker':14s} {'rows':>7s}  {'first':19s} {'last':19s} {'KB':>7s}")
    print("-" * 84)
    for r in rows:
        print(f"{r['file']:22s} {r['ticker']:14s} {r['rows']:>7d}  "
              f"{r['first']:19s} {r['last']:19s} {r['size_kb']:>7.1f}")
    print("-" * 84)
    print(f"{'TOTAL':22s} {'':14s} {sum(r['rows'] for r in rows):>7d}")

    if problems:
        print("\n✗ PROBLEMS FOUND:")
        for p in problems:
            print("   -", p)
        return 1
    print("\n✓ All files: >0 rows, no NaNs, integer volume, "
          "high >= max(open,close), low <= min(open,close), timestamps sorted & unique.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
