"""Bar-by-bar paper replay engine for the QuantAI Terminal.

SAFETY CONTRACT
---------------
* Replay is a HISTORICAL SIMULATION. It is never a live feed and never claims
  to be one. No order reaches any broker.
* Replay uses the SAME execution contract and the SAME risk rules as the
  backtest engine, so a replayed trade is comparable with a backtested one.
* Signals are causal: the signal at bar[t] uses only bars 0..t.
* Live trading is permanently disabled; there is no broker adapter anywhere.

This module is a mixin: it is composed into `AppState` in `state_manager.py`.
"""
from __future__ import annotations

import threading
import time
import traceback
import uuid

import numpy as np

from quantai.backtest import technical_score
from quantai.config import DataOrigin
from quantai.features import FEATURE_NAMES, FEATURE_WARMUP, build_features
from quantai.indicators import compute_indicators, indicator_score
from quantai.model import model_matches_features
from quantai.metrics import new_live_stats, update_live_stats
from quantai.risk_rules import (effective_risk_pct, iso_week_key,
                              progressive_cooldown_bars, weekly_drawdown_pct)


class PaperReplayMixin:
    def _record_risk_event(self, event_type: str, reason: str, detail: str = ""):
        """Write a risk event into the journal, if the risk engine is present.

        The replay mixin is composed alongside the risk-engine mixin, so the
        journal writer is normally available. It is guarded so the replay can
        still run (and still log) if it is used without it.
        """
        writer = getattr(self, "_record_event", None)
        if writer is None:
            self.log("RISK", f"{event_type}: {reason}")
            return
        try:
            writer(event_type, reason, detail)
        except Exception as e:            # never break the safety path
            self.log("ERROR", f"Could not write the journal event: {e}")

    """Historical replay: start / step / close / stop."""

    def start_replay(self, speed_ms: int = 600, use_test_window: bool = True,
                     mode: str = "ensemble", threshold: float | None = None):
        ds = self.active()
        if ds is None:
            raise ValueError("Import a dataset first.")
        with self.lock:
            if self.replay["running"]:
                raise ValueError("Replay already running.")
            if self.kill_switch:
                raise ValueError("Kill switch is engaged. Release it before starting replay.")
            df, meta = ds["df"], ds["meta"]
            feats = build_features(df)
            ind = compute_indicators(df, meta.timeframe)
            proba = None
            if self.model is not None and self.model_binding and \
               self.model_binding.get("dataset_id") == meta.dataset_id and \
               model_matches_features(self.model):
                proba = np.full((len(df), 3), np.nan)
                ok = feats[FEATURE_NAMES].notna().all(axis=1).to_numpy()
                if ok.any():
                    p = self.model.predict_proba(feats.loc[ok, FEATURE_NAMES].to_numpy())
                    tmp = np.zeros((int(ok.sum()), 3))
                    for col, cls in enumerate(self.model.classes_):
                        tmp[:, int(cls)] = p[:, col]
                    proba[ok] = tmp
            start = 35
            smode = mode if mode in ("ensemble", "rules_only", "indicators", "ml_only") else "ensemble"
            # The model needs FEATURE_WARMUP settled bars before its first
            # probability exists. Starting earlier would show "ML ON" while the
            # ML term silently contributes zero, so the ML-driven modes start
            # at the feature warm-up bar. Rules/indicators only need the short
            # warm-up, so they keep it.
            if smode in ("ensemble", "ml_only") and proba is not None:
                start = max(start, FEATURE_WARMUP)
            if use_test_window and self.research and self.research.get("test_start_bar"):
                start = max(start, int(self.research["test_start_bar"]))
            r = self._fresh_replay()
            cost = self.execution.to_cost_model(is_intraday=meta.timeframe != "1D")
            start_week = iso_week_key(df["timestamp"].iloc[start])
            r.update({
                "running": True, "finished": False,
                "mode": ("HISTORICAL_REPLAY" if meta.source_type == DataOrigin.IMPORTED_CSV
                         else "SIMULATED_REPLAY"),
                "bar": start, "total_bars": len(df),
                "cash": self.risk.initial_capital, "initial_capital": self.risk.initial_capital,
                "peak": self.risk.initial_capital,
                "day_start_equity": self.risk.initial_capital,
                "equity": [self.risk.initial_capital], "equity_labels": [str(df["timestamp"].iloc[start])],
                "speed_ms": max(60, int(speed_ms)),
                "candles": df, "feats": feats, "proba": proba, "ind": ind,
                "days": df["timestamp"].dt.tz_convert("Asia/Kolkata").dt.normalize(),
                "cost": cost, "symbol": meta.symbol, "timeframe": meta.timeframe,
                "started_at": time.strftime("%H:%M:%S"), "run_id": f"replay_{uuid.uuid4().hex[:12]}",
                "dataset_id": meta.dataset_id,
                "ml_active": proba is not None,
                "strategy_mode": smode,
                "threshold": float(threshold) if threshold is not None else (self.research or {}).get("entry_threshold", 0.42),
                "current_week": start_week,
                "week_start_equity": self.risk.initial_capital,
                "week_blocked": False,
                "weekly_block_reason": "",
                "weekly_breaches": [],
                "weekly_drawdown_pct": 0.0,
                "cooldown_events": [],
            })
            r["current_day"] = r["days"].iloc[start]
            self.replay = r
            self._stop.clear()
            self._thread = threading.Thread(target=self._replay_loop, daemon=True)
            self._thread.start()
        self.log("REPLAY", f"Started {self.replay['mode']} on {meta.symbol} {meta.timeframe} "
                           f"from bar {start}. ML {'ON' if self.replay['ml_active'] else 'OFF (rules only)'}.")

    def _replay_loop(self):
        while not self._stop.is_set():
            with self.lock:
                r = self.replay
                if not r["running"]:
                    return
                if r["bar"] >= r["total_bars"] - 1:
                    self._finish_replay()
                    return
                try:
                    self._step()
                except Exception as e:
                    self.log("ERROR", f"Replay step failed: {e}\n{traceback.format_exc(limit=3)}")
                    r["running"] = False
                    return
                delay = r["speed_ms"] / 1000.0
            time.sleep(delay)

    def _finish_replay(self):
        r = self.replay
        if r["position"] is not None:
            self._close(float(r["candles"]["close"].iloc[r["bar"]]), "final_liquidation")
        r["running"] = False
        r["finished"] = True
        self.log("REPLAY", f"Finished. Trades={r['wins'] + r['losses']} "
                           f"Net={((r['cash'] - r['initial_capital']) / r['initial_capital'] * 100):+.2f}%")

    def _close(self, price: float, reason: str):
        r = self.replay
        pos = r["position"]
        cost = r["cost"]
        slip = price * cost.slippage_pct
        fill = max(price - slip, 0.05)
        leg = cost.leg_cost(fill * pos["qty"], is_buy=False)
        r["total_slippage"] += slip * pos["qty"]
        r["total_costs"] += leg["total"]
        pnl = (fill - pos["entry"]) * pos["qty"] - pos["entry_cost"] - leg["total"]
        r["cash"] += fill * pos["qty"] - leg["total"]
        if pnl > 0:
            r["wins"] += 1
            r["consec_losses"] = 0
        else:
            r["losses"] += 1
            r["consec_losses"] += 1
            if r["consec_losses"] >= self.risk.max_consecutive_losses:
                cd = progressive_cooldown_bars(
                    r["consec_losses"], self.risk.max_consecutive_losses,
                    self.risk.cooldown_bars, self.risk.progressive_cooldown,
                    level2_bars=self.risk.cooldown_bars_level2,
                    level3_bars=self.risk.cooldown_bars_level3)
                r["cooldown_until"] = r["bar"] + cd
                r["cooldown_events"].append({"bar": r["bar"], "consecutive_losses": r["consec_losses"],
                                             "cooldown_bars": cd, "until_bar": r["cooldown_until"]})
        ts = r["candles"]["timestamp"]
        trade = {"entry_bar": pos["bar"], "exit_bar": r["bar"], "qty": pos["qty"],
                 "entry": pos["entry"], "exit": fill, "pnl": pnl, "reason": reason,
                 "costs": pos["entry_cost"] + leg["total"],
                 "entry_time": str(ts.iloc[pos["bar"]]), "exit_time": str(ts.iloc[r["bar"]]),
                 "direction": "LONG", "stop": pos["stop"], "target": pos["target"],
                 "entry_reason": pos.get("entry_reason", "signal"), "exit_reason": reason,
                 "strategy": r.get("strategy_mode", "ensemble")}
        r["trades"].insert(0, trade)
        r["orders"].insert(0, {"bar": r["bar"], "side": "SELL", "qty": pos["qty"],
                               "price": fill, "reason": reason, "pnl": pnl})
        r["orders"] = r["orders"][:100]
        r["position"] = None
        # Fold the closed trade into the running performance accumulator.
        update_live_stats(r.get("stats") or new_live_stats(), pnl,
                          pos["entry_cost"] + leg["total"])
        # A kill-switch square-off carries the operator's reason in its notes,
        # so the trade row itself explains WHY it was closed.
        notes = ""
        kill_reason = getattr(self, "_kill_reason", "") or ""
        if reason == "kill_switch_square_off" and kill_reason:
            notes = f"Kill switch: {kill_reason}"
        try:
            self.journal.add({**trade, "run_id": r.get("run_id"), "dataset_id": r.get("dataset_id"),
                              "symbol": r.get("symbol"), "timeframe": r.get("timeframe"),
                              "entry_price": trade["entry"], "exit_price": trade["exit"],
                              "notes": notes})
        except Exception as e:
            self.log("ERROR", f"Journal write failed: {e}")
        if reason == "kill_switch_square_off":
            self._kill_reason = ""
        self.log("EXIT", f"{reason} {pos['qty']} @ {fill:.2f} | P&L {pnl:+.2f}")

    def _step(self):
        r = self.replay
        df, feats, cost = r["candles"], r["feats"], r["cost"]
        i = r["bar"]
        bar = df.iloc[i]
        days = r["days"]
        entered = False

        if days.iloc[i] != r["current_day"]:
            r["current_day"] = days.iloc[i]
            r["day_start_equity"] = r["equity"][-1] if r["equity"] else r["initial_capital"]
            r["day_blocked"] = False

        # ISO-week rollover: the weekly loss limit resets with the week.
        week = iso_week_key(df["timestamp"].iloc[i])
        if week != r["current_week"]:
            r["current_week"] = week
            r["week_start_equity"] = r["equity"][-1] if r["equity"] else r["initial_capital"]
            r["week_blocked"] = False
            r["weekly_block_reason"] = ""
            r["weekly_breaches"] = []

        if r["pending"] is not None and r["position"] is None:
            p = r["pending"]
            r["pending"] = None
            raw = float(bar["open"])
            slip = raw * cost.slippage_pct
            fill = raw + slip
            turnover = fill * p["qty"]
            leg = cost.leg_cost(turnover, is_buy=True)
            if turnover + leg["total"] <= r["cash"]:
                r["cash"] -= turnover + leg["total"]
                r["total_costs"] += leg["total"]
                r["total_slippage"] += slip * p["qty"]
                r["position"] = {"qty": p["qty"], "entry": fill, "bar": i,
                                 "entry_cost": leg["total"],
                                 "stop": max(fill - p["stop_dist"], 0.05),
                                 "target": fill + p["target_dist"],
                                 "entry_reason": p.get("entry_reason", "signal")}
                entered = True
                r["orders"].insert(0, {"bar": i, "side": "BUY", "qty": p["qty"],
                                       "price": fill, "reason": "next_bar_open", "pnl": None})
                r["orders"] = r["orders"][:100]
                self.log("ENTRY", f"BUY {p['qty']} @ {fill:.2f} (next-bar open)")
            else:
                r["rejected"]["risk_qty_zero"] += 1

        if r["position"] is not None:
            pos = r["position"]
            o, h, l = float(bar["open"]), float(bar["high"]), float(bar["low"])
            if not entered and o <= pos["stop"]:
                self._close(o, "gap_stop_at_open")
            elif l <= pos["stop"]:
                self._close(pos["stop"], "stop_loss")
            elif not entered and o >= pos["target"]:
                self._close(o, "gap_target_at_open")
            elif h >= pos["target"]:
                self._close(pos["target"], "target")

        if cost.is_intraday and r["position"] is not None:
            if i == r["total_bars"] - 1 or days.iloc[i + 1] != r["current_day"]:
                self._close(float(bar["close"]), "intraday_eod_square_off")

        holdings = r["position"]["qty"] * float(bar["close"]) if r["position"] else 0.0
        holdings_low = r["position"]["qty"] * float(bar["low"]) if r["position"] else 0.0
        eq = r["cash"] + holdings
        eq_low = r["cash"] + holdings_low
        r["peak"] = max(r["peak"], eq)
        if r["peak"] > 0:
            r["max_dd"] = max(r["max_dd"], (r["peak"] - eq_low) / r["peak"] * 100)
        r["equity"].append(eq)
        r["equity_labels"].append(str(df["timestamp"].iloc[i]))
        r["equity"] = r["equity"][-4000:]
        r["equity_labels"] = r["equity_labels"][-4000:]

        if r["day_start_equity"] > 0 and \
           (r["day_start_equity"] - eq) / r["day_start_equity"] * 100 >= self.risk.max_daily_drawdown_pct:
            r["day_blocked"] = True

        # Weekly loss limit: blocks NEW ENTRIES until the next ISO week.
        r["weekly_drawdown_pct"] = weekly_drawdown_pct(r["week_start_equity"], eq)
        if r["weekly_drawdown_pct"] >= self.risk.max_weekly_drawdown_pct:
            if not r["week_blocked"]:
                # First breach of THIS ISO week: write the reason down once
                # so the operator can see exactly why trading stopped.
                r["weekly_block_reason"] = (
                    f"WEEKLY LOSS LIMIT BREACHED — the week is down "
                    f"{r['weekly_drawdown_pct']:.2f}% against a "
                    f"{self.risk.max_weekly_drawdown_pct:.2f}% limit "
                    f"(ISO week {r['current_week']}). New entries are blocked "
                    f"until the next ISO week; open positions are still managed.")
                r["weekly_breaches"].append({
                    "bar": i, "week": r["current_week"],
                    "weekly_drawdown_pct": r["weekly_drawdown_pct"],
                    "limit_pct": self.risk.max_weekly_drawdown_pct,
                })
                self.log("RISK", r["weekly_block_reason"])
                self._record_risk_event(
                    "weekly_loss_limit_breached", r["weekly_block_reason"],
                    "New entries are blocked until the next ISO week. The replay "
                    "keeps running and open positions are still managed.")
            r["week_blocked"] = True

        # Total drawdown circuit breaker
        if r["halted_reason"] is None and r["peak"] > 0 and \
           (r["peak"] - eq_low) / r["peak"] * 100 >= self.risk.max_total_drawdown_pct:
            r["halted_reason"] = f"total_drawdown_halt: breached {self.risk.max_total_drawdown_pct:.2f}% limit"
            r["pending"] = None
            if r["position"] is not None:
                self._close(float(bar["close"]), "total_drawdown_halt")
            r["running"] = False
            r["finished"] = True
            self.log("RISK", f"TOTAL DRAWDOWN HALT at bar {i}. Replay stopped, position squared off.")
            return

        r["last_signal"] = None
        if r["position"] is None and r["pending"] is None and i < r["total_bars"] - 1:
            row = feats.iloc[i]
            vals = row[["atr", "rsi_14_norm", "bb_percent_b"]].to_numpy(dtype=float)
            if np.isfinite(vals).all() and float(row["atr"]) > 0:
                tech = technical_score(row)
                p_up = p_down = 0.0
                if r["proba"] is not None and np.isfinite(r["proba"][i]).all():
                    p_down, _, p_up = r["proba"][i]
                smode = r.get("strategy_mode", "ensemble")
                if smode == "indicators":
                    score = indicator_score(r["ind"].iloc[i])
                    if not np.isfinite(score):
                        r["rejected"]["no_signal"] += 1
                        r["last_signal"] = None
                        return
                elif smode == "rules_only" or r["proba"] is None:
                    score = tech
                elif smode == "ml_only":
                    score = p_up - p_down
                else:
                    score = 0.6 * tech + 0.4 * (p_up - p_down)
                thr = r.get("threshold", 0.42)
                r["last_signal"] = {"score": score, "tech": tech, "p_up": p_up,
                                    "p_down": p_down, "threshold": thr}
                blocked = None
                if self.kill_switch:
                    blocked = "kill_switch"
                elif score < thr:
                    blocked = "no_signal"
                elif self.risk.max_open_positions < 1:
                    blocked = "max_open_positions"
                elif r["day_blocked"]:
                    blocked = "daily_drawdown"
                elif r["week_blocked"]:
                    blocked = "weekly_drawdown"
                elif i < r["cooldown_until"]:
                    blocked = "cooldown"
                elif cost.is_intraday and days.iloc[i + 1] != r["current_day"]:
                    blocked = "no_overnight"
                if blocked:
                    r["rejected"][blocked] += 1
                else:
                    atr = float(row["atr"])
                    stop_dist = atr * self.risk.stop_atr_mult
                    target_dist = atr * self.risk.target_atr_mult
                    px = float(bar["close"])
                    # Volatility-adjusted risk: the rupee risk at the stop
                    # shrinks when the market is more volatile than the
                    # target ATR%.
                    eff_risk_pct, vol_detail = effective_risk_pct(
                        self.risk.risk_per_trade_pct, atr, px,
                        self.risk.auto_risk_by_volatility,
                        self.risk.risk_vol_target_pct, self.risk.risk_vol_min_factor,
                        self.risk.risk_vol_max_factor)
                    q_risk = int((r["initial_capital"] * eff_risk_pct / 100) // stop_dist)
                    q_cash = int((r["cash"] * self.risk.max_cash_fraction) // px)
                    q_exp = int((r["initial_capital"] * self.risk.max_exposure_pct / 100) // px)
                    q = min(q_risk, q_cash, q_exp)
                    if self.execution.max_volume_participation_pct > 0:
                        q_vol = int(float(bar["volume"]) * self.execution.max_volume_participation_pct / 100.0)
                        if q < q_vol:
                            pass
                        q = min(q, q_vol)
                        if q_vol <= 0:
                            r["rejected"]["volume_cap"] += 1
                    if q <= 0:
                        r["rejected"]["risk_qty_zero"] += 1
                    else:
                        r["pending"] = {"qty": q, "stop_dist": stop_dist,
                                        "target_dist": target_dist, "signal_bar": i,
                                        "risk_pct_used": eff_risk_pct,
                                        "vol_detail": vol_detail,
                                        "entry_reason": f"{smode} score={score:.3f} thr={thr:.2f}"}
        r["bar"] += 1

    def stop_replay(self):
        with self.lock:
            self._stop.set()
            if self.replay.get("running"):
                self.replay["running"] = False
                self.log("REPLAY", "Stopped by user.")
