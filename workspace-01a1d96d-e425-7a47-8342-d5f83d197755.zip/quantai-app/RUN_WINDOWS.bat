@echo off
title QuantAI Terminal
cd /d "%~dp0"
echo === QuantAI Terminal ===
echo Installing requirements (first run only takes time)...
py -m pip install -r requirements.txt
echo.
echo Starting server on http://127.0.0.1:8000 ...
start "" http://127.0.0.1:8000
py app.py
pause
