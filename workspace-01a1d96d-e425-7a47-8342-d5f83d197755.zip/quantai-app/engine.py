"""QuantAI Terminal — public entry point.

This module is a thin façade over the focused implementation modules:

* `state_manager.py`            — AppState core (data, persistence, snapshot)
* `research_orchestrator.py`     — training + advanced analyses
* `paper_replay.py`              — historical paper replay engine
* `risk_engine.py`               — kill switch + risk/execution limits

`AppState` is composed from those mixins in `state_manager.py`. Every name
that used to live here is still importable from here, so `from engine import
STATE, DATA_DIR, LIVE_TRADING_ENABLED, AppState` keeps working unchanged.

SAFETY CONTRACT
---------------
* No broker connection. No live order routing. Live trading is permanently disabled.
* Simulated data is always labelled SIMULATED/TEST_FIXTURE. Imported CSV is UNVERIFIED
  unless the user explicitly marks it BROKER_VENDOR (and even then it is user-asserted).
* Historical replay never claims to be a live feed.
* Risk limits are enforced in the backend replay/backtest engines, not the frontend.
* Datasets, models, research runs, settings and the paper journal persist across restarts.
"""
from __future__ import annotations

from paper_replay import PaperReplayMixin
from research_orchestrator import ResearchOrchestratorMixin, _verdict
from risk_engine import EXEC_LIMITS, RISK_LIMITS, RiskEngineMixin
from state_manager import (DATA_DIR, LIVE_TRADING_ENABLED, STATE, STORE_ROOT, AppState)

__all__ = [
    "AppState", "STATE", "DATA_DIR", "STORE_ROOT", "LIVE_TRADING_ENABLED",
    "RISK_LIMITS", "EXEC_LIMITS", "_verdict",
    "RiskEngineMixin", "PaperReplayMixin", "ResearchOrchestratorMixin",
]
