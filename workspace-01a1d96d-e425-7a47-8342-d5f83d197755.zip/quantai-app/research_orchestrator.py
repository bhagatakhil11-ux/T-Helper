"""Research orchestration for the QuantAI Terminal.

SAFETY CONTRACT
---------------
* The model is trained on the TRAIN split only. Train / validation / unseen-test
  metrics are always reported separately.
* Splits are purged chronologically: labels cannot leak across split boundaries.
* Every backtest (ensemble, rules, indicators, ML, buy & hold) runs on the SAME
  unseen test window with the SAME costs, so comparisons are apples-to-apples.
* A CANDIDATE verdict is NOT proof of profitability. Synthetic data always
  yields PLUMBING_ONLY — no market conclusion is ever drawn from fake data.

This module is a mixin: it is composed into `AppState` in `state_manager.py`.
"""
from __future__ import annotations

import hashlib
import time
import traceback
import uuid
from dataclasses import asdict

import numpy as np
import pandas as pd
import sklearn

from quantai.backtest import run_backtest
from quantai.benchmark import nifty_benchmark
from quantai.config import (CostModel, DataOrigin, ResearchConfig, ResearchQuality)
from quantai.features import (FEATURE_NAMES, FEATURE_VERSION, build_dataset,
                              build_features, purged_split)
from quantai.indicators import compute_indicators
from quantai.metrics import performance_metrics
from quantai.model import (CalibratedForest, aggregate_walk_forward_importance,
                           calibration_report, evaluate, feature_importance,
                           feature_importance_stability, fit_forest,
                           fit_probability_calibrator, momentum_baseline,
                           model_matches_features, overfit_diagnostics,
                           walk_forward, _proba)
from quantai.montecarlo import run_monte_carlo
from quantai.portfolio import run_portfolio
from quantai.regime import detect_regimes, regime_performance
from quantai.sensitivity import run_sensitivity
from storage import json_safe


def _verdict(meta, test_rep, ens, bh, wf, overfit=None, benchmark=None):
    reasons = []
    if meta.source_type in (DataOrigin.SIMULATED, DataOrigin.TEST_FIXTURE):
        return "PLUMBING_ONLY", ["Dataset is not real market history. No market conclusion can be drawn."]
    if meta.research_quality is ResearchQuality.LOW_CONFIDENCE_INSUFFICIENT_DATA:
        reasons.append(f"Only {meta.candle_count} bars; research grade needs {meta.required_research_bars}.")
    if test_rep.accuracy <= max(test_rep.majority_baseline_accuracy, test_rep.momentum_baseline_accuracy):
        reasons.append("Model did not beat simple baselines on the unseen test split.")
    if overfit and overfit.get("reliability") == "LOW":
        reasons.append("Model reliability is LOW (overfit / baseline flags).")
    if ens.net_profit <= 0:
        reasons.append("Strategy lost money on the unseen window after costs and slippage.")
    if ens.total_trades < 5:
        reasons.append("Fewer than 5 closed trades: statistically meaningless.")
    if wf and np.mean([f["accuracy"] for f in wf]) < test_rep.accuracy - 0.10:
        reasons.append("Walk-forward accuracy materially worse than holdout: possible overfit.")
    if bh.net_profit > ens.net_profit:
        reasons.append("Buy & hold beat the strategy on the same window.")
    if benchmark and benchmark.get("status") == "ok" and benchmark.get("net_return_pct") is not None:
        if benchmark["net_return_pct"] > ens.net_return_pct:
            reasons.append("NIFTY 50 buy & hold beat the strategy on the overlapping window (gross of index costs).")
    if reasons:
        return "NO_EDGE", reasons
    return "CANDIDATE", ["Beat baselines and buy & hold after costs on this window only.",
                        "Not proof of future profit. More symbols, more periods, then paper trading."]


class ResearchOrchestratorMixin:
    """Model training, backtests and the advanced analyses."""

    def run_research(self, horizon: int = 5, entry_threshold: float = 0.42,
                     mode: str = "ensemble"):
        ds = self.active()
        if ds is None:
            raise ValueError("Import a CSV dataset first.")
        with self.lock:
            if self.research_busy:
                raise ValueError("Research already running.")
            self.research_busy = True
            self.research_error = None
        try:
            df, meta = ds["df"], ds["meta"]
            cost = self.execution.to_cost_model(is_intraday=meta.timeframe != "1D")
            cfg = ResearchConfig(symbol=meta.symbol, timeframe=meta.timeframe,
                                 forward_horizon=horizon, cost=cost, risk=self.risk)
            round_trip = 2 * (cfg.cost.slippage_pct + cfg.cost.delivery_stt + cfg.cost.exchange_turnover)
            X, y, candles, _ = build_dataset(df, horizon, round_trip, cfg.return_threshold, cfg.warmup_bars)
            split = purged_split(candles, horizon, cfg.train_frac, cfg.val_frac)
            pos_of = {int(c): i for i, c in enumerate(candles)}
            tr = np.array([pos_of[int(c)] for c in split.train_idx])
            va = np.array([pos_of[int(c)] for c in split.val_idx])
            te = np.array([pos_of[int(c)] for c in split.test_idx])

            clf = fit_forest(X[tr], y[tr], cfg.n_estimators, cfg.max_depth,
                             cfg.min_samples_leaf, cfg.random_state)
            mom = momentum_baseline(X[:, 0], cfg.return_threshold)

            # --- probability calibration -------------------------------------
            # The temperature is fitted on the VALIDATION split ONLY. The test
            # split is never handed to the calibrator, so the calibration
            # numbers reported for the test split are out-of-sample.
            calibrator = fit_probability_calibrator(clf, X[va], y[va])
            model = CalibratedForest(clf, calibrator)
            val_raw = _proba(clf, X[va])
            test_raw = _proba(clf, X[te])
            val_cal = calibrator.apply(val_raw)
            test_cal = calibrator.apply(test_raw)
            cal_val_report = calibration_report(val_raw, val_cal, y[va])
            cal_test_report = calibration_report(test_raw, test_cal, y[te])
            cal_report = {
                "method": calibrator.method,
                "fitted_on": "validation split only (the unseen test split was never used to fit it)",
                "calibrator": calibrator.to_dict(),
                "validation": cal_val_report,
                "unseen_test": cal_test_report,
                "argmax_preserved_on_test": bool(cal_test_report.get("argmax_preserved", True)),
                "deployment_policy": {
                    "deployed_artifact": "calibrated",
                    "artifact_description": "The CalibratedForest (forest + calibrator) is the "
                                            "model that gets saved, reloaded and replayed. "
                                            "The raw forest is never deployed.",
                    "affects_threshold_entries": True,
                    "threshold_policy_note": "YES — the calibrated probabilities ARE what the "
                                             "backtest and the paper replay feed into the "
                                             "threshold rule (p_up - p_down >= entry_threshold). "
                                             "Because the calibrated probabilities are flatter, "
                                             "the same threshold can fire more or less often "
                                             "than it did on the raw probabilities. The "
                                             "calibrated run is therefore the one whose trade "
                                             "count and net result describe the deployed "
                                             "behaviour.",
                    "argmax_guarantee": "The predicted class (arg-max) and the accuracy are "
                                        "provably identical to the raw forest's — only the "
                                        "confidence and the entry frequency can move.",
                },
                "note": "Calibration corrects CONFIDENCE, not the prediction. Temperature "
                        "scaling keeps the class order of every row identical, so the "
                        "predicted class (arg-max) and the accuracy are unchanged while the "
                        "stated probability becomes more trustworthy. It is NOT a guarantee "
                        "that trading behaviour is unchanged: a threshold rule acting on "
                        "p_up - p_down can fire more or less often after calibration. "
                        "It is not evidence of an edge.",
            }

            train_rep = evaluate(clf, X[tr], y[tr], y[tr], mom[tr], "train")
            val_rep = evaluate(clf, X[va], y[va], y[tr], mom[va], "validation")
            test_rep = evaluate(clf, X[te], y[te], y[tr], mom[te], "unseen_test")
            # The same evaluation, but on the calibrated probabilities. Accuracy
            # and macro-F1 are identical by construction; log-loss and Brier move.
            test_rep_cal = evaluate(clf, X[te], y[te], y[tr], mom[te], "unseen_test_calibrated",
                                    proba_override=test_cal)

            wf = walk_forward(X, y, candles, horizon, cfg.walk_forward_folds,
                              min(cfg.n_estimators, 200), cfg.max_depth,
                              cfg.min_samples_leaf, cfg.random_state)
            wf_importance = aggregate_walk_forward_importance(wf)
            overfit = overfit_diagnostics(train_rep.to_dict(), val_rep.to_dict(), test_rep.to_dict(), wf)

            # --- feature-importance stability across seeds -------------------
            # Fitted on the TRAIN split only, so the diagnostic never touches
            # validation or test data.
            stability = feature_importance_stability(
                X[tr], y[tr],
                seeds=(cfg.random_state, cfg.random_state + 17, cfg.random_state + 101),
                n_estimators=min(cfg.n_estimators, 200), max_depth=cfg.max_depth,
                min_samples_leaf=cfg.min_samples_leaf)

            feats = build_features(df)
            proba = np.full((len(df), 3), np.nan)
            ok = feats[FEATURE_NAMES].notna().all(axis=1).to_numpy()
            if ok.any():
                p = model.predict_proba(feats.loc[ok, FEATURE_NAMES].to_numpy())
                tmp = np.zeros((int(ok.sum()), 3))
                for col, cls in enumerate(model.classes_):
                    tmp[:, int(cls)] = p[:, col]
                proba[ok] = tmp

            test_start = int(split.test_idx[0])
            # Causal indicator set, shared by the indicator strategy on the SAME
            # purged split / unseen test window as every other strategy.
            ind = compute_indicators(df, meta.timeframe)
            runs = {}
            for strat_mode, label in [("ensemble", "Ensemble (rules + ML)"),
                                      ("rules_only", "Rules only"),
                                      ("indicators", "Indicators (EMA/RSI/MACD/BB)"),
                                      ("ml_only", "ML only"),
                                      ("buy_and_hold", "Buy & hold")]:
                runs[strat_mode] = run_backtest(df, feats, test_start, cfg.cost, self.risk,
                                                meta.timeframe, proba=proba, mode=strat_mode,
                                                entry_threshold=entry_threshold, label=label,
                                                max_volume_participation_pct=self.execution.max_volume_participation_pct,
                                                indicator_df=ind)

            # NIFTY 50 benchmark from an imported dataset (never fabricated).
            nifty = None
            for k, v in self.datasets.items():
                if v["meta"].symbol.upper().replace(" ", "") in ("NIFTY50", "NIFTY", "NIFTY_50") and \
                   v["meta"].timeframe == meta.timeframe:
                    nifty = v["df"]
                    break
            benchmark = nifty_benchmark(nifty, df, test_start, self.risk.initial_capital, meta.timeframe)

            status, reasons = _verdict(meta, test_rep, runs["ensemble"], runs["buy_and_hold"], wf,
                                       overfit, benchmark)
            run_id = f"run_{uuid.uuid4().hex[:16]}"
            model_id = "model_" + hashlib.sha256(
                f"{meta.dataset_id}|{FEATURE_VERSION}|{cfg.random_state}|{horizon}|{cfg.n_estimators}|{cfg.max_depth}|{cfg.min_samples_leaf}".encode()
            ).hexdigest()[:16]
            report = {
                "run_id": run_id, "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                "verdict": status, "verdict_reasons": reasons,
                "dataset": meta.to_dict(), "split": split.to_dict(),
                "train": train_rep.to_dict(),
                "validation": val_rep.to_dict(), "unseen_test": test_rep.to_dict(),
                "unseen_test_calibrated": test_rep_cal.to_dict(),
                "calibration": cal_report,
                "overfit": overfit,
                "walk_forward": wf, "feature_importance": feature_importance(clf),
                "feature_importance_stability": stability,
                "walk_forward_feature_importance": wf_importance,
                "backtests": {k: v.to_dict() for k, v in runs.items()},
                "equity_curves": {k: v.equity_curve for k, v in runs.items()},
                "trade_logs": {k: v.trade_log for k, v in runs.items()},
                "benchmark": benchmark,
                "cost_model": cfg.cost.summary(),
                # The risk rules the backtest actually ran under. Without
                # this, two research runs are not comparable.
                "risk_config": asdict(self.risk),
                "risk_summary": self.risk.summary(),
                "execution": asdict(self.execution),
                "execution_contract": "Signal at bar[t] close -> entry at bar[t+1] open + slippage; "
                                      "gap opens fill at open; stop before target inside a bar; "
                                      "MTM equity and unrealized drawdown every bar; total-DD breach halts trading.",
                "test_start_bar": test_start, "entry_threshold": entry_threshold,
                "selected_mode": mode,
                "strategy_modes": list(runs.keys()),
                "config": cfg.to_dict(), "model_id": model_id,
                "model_version": "RandomForest-v2.0", "feature_version": FEATURE_VERSION,
                "model_history": [m for m in self.store.list_models() if m.get("dataset_id") == meta.dataset_id][:10],
            }
            report = json_safe(report)
            metadata = {
                "model_id": model_id, "model_version": "RandomForest-v2.0",
                "created_at": report["created_at"], "dataset_id": meta.dataset_id,
                "symbol": meta.symbol, "timeframe": meta.timeframe,
                "feature_version": FEATURE_VERSION, "feature_names": FEATURE_NAMES,
                "random_state": cfg.random_state, "config": cfg.to_dict(),
                "execution": asdict(self.execution),
                "sklearn_version": sklearn.__version__, "numpy_version": np.__version__,
                "pandas_version": pd.__version__,
                "split": split.to_dict(), "train_samples": int(len(tr)),
                "test_accuracy": test_rep.accuracy, "test_macro_f1": test_rep.macro_f1,
                "calibration": {
                    "method": calibrator.method, "fitted": calibrator.fitted,
                    "temperature": calibrator.temperature,
                    "fitted_on": "validation split only",
                    "n_calibration_samples": calibrator.n_samples,
                },
                "feature_importance_stability_score": stability.get("stability_score"),
                "verdict": status, "run_id": run_id,
            }
            with self.lock:
                self.store.save_model(model_id, model, metadata)
                self.store.save_research(run_id, report)
                self.research = report
                self.model = model
                self.model_binding = {
                    "key": self.active_key, "dataset_id": meta.dataset_id,
                    "symbol": meta.symbol, "timeframe": meta.timeframe,
                    "feature_version": FEATURE_VERSION, "model": "RandomForest-v2.0",
                    "model_id": model_id, "trained_on": "train split only",
                }
            self.log("RESEARCH", f"Verdict {status} | test acc {test_rep.accuracy:.4f} "
                                 f"vs majority {test_rep.majority_baseline_accuracy:.4f} | model {model_id}")
            return report
        except Exception as e:
            with self.lock:
                self.research_error = f"{type(e).__name__}: {e}"
            self.log("ERROR", self.research_error + "\n" + traceback.format_exc(limit=3))
            raise
        finally:
            with self.lock:
                self.research_busy = False

    # ---------------- advanced research ----------------
    def _sleeve_for(self, key: str, horizon: int = 5) -> dict:
        """Prepare one symbol sleeve: features, optional bound-model proba, an
        out-of-sample start bar, and PRE-TEST volatility for allocation."""
        ds = self.datasets.get(key)
        if ds is None:
            raise ValueError(f"Unknown dataset {key}.")
        df, meta = ds["df"], ds["meta"]
        feats = build_features(df)
        # Out-of-sample start: reuse stored research split if present, else purged split.
        start_bar = None
        for r in self.store.list_research():
            if r.get("dataset_id") == meta.dataset_id:
                rep = self.store.load_research(r["run_id"])
                if rep and rep.get("test_start_bar"):
                    start_bar = int(rep["test_start_bar"])
                    break
        if start_bar is None:
            cost = self.execution.to_cost_model(is_intraday=meta.timeframe != "1D")
            rt = 2 * (cost.slippage_pct + cost.delivery_stt + cost.exchange_turnover)
            _, _, candles, _ = build_dataset(df, horizon, rt, 0.002, 35)
            split = purged_split(candles, horizon)
            start_bar = int(split.test_idx[0])
        # Optional bound model proba (train-split model only; no refit here).
        proba = None
        for m in self.store.list_models():
            if m.get("dataset_id") == meta.dataset_id:
                try:
                    clf = self.store.load_model(m["model_id"])
                    # A model trained on an older feature set cannot consume
                    # today's feature matrix; skip it rather than crash.
                    if not model_matches_features(clf):
                        proba = None
                        break
                    proba = np.full((len(df), 3), np.nan)
                    ok = feats[FEATURE_NAMES].notna().all(axis=1).to_numpy()
                    if ok.any():
                        p = clf.predict_proba(feats.loc[ok, FEATURE_NAMES].to_numpy())
                        tmp = np.zeros((int(ok.sum()), 3))
                        for col, cls in enumerate(clf.classes_):
                            tmp[:, int(cls)] = p[:, col]
                        proba[ok] = tmp
                    break
                except Exception:
                    proba = None
        pretest_ret = df["close"].iloc[:start_bar].pct_change().dropna()
        pretest_vol = float(pretest_ret.std()) if len(pretest_ret) > 2 else None
        return {"key": key, "symbol": meta.symbol, "df": df, "feats": feats,
                "proba": proba, "start_bar": start_bar, "pretest_vol": pretest_vol,
                "timeframe": meta.timeframe, "source_type": meta.source_type}

    def begin_analysis(self, kind: str) -> bool:
        """Atomically mark an analysis busy BEFORE spawning its worker thread, so
        pollers never observe a not-busy/no-result race. Returns False if busy."""
        if kind not in self.analyses:
            raise ValueError("Unknown analysis kind.")
        with self.lock:
            if self.analysis_busy.get(kind):
                return False
            self.analysis_busy[kind] = True
            self.analysis_error[kind] = None
            self._analysis_preacquired[kind] = True
            return True

    def _run_analysis(self, kind: str, fn):
        with self.lock:
            pre = self._analysis_preacquired.pop(kind, False)
            if self.analysis_busy.get(kind) and not pre:
                raise ValueError(f"{kind} analysis already running.")
            self.analysis_busy[kind] = True
            self.analysis_error[kind] = None
        try:
            result = fn()
            run_id = f"run_{uuid.uuid4().hex[:16]}"
            result = json_safe({"run_id": run_id, "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                                "kind": kind, **result})
            with self.lock:
                self.store.save_analysis(kind, run_id, result)
                self.analyses[kind] = result
            self.log("RESEARCH", f"{kind} analysis complete ({run_id}).")
            return result
        except Exception as e:
            with self.lock:
                self.analysis_error[kind] = f"{type(e).__name__}: {e}"
            self.log("ERROR", f"{kind} analysis failed: {e}")
            raise
        finally:
            with self.lock:
                self.analysis_busy[kind] = False

    def run_portfolio_analysis(self, keys: list[str], allocation_method: str = "equal",
                               max_symbol_weight_pct: float = 40.0,
                               max_portfolio_exposure_pct: float = 90.0,
                               mode: str = "ensemble", entry_threshold: float = 0.42,
                               horizon: int = 5):
        def fn():
            if not keys or len(keys) < 2:
                raise ValueError("Portfolio research needs at least 2 imported symbols.")
            sleeves = [self._sleeve_for(k, horizon) for k in keys]
            tfs = {s["timeframe"] for s in sleeves}
            if len(tfs) != 1:
                raise ValueError("All portfolio symbols must share the same timeframe.")
            tf = next(iter(tfs))
            if any(s["source_type"] in (DataOrigin.SIMULATED, DataOrigin.TEST_FIXTURE) for s in sleeves):
                self.log("RESEARCH", "Portfolio includes synthetic/test data; results are plumbing only.")
            cost = self.execution.to_cost_model(is_intraday=tf != "1D")
            res = run_portfolio(sleeves, self.risk.initial_capital, cost, self.risk, tf,
                                mode=mode, entry_threshold=entry_threshold,
                                allocation_method=allocation_method,
                                max_symbol_weight_pct=max_symbol_weight_pct,
                                max_portfolio_exposure_pct=max_portfolio_exposure_pct,
                                volume_cap_pct=self.execution.max_volume_participation_pct)
            res["summary_label"] = f"{len(keys)} symbols · {allocation_method} · net {res['portfolio_metrics']['total_return_pct']:.2f}%"
            res["has_synthetic"] = any(s["source_type"] in (DataOrigin.SIMULATED, DataOrigin.TEST_FIXTURE) for s in sleeves)
            return res
        return self._run_analysis("portfolio", fn)

    def run_sensitivity_analysis(self, thresholds=None, stop_mults=None, target_mults=None,
                                 mode: str = "ensemble", entry_threshold: float = 0.42,
                                 horizon: int = 5):
        def fn():
            if self.active() is None:
                raise ValueError("Import a dataset first.")
            sl = self._sleeve_for(self.active_key, horizon)
            cost = self.execution.to_cost_model(is_intraday=sl["timeframe"] != "1D")
            res = run_sensitivity(sl["df"], sl["feats"], sl["start_bar"], cost, self.risk,
                                  sl["timeframe"], mode=mode, proba=sl.get("proba"),
                                  thresholds=thresholds, stop_mults=stop_mults,
                                  target_mults=target_mults,
                                  volume_cap_pct=self.execution.max_volume_participation_pct)
            res["symbol"] = sl["symbol"]
            res["summary_label"] = f"{sl['symbol']} · {res['stability']} · {res['summary']['profitable_combinations']}/{res['grid_size']} profitable"
            return res
        return self._run_analysis("sensitivity", fn)

    def run_regime_analysis(self, mode: str = "ensemble", entry_threshold: float = 0.42,
                            horizon: int = 5, ema_span: int = 50, slope_lookback: int = 10):
        def fn():
            if self.active() is None:
                raise ValueError("Import a dataset first.")
            sl = self._sleeve_for(self.active_key, horizon)
            cost = self.execution.to_cost_model(is_intraday=sl["timeframe"] != "1D")
            regimes = detect_regimes(sl["df"], ema_span=ema_span, slope_lookback=slope_lookback)
            res = run_backtest(sl["df"], sl["feats"], sl["start_bar"], cost, self.risk,
                               sl["timeframe"], proba=sl.get("proba"), mode=mode,
                               entry_threshold=entry_threshold, label=f"{sl['symbol']} regime",
                               max_volume_participation_pct=self.execution.max_volume_participation_pct)
            perf = regime_performance(sl["df"], regimes, res.trade_log, res.equity_curve,
                                      sl["start_bar"], self.risk.initial_capital)
            perf["symbol"] = sl["symbol"]
            perf["overall_net_return_pct"] = res.net_return_pct
            perf["summary_label"] = f"{sl['symbol']} · profitable in {len(perf['profitable_regimes'])}/{len(perf['tested_regimes'])} tested regimes"
            # Drop the full per-bar label array from the stored summary to keep it light;
            # keep distribution + per-regime aggregates.
            perf.pop("regime_labels", None)
            return perf
        return self._run_analysis("regime", fn)

    def run_montecarlo_analysis(self, source: str = "research", mode: str = "ensemble",
                                n_simulations: int = 2000, method: str = "block",
                                block_size: int = 5, seed: int = 42,
                                ruin_drawdown_pct: float = 50.0):
        def fn():
            if source == "journal":
                trades = self.journal.list(limit=100000)
                pnls = [float(t["pnl"]) for t in trades if t.get("pnl") is not None]
                label = "paper journal"
            elif self.research and self.research.get("trade_logs", {}).get(mode):
                pnls = [float(t["pnl"]) for t in self.research["trade_logs"][mode]]
                label = f"research backtest ({mode})"
            else:
                raise ValueError("No trades available. Run research (with trades) or paper replay first.")
            res = run_monte_carlo(pnls, self.risk.initial_capital, n_simulations=n_simulations,
                                  method=method, block_size=block_size, seed=seed,
                                  ruin_drawdown_pct=ruin_drawdown_pct)
            res["source"] = label
            res["summary_label"] = (f"{label} · {res['n_simulations']} sims · "
                                    f"P(loss)={res.get('probability_of_loss', 0):.0%}" if res["status"] == "ok"
                                    else f"{label} · insufficient trades")
            return res
        return self._run_analysis("montecarlo", fn)
