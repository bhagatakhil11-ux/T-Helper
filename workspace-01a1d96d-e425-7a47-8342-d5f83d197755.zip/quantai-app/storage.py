"""Durable, path-safe persistence for datasets, models, research and settings.

Design rules:
  * Every on-disk object is addressed by a validated id, never by a user path.
  * Writes are atomic (temp file + os.replace) so a crash cannot half-write state.
  * Uploaded CSV bytes are stored as DATA and read back with a CSV parser only.
    Nothing here imports, execs, or evaluates uploaded content.
"""
from __future__ import annotations

import json
import math
import os
import re
import shutil
import tempfile
import threading
from dataclasses import asdict
from pathlib import Path

import joblib
import pandas as pd

from quantai.config import DataOrigin, ResearchQuality, VerificationStatus
from quantai.data import DatasetMeta

DATASET_ID_RE = re.compile(r"^[A-Z0-9&.\-]+_(?:1m|5m|15m|1D)_[0-9a-f]{12}$")
MODEL_ID_RE = re.compile(r"^model_[0-9a-f]{16}$")
RUN_ID_RE = re.compile(r"^run_[0-9a-f]{16}$")


def json_safe(obj):
    """Recursively convert numpy/pandas/Enum/non-finite values to JSON-safe types."""
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [json_safe(v) for v in obj]
    if isinstance(obj, Path):
        return str(obj)
    if hasattr(obj, "value") and hasattr(obj, "name"):  # Enum
        return obj.value
    if hasattr(obj, "item"):  # numpy scalar
        try:
            obj = obj.item()
        except Exception:
            pass
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if hasattr(obj, "isoformat"):
        return obj.isoformat()
    return obj


def atomic_write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(json_safe(obj), f, indent=2, allow_nan=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def read_json(path: Path, default=None):
    if not path.exists():
        return default
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def meta_from_dict(d: dict) -> DatasetMeta:
    d = dict(d)
    d["source_type"] = DataOrigin(d["source_type"])
    d["verification_status"] = VerificationStatus(d["verification_status"])
    d["research_quality"] = ResearchQuality(d["research_quality"])
    known = {f for f in DatasetMeta.__dataclass_fields__}
    return DatasetMeta(**{k: v for k, v in d.items() if k in known})


class Store:
    """Filesystem store rooted at one directory. Thread-safe via a lock."""

    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.lock = threading.RLock()
        for sub in ("datasets", "models", "research", "previews", "logs"):
            (self.root / sub).mkdir(parents=True, exist_ok=True)

    # ---------- paths (validated) ----------
    def dataset_dir(self, dataset_id: str) -> Path:
        if not DATASET_ID_RE.fullmatch(dataset_id):
            raise ValueError("Invalid dataset id")
        p = (self.root / "datasets" / dataset_id).resolve()
        if self.root not in p.parents and p != self.root:
            raise ValueError("Path traversal blocked")
        return p

    def model_dir(self, model_id: str) -> Path:
        if not MODEL_ID_RE.fullmatch(model_id):
            raise ValueError("Invalid model id")
        return self.root / "models" / model_id

    def research_path(self, run_id: str) -> Path:
        if not RUN_ID_RE.fullmatch(run_id):
            raise ValueError("Invalid research run id")
        return self.root / "research" / f"{run_id}.json"

    # ---------- datasets ----------
    def save_dataset(self, df: pd.DataFrame, meta: DatasetMeta, source_path: Path | None = None) -> None:
        with self.lock:
            d = self.dataset_dir(meta.dataset_id)
            d.mkdir(parents=True, exist_ok=True)
            csv_tmp = d / "candles.csv.tmp"
            df.to_csv(csv_tmp, index=False)
            os.replace(csv_tmp, d / "candles.csv")
            atomic_write_json(d / "meta.json", meta.to_dict())
            if source_path is not None and Path(source_path).exists():
                shutil.copyfile(source_path, d / "source_upload.csv")

    def load_dataset(self, dataset_id: str) -> tuple[pd.DataFrame, DatasetMeta]:
        with self.lock:
            d = self.dataset_dir(dataset_id)
            meta = meta_from_dict(read_json(d / "meta.json"))
            df = pd.read_csv(d / "candles.csv")
            df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True).dt.tz_convert("Asia/Kolkata")
            df["volume"] = df["volume"].astype("int64")
            return df, meta

    def delete_dataset(self, dataset_id: str) -> None:
        with self.lock:
            d = self.dataset_dir(dataset_id)
            if d.exists():
                shutil.rmtree(d)

    def list_dataset_ids(self) -> list[str]:
        with self.lock:
            if not (self.root / "datasets").exists():
                return []
            return sorted(p.name for p in (self.root / "datasets").iterdir()
                          if p.is_dir() and DATASET_ID_RE.fullmatch(p.name))

    # ---------- models ----------
    def save_model(self, model_id: str, clf, metadata: dict) -> None:
        with self.lock:
            d = self.model_dir(model_id)
            d.mkdir(parents=True, exist_ok=True)
            tmp = d / "model.joblib.tmp"
            joblib.dump(clf, tmp)
            os.replace(tmp, d / "model.joblib")
            atomic_write_json(d / "metadata.json", metadata)

    def load_model(self, model_id: str):
        with self.lock:
            d = self.model_dir(model_id)
            return joblib.load(d / "model.joblib")

    def model_metadata(self, model_id: str) -> dict | None:
        return read_json(self.model_dir(model_id) / "metadata.json")

    def list_models(self) -> list[dict]:
        with self.lock:
            out = []
            base = self.root / "models"
            if base.exists():
                for p in sorted(base.iterdir()):
                    if p.is_dir() and MODEL_ID_RE.fullmatch(p.name):
                        m = read_json(p / "metadata.json")
                        if m:
                            out.append(m)
            return sorted(out, key=lambda x: x.get("created_at", ""), reverse=True)

    # ---------- research ----------
    def save_research(self, run_id: str, report: dict) -> None:
        with self.lock:
            atomic_write_json(self.research_path(run_id), report)

    def load_research(self, run_id: str) -> dict | None:
        return read_json(self.research_path(run_id))

    def list_research(self) -> list[dict]:
        with self.lock:
            out = []
            base = self.root / "research"
            if base.exists():
                for p in base.glob("run_*.json"):
                    r = read_json(p)
                    if r:
                        out.append({"run_id": r.get("run_id"), "created_at": r.get("created_at"),
                                    "dataset_id": r.get("dataset", {}).get("dataset_id"),
                                    "verdict": r.get("verdict"), "symbol": r.get("dataset", {}).get("symbol")})
            return sorted(out, key=lambda x: x.get("created_at", ""), reverse=True)

    # ---------- settings / registry ----------
    def save_settings(self, settings: dict) -> None:
        with self.lock:
            atomic_write_json(self.root / "settings.json", settings)

    def load_settings(self) -> dict:
        return read_json(self.root / "settings.json", {})

    def save_registry(self, registry: dict) -> None:
        with self.lock:
            atomic_write_json(self.root / "registry.json", registry)

    def load_registry(self) -> dict:
        return read_json(self.root / "registry.json", {"active_key": None, "datasets": {}, "history": []})

    # ---------- advanced analyses (portfolio / sensitivity / regime / monte carlo) ----------
    def save_analysis(self, kind: str, run_id: str, data: dict) -> None:
        if kind not in ("portfolio", "sensitivity", "regime", "montecarlo"):
            raise ValueError("Invalid analysis kind")
        if not RUN_ID_RE.fullmatch(run_id):
            raise ValueError("Invalid analysis run id")
        with self.lock:
            d = self.root / "analyses" / kind
            d.mkdir(parents=True, exist_ok=True)
            atomic_write_json(d / f"{run_id}.json", data)

    def load_analysis(self, kind: str, run_id: str) -> dict | None:
        if kind not in ("portfolio", "sensitivity", "regime", "montecarlo"):
            raise ValueError("Invalid analysis kind")
        if not RUN_ID_RE.fullmatch(run_id):
            raise ValueError("Invalid analysis run id")
        return read_json(self.root / "analyses" / kind / f"{run_id}.json")

    def list_analyses(self, kind: str) -> list[dict]:
        if kind not in ("portfolio", "sensitivity", "regime", "montecarlo"):
            raise ValueError("Invalid analysis kind")
        with self.lock:
            base = self.root / "analyses" / kind
            out = []
            if base.exists():
                for p in base.glob("run_*.json"):
                    r = read_json(p)
                    if r:
                        out.append({"run_id": r.get("run_id"), "created_at": r.get("created_at"),
                                    "summary": r.get("summary_label", "")})
            return sorted(out, key=lambda x: x.get("created_at", ""), reverse=True)

    # ---------- authorized feed registry ----------
    def save_feeds(self, feeds: list[dict]) -> None:
        with self.lock:
            atomic_write_json(self.root / "feeds.json", feeds)

    def load_feeds(self) -> list[dict]:
        return read_json(self.root / "feeds.json", [])
