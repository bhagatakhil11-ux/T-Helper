# QuantAI Terminal — Professional Research & Paper Trading Platform

A self-contained, browser-based **stock market research, machine learning, backtesting, and
paper trading terminal** for NSE equities. Built for evidence-gated decision making — **not** a
profit-guaranteeing bot.

> 🔒 **Live trading is permanently disabled.** There is no broker adapter, no API key field,
> and no real-money order routing anywhere in this codebase. This is strictly a research and
> paper-trading tool.

---

## Table of contents
1. [What it does](#what-it-does)
2. [Requirements](#requirements)
3. [Installation](#installation)
4. [Running the terminal](#running-the-terminal)
5. [Importing real market data](#importing-real-market-data)
6. [Candlestick charts & technical analysis](#candlestick-charts--technical-analysis)
7. [Running research](#running-research)
8. [Advanced research](#advanced-research)
9. [Paper trading (replay)](#paper-trading-replay)
10. [Trading journal](#trading-journal)
11. [Risk & safety](#risk--safety)
12. [Performance metrics explained](#performance-metrics-explained)
13. [Reports & export](#reports--export)
14. [Architecture](#architecture)
15. [Testing](#testing)
16. [Troubleshooting](#troubleshooting)
17. [Known limitations](#known-limitations)
18. [Safety rules](#safety-rules)

---

## What it does

The terminal implements a complete, honest research pipeline:

```
Historical OHLCV CSV
   → strict validation + provenance labelling
   → causal feature engineering (22 features, no look-ahead)
   → forward-return labels with a cost hurdle
   → purged chronological train/validation/test split
   → Random Forest training (train split only)
   → probability calibration (validation split only, arg-max preserving)
   → baselines + walk-forward + overfit diagnostics
   → feature-importance stability across random seeds
   → 5-way backtest on the unseen window with Indian costs
     (ensemble · rules · indicators · ML · buy & hold)
   → NIFTY 50 benchmark comparison (if imported)
   → research verdict (PLUMBING_ONLY / NO_EDGE / CANDIDATE)
   → bar-by-bar paper replay with the same risk engine
   → persistent trading journal + exports
```

### Feature set — `features-v2.0` (22 features, every one strictly causal)

A feature at bar `t` is a function of bars `0..t` **only**. No rolling window is
centred, no `ewm` looks ahead, and nothing reads bar `t + k`.

| Family | Features |
| --- | --- |
| Returns | `return_1`, `return_3`, `return_5`, `return_10` |
| Volatility | `atr_ratio`, `atr_expansion`, `volatility_20`, `volatility_ratio` |
| Volume | `volume_ratio`, `volume_trend`, `volume_zscore` |
| EMA distance | `ema_9_dist`, `ema_21_dist`, `ema_50_dist`, `ema_200_dist`, `ema_9_21_diff` |
| RSI | `rsi_14_norm`, `rsi_slope_5` |
| MACD | `macd_hist_norm`, `macd_norm`, `macd_cross` |
| Bollinger | `bb_percent_b` |

The eight original `features-v1.0` features keep their exact formulas and
exact values, so every downstream consumer (rules-only backtest, paper replay,
older reports) behaves identically. `FEATURE_VERSION` is part of the model id,
and a model trained on an older feature set is skipped rather than fed a
mismatched feature matrix.

**How causality is enforced, not just asserted:**
- `pct_change` / `diff` / `shift(n)` with `n > 0` look backwards only.
- `rolling` / `ewm` are left-trailing by construction (no `center=True`).
- `min_periods` only masks the warm-up; the underlying EWM numbers are
  identical to the full-history ones.
- Labels at bar `i` read `close[i + horizon]` **only**, and the purged split
  leaves a `horizon`-wide gap between train / validation / test.
- `tests/test_ml_causality_calibration.py` proves it three ways: features built
  on a prefix equal the full-history features at the same bar; mutating future
  bars leaves every earlier feature bit-identical; truncating the frame does
  not change the last kept bar.

### Probability calibration — validation split only

A random forest on three noisy classes is usually badly over-confident on the
bars it gets wrong. The calibrator fixes the **confidence**, never the
**prediction**:

```
z = log(p)                       # the forest's log-probabilities
p_calibrated = softmax(z / T)    # == p ** (1/T), renormalised
```

`T` is fitted on the **validation split only** — the unseen test split is never
handed to the calibrator, so the calibration numbers reported for the test
split are a genuine out-of-sample measurement. The temperature search is
deterministic (coarse grid, then local refinement) and bounded to
`[0.25, 4.0]`; if the fit lands on a bound, the report says so.

**Why temperature scaling and not per-class Platt scaling:** `T` is one positive
number, so the class order inside every row is preserved and the arg-max is
mathematically identical before and after. A per-class transform *can* reorder
the classes, which would change live trading behaviour under the guise of
"better probabilities". Temperature scaling cannot.

Consequences, stated plainly:
- **Accuracy, macro-F1 and the confusion matrix are unchanged.** The report
  prints the before/after so you can verify it.
- **Brier score, log-loss and ECE improve** (typically ECE drops by 3-5x on the
  test split).
- Calibration is **not** evidence of an edge. It only means the stated
  probability deserves to be believed.

**Deployment policy (stated in every report, not hidden in the code):**

| | |
| --- | --- |
| Deployed artifact | the `CalibratedForest` (forest + calibrator) — the raw forest is never deployed |
| Calibrated probabilities drive threshold entries | **yes** |
| What is guaranteed | the predicted class (arg-max) and the accuracy are identical to the raw forest's |
| What is *not* guaranteed | the number of entries — a threshold on `p_up - p_down` fires more or less often once the probabilities are flattened |

Because the calibrated probabilities are what the backtest and the paper
replay feed into the threshold rule, the calibrated run is the one whose
trade count and net result describe the deployed behaviour. The report shows
both the raw and the calibrated test-split metrics so you can see exactly what
the calibrator moved.

The saved model is a `CalibratedForest` (forest + calibrator in one picklable
object) exposing the same `classes_` / `predict_proba()` surface the app
already used, so it reloads cleanly and old plain-forest models still load.

### Feature-importance stability across seeds

The model is refit on the train split with several random seeds and the
importance rankings are compared: mean rank, rank standard deviation, per-seed
rank correlation and a 0-100 stability score, plus the features that moved
more than 3 rank positions or received zero importance in every seed.

**This is a diagnostic, not a verdict.** Stability means the model tells the
same story across seeds; it says *nothing* about predictive power — a
consistently useless feature can be perfectly stable. Each walk-forward fold
also stores its own feature-importance snapshot, and the report aggregates the
mean importance and how often each feature landed in a fold's top 5.

**Twelve tabs:** Dashboard · Data Import · Research · **Charts & TA** · Portfolio · Sensitivity ·
Regimes · Monte Carlo · Paper Replay · Journal · Risk & Safety · Reports.
Dark/light theme, responsive layout, comparison charts, readable tables.

**Candlestick & technical-analysis layer** (Charts & TA tab):
- **Interactive OHLC candles** — green bullish / red bearish, mouse-wheel zoom, drag-to-pan,
  crosshair with date + price read-out, click-to-select a date, hover tooltip with
  Open / High / Low / Close / Volume, and a **separate volume bar panel** below the price chart.
- **Indicators, each individually toggleable** — EMA 9/20/50/200, SMA 20/50/200, RSI(14),
  MACD(12,26,9) with histogram, Bollinger(20,2), ATR(14), and VWAP (intraday only).
  RSI and MACD get their own sub-panels; EMA/SMA/Bollinger/VWAP overlay the price chart.
- **Candlestick patterns** — Doji, Hammer, Inverted Hammer, Shooting Star, Bullish/Bearish
  Engulfing, Morning Star, Evening Star, Marubozu — each with its candle timestamp, bias and a
  plain-language explanation. **Patterns are observations, never guaranteed buy/sell signals.**
- **Support & resistance zones** drawn as horizontal bands from fractal swing pivots,
  split into **confirmed historical levels** (solid) and **developing levels** (dashed, unconfirmed).
- **Technical analysis summary** — trend, momentum, RSI condition, MACD condition, price vs
  EMA 20/50/200, nearby support/resistance and recent patterns. It reports **individual readings,
  never an unexplained BUY/SELL verdict.**

**Advanced research layer** (all on the same leak-free, cost-aware engine):
- **Multi-symbol portfolio** — independent capital sleeves, equal/inverse-vol allocation,
  concentration caps, combined equity + drawdown, return-correlation matrix.
- **Parameter sensitivity** — threshold × stop-ATR × target-ATR grid with a
  STABLE / MIXED / FRAGILE verdict that exposes narrow-parameter over-optimisation.
- **Market regimes** — causal bullish/bearish/sideways labelling and per-regime performance.
- **Monte Carlo** — IID / moving-block bootstrap of your actual trade P&Ls; percentile
  distributions and ruin/streak probabilities, never a guaranteed outcome.
- **Authorized data feeds** — optional HTTPS CSV fetch (SSRF-guarded), append-only updates,
  distinct downloaded / manual / synthetic provenance with source + timestamp.

---

## Requirements

- **Python 3.11+** (3.13 tested)
- Dependencies (see `requirements.txt`):
  - `flask>=3.0` — web server
  - `pandas>=2.2`, `numpy>=1.26` — data handling
  - `scikit-learn>=1.4` — Random Forest
  - `joblib>=1.3` — model persistence
  - `pytest>=8.0` — test suite
  - `yfinance>=1.8` — only needed to *fetch* real market data (`fetch_real_nse.py`).
    The terminal itself never calls out to the internet.
- A modern browser (Chrome/Edge/Firefox). No CDN or internet needed at runtime — the entire
  UI is a single self-contained HTML file with inline CSS/JS.

---

## Installation

### Windows (recommended for daily use)
1. Install Python from [python.org](https://python.org) — tick **"Add to PATH"**.
2. Extract the project folder.
3. Double-click **`RUN_WINDOWS.bat`**. It installs dependencies and opens the terminal.

### Manual (any OS)
```bash
cd quantai-app
python -m pip install -r requirements.txt
python app.py
```

---

## Running the terminal

```bash
python app.py
```

- **Default bind: `127.0.0.1:8000` (localhost only).** Open `http://127.0.0.1:8000`.
- To use a different port: `QUANTAI_PORT=8080 python app.py`
- The Arena live preview sets `QUANTAI_HOST=0.0.0.0` explicitly. **On your own PC, leave
  `QUANTAI_HOST` unset** so the terminal is not exposed to your network.

All state persists in `data_store/` (datasets, models, research runs, settings, journal).
Restarting the server restores everything; **paper replay never auto-resumes** after a restart.

---

## Importing real market data

1. Go to **Data Import**.
2. Choose a `.csv` file (max 64 MB). Required columns:
   ```
   timestamp,open,high,low,close,volume
   2015-01-01 00:00:00,745.00,752.30,743.10,750.85,3254100
   ```
3. Set **Symbol** (e.g. `RELIANCE`, `NIFTY50`, `M&M`), **Timeframe** (`1D`/`15m`/`5m`/`1m`),
   **Data origin**, **Adjustment policy**, and **Market calendar**.
4. Click **Preview & validate** to inspect the quality report and first/last rows *before*
   committing. Then **Confirm import**. (Or **Import directly** to skip preview.)

### Fetching real NSE data from Yahoo Finance

`fetch_real_nse.py` downloads real market history for the Indian market and writes it
straight into `uploads/` in the exact format the terminal expects.

```bash
pip install -r requirements.txt          # includes yfinance
python3 fetch_real_nse.py                 # ~10 s, writes 6 CSVs + an audit file
```

| File | Yahoo symbol | Timeframe | Range |
|------|--------------|-----------|-------|
| `uploads/RELIANCE_1D.csv`  | `RELIANCE.NS`  | 1D  | 2016-01-01 → today |
| `uploads/TCS_1D.csv`       | `TCS.NS`       | 1D  | 2016-01-01 → today |
| `uploads/HDFCBANK_1D.csv`  | `HDFCBANK.NS`  | 1D  | 2016-01-01 → today |
| `uploads/INFY_1D.csv`      | `INFY.NS`      | 1D  | 2016-01-01 → today |
| `uploads/NIFTY50_1D.csv`   | `^NSEI`        | 1D  | 2016-01-01 → today |
| `uploads/RELIANCE_15m.csv` | `RELIANCE.NS`  | 15m | last 60 days, 09:15–15:15 IST, weekdays only |

Every file has exactly the columns `timestamp,open,high,low,close,volume`, no NaNs,
integer volume, and clean OHLC relationships. Daily timestamps are stamped
`YYYY-MM-DD 00:00:00`; intraday timestamps keep their real bar time (`YYYY-MM-DD HH:MM:SS` IST)
so the bars of a day do not collapse onto one row.

What the script does *not* hide:

* `auto_adjust=True` — OHLC is split- and dividend-adjusted, so a bonus issue does not
  look like a 50 % crash.
* **Weekend bars are dropped.** Yahoo emits a handful of Saturday/Sunday bars for NSE
  symbols whose open is exactly the previous Friday's close; the hourly feed shows no
  trading hours on those dates, only a zero-volume closing mark. The NSE cash segment
  trades Monday to Friday, so those rows are not regular sessions. Every dropped bar is
  written to `uploads/AUDIT_dropped_weekend_rows.csv` with the reason attached —
  nothing is discarded silently.
* The script prints a summary table with row counts and date ranges and re-checks every
  invariant before it exits.

### Market calendar (NSE holidays)

The quality layer counts a missing trading session as a defect. For an Indian market that
is wrong: the NSE is shut on ~12–15 public holidays a year, so a *complete* NSE history
still shows ~155 missing weekdays between 2016 and 2026.

`quantai/nse_holidays.py` holds the calendar. The dates were derived from the Yahoo
`^NSEI` series (a day with no index bar is a day the whole market was shut) and then
reconciled against the published NSE holiday lists for 2016–2025 — every date matches.
The same derivation was cross-checked against the four equity series: every weekday
missing from an equity series is also missing from the index, so the fetched history has
**no stock-specific holes**.

Pick **Market calendar → NSE (India)** in the import form and those holidays are
reported as holidays instead of missing sessions. A calendar only ever *explains* a gap —
it never creates, fills or alters a bar, and a genuine hole is still reported.

### Data validation rules
- **Timestamps:** ISO, `dd-MMM-yyyy`, epoch seconds/millis. Naive timestamps are interpreted as
  **IST**; explicit `Z`/offsets are converted to IST. Intraday bars must align to the timeframe
  grid inside 09:15–15:30.
- **OHLC:** zero/negative prices, invalid high/low relationships → rejected (never repaired).
- **Volume:** negative or fractional volume → rejected. Zero-volume and abnormal volume
  → **flagged as warnings**, not silently dropped.
- **Duplicates:** ambiguous duplicate timestamps are dropped entirely (never guessed).
- **Gaps:** missing bars on non-holiday sessions are counted; holiday/weekend skips separated.
- **Corporate actions:** overnight price discontinuities ≥8% are detected and reviewed (see below).
- **Provenance:** every dataset gets a SHA-256 hash and a dataset id. Imported CSV is labelled
  `IMPORTED_CSV_UNVERIFIED`. **The API refuses to label uploaded bytes as verified exchange data.**
  Synthetic/demo data is labelled `TEST_FIXTURE` / `SIMULATED` and can never be treated as real.

### Dataset quality report

`quantai/quality.py` produces a full report at import time. It is shown on the **Data Import**
tab (before *and* after import) and returned by `GET /api/dataset/quality`.

**1. Corporate actions & price discontinuities**
Every overnight gap of ≥8% is reported with its date, size, implied ratio, confidence and the
evidence behind the reading. A discontinuity is called *suspected split/bonus* only when the gap
matches a canonical ratio (1:2, 1:3, 1:5, 1:10, 1:1.25 …) **and** the new price level held
through the close.

> ⚠️ **Price data alone cannot separate a corporate action from a market move of the same size.**
> A genuine −50% crash is mathematically identical to a 1:2 split. Every event carries that
> caveat and must be checked against the exchange corporate-action register. **Prices are never
> adjusted by the app** — it reports, you decide.

The file's declared **adjustment policy** is cross-checked against its content: a file that claims
`SPLIT_AND_BONUS_ADJUSTED` but still contains suspected events raises a serious issue.

**2. Missing bars & holiday gaps**
Missing *sessions*, holiday skips, holes *inside* an intraday session and sessions that start after
the 09:15 open are reported separately, each with the dates involved. The headline
`missing_bars` / `holiday_or_weekend_skips` numbers use the original arithmetic, so previously
saved datasets stay comparable.

**3. Volume anomalies**
The original ratio rule (>8× or <1/8× the trailing 20-bar median) is kept, and two z-scores are
added on top:

- **robust z-score** — `0.6745 × (v − rolling median) / rolling MAD`, and
- **log-space z-score** — the classic z-score on `log(volume)`.

A bar is abnormal when the ratio test *or* either z-score fires (|robust z| ≥ 6, |log z| ≥ 4).
The z-scores catch spikes that the ratio rule misses — e.g. a 5× spike in a series whose typical
volume never doubles. When the trailing MAD collapses to zero (a perfectly flat volume series) the
scale falls back to the mean absolute deviation, so a spike in flat data is still caught.

**4. Dataset quality score (0–100)**
Five transparent components, each shown with its points and a plain-English detail:

| Component | Weight | What it measures |
|---|---|---|
| Row integrity | 20 | rows kept vs rows read; duplicate penalty |
| Continuity & coverage | 25 | bars present vs bars expected over the observed range |
| Volume sanity | 15 | abnormal + zero-volume bars |
| Price consistency | 20 | detected corporate actions / price discontinuities |
| History sufficiency | 20 | bars vs the research-grade requirement |

Serious issues subtract a **severity penalty** (HIGH −12, MEDIUM −6, LOW −2) and also **cap the
grade**: a HIGH issue can never score above C, a MEDIUM issue never above B. A file with a
detected split is therefore never graded "clean".

> The score describes **the file**, not the market. It says nothing about market authenticity,
> profitability or edge. For a `TEST_FIXTURE` the report says so explicitly.

**5. Import-time warnings**
Serious issues are listed in the import report, repeated in the `warnings` array, surfaced as a
red banner in the **Preview** card *before* you confirm, and the import confirmation message
switches from green to amber when any exist.

### NIFTY 50 benchmark
Import a NIFTY 50 dataset with symbol `NIFTY50` (matching timeframe). Research will then compute
a buy-and-hold benchmark over the exact test window. **If no NIFTY data is imported, the report
says "missing" — it never fabricates benchmark numbers.**

### Dataset management
- **Loaded datasets:** select, export (CSV), delete.
- **Import history:** every import is recorded with timestamp, source, and verification status.
- **Dataset viewer:** inspect head/tail rows of any loaded dataset.
- Deleting a dataset invalidates any model bound to it.

---

## Candlestick charts & technical analysis

Open the **Charts & TA** tab. Everything on this tab is computed from the **actual imported
candles of the selected dataset** — nothing is interpolated, synthesised or estimated.

### Chart controls
| Control | What it does |
|---|---|
| **Symbol** | Every imported symbol. Picking one repopulates the timeframe list with **only the timeframes that actually exist for that symbol** — no empty dropdowns. |
| **Timeframe** | The timeframes loaded for the selected symbol (`1D`, `15m`, `5m`, `1m`). Switching timeframe reloads the chart for the **same symbol** in one click. |
| **Same symbol, other timeframes** | A compact comparison table of every timeframe of the current symbol (close, trend, momentum, RSI, bullish/bearish reading counts, nearby S/R). **Click any row to switch the chart to that timeframe.** It is a comparison table, not a second chart. |
| **Remembered view** | The last symbol + timeframe you looked at is remembered in the browser **and** on the server, so reopening the terminal (or reloading the page) lands you back on the same chart. |
| **Jump to date** | Moves the view to a specific candle and recomputes the technical readings **as of that candle**. |
| **Visible range** | Slider for the number of candles shown (20–400). |
| **Mouse wheel** | Zoom in/out around the cursor. |
| **Drag** | Pan left/right. |
| **Hover** | Crosshair + tooltip with Open, High, Low, Close, Volume, change % and every enabled indicator reading at that bar. |
| **Click a candle** | Selects that date — the view truncates there and all readings/patterns/levels are recomputed using **no candle after that point**. |
| **Reset zoom** | Returns to the full latest view. |

### Chart layout
1. **Price panel** — candles (green up / red down), EMA/SMA/Bollinger/VWAP overlays, S/R zone bands,
   pattern markers (▲ below for bullish, ▼ above for bearish), last-price line, indicator legend.
2. **Volume panel** — separate bar panel below the price chart, coloured by candle direction.
   Zero-volume bars are dimmed (possible stale/placeholder candles).
3. **RSI(14) panel** — with the 30 / 70 guide lines.
4. **MACD(12,26,9) panel** — histogram + MACD line + signal line.

### Indicators
| Indicator | Convention used |
|---|---|
| EMA 9 / 20 / 50 / 200 | SMA-seeded recursive EMA, α = 2/(p+1) |
| SMA 20 / 50 / 200 | simple rolling mean |
| RSI(14) | Wilder smoothing, SMA-seeded; first valid value at bar 14 |
| MACD(12,26,9) | EMA12 − EMA26, signal = EMA9 of the MACD line |
| Bollinger(20,2) | SMA ± 2 × population std (ddof = 0), plus %B and bandwidth |
| ATR(14) | Wilder smoothing of True Range |
| VWAP | **Only for intraday** with positive volume — session-anchored (IST trading date). Always `N/A` for `1D`. |

Every indicator can be switched on and off individually. **Warm-up bars stay blank — they are
never back-filled.** Every value at bar *i* uses only bars 0…*i*: there is no centred window
and no future bar anywhere in the calculation.

### Candlestick patterns
Doji · Hammer · Inverted Hammer · Shooting Star · Bullish Engulfing · Bearish Engulfing ·
Morning Star · Evening Star · Marubozu.

Each detection shows the **candle timestamp**, the pattern name, a directional bias, a
**strength label** and a plain-language explanation of what the shape shows.

#### Pattern strength — `weak` / `medium` / `strong`
Every detected pattern is scored from **two observable things**, never from a forecast:

| Component | How it is measured | Points |
|---|---|---|
| **Volume** | The pattern bar's volume ÷ the mean volume of the **bars before it** (20-bar window, the pattern bar excluded). `≥ 1.5×` = heavy (2), `≥ 1.0×` = normal (1), below = light (0). | 0–2 |
| **Location** | Where the pattern bar sat inside the recent 20-bar range **relative to the direction it implies**: a bullish pattern's low in the bottom quarter of the range (2), lower half (1), upper half (0); a bearish pattern's high in the top quarter (2), upper half (1), lower half (0). A neutral pattern (doji) is scored on **exhaustion** — indecision right after a ≥ 1.5 ATR move (2), after a ≥ 0.75 ATR move (1), otherwise (0). | 0–2 |

The two are added into a **0–4 score** and banded: **0–1 = weak, 2 = medium, 3–4 = strong**.
Both components use only bars up to and including the pattern bar, so the score is causal like
the pattern itself — rewriting future volume cannot change an earlier pattern's score.

> ⚠️ **A candlestick pattern is an observation, not a guaranteed buy or sell signal.**
> The same shape means different things in different contexts, and every pattern in this app
> carries that warning in its own output. The app never converts a pattern into an order.
> The strength label describes **the quality of the pattern itself** (was it backed by volume,
> did it appear where it should). It is **not** a probability of success and carries no
> expected return.

### Support & resistance
Levels come from **fractal swing pivots** (a pivot high/low is the extreme of a ±5-bar window),
clustered by price into zones with a tolerance derived from ATR.

- A pivot is only **confirmed** once the right-hand bars exist — the confirmation bar is
  always *pivot bar + 5*. A historical level therefore **never uses a future candle**.
- **Confirmed historical levels** are drawn as solid bands and listed separately.
- **Developing levels** are the most recent unconfirmed swings, drawn as dashed bands and
  labelled `(dev)` so they are never confused with settled structure.
- Each zone reports its price band, mid, pivot touches and last reaction bar.

#### Click a zone for its strength detail
Clicking a zone — **the row in the table** or **the band on the chart** — opens a detail card
with the numbers that decide how strong the zone actually is:

| Field | Meaning |
|---|---|
| **Price touches** | How many bars reached into the zone band. |
| **Reactions** | How many of those touches were followed by price moving **away** from the zone by at least 0.5 ATR within the next 5 bars. |
| **Reaction rate** | Reactions ÷ touches, shown as a bar. |
| **Typical reaction** | The direction price usually moved away (bullish for a support band, bearish for a resistance band). |
| **Touch & reaction history** | Every recorded touch with its bar, timestamp, whether it reacted, the reaction bar and price, and the resulting move. The most recent 40 touches are listed; the counts always cover **all** touches. |
| **Strength label** | `strong` (reaction rate ≥ 70% and ≥ 3 touches) · `moderate` (≥ 45%) · `weak` (≥ 25%) · `failed` (price kept reaching it and went straight through) · `untested` / `unrated`. |

> A zone with many touches but a **low reaction rate** is a level price kept reaching
> **through** — that is a weakness, not a strength, and the label says so.
> Touch and reaction history is descriptive of what happened in the past. It does not
> predict what happens next time.

### Technical analysis summary
A separate panel shows, as **individual readings**:

- current **trend** (UPTREND / DOWNTREND / MIXED / INSUFFICIENT_DATA) with the reason
- **momentum** (BULLISH / BEARISH / MIXED) and the 5-bar return
- **RSI condition** (OVERBOUGHT / OVERSOLD / NEUTRAL / WARM_UP) plus the 1-bar slope
- **MACD** line, signal, histogram, condition and any fresh cross
- **price vs EMA 20 / 50 / 200** — value, ABOVE/BELOW and distance %
- **Bollinger %B** and band position, **ATR 14**, **VWAP** vs price
- **nearby support and resistance** (with confirmed / developing status)
- **recently detected patterns**

#### Confluence — how many indicators agree
The summary ends with a **Confluence** section: a **count** of how many indicator readings
currently point the same way, so you can see at a glance whether the readings are telling a
consistent story or contradicting each other.

- **Pointing up** — EMA alignment (close > EMA20 > EMA50), price vs EMA 20 / 50 / 200, MACD
  histogram sign, MACD line vs signal line, RSI vs 50, RSI slope, Bollinger %B vs the middle
  band, price vs VWAP, the 5-bar return, and a fresh MACD cross.
- **Pointing down** — the same readings with the opposite sign.
- **Neutral / not yet available** — readings that are genuinely flat, or still inside their
  warm-up period (never back-filled).
- The section shows the **bullish count, bearish count, neutral count, total readings** and
  the **agreement percentage**, plus the plain list of which reading produced each vote.

> ⚠️ **Confluence is a count, never a BUY/SELL signal.**
> It says the indicators currently agree (or do not). It is **not** a forecast, it is **not**
> a probability of success, and a high agreement count does not mean the trade will work —
> indicators can agree and still be wrong. The wording of every reading is deliberately
> neutral (no "buy", "sell", "enter" or "exit"), and the panel prints that disclaimer itself.

> The panel deliberately has **no unexplained BUY/SELL verdict**. It reports what each
> indicator reads and lets you decide. The disclaimer is shown inside the panel.

### Data integrity on this tab
- Only **actual imported candles** are drawn. No candle or price is ever fabricated.
- Missing bars are **counted and reported**, never interpolated or filled.
- Zero-volume bars are flagged in the data-integrity panel and dimmed on the chart.
- Datasets that are not real market data (TEST_FIXTURE / SIMULATED) are clearly labelled
  *"NOT REAL MARKET DATA"* in the header and the integrity panel.
- Selecting a past date **truncates** the payload server-side, so a historical view can never
  display or use a future candle.
- Exports (`/api/chart/export`) contain exactly what the chart shows — candles, indicator
  series, patterns, zones and the summary.

---

## Running research

1. Import a dataset first.
2. Go to **Research**, set **Forward horizon** (1–60 bars) and **Entry threshold** (0–1).
3. Click **Run research**. Training runs in a background thread; the UI polls for completion.

### What you get
- **Train / Validation / Unseen-test** classification metrics, reported separately:
  accuracy, macro F1, log loss, Brier, confusion matrix, per-class precision/recall/F1.
- **Baselines:** majority-class and momentum. The model must beat the better baseline.
- **Purged chronological split:** 60/20/20 with a `horizon`-bar purge gap at both boundaries
  so labels cannot leak across splits.
- **Walk-forward:** 4 expanding, purged, out-of-sample folds.
- **Overfit diagnostics:** train→test gap, validation→test gap, walk-forward consistency,
  class imbalance, baseline comparison → a reliability rating (OK / MEDIUM / LOW) with flags.
- **5-way backtest** on the same unseen window: Ensemble, Rules-only, **Indicators**, ML-only,
  Buy & hold. Every strategy is evaluated on the **same purged chronological split and the same
  unseen test window**, with identical costs and execution rules — the comparison is
  apples-to-apples, and the indicator strategy never sees the ML model.
- **NIFTY 50 benchmark** comparison (if imported).
- **Feature importance** and **model versioning** (model id, random seed, library versions,
  training config — all saved for reproducibility).
- **Probability calibration** (temperature scaling fitted on the validation split only),
  reporting Brier / ECE / log-loss before and after on both validation and the unseen test
  split, the fitted temperature, and an explicit check that the per-row arg-max — and
  therefore the predicted class — did not change.
- **Feature-importance stability** across several random seeds (mean/std importance, rank
  standard deviation, rank correlation, top-5 frequency, stability score) and per-fold
  **walk-forward importance** aggregated across the expanding folds.
- **Verdict:**
  - `PLUMBING_ONLY` — synthetic/test data; no market conclusion possible.
  - `NO_EDGE` — failed one or more gates (baselines, after-cost profit, trade count, overfit,
    buy & hold, benchmark).
  - `CANDIDATE` — passed the gates **on this window only**. **Not proof of profitability.**
    Requires multi-symbol, multi-period, and paper-trading confirmation.

> ⚠️ **Accuracy alone is never treated as an edge.** A high-accuracy model that loses money
> after costs, or that fails to beat buy & hold, gets `NO_EDGE`.

---

## Advanced research

All advanced analyses run on the **same** out-of-sample window, cost model and risk engine as
single-symbol research. Results are persisted (`data_store/analyses/<kind>/`) and exportable from
the **Reports** tab. None of them fabricate performance: on synthetic or edge-less data they
correctly report losses, fragility and untested regimes.

### Multi-symbol portfolio (Portfolio tab)
Select 2–8 imported symbols (same timeframe). Each symbol runs the chosen strategy as an
**independent capital sleeve**; capital is split up-front and the sleeve equity curves are summed
on a common timestamp clock.
- **Allocation:** equal weight, or inverse pre-test volatility (weights use only data before the
  test window — no look-ahead). A per-symbol concentration cap clips and redistributes weights.
- **Outputs:** combined equity curve, portfolio drawdown, Sharpe/Sortino/profit factor, allocation
  table, Herfindahl concentration index + effective-N, and a pairwise return-correlation matrix.
- **Limits enforced:** per-symbol weight cap and a portfolio exposure cap passed to every sleeve.
- **Model boundary:** this is *not* a shared-margin intraday book with cross-symbol netting or
  shared-cash contention. It is a sum of independently funded sleeves (documented limitation).

### Parameter sensitivity (Sensitivity tab)
Sweeps entry threshold × stop-ATR × target-ATR (up to 200 combinations) on the active symbol.
Reports the fraction of profitable combinations, return dispersion, and how the best point's
**immediate neighbours** perform. Verdict:
- **STABLE** — profitable across a broad neighbourhood (necessary, not sufficient, for robustness).
- **MIXED** — results depend materially on parameters.
- **FRAGILE** — profit only at isolated points → overfit signature, not a deployable edge.

### Market regimes (Regimes tab)
Causal labelling from a slow EMA, its slope and price position (no centred windows, no future
bars): **BULLISH / BEARISH / SIDEWAYS**. Trades and mark-to-market bar returns are bucketed by the
regime at entry. Flags regimes where the strategy loses or never traded, so you never assume one
strategy works in all conditions.

### Monte Carlo (Monte Carlo tab)
Resamples your **actual realised trade P&Ls** (from a research backtest or the paper journal):
- **IID** bootstrap (independent draws) or **moving-block** bootstrap (preserves winning/losing
  streaks). Seeded for reproducibility.
- Reports percentile distributions of final equity, return, max drawdown and longest losing
  streak, plus P(final loss) and P(drawdown ≥ threshold).
- Requires ≥ 10 trades; with fewer it refuses and says so. **It is a distribution of the existing
  trade sample, not a prediction** — it cannot model regime shifts, slippage drift or capacity.

### Authorized data feeds & updates (Data Import tab)
- Register an **HTTPS CSV endpoint you are authorized to use** (broker/vendor export, licensed API,
  your own hosting) with a required license/authorization note. Fetches are **SSRF-guarded**:
  https only, public unicast IPs only, redirects re-validated, 64 MB / 30 s caps. Loopback,
  private, link-local and cloud-metadata addresses are blocked.
- Downloaded data is labelled `DATA_FEED` / `DATA_FEED_UNVERIFIED` with `feed_url`, `retrieved_at`
  and `license_note`. Authorization is **your assertion**; content is not independently verified.
- **Append-only updates:** only strictly-newer bars are added; conflicting overlaps are rejected
  (history is never silently overwritten); gaps are reported, **never filled or interpolated**.
- Provenance is always distinct: `MANUAL_IMPORT` (uploaded CSV), `AUTHORIZED_FEED` (downloaded),
  `SYNTHETIC` (demo/test fixture). The app never scrapes exchanges or bypasses restrictions.

---

## Paper trading (replay)

1. Go to **Paper Replay**.
2. Set speed, start window (unseen test window or from bar 35), strategy, and entry threshold.
3. Click **Start**. Bars replay one at a time using the **same execution and risk rules** as the
   backtest.

The **strategy** selector offers `Ensemble (rules + ML)`, `Rules only`,
**`Indicators (EMA/RSI/MACD/BB)`** and `ML only`. The indicator mode replays the pure
technical-indicator long-bias score — the same score the Research tab backtests on the unseen
window — so a paper run and a backtest stay comparable. The Research tab's "Strategy for paper
replay" selector pre-selects the mode used by the next replay.

This is a **historical simulation, not a live feed.** No orders reach any broker. Every closed
trade is written to the persistent [Journal](#trading-journal).

Execution contract (cannot be disabled):
- Signal at bar `t` close → entry at bar `t+1` **open** + slippage.
- Gap beyond stop → fills at the **open** (worse price), not the stop.
- Stop & target in the same bar → **stop assumed first** (conservative).
- Equity marked-to-market every bar; drawdown includes unrealized loss.
- Intraday positions squared off the same session; no entry that would fill next session.
- Total-drawdown breach → squares off and **halts all trading**.

---

## Trading journal

The **Journal** tab records every closed paper-replay trade:
- Entry/exit price and date/time, direction, quantity
- Stop-loss and target
- Profit/loss and costs
- Entry and exit reason, strategy used
- **Editable trade notes** (persisted)
- **Tags** — free-text, normalised, multi-tag
- **Emotional state** — `Calm` / `FOMO` / `Revenge` / `Neutral` (or left unrecorded)

### Tags

A tag is a short, lower-cased, hyphenated label: `breakout`, `mean-reversion`, `news`,
`gap`, `mistake`, `revenge-trade`, `fomo-trade`, `overtrade`, `late-entry`, `followed-plan`,
`patient`, `a-plus-setup`, `b-grade-setup`, `scalp`, `swing`, `held-through-loss`,
`cut-early`. The list is only a **suggestion** — any custom tag works, and the UI offers the
vocabulary as one-click chips.

Tags are normalised on the way in: `Mean Reversion` becomes `mean-reversion`, `Breakout` and
`breakout` are the same tag, blanks are dropped, and at most 8 tags of 32 characters each are
kept per trade. Editing the tags never touches your notes, and editing the notes never touches
the tags — the three annotations are written independently.

A **bulk tag** action applies one tag to every trade matching the current filters (symbol,
strategy), in `add`, `remove` or `replace` mode.

### Emotional state

The emotional state is recorded next to the notes, on purpose. The point is to spot the
**pattern** — "my revenge trades lose, my calm ones don't" — not to judge yourself. The journal
breaks the numbers down by emotional state so that pattern is visible.

### Breakdowns

The journal summary now shows the same trades split four ways:

| Breakdown | What it answers |
|---|---|
| **Strategy** | which strategy actually made money, on the same trades and the same costs |
| **Emotional state** | which emotional state the losing trades were taken in |
| **Tag** | which setup is working (`breakout`) and which is bleeding (`mistake`) |
| **Symbol** | which instrument the money is made in |

Each row shows trades, W/L, win rate, net P&L, profit factor, average P&L, expectancy and
costs. **Daily / weekly / monthly** period summaries sit underneath, unchanged.

Two honesty rules are enforced in the data, not just in the wording:
- A profit factor is shown as `—` when there is no losing trade yet. It is *undefined*, not 0 and
  not 1.
- The tag rows deliberately **do not add up** to the journal total, because a trade carrying
  three tags is counted once per tag. The UI says so.

### Exports

Every export carries the new fields:

| Export | Contains |
|---|---|
| `Paper journal (CSV)` | every trade **including `tags` and `emotion`** |
| `Export journal summary (CSV)` | the daily/weekly/monthly buckets |
| `Export journal breakdown (CSV)` | the strategy / emotion / tag / symbol breakdown |

---

## Live paper-replay performance

While a replay is running, the **Live performance** card tracks the strategy as it trades, not
only after it finishes:

| Live metric | Where it comes from |
|---|---|
| Running win rate | closed trades only — never the open position |
| Profit factor | gross profit ÷ gross loss, updated on every exit |
| Expectancy per trade | net P&L ÷ closed trades |
| Average win / average loss / payoff ratio | from the closed trades |
| Max drawdown | the stricter of the intrabar worst-low and the close-to-close curve |
| Current & longest win/loss streaks | updated on every exit; a breakeven breaks the streak |
| Best / worst trade | from the closed trades |
| Cost drag | total costs of both legs, as a % of capital |

Every number is derived from **realised fills**. Before the first trade closes, the card says so
and shows `—` rather than a fake `0.0%` or a fake profit factor of `1.00`. The unrealised P&L of
an open position is shown separately from the realised P&L, so the win rate never counts a trade
that has not closed yet.

---

## Risk & safety

All limits are **enforced by the backend**, not just the frontend:

| Limit | Default | Range | Enforced in |
|---|---|---|---|
| Risk per trade | 0.5% | 0.05–2% | backtest + replay |
| Max daily drawdown | 2% | 0.5–10% | backtest + replay |
| **Max weekly drawdown** | **5%** | **1–15%** | backtest + replay |
| **Max total drawdown (halt)** | 15% | 2–50% | backtest + replay |
| Max portfolio exposure | 50% | 5–100% | backtest + replay |
| Max open positions | 1 | 1–5 | backtest + replay |
| Consecutive losses → cooldown | 3 | 1–20 | backtest + replay |
| Cooldown band 1 | 15 bars | 1–500 | backtest + replay |
| **Cooldown band 2** | **30 bars** | **1–500** | backtest + replay |
| **Cooldown band 3** | **50 bars** | **1–500** | backtest + replay |
| Progressive cooldown | ON | on / off | backtest + replay |
| Volatility-adjusted risk | **OFF** | on / off | backtest + replay |
| Normal volatility (ATR % of price) | 2.0% | 0.05–25 | backtest + replay |
| Volatility factor clamp | 0.25× – 2.0× | 0.05–5 | backtest + replay |
| Stop-loss ATR multiple | 1.8 | 0.5–10 | backtest + replay |
| Target ATR multiple | 3.6 | 0.5–20 | backtest + replay |

Every one of these is clamped **in the backend**, on the way in *and* on the way out: a value
outside the range is clipped by the server, and a hand-edited `settings.json` is re-clamped
when it is loaded. The range sliders in the UI are a convenience, never the enforcement.

### The three drawdown limits are different

| Limit | Measured from | When breached |
|---|---|---|
| Daily | the equity at the start of the day | new entries blocked until the next day |
| **Weekly** | the equity at the start of the ISO week | new entries blocked until the next ISO week |
| Total | the running peak | the position is squared off and **all trading halts** |

The weekly limit uses **ISO weeks** (Monday to Sunday), which is what a trading week means.
Its range is **1%–15%** — a bigger weekly number would stop being a weekly limit and start
being the total-drawdown limit under a different name.

A weekly breach does **not** halt the engine — it blocks new entries for the rest of that
week, exactly like the daily limit. Only the total-drawdown breach stops everything.

**What you see when the weekly limit is breached.** The first breach of an ISO week produces
a clear message, everywhere at once:

- a red **"⛔ TRADING HALTED FOR THE WEEK"** banner in the Risk tab, with the actual drawdown,
  the limit and the ISO week;
- the same reason in the **risk engine state** card, plus a table of every weekly breach in
  that run;
- a line in the engine log;
- a `weekly_loss_limit_breached` **journal event** — so the reason is on the record and
  survives a restart;
- a counter of how many signals the block actually rejected.

The message says what happens next: *new entries are blocked until the next ISO week; open
positions are still managed*. The block lifts automatically at the start of the next ISO week,
and the weekly limit is measured again from that week's starting equity.

### Progressive cooldown

A fixed cooldown treats the 3rd loss and the 9th loss the same. The progressive cooldown
lengthens with the streak in three **bands**, anchored on the configured threshold:

| Consecutive losses | Band | Cooldown (defaults) |
|---|---|---|
| 0–2 | below the threshold | no cooldown |
| 3–4 | band 1 | **15 bars** |
| 5–6 | band 2 | **30 bars** |
| 7 and above | band 3 | **50 bars** |

**Band 3 is flat on purpose.** The cooldown stops growing once the streak reaches
`threshold + 4` losses. An earlier version multiplied the base cooldown for every extra two
losses, which meant a 20-loss streak locked the engine out for 165 bars — long enough to
change what a backtest measures, and long enough for the operator to lose trust in the tool.
A losing streak ends because the **total-drawdown circuit breaker** ends it, not because the
cooldown silently grows without limit.

All three band lengths are **configurable** in the Risk tab (band 1, band 2, band 3) and the
backend refuses a set that shrinks as the streak grows — band 2 can never be shorter than
band 1, and band 3 can never be shorter than band 2. Switch progressive cooldown off to get
the old flat behaviour back.

Every cooldown the engine actually applied is recorded and shown in the Paper Replay tab, with
the bar it started on, the streak length at the time and how long it lasted.

### Volatility-adjusted risk per trade

Sizing by ATR already keeps the **rupee** risk at the stop constant: a bigger stop means a
smaller position. What it does **not** do is change how much of your **capital** you risk. A
volatile instrument therefore gets traded with exactly the same rupee risk as a calm one —
which is precisely when stops get hit by noise.

With the option switched on, the risk is scaled by how far the current ATR% is from the
target ATR%:

```
factor   = clamp(target_atr_pct ÷ measured_atr_pct, min_factor, max_factor)
risk_pct = base_risk_pct × factor
```

With the default target of 2% ATR:

| Current ATR | Factor | Risk per trade (base 0.5%) |
|---|---|---|
| 1% (calm) | 2.00× (capped) | 1.00% |
| 2% (target) | 1.00× | 0.50% |
| 4% (volatile) | 0.50× | 0.25% |
| 8% (very volatile) | 0.25× (capped) | 0.125% |

The option is **off by default**, so an existing research run keeps its sizing until you turn
it on. Every trade records the risk percentage it actually used, the ATR% that produced it and
the factor applied.

> ⚠️ **When you switch it on, the Risk tab shows a warning banner.** Two consequences you have
> to accept: the risk numbers in an **older report were produced with a fixed risk per trade**
> and are **not comparable** with a new one, and the position size now changes bar to bar.
> The engine never risks more than `base × max_factor` and never less than
> `base × min_factor`. This does **not** forecast volatility — it only reacts to the
> volatility that has already happened.

### Changing the limits with an open paper position

If a paper position is open, the backend **refuses** the change and answers `409` with the
details of the open position (quantity, entry, stop, target, unrealised P&L) and the exact list
of limits that would change. The UI shows that as a warning with **Apply anyway** and
**Cancel**.

This is a server-side refusal, not a frontend nicety: there is no way to change the limits
mid-trade without explicitly acknowledging it. The acknowledgement is written to the journal as
a `risk_settings_changed` event.

Note what the change does and does not do: it does **not** resize or re-stop the trade that is
already open — it changes every **future** entry.

### The kill switch and its reason

The kill switch instantly halts the replay, squares off any open position and blocks a restart
until it is released. The state persists across restarts.

You are asked **why** you are stopping. The reason is **optional**, but it is saved in **two**
places:

1. the **journal**, as a **risk event** — with the timestamp, the bar, the equity, the open
   position and the reason text:

   > "Revenge trading after 3 losses — stepping away for the day"

2. the **settings**, as `kill_reason` — so the terminal can tell you why it is halted
   **without** opening the journal, and the reason survives a restart of the whole terminal.

If you engage the kill switch **without** writing a reason, the app records the literal text
**"No reason provided"** rather than a blank. A blank would look like a lost record; an
explicit "no reason provided" is an honest record of what you did.

The reason is shown on the Dashboard next to the kill-switch status and in the Emergency
section of the Risk tab. If the kill switch squared off an open position, that trade's
`notes` carry the reason too, so the trade row itself explains why it was closed.

A kill switch is **not a trade**. It lives in its own `events` table, so the trade count, the
win rate and every journal breakdown stay exactly what they were. Risk events are listed in
the Journal tab and exported as `quantai_journal_events.csv`.

**Execution assumptions** (configurable): slippage (bps/fill), brokerage flat + % cap, and an
optional volume-participation cap. The fill *timing* contract is fixed and cannot be relaxed.

> The single-symbol engine holds at most one position at a time. `max_open_positions` is an
> enforced cap; values above 1 do not create multi-position behavior in this build (see
> [Known limitations](#known-limitations)).

---

## Performance metrics explained

Every strategy (and the paper replay) reports:

| Metric | Meaning |
|---|---|
| **Total Return (%)** | Net change in equity over the window, after costs. |
| **CAGR** | Calendar-time annualised growth. `N/A` if the window is <30 days (annualising a short window is misleading). |
| **Sharpe Ratio** | Annualised mean bar return ÷ std dev. `N/A` if <30 bars or <5 trades — never a fake 0.0. |
| **Sortino Ratio** | Like Sharpe but penalises only downside volatility. Uses the canonical all-bar downside deviation `sqrt(mean(min(r,0)²))`. |
| **Maximum Drawdown** | Largest peak-to-trough equity drop, including unrealized intrabar lows. |
| **Win Rate** | % of closed trades with positive P&L. |
| **Profit Factor** | Gross profit ÷ gross loss. `N/A` when there are no trades. |
| **Avg Profit/Loss per Trade** | Average winning trade and average losing trade (₹). |
| **Risk-to-Reward Ratio** | Average win ÷ average loss. `N/A` if no losing trades. |
| **Total Trades** | Number of closed round-trips. |
| **Consecutive Wins/Losses** | Longest winning and losing streaks. |

Metrics that are statistically meaningless on short windows return **`N/A` with a reason**,
not a misleading number.

---

## Reports & export

### Downloading the project
The **Reports & export** tab has a **Download the project** card with the complete source of the
terminal and of the standalone research kit, as ready-to-run ZIP archives:

| File | What it is |
|---|---|
| `quantai-app.zip` | The whole web app. Unzip, `pip install -r requirements.txt`, then `python app.py`. |
| `quantai-research.zip` | The standalone research kit (`run_research.py`). |
| `README.md` | This documentation. |

They are served from `/download/<name>` (with a manifest at `/api/downloads`) and carry an
`attachment` disposition, so a browser saves them directly. The route serves **only** these
three names from a fixed allow-list — the URL never contributes a path, so it cannot be used
to read arbitrary files. The archives contain **no market data, no models and no personal
settings**: `data_store/`, `__pycache__/` and the test caches are excluded at build time.

---

## Reports & export

The **Reports** tab exports everything as CSV/JSON generated from actual stored results:
- Research results (JSON)
- Backtest summary (CSV)
- Performance metrics (CSV)
- Backtest trade history by mode (CSV)
- Paper journal (CSV) — includes the `tags` and `emotion` columns
- Journal summary by period (CSV)
- Journal breakdown by strategy / emotional state / tag / symbol (CSV)
- Active dataset quality report (JSON)
- Active dataset candles (CSV)
- Portfolio sleeves / sensitivity grid / regime performance / Monte Carlo percentiles (CSV)
- **Chart analysis (JSON)** — the imported candles, every indicator series, detected patterns,
  support/resistance zones and the technical summary for the active dataset

Research run history and a model registry (id, dataset, seed, test accuracy, verdict, library
versions) are also shown.

---

## Architecture

```
quantai-app/
├── app.py              Flask server: security, routes, exports, app factory
├── engine.py           Backwards-compatible façade — re-exports the public API
├── state_manager.py    AppState core: init, persistence, data import, charting, feeds,
│                       snapshot + the single shared STATE singleton
├── research_orchestrator.py  Research training, verdict logic, portfolio / sensitivity /
│                       regime / Monte Carlo orchestration (ResearchOrchestratorMixin)
├── paper_replay.py     Historical bar-by-bar paper replay (PaperReplayMixin)
├── risk_engine.py      Kill switch, risk-limit clamping, execution settings (RiskEngineMixin)
├── storage.py          Durable, path-safe persistence (datasets/models/research/settings)
├── journal.py          SQLite trading journal + period summaries
├── static/index.html   Single-file UI (12 tabs, inline CSS/JS, no CDN)
├── quantai/            Audited research package
│   ├── config.py       Provenance enums, dated Indian cost model, risk/execution config
│   ├── data.py         Strict CSV validation + provenance + preview
│   ├── quality.py      Corporate actions, gap report, volume anomalies, 0-100 score
│   ├── data_sources.py Authorized feed registry, SSRF-guarded fetch, append-only merge
│   ├── features.py     8 causal features, forward labels, purged split
│   ├── indicators.py   Causal EMA/SMA/RSI/MACD/Bollinger/ATR/VWAP library + indicator score
│   ├── patterns.py     Candlestick pattern detection with explanations (never signals)
│   ├── levels.py       Causal fractal-pivot support/resistance zones
│   ├── charting.py     Chart payload assembly + technical analysis summary
│   ├── model.py        Random Forest, baselines, walk-forward, overfit diagnostics
│   ├── backtest.py     Event-driven long-only engine, 5 modes, risk halts
│   ├── metrics.py      Performance analytics (CAGR, Sharpe, Sortino, streaks, R:R)
│   ├── benchmark.py    NIFTY 50 comparison (never fabricated)
│   ├── portfolio.py    Multi-symbol sleeves, allocation, correlation, concentration
│   ├── sensitivity.py  Parameter grid + stability / overfit detection
│   ├── regime.py       Causal bull/bear/sideways labelling + per-regime performance
│   └── montecarlo.py   IID / block bootstrap of trade P&Ls, distributions, ruin probs
├── tests/              260 tests (16 original + 45 professional + 70 advanced + 78 charting
│                       + 14 module-structure + 8 frontend-structure + 29 data-quality)
├── make_fixture.py     Synthetic test-fixture generator (labelled NOT REAL)
├── requirements.txt
└── RUN_WINDOWS.bat
```

### Python module layout

`engine.py` used to be one ~1,400-line monolith. It is now split into four focused modules
plus a thin façade. **No behaviour changed** — all 44 original functions were moved verbatim
and an AST comparison confirmed zero raw and zero semantic body differences.

| Module | Responsibility |
|---|---|
| `state_manager.py` | `AppState` core — initialisation, persistence, data import, chart payloads, feed registry, snapshot. Owns the single `STATE` singleton. |
| `research_orchestrator.py` | `ResearchOrchestratorMixin` — research training, verdict logic, portfolio / sensitivity / regime / Monte Carlo orchestration. |
| `paper_replay.py` | `PaperReplayMixin` — historical bar-by-bar paper replay. |
| `risk_engine.py` | `RiskEngineMixin` — kill switch, risk-limit clamping, execution settings. |
| `engine.py` | Public façade. `from engine import AppState, STATE, …` still works unchanged, and it re-exports the **same** `STATE` object as `state_manager`. |

`AppState` is composed from the three mixins, so the MRO is
`AppState → RiskEngineMixin → PaperReplayMixin → ResearchOrchestratorMixin → object`.
`app.py` imports `STATE`, `DATA_DIR` and `LIVE_TRADING_ENABLED` directly from
`state_manager`. There are no import cycles and no duplicated methods.
`tests/test_module_structure.py` locks all of this in.

### Frontend layout

`static/index.html` is still **one** file — the JavaScript stays inline and **no separate
`.js` files are created**. The inline script is organised into 11 clearly commented logical
sections (a section map is printed at the top of the script):

1. Bootstrap & shared state · 2. Theme & tab navigation · 3. API & DOM helpers ·
4. Canvas primitives · 5. Render helpers · 6. Main renderer · 7. Advanced research
renderers · 8. Trading journal · 9. Charts & technical analysis · 10. Event handlers & API
actions · 11. Boot.

The code was moved **verbatim** — only banner comments were added. A static check proves no
temporal-dead-zone risk was introduced by the reordering, and `tests/test_frontend_sections.py`
guards that the script stays inline, stays sectioned and stays syntactically valid.

**Persistence layout** (`data_store/`): `datasets/<id>/`, `models/<id>/`, `research/<run>.json`,
`analyses/<kind>/<run>.json`, `journal.sqlite3`, `settings.json`, `registry.json`, `feeds.json`,
`logs/`. All writes are atomic; all on-disk ids are validated against strict patterns to prevent
path traversal.

---

## Testing

```bash
python -m pytest tests -q
```

**443 tests, all passing.** Coverage includes:
- Original 16 pipeline regression tests (preserved, none removed).
- Metrics: CAGR, drawdown, streaks, Sharpe/Sortino N/A rules, Sortino formula regression.
- Costs: exact delivery/intraday STT, GST, stamp, brokerage cap, both-leg charging.
- Risk: total-DD halt, max-open-positions, volume cap, cooldown, kill switch.
- Data validation: abnormal volume, preview, timezone/epoch handling, provenance.
- NSE holiday calendar: published dates present, a genuine gap still reported with the
  calendar on, candle count identical with/without it, preview→confirm round trip,
  unknown calendar rejected.
- Persistence: restart survival, path-traversal rejection, JSON safety, journal summaries.
- ML: seed reproducibility, label purging, look-ahead mutation guard, model/report saving.
- API security: extension/symbol/timeframe validation, preview→confirm, exports, clamping,
  benchmark honesty, live-disabled health check.
- **Portfolio:** hand-checked allocation/cap redistribution, HHI, equity alignment + capital
  conservation, correlation (perfect/inverse/insufficient), duplicate/single-symbol rejection.
- **Sensitivity:** grid coverage, neighbour logic, one grid point re-verified against a direct
  backtest, grid limit, determinism, random-walk-not-STABLE guard.
- **Regime:** trend/flat labelling, no-look-ahead prefix stability, hand-checked trade/return
  bucketing, untested-regime flags.
- **Monte Carlo:** closed-form degenerate cases (all-wins/all-losses), percentile ordering, seed
  reproducibility, block-preserves-streaks, insufficient-trade refusal, no fabricated output.
- **Data sources:** SSRF guard (loopback/private/metadata/credentials/redirects), fetch contract,
  append-only merge (conflict rejection, never fills gaps), provenance labels, engine integration.
- **Advanced API:** input validation, feed lifecycle, background workers end-to-end, exports,
  append-only update, honest insufficient/error reporting.
- **Indicators:** EMA against an independent SMA-seeded reference, SMA warm-up, RSI against
  Wilder's worked example plus all-gain/all-loss/flat edge cases, ATR true-range with a
  previous-close gap, MACD = EMA12−EMA26, Bollinger population std and undefined %B on a
  flat band, VWAP validity rules (daily ⇒ invalid, zero volume ⇒ invalid, session reset),
  warm-up is null and never back-filled, and a **look-ahead guard** that mutates future bars
  and proves every earlier indicator value is unchanged.
- **Patterns:** each of the 9 patterns fires on hand-built candles, Doji is suppressed when a
  more specific pattern fires, detections are bar-sorted, carry timestamp + explanation +
  the "not a guaranteed signal" note, and a **future-mutation guard** proves earlier
  detections never change.
- **Chart data:** payload shape, candles match the imported rows exactly, warm-up is null,
  missing bars are reported not interpolated, zero-volume bars flagged, historical views are
  **truncated** and stable under future-data mutation, confirmed vs developing levels are
  separated, nearby support/resistance sit on the correct side of price, and the summary
  panel exposes individual readings with **no BUY/SELL verdict key**.
- **Chart API:** symbol listing with real-vs-fixture labelling, as-of truncation, unknown-key
  and no-dataset errors, JSON export, intraday VWAP validity, indicator strategy running on
  the **same purged split** as ML/rules, and a **causality test** proving the indicator
  backtest's trades are unchanged when the dataset is truncated.
- **Risk engine completion** (`tests/test_risk_engine_completion.py`): the weekly limit's
  **1–15%** range clamped by the backend *and* on load from a tampered settings file, the
  weekly breach producing a clear message + a journal event + a rejected-signal count, the
  block lifting at the next ISO week, the three cooldown bands (**3 → 15 bars, 5 → 30 bars,
  7+ → 50 bars**) including their configurability and the "bands never shrink" rule, the
  volatility toggle being off by default and leaving the sizing byte-identical when off, and
  the kill-switch reason being saved to the journal **and** the settings, surviving a restart,
  defaulting to **"No reason provided"**.
- **Charts & TA features** (`tests/test_chart_ta_features.py`): symbol/timeframe grouping,
  the cross-timeframe comparison table, the remembered last view (including surviving a
  restart), zone touch/reaction counting and the strength label (a level that price keeps
  reaching *through* is labelled weak/failed, not strong), pattern strength labels with a
  **causality guard** (rewriting future volume cannot change an earlier pattern's score),
  and the Confluence counts — plus assertions that the confluence readings and the whole
  payload **never contain a buy/sell instruction**.
- **Chart JavaScript:** `tests/chart_js_harness.js` executes the real inline JS from
  `static/index.html` under a headless DOM shim with a recording canvas — it asserts that
  candles, volume bars, RSI, MACD, S/R zones, date labels and the indicator legend are
  actually drawn, that wheel-zoom shrinks the window, that the crosshair maps to the right
  bar, that toggling an indicator removes it, and that selecting a past date truncates the
  payload. It also drives the new Charts & TA behaviour end-to-end against the **live API**:
  switching the timeframe of the same symbol, the cross-timeframe comparison table, the
  Confluence block in the summary, clicking a zone row to open its touch/reaction detail, and
  the pattern strength labels. Run from pytest (`tests/test_chart_js.py`) or directly with `node`.
- **Module structure:** every new module imports cleanly, `AppState` is composed from the
  three mixins with no duplicated methods, the `STATE` singleton is the *same object* through
  `engine` and `state_manager`, `app.py` is wired to the new modules, and the import graph is
  cycle-free.
- **Frontend structure:** the JS is still inline (no external `<script src=…>`), all 11
  section banners are present and in order with descriptions, the inline script parses under
  a real JS engine, and no temporal-dead-zone risk was introduced by the reordering.
- **Data quality:** a 1:2 split is detected as a *suspected* corporate action with the implied
  ratio, HIGH confidence and its evidence; a plain −30% move is **not**; detected prices are
  proven untouched; the headline `missing_bars` / `holiday_skips` numbers are proven identical to
  the legacy counter; a holiday-listed date is reported as an expected skip rather than missing
  data; an intra-session hole is reported as such; a volume spike below the 8× ratio threshold is
  still caught by the z-score; a flat-volume series does not hide a spike; the 0–100 score is
  bounded, fully broken down, and a serious issue can never be graded clean; a file that claims
  to be split-adjusted but is not is flagged; and a provenance file written *before* this layer
  still loads unchanged and gets its report recomputed on restart.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError` | Run `python -m pip install -r requirements.txt`. |
| Port 8000 in use | `QUANTAI_PORT=8080 python app.py`. |
| "No valid candles after validation" | Check column names, timestamp format, and OHLC relationships. Use **Preview** to see rejection reasons. |
| Intraday rows rejected | Timestamps must align to the timeframe grid inside 09:15–15:30 IST. Naive times are read as IST. |
| Research fails "single class" | The training window has only one label class. Import more history or reduce the horizon. |
| Verdict always `PLUMBING_ONLY` | You're using demo/synthetic data. Import real market history for a market verdict. |
| Benchmark "missing" | Import a `NIFTY50` dataset with a matching timeframe. |
| Replay won't start | Kill switch may be engaged — release it in Risk & Safety. |
| Metrics show `N/A` | Too few bars/trades for a statistically meaningful ratio. This is intentional. |
| Charts tab says "No imported datasets" | The chart only shows real imported rows. Import a CSV on the **Data Import** tab first. |
| An indicator line is missing on the chart | It is still in warm-up (e.g. EMA 200 needs 200 bars). Warm-up is left blank on purpose — it is never back-filled. |
| VWAP is missing | VWAP is intraday-only and needs positive volume. It is always unavailable on `1D`. |
| Support/resistance looks empty | Zones need swing pivots, so very short or very smooth series produce none. That is honest output, not a bug. |

---

## Known limitations

- **The journal measures the strategy, not the trader.** The live win rate, profit factor and
  drawdown come from the replay engine's simulated fills. Tagging a trade as `mistake` or
  recording `FOMO` is **self-reported** — the app cannot verify it, and a trader who only tags
  the trades they remember will produce a biased breakdown. Treat the breakdowns as a prompt to
  look, not as a diagnosis.
- **A small breakdown is noise.** One trade in a strategy, an emotional state or a tag row
  decides that row's win rate entirely. The trade count is printed next to every number
  precisely so a one-trade row cannot be mistaken for a result.
- **The emotional-state breakdown has no baseline.** Without it, "revenge trades lose money"
  could just mean revenge trades are rare and were entered on bad days. Compare the counts
  before drawing a conclusion.
- **Live replay statistics describe the replay, not the future.** A running win rate over twelve
  simulated trades is a description of those twelve trades, not a forecast.
- **The weekly loss limit uses ISO weeks, not the exchange's settlement week.** For most
  instruments these are the same, but a week that contains a market holiday still counts as one
  ISO week, and a limit breached on Sunday evening is measured against a Monday start.
- **The volatility adjustment is a heuristic, not a volatility model.** It compares the current
  ATR% against a single number you set by hand. It does not forecast volatility, it does not
  know whether the volatility is about to mean-revert, and a target ATR% that is wrong for the
  instrument makes the whole adjustment wrong in a consistent direction. It is off by default for
  that reason.
- **Progressive cooldown lengthens the pause, it does not improve the trade.** A longer cooldown
  after a losing streak reduces the number of trades taken during a bad patch; it does not make
  the next trade better. Fewer trades also means fewer observations, which makes the backtest
  statistics less precise — a strict comparison against the fixed cooldown should look at the
  trade count, not only the P&L.
- **The kill-switch reason is self-reported.** The app records what you type; it cannot verify
  the reason, and an unrecorded reason is still recorded honestly as **"No reason provided"**
  rather than as a blank — but the text itself is exactly as reliable as the operator's honesty
  at the moment they clicked.
- **A weekly-limit breach blocks entries, it does not flatten the book.** The weekly limit is a
  *new-entry* block, exactly like the daily one: an open position is still managed (its stop
  and target are honoured) and the position is not force-closed. If you want the weekly limit
  to flatten everything, the **total-drawdown** limit is the one that does that.
- **The weekly limit is measured on a daily-bar series in ~5-bar weeks.** On a `1D` dataset an
  ISO week is only five candles, so a weekly limit can be reached — or missed — inside a single
  week. On an intraday series the same limit covers a much longer stretch of real time. The
  limit is the same number; what it spans is not.
- **The volatility adjustment makes old and new runs non-comparable.** Once it is switched on,
  the risk per trade changes bar to bar, so a report produced with the toggle off cannot be
  compared line by line with one produced with it on. The Risk tab warns about this when the
  option is enabled.

- **Probability calibration fixes confidence, not the trading behaviour.** Temperature scaling
  preserves each row's class order, so the predicted class (arg-max) and the accuracy are
  provably unchanged — but a threshold rule that acts on `p_up − p_down` can fire more or
  less often after calibration, because the probabilities are flattened. The report shows the
  raw and calibrated numbers side by side instead of claiming "same decisions".
- **Calibration is not an edge.** A better Brier/ECE only means the stated probability deserves
  to be believed. It says nothing about whether the direction is profitable.
- **Feature-importance stability is a diagnostic, not a verdict.** A model can rank features
  identically across every seed and still have zero predictive power. The stability score is
  reported as a consistency measure, never as a quality gate.

- **Portfolio is a sum of independent sleeves, not a shared-margin book.** The multi-symbol
  portfolio layer allocates capital up-front and sums sleeve equity curves; it does not model
  cross-symbol margin netting, shared-cash contention, or pyramiding. The live *replay* engine
  remains single-symbol, single-position.
- **Cost/execution model is an approximation.** Fixed bps slippage, no order book, no partial
  fills, no liquidity impact beyond the optional volume-participation cap. Rates are dated
  assumptions (effective 2025-10-01), not live broker quotes — verify against your contract note.
- **Corporate-action adjustment is user-asserted.** The default `UNKNOWN_UNVERIFIED` policy
  means split/bonus correctness is not proven. Multi-year raw data can create fake signals.
- **`CANDIDATE` is single-symbol, single-window.** It is not proof of profitability. Use the
  portfolio, sensitivity, regime and Monte Carlo tabs plus out-of-sample paper confirmation
  before trusting any result — and even then it is research, not a guarantee.
- **Monte Carlo resamples the existing trade distribution.** It cannot anticipate regime shifts,
  changing slippage, or capacity decay; with few trades the distributions are wide and unreliable.
- **Regime labels are a simple causal EMA/slope heuristic**, not a ground-truth market state;
  thresholds are configurable and results depend on them.
- **Authorized-feed authorization is user-asserted.** The SSRF guard blocks unsafe targets but the
  app cannot verify your license or the exchange-provenance of fetched content.
- **Candlestick patterns and S/R zones are shape statistics, not market physics.** The 9 patterns
  use fixed geometric thresholds (body ≤ 10 % of range for a Doji, 34 % for a small body, 90 %
  body with ≤ 12 % shadows for a Marubozu). Support/resistance uses ±5-bar fractal pivots
  clustered by an ATR-derived tolerance. Different thresholds give different zones — the
  parameters are not auto-tuned, and no level is guaranteed to hold.
- **The TA summary is descriptive.** It reports what the indicators read on the selected bar.
  It contains no forecast model, no probability of a future move, and no BUY/SELL verdict,
  because a candle pattern cannot justify one.
- **Confluence counts agreement, not edge.** The Confluence section counts how many indicator
  readings point the same way. Most of those readings are derived from the same price series,
  so they are **not independent evidence** — ten agreeing readings can come from one trend.
  A high agreement count says the readings are consistent, not that the next move is likely to
  pay, and readings can agree and still be wrong. The count is also **not** comparable across
  timeframes: a 15m chart produces more readings and a different mix than a 1D chart.
- **Pattern strength is a quality label, not a probability.** The `weak`/`medium`/`strong`
  label summarises volume participation and location. It is computed with fixed thresholds
  (1.5× volume, 20-bar range, 0.5 ATR reactions) that are **not** calibrated to outcomes and
  **not** tuned per instrument. A "strong" pattern can still be a losing trade, and the score
  carries no expected return.
- **Zone touch/reaction history is backward-looking.** The reaction rule is a fixed
  0.5-ATR-within-5-bars rule applied to past bars. A zone can be labelled `failed` because
  price happened to punch through it during a volatile session, and a `strong` zone can still
  break. The touch list is capped at the most recent 40 entries while the counts cover all
  touches.
- **The cross-timeframe table is a snapshot, not a signal.** The comparison rows are computed
  at each timeframe's own last bar, so the rows are **not time-aligned** — a 15m row and a 1D
  row describe different moments. Use it to orient yourself, then open the timeframe you want.
- **VWAP assumes IST session boundaries and no intraday auction gaps.** It is a plain
  typical-price × volume cumulative average, not a broker-grade VWAP tape.
- **Chart payloads are O(bars).** A multi-year daily dataset ships thousands of candles plus 18
  indicator series to the browser in one JSON payload. This is fine for a research terminal;
  it is not designed for tick-level data.
- **The chart engine is hand-verified, not browser-verified end-to-end.** The JavaScript is
  executed under a headless DOM harness with a recording canvas (see `tests/chart_js_harness.js`),
  which proves the drawing, zoom, pan and crosshair code paths run and draw what they should —
  but it is not a real GPU browser session.
- **Sharpe/Sortino/profit-factor are unstable at low trade counts** and return `N/A` below
  thresholds.
- **Paper replay is historical simulation**, not a live market feed.
- **NIFTY benchmark is gross of costs** (an index is not directly tradable). Use an ETF/fund
  with its own costs for a like-for-like comparison.
- **No transaction-level tax lots, no futures/options.** Cash equities only.

---

## Safety rules

1. **Live trading is completely disabled** — hard-coded `LIVE_TRADING_ENABLED = False`.
2. **No broker API integration** and **no real-money order execution** exist in this codebase.
3. The application is strictly for **research and paper trading**.
4. **No fabricated performance results.** Every metric derives from actual simulated fills.
5. **Synthetic data is always distinguished** from imported (unverified) market data. Uploaded
   bytes can never be labelled as verified exchange data.
6. **A `CANDIDATE` verdict is not proof of profitability.**
7. **No fabricated candles, prices or indicators.** Charts draw only the imported rows; missing
   bars are reported and never interpolated; indicator warm-up values stay blank.
8. **Candlestick patterns and support/resistance are observations, not signals.** The app never
   turns them into an order and the TA panel never prints an unexplained BUY/SELL verdict.
9. **All indicator calculations are causal.** Historical views never read a future candle, and
   the indicator strategy is evaluated on the same purged split as every other strategy.

---

*Past performance does not predict future results. Trading involves risk of loss. Verify broker
and SEBI requirements before any real-money deployment. If your only goal is profit, a low-cost
broad-market index ETF is often a better choice than an unproven active strategy.*
