"""One-shot refactor: split engine.py into 4 focused modules + a thin façade.

Method bodies are extracted VERBATIM (byte-identical line ranges) so behaviour
cannot drift. Only imports/class wrappers are new.

!! ARCHIVED — DO NOT RE-RUN. !!
This was a one-shot migration script. It reads the pristine monolith from
/tmp/engine_ORIGINAL.py and OVERWRITES engine.py, state_manager.py,
research_orchestrator.py, paper_replay.py and risk_engine.py. The pristine
source no longer exists in /tmp, and re-running it would destroy the current,
verified modules. The refactor it performed is already complete and tested
(tests/test_module_structure.py). Kept only as a record of how the split was
produced.
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path("/home/user/quantai-app")
SRC = Path("/tmp/engine_ORIGINAL.py")
if not SRC.exists():
    raise SystemExit("pristine engine.py backup missing at /tmp/engine_ORIGINAL.py")
lines = SRC.read_text().split("\n")


def seg(a: int, b: int) -> str:
    """1-indexed inclusive line range -> text (rstripped)."""
    return "\n".join(lines[a - 1:b]).rstrip("\n")


def body(a: int, b: int) -> str:
    """Method range -> verbatim. Methods already sit at 4-space indent, which is
    exactly the class-body indent of the new mixins. No dedent, no re-indent."""
    return seg(a, b)


# ---------------------------------------------------------------- ranges
R_VERDICT = (73, 98)
R_INIT = (101, 128)
R_PERSIST = (130, 238)
R_DATA = (239, 442)
R_RESEARCH = (444, 579)
R_REPLAY = (581, 855)
R_RISK = (857, 898)
R_ADV = (900, 1075)
R_FEEDS = (1076, 1149)
R_SNAP = (1150, 1226)

# ---------------------------------------------------------------- risk_engine.py
RISK = f'''"""Risk & execution control for the QuantAI Terminal.

SAFETY CONTRACT
---------------
* Every risk limit is clamped to a hard range here — the frontend can never
  widen a limit beyond these bounds.
* The kill switch blocks new entries in BOTH the backend replay engine and the
  backtest engine. It is never a UI-only affordance.
* No broker connection, no live order routing, ever.

This module is a mixin: it is composed into `AppState` in `state_manager.py`.
"""
from __future__ import annotations

from dataclasses import asdict

import numpy as np

from quantai.config import ExecutionConfig, RiskConfig

RISK_LIMITS = {{
    "risk_per_trade_pct": (0.05, 2.0),
    "max_daily_drawdown_pct": (0.5, 10.0),
    "max_total_drawdown_pct": (2.0, 50.0),
    "max_exposure_pct": (5.0, 100.0),
    "initial_capital": (10_000, 100_000_000),
    "max_open_positions": (1, 5),
    "max_consecutive_losses": (1, 20),
    "cooldown_bars": (1, 500),
    "stop_atr_mult": (0.5, 10.0),
    "target_atr_mult": (0.5, 20.0),
    "max_cash_fraction": (0.1, 1.0),
}}
EXEC_LIMITS = {{
    "slippage_bps": (0.0, 50.0),
    "brokerage_flat_inr": (0.0, 100.0),
    "brokerage_pct_cap": (0.0, 0.01),
    "max_volume_participation_pct": (0.0, 25.0),
}}


class RiskEngineMixin:
    """Kill switch, risk limits and execution-cost settings."""

{body(*R_RISK)}
'''

# ---------------------------------------------------------------- paper_replay.py
REPLAY = f'''"""Bar-by-bar paper replay engine for the QuantAI Terminal.

SAFETY CONTRACT
---------------
* Replay is a HISTORICAL SIMULATION. It is never a live feed and never claims
  to be one. No order reaches any broker.
* Replay uses the SAME execution contract and the SAME risk rules as the
  backtest engine, so a replayed trade is comparable with a backtested one.
* Signals are causal: the signal at bar[t] uses only bars 0..t.
* Live trading is permanently disabled; there is no broker adapter anywhere.

This module is a mixin: it is composed into `AppState` in `state_manager.py`.
"""
from __future__ import annotations

import threading
import time
import traceback
import uuid

import numpy as np

from quantai.backtest import technical_score
from quantai.config import DataOrigin
from quantai.features import FEATURE_NAMES, build_features
from quantai.indicators import compute_indicators, indicator_score


class PaperReplayMixin:
    """Historical replay: start / step / close / stop."""

{body(*R_REPLAY)}
'''

# ---------------------------------------------------------------- research_orchestrator.py
RESEARCH = f'''"""Research orchestration for the QuantAI Terminal.

SAFETY CONTRACT
---------------
* The model is trained on the TRAIN split only. Train / validation / unseen-test
  metrics are always reported separately.
* Splits are purged chronologically: labels cannot leak across split boundaries.
* Every backtest (ensemble, rules, indicators, ML, buy & hold) runs on the SAME
  unseen test window with the SAME costs, so comparisons are apples-to-apples.
* A CANDIDATE verdict is NOT proof of profitability. Synthetic data always
  yields PLUMBING_ONLY — no market conclusion is ever drawn from fake data.

This module is a mixin: it is composed into `AppState` in `state_manager.py`.
"""
from __future__ import annotations

import hashlib
import time
import traceback
import uuid
from dataclasses import asdict

import numpy as np
import pandas as pd
import sklearn

from quantai.backtest import run_backtest
from quantai.benchmark import nifty_benchmark
from quantai.config import (CostModel, DataOrigin, ResearchConfig, ResearchQuality)
from quantai.features import (FEATURE_NAMES, FEATURE_VERSION, build_dataset,
                              build_features, purged_split)
from quantai.indicators import compute_indicators
from quantai.metrics import performance_metrics
from quantai.model import (evaluate, feature_importance, fit_forest,
                           momentum_baseline, overfit_diagnostics, walk_forward)
from quantai.montecarlo import run_monte_carlo
from quantai.portfolio import run_portfolio
from quantai.regime import detect_regimes, regime_performance
from quantai.sensitivity import run_sensitivity
from storage import json_safe


{seg(*R_VERDICT)}


class ResearchOrchestratorMixin:
    """Model training, backtests and the advanced analyses."""

{body(*R_RESEARCH)}

    # ---------------- advanced research ----------------
{body(*R_ADV)}
'''

# ---------------------------------------------------------------- state_manager.py
STATE = f'''"""Core application state for the QuantAI Terminal.

Owns the in-memory + on-disk state that every other layer reads:
datasets, the active dataset, models, research runs, feeds, settings and the
paper journal. The behaviour-specific layers are composed in as mixins:

* `risk_engine.RiskEngineMixin`      — kill switch, risk/execution limits
* `paper_replay.PaperReplayMixin`    — historical paper replay
* `research_orchestrator.ResearchOrchestratorMixin` — training + analyses

SAFETY CONTRACT
---------------
* No broker connection. No live order routing. Live trading is permanently disabled.
* Simulated data is always labelled SIMULATED/TEST_FIXTURE. Imported CSV is UNVERIFIED
  unless the user explicitly marks it BROKER_VENDOR (and even then it is user-asserted).
* Datasets, models, research runs, settings and the paper journal persist across restarts.
* Charts draw only real imported rows; nothing is ever fabricated.
"""
from __future__ import annotations

import threading
import time
import uuid
from dataclasses import asdict
from pathlib import Path

from quantai.charting import build_chart_payload
from quantai.config import DataOrigin, ExecutionConfig, RiskConfig
from quantai.data import load_csv, preview_csv
from quantai.data_sources import (FeedSource, fetch_feed_csv, merge_append_only,
                                  validate_feed_url)
from quantai.metrics import performance_metrics
from journal import Journal
from storage import Store, atomic_write_json, json_safe, read_json

from paper_replay import PaperReplayMixin
from research_orchestrator import ResearchOrchestratorMixin
from risk_engine import RiskEngineMixin

DATA_DIR = Path(__file__).parent / "uploads"
DATA_DIR.mkdir(exist_ok=True)
STORE_ROOT = Path(__file__).parent / "data_store"

LIVE_TRADING_ENABLED = False  # hard lock, not user-configurable


class AppState(RiskEngineMixin, PaperReplayMixin, ResearchOrchestratorMixin):
    """The single shared application state (one instance per process)."""

{body(*R_INIT)}

    # ---------------- persistence ----------------
{body(*R_PERSIST)}

    # ---------------- data ----------------
{body(*R_DATA)}

    # ---------------- authorized data feeds ----------------
{body(*R_FEEDS)}

    # ---------------- snapshot ----------------
{body(*R_SNAP)}
'''

# ---------------------------------------------------------------- engine.py (façade)
ENGINE = '''"""QuantAI Terminal — public entry point.

This module is a thin façade over the focused implementation modules:

* `state_manager.py`            — AppState core (data, persistence, snapshot)
* `research_orchestrator.py`     — training + advanced analyses
* `paper_replay.py`              — historical paper replay engine
* `risk_engine.py`               — kill switch + risk/execution limits

`AppState` is composed from those mixins in `state_manager.py`. Every name
that used to live here is still importable from here, so `from engine import
STATE, DATA_DIR, LIVE_TRADING_ENABLED, AppState` keeps working unchanged.

SAFETY CONTRACT
---------------
* No broker connection. No live order routing. Live trading is permanently disabled.
* Simulated data is always labelled SIMULATED/TEST_FIXTURE. Imported CSV is UNVERIFIED
  unless the user explicitly marks it BROKER_VENDOR (and even then it is user-asserted).
* Historical replay never claims to be a live feed.
* Risk limits are enforced in the backend replay/backtest engines, not the frontend.
* Datasets, models, research runs, settings and the paper journal persist across restarts.
"""
from __future__ import annotations

from paper_replay import PaperReplayMixin
from research_orchestrator import ResearchOrchestratorMixin, _verdict
from risk_engine import EXEC_LIMITS, RISK_LIMITS, RiskEngineMixin
from state_manager import (DATA_DIR, LIVE_TRADING_ENABLED, STORE_ROOT, AppState)

__all__ = [
    "AppState", "STATE", "DATA_DIR", "STORE_ROOT", "LIVE_TRADING_ENABLED",
    "RISK_LIMITS", "EXEC_LIMITS", "_verdict",
    "RiskEngineMixin", "PaperReplayMixin", "ResearchOrchestratorMixin",
]

# The single shared application state used by the Flask server.
STATE = AppState()
'''

for name, text in [("risk_engine.py", RISK), ("paper_replay.py", REPLAY),
                   ("research_orchestrator.py", RESEARCH), ("state_manager.py", STATE)]:
    (ROOT / name).write_text(text)
    print(f"wrote {name}: {len(text.splitlines())} lines")

(ROOT / "engine.py").write_text(ENGINE)
print(f"wrote engine.py (façade): {len(ENGINE.splitlines())} lines")
