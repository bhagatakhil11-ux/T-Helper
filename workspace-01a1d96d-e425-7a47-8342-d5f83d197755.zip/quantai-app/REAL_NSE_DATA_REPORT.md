# Real NSE market data — fetch & validation report

**Source:** Yahoo Finance (`yfinance` 1.8.0, `auto_adjust=True`)
**Fetched:** 2026-11-14 · **Script:** `fetch_real_nse.py` · **Output:** `uploads/`

---

## 1. Files produced

| File | Yahoo symbol | Timeframe | Rows | First | Last | Rejected | Grade |
|------|--------------|-----------|-----:|-------|------|---------:|-------|
| `RELIANCE_1D.csv`  | `RELIANCE.NS` | 1D  | 2 681 | 2016-01-01 00:00:00 | 2026-11-13 00:00:00 | 0 | A (99/100) |
| `TCS_1D.csv`       | `TCS.NS`      | 1D  | 2 681 | 2016-01-01 00:00:00 | 2026-11-13 00:00:00 | 0 | A (99/100) |
| `HDFCBANK_1D.csv`  | `HDFCBANK.NS` | 1D  | 2 681 | 2016-01-01 00:00:00 | 2026-11-13 00:00:00 | 0 | A (97/100) |
| `INFY_1D.csv`      | `INFY.NS`     | 1D  | 2 681 | 2016-01-01 00:00:00 | 2026-11-13 00:00:00 | 0 | A (96/100) |
| `NIFTY50_1D.csv`   | `^NSEI`       | 1D  | 2 676 | 2016-01-04 00:00:00 | 2026-11-13 00:00:00 | 0 | A (99/100) |
| `RELIANCE_15m.csv` | `RELIANCE.NS` | 15m | 1 496 | 2026-08-18 09:15:00 | 2026-11-13 15:15:00 | 0 | B (84/100) |

**Total: 14 896 rows across 6 files.**

The 15m file's B grade is *not* a defect — it is the "history sufficiency" component
(1 496 bars vs the 7 500 the layer asks for). The file is capped at `period="60d"` because
that is what the request specified. It has **0 serious issues**.

---

## 2. Invariants checked (recomputed independently from the files on disk)

Every file passed every check:

| Check | Result |
|---|---|
| Schema exactly `timestamp,open,high,low,close,volume` | ✅ 6/6 |
| Timestamp format `YYYY-MM-DD HH:MM:SS`; daily at `00:00:00` | ✅ 6/6 |
| No NaNs | ✅ 0 NaNs total |
| Integer volume (never silently truncated) | ✅ 6/6 |
| `high ≥ max(open, close)` | ✅ 6/6 |
| `low ≤ min(open, close)` and `high ≥ low` | ✅ 6/6 |
| Timestamps sorted ascending, no duplicates | ✅ 6/6 |
| Weekdays only | ✅ 6/6 |
| More than zero rows | ✅ 6/6 |

### 15-minute session grid

| Check | Result |
|---|---|
| Bars outside 09:15–15:15 IST | 0 |
| Bars off the 15-minute grid | 0 |
| Weekend bars | 0 |
| Distinct sessions | 60 (24–25 bars each) |
| Timestamps keep real bar time | ✅ (a 00:00:00 stamp would collapse 25 bars/day onto one row) |

---

## 3. Two data issues found, and how they were handled

### 3.1 Yahoo emits phantom weekend bars — dropped, with an audit trail

Yahoo served a Saturday/Sunday bar for every symbol (2019-10-27, 2020-11-14, 2025-02-01).
Evidence that these are not regular sessions:

* the bar's **open is exactly the previous Friday's close**;
* the hourly feed for those dates contains **no trading hours at all** — only a
  zero-volume closing mark at 15:15 (`O=H=L=C=Fri close, V=0`);
* Yahoo's own weekly roll-up counts them as extra sessions, i.e. they are extra rows
  in the source, not missing data on our side.

The NSE cash segment trades Monday to Friday, so those rows are not regular trading
sessions and would distort any daily indicator that treats them as full days.

**13 dropped rows are written to `uploads/AUDIT_dropped_weekend_rows.csv`** with the
reason attached — nothing is discarded silently.

### 3.2 The "155 missing sessions" was a false alarm — NSE holiday calendar added

Without a market calendar the quality layer read every NSE market holiday as a missing
trading session and raised a **HIGH-severity** issue, capping the score at 70 (grade C).

The missing days are exactly the NSE holiday calendar. The dates were derived from the
`^NSEI` series (no index bar ⇒ the whole market was shut) and reconciled against the
published NSE holiday lists for 2016–2025 — **every date matches**. Cross-checked
against the four equity series: every weekday missing from an equity series is also
missing from the index, so the fetched history has **zero stock-specific holes**.

`quantai/nse_holidays.py` now supplies this calendar to the import path
(*Market calendar → NSE (India)* in the import form). It only ever *explains* a gap — it
never creates, fills or alters a bar, and a genuine hole is still reported.

**Result: 70 (C) → 99 (A)** on the daily files.

---

## 4. Honest limitations

* **The calendar covers 2016-01-01 … 2026-11-10.** A file extending past that window will
  still be reported as having missing sessions — the honest behaviour, since the
  calendar is unknown there.
* **A handful of holidays carry a *partial* bar in Yahoo's feed** (e.g. 2021-11-04,
  Diwali, where the index bar trades a fraction of a normal day's volume). Those dates
  are deliberately **not** in the calendar: claiming them would risk hiding a real hole.
  The error is in the safe direction — a real gap is never hidden, only occasionally
  reported that does not exist.
* **The 15m file has 4 short sessions** (24 bars instead of 25) and **4 zero-volume
  bars**. These are genuine feed gaps; the quality layer flags them.
* **Volume differs between Yahoo's daily and hourly feeds** (the hourly `09:15` bar
  carries zero volume). Daily volume is the authoritative figure and is what the CSVs
  use.
* **`auto_adjust=True` means the prices are split- and dividend-adjusted**, while the
  quality layer's corporate-action detector deliberately runs on raw prices. That is why
  the reports say *prices left unadjusted* — they describe the check, not the file.
* The imported datasets are labelled `IMPORTED_CSV_UNVERIFIED`. The app will not label
  uploaded bytes as verified exchange data, and this report does not claim otherwise.

---

## 5. Reproducing

```bash
pip install -r requirements.txt      # includes yfinance>=1.8
python3 fetch_real_nse.py             # ~10 s -> 6 CSVs + audit trail + summary table
python3 -m pytest tests -q           # 443 passed
```
