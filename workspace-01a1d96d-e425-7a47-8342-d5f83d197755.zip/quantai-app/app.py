"""QuantAI Terminal — Flask server. Research + paper replay only. No live trading.

Security defaults:
  * Binds to 127.0.0.1 unless QUANTAI_HOST is explicitly set (the Arena preview
    sets QUANTAI_HOST=0.0.0.0; on your own PC leave it unset).
  * Uploads are size-capped, extension-checked, saved under generated names, and
    parsed strictly as CSV. Uploaded files are never imported/executed as code.
  * All dataset/model/research ids are validated before touching the filesystem.
"""
from __future__ import annotations

import csv
import io
import json
import logging
import os
import re
import uuid
from logging.handlers import RotatingFileHandler
from pathlib import Path

import numpy as np
import pandas as pd
from flask import Flask, jsonify, request, send_from_directory, Response
from werkzeug.utils import secure_filename

from state_manager import DATA_DIR, LIVE_TRADING_ENABLED, STATE

# The workspace root — one level above the app directory. The downloadable
# build archives are written there.
APP_ROOT = Path(__file__).resolve().parent
WORKSPACE_ROOT = APP_ROOT.parent
from journal import EMOTION_STATES, SUGGESTED_TAGS
from quantai.config import SUPPORTED_TIMEFRAMES
from quantai.nse_holidays import nse_holidays

SYMBOL_RE = re.compile(r"^[A-Z0-9&.\-]{1,20}$")
ALLOWED_EXT = {".csv"}
ADJUSTMENTS = {"UNKNOWN_UNVERIFIED", "SPLIT_AND_BONUS_ADJUSTED", "UNADJUSTED"}
# Broker/vendor CSV is still user-supplied bytes; it is NOT independently verified.
SOURCE_TYPES = {"IMPORTED_CSV", "TEST_FIXTURE", "SIMULATED"}

# Market calendars the quality layer can use to tell a market holiday from a
# genuine hole in the file. A calendar only suppresses a "missing session"
# finding for dates the market was genuinely shut; it never creates, fills
# or alters a bar.
CALENDARS = {
    "": lambda: set(),
    "NSE": nse_holidays,
}


def _csv_response(rows: list[dict], filename: str, fieldnames: list[str] | None = None) -> Response:
    buf = io.StringIO()
    cols = fieldnames or (list(rows[0].keys()) if rows else [])
    if cols:
        w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename={filename}"})


TRADE_EXPORT_COLS = ["entry_bar", "exit_bar", "entry_time", "exit_time", "direction", "strategy",
                     "qty", "entry", "exit", "stop", "target", "pnl", "costs",
                     "entry_reason", "exit_reason", "reason"]


def _setup_logging(app: Flask, state):
    log_dir = state.store.root / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(log_dir / "terminal.log", maxBytes=2_000_000, backupCount=3)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    handler.setLevel(logging.INFO)
    app.logger.addHandler(handler)
    app.logger.setLevel(logging.INFO)


def create_app(state=None) -> Flask:
    state = state or STATE
    app = Flask(__name__, static_folder="static", static_url_path="/static")
    app.config["MAX_CONTENT_LENGTH"] = 64 * 1024 * 1024
    app.config["STATE"] = state
    _setup_logging(app, state)

    def st():
        return app.config["STATE"]

    def err(msg, code=400):
        app.logger.warning("API error: %s", msg)
        return jsonify({"error": msg}), code

    @app.errorhandler(413)
    def too_large(_):
        return err("File too large. Maximum upload size is 64 MB.", 413)

    @app.errorhandler(404)
    def not_found(_):
        return err("Not found.", 404)

    @app.errorhandler(500)
    def server_error(e):
        app.logger.exception("Unhandled server error")
        return err("Internal server error. See logs/terminal.log for details.", 500)

    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    @app.get("/api/state")
    def api_state():
        return jsonify(st().snapshot())

    @app.get("/api/health")
    def api_health():
        s = st()
        return jsonify({"ok": True, "live_trading_enabled": LIVE_TRADING_ENABLED,
                        "datasets": len(s.datasets), "journal_trades": s.journal.count(),
                        "research_busy": s.research_busy})

    # ---------------- import / preview ----------------
    def _validate_upload():
        f = request.files.get("file")
        if f is None or not f.filename:
            raise ValueError("No file uploaded.")
        ext = Path(f.filename).suffix.lower()
        if ext not in ALLOWED_EXT:
            raise ValueError("Only .csv files are accepted.")
        symbol = (request.form.get("symbol") or "").strip().upper()
        if not SYMBOL_RE.fullmatch(symbol):
            raise ValueError("Symbol must be 1-20 chars: A-Z, 0-9, &, ., - (e.g. RELIANCE, NIFTY50, M&M).")
        timeframe = request.form.get("timeframe") or "1D"
        if timeframe not in SUPPORTED_TIMEFRAMES:
            raise ValueError(f"Unsupported timeframe. Use one of {SUPPORTED_TIMEFRAMES}.")
        source_type = request.form.get("source_type") or "IMPORTED_CSV"
        if source_type not in SOURCE_TYPES:
            raise ValueError("Uploaded CSV cannot be marked as verified exchange data. "
                             "Use IMPORTED_CSV (unverified) or TEST_FIXTURE.")
        adjustment = request.form.get("adjustment") or "UNKNOWN_UNVERIFIED"
        if adjustment not in ADJUSTMENTS:
            raise ValueError("Invalid adjustment policy.")
        # Market calendar: lets the quality layer tell a market holiday from
        # a genuine hole in the file. It never creates or alters a bar.
        calendar = (request.form.get("market_calendar") or "").strip().upper()
        if calendar not in CALENDARS:
            raise ValueError("Invalid market calendar.")
        holidays = CALENDARS[calendar]()
        # Generated filename: user filename never touches the filesystem path.
        dest = DATA_DIR / f"upload_{uuid.uuid4().hex}{ext}"
        f.save(dest)
        # The original filename is kept as provenance metadata only — it is
        # sanitised and never used to build a path.
        safe_name = re.sub(r"[^A-Za-z0-9._-]", "_", Path(f.filename).name)[:80] or "upload.csv"
        return dest, symbol, timeframe, source_type, adjustment, safe_name, holidays

    @app.post("/api/import")
    def api_import():
        try:
            dest, symbol, tf, source, adj, fname, holidays = _validate_upload()
            meta = st().import_csv(dest, symbol, tf, source, adj,
                                    source_name=fname, holidays=holidays)
            return jsonify({"ok": True, "dataset": meta})
        except Exception as e:
            return err(f"{type(e).__name__}: {e}")
        finally:
            try:
                dest.unlink(missing_ok=True)
            except Exception:
                pass

    @app.post("/api/preview")
    def api_preview():
        try:
            dest, symbol, tf, source, adj, fname, holidays = _validate_upload()
            rep = st().preview(dest, symbol, tf, source, adj,
                               source_name=fname, holidays=holidays)
            return jsonify({"ok": True, **rep})
        except Exception as e:
            return err(f"{type(e).__name__}: {e}")
        finally:
            try:
                dest.unlink(missing_ok=True)
            except Exception:
                pass

    @app.post("/api/preview/confirm")
    def api_preview_confirm():
        token = (request.json or {}).get("preview_token", "")
        try:
            meta = st().confirm_preview(token)
            return jsonify({"ok": True, "dataset": meta})
        except Exception as e:
            return err(f"{type(e).__name__}: {e}")

    @app.post("/api/select")
    def api_select():
        key = (request.json or {}).get("key")
        try:
            st().select_dataset(key)
            return jsonify({"ok": True})
        except Exception as e:
            return err(str(e))

    @app.post("/api/delete")
    def api_delete():
        key = (request.json or {}).get("key")
        if key not in st().datasets:
            return err("Unknown dataset.")
        st().delete_dataset(key)
        return jsonify({"ok": True})

    @app.get("/api/dataset/view")
    def api_dataset_view():
        key = request.args.get("key", "")
        try:
            return jsonify({"ok": True, **st().dataset_view(key, rows=int(request.args.get("rows", 10)))})
        except Exception as e:
            return err(str(e))

    @app.get("/api/dataset/history")
    def api_dataset_history():
        return jsonify({"ok": True, "history": st().dataset_history()})

    @app.get("/api/dataset/export")
    def api_dataset_export():
        key = request.args.get("key", "")
        ds = st().datasets.get(key)
        if not ds:
            return err("Unknown dataset.")
        df = ds["df"].copy()
        df["timestamp"] = df["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S%z")
        return _csv_response(df.to_dict("records"), f"{ds['meta'].dataset_id}_candles.csv")

    @app.get("/api/dataset/quality")
    def api_dataset_quality():
        key = request.args.get("key", "")
        ds = st().datasets.get(key)
        if not ds:
            return err("Unknown dataset.")
        return jsonify({"ok": True, "quality": ds["meta"].to_dict()})

    # ---------------- charting / technical analysis ----------------
    @app.get("/api/chart/symbols")
    def api_chart_symbols():
        return jsonify({"ok": True, "symbols": st().chart_symbols(),
                        "timeframes": list(SUPPORTED_TIMEFRAMES)})

    @app.get("/api/chart/groups")
    def api_chart_groups():
        """Datasets grouped by symbol, with the timeframes each symbol has."""
        return jsonify({"ok": True, **st().chart_symbol_groups()})

    @app.get("/api/chart/compare")
    def api_chart_compare():
        """A compact cross-timeframe comparison for one symbol."""
        symbol = request.args.get("symbol", "")
        try:
            return jsonify({"ok": True, "symbol": (symbol or "").upper(),
                            "rows": st().chart_compare(symbol)})
        except Exception as e:
            return err(str(e))

    @app.get("/api/chart/data")
    def api_chart_data():
        key = request.args.get("key") or None
        as_of = request.args.get("as_of_bar")
        try:
            payload = st().chart_payload(key=key,
                                         as_of_bar=int(as_of) if as_of not in (None, "") else None)
        except Exception as e:
            return err(str(e))
        return jsonify(payload)

    @app.get("/api/chart/export")
    def api_chart_export():
        """Export the chart payload (candles + indicators + patterns + levels) as JSON."""
        key = request.args.get("key") or None
        try:
            payload = st().chart_payload(key=key)
        except Exception as e:
            return err(str(e))
        body = json.dumps(payload, indent=2, default=str)
        return Response(body, mimetype="application/json",
                        headers={"Content-Disposition": "attachment; filename=chart_analysis.json"})

    # ---------------- research ----------------
    @app.post("/api/research")
    def api_research():
        body = request.json or {}
        try:
            horizon = int(body.get("horizon", 5))
            thr = float(body.get("entry_threshold", 0.42))
            if not (1 <= horizon <= 60):
                raise ValueError("Horizon must be 1-60 bars.")
            if not (0 <= thr <= 1):
                raise ValueError("Entry threshold must be 0-1.")
            mode = _mode(body)
        except Exception as e:
            return err(str(e))
        if st().active() is None:
            return err("Import a dataset first.")
        if st().research_busy:
            return err("Research already running.", 409)
        import threading

        def worker():
            try:
                st().run_research(horizon=horizon, entry_threshold=thr, mode=mode)
            except Exception:
                app.logger.exception("Research worker failed")

        threading.Thread(target=worker, daemon=True).start()
        return jsonify({"ok": True, "started": True})

    @app.get("/api/research/history")
    def api_research_history():
        return jsonify({"ok": True, "history": st().store.list_research()})

    @app.get("/api/models")
    def api_models():
        return jsonify({"ok": True, "models": st().store.list_models()})

    # ---------------- advanced research ----------------
    def _float_list(v, lo, hi, max_len=7, name="values"):
        if v is None:
            return None
        if not isinstance(v, list) or not (1 <= len(v) <= max_len):
            raise ValueError(f"{name}: provide 1-{max_len} values.")
        out = [float(x) for x in v]
        if any(not (lo <= x <= hi) for x in out):
            raise ValueError(f"{name}: values must be within [{lo}, {hi}].")
        if len(set(out)) != len(out):
            raise ValueError(f"{name}: duplicate values.")
        return sorted(out)

    def _mode(body):
        m = body.get("mode", "ensemble")
        if m not in ("ensemble", "ml_only", "rules_only", "indicators"):
            raise ValueError("mode must be ensemble, ml_only, rules_only or indicators.")
        return m

    def _start_analysis(kind, fn):
        import threading
        if not st().begin_analysis(kind):
            return err(f"{kind} analysis already running.", 409)

        def worker():
            try:
                fn()
            except Exception:
                app.logger.exception("%s worker failed", kind)

        threading.Thread(target=worker, daemon=True).start()
        return jsonify({"ok": True, "started": True, "kind": kind})

    @app.post("/api/portfolio/run")
    def api_portfolio_run():
        body = request.json or {}
        try:
            keys = body.get("keys") or []
            if not isinstance(keys, list) or not (2 <= len(keys) <= 8):
                raise ValueError("Select 2-8 imported symbols.")
            if any(k not in st().datasets for k in keys):
                raise ValueError("One or more selected datasets are not imported.")
            method = body.get("allocation_method", "equal")
            if method not in ("equal", "inverse_vol"):
                raise ValueError("allocation_method must be equal or inverse_vol.")
            cap = float(body.get("max_symbol_weight_pct", 40.0))
            if not (5 <= cap <= 100):
                raise ValueError("max_symbol_weight_pct must be 5-100.")
            expo = float(body.get("max_portfolio_exposure_pct", 90.0))
            if not (10 <= expo <= 100):
                raise ValueError("max_portfolio_exposure_pct must be 10-100.")
            mode = _mode(body)
            thr = float(body.get("entry_threshold", 0.42))
            if not (0 <= thr <= 1):
                raise ValueError("Entry threshold must be 0-1.")
        except Exception as e:
            return err(str(e))
        return _start_analysis("portfolio", lambda: st().run_portfolio_analysis(
            keys, allocation_method=method, max_symbol_weight_pct=cap,
            max_portfolio_exposure_pct=expo, mode=mode, entry_threshold=thr))

    @app.post("/api/sensitivity/run")
    def api_sensitivity_run():
        body = request.json or {}
        try:
            thresholds = _float_list(body.get("thresholds"), 0, 1, name="thresholds")
            stops = _float_list(body.get("stop_mults"), 0.5, 10, name="stop_mults")
            targets = _float_list(body.get("target_mults"), 0.5, 20, name="target_mults")
            mode = _mode(body)
        except Exception as e:
            return err(str(e))
        if st().active() is None:
            return err("Import a dataset first.")
        return _start_analysis("sensitivity", lambda: st().run_sensitivity_analysis(
            thresholds=thresholds, stop_mults=stops, target_mults=targets, mode=mode))

    @app.post("/api/regime/run")
    def api_regime_run():
        body = request.json or {}
        try:
            mode = _mode(body)
            ema_span = int(body.get("ema_span", 50))
            slope_lb = int(body.get("slope_lookback", 10))
            if not (10 <= ema_span <= 200):
                raise ValueError("ema_span must be 10-200.")
            if not (2 <= slope_lb <= 60):
                raise ValueError("slope_lookback must be 2-60.")
        except Exception as e:
            return err(str(e))
        if st().active() is None:
            return err("Import a dataset first.")
        return _start_analysis("regime", lambda: st().run_regime_analysis(
            mode=mode, ema_span=ema_span, slope_lookback=slope_lb))

    @app.post("/api/montecarlo/run")
    def api_montecarlo_run():
        body = request.json or {}
        try:
            source = body.get("source", "research")
            if source not in ("research", "journal"):
                raise ValueError("source must be research or journal.")
            method = body.get("method", "block")
            if method not in ("iid", "block"):
                raise ValueError("method must be iid or block.")
            n_sim = int(body.get("n_simulations", 2000))
            if not (100 <= n_sim <= 20000):
                raise ValueError("n_simulations must be 100-20000.")
            block = int(body.get("block_size", 5))
            if not (2 <= block <= 50):
                raise ValueError("block_size must be 2-50.")
            ruin = float(body.get("ruin_drawdown_pct", 50.0))
            if not (5 <= ruin <= 95):
                raise ValueError("ruin_drawdown_pct must be 5-95.")
            seed = int(body.get("seed", 42))
            mode = _mode(body)
        except Exception as e:
            return err(str(e))
        return _start_analysis("montecarlo", lambda: st().run_montecarlo_analysis(
            source=source, mode=mode, n_simulations=n_sim, method=method,
            block_size=block, seed=seed, ruin_drawdown_pct=ruin))

    @app.get("/api/analysis/<kind>")
    def api_analysis_get(kind):
        if kind not in ("portfolio", "sensitivity", "regime", "montecarlo"):
            return err("Unknown analysis kind.", 404)
        return jsonify({"ok": True, "result": st().analyses.get(kind),
                        "busy": st().analysis_busy.get(kind, False),
                        "error": st().analysis_error.get(kind)})

    @app.get("/api/analysis/<kind>/history")
    def api_analysis_history(kind):
        try:
            return jsonify({"ok": True, "history": st().store.list_analyses(kind)})
        except ValueError as e:
            return err(str(e), 404)

    @app.get("/api/analysis/<kind>/export")
    def api_analysis_export(kind):
        res = st().analyses.get(kind)
        if not res:
            return err("No result to export. Run the analysis first.", 404)
        if kind == "sensitivity":
            rows = res.get("results", [])
        elif kind == "portfolio":
            rows = [{"symbol": s, "weight_pct": res["weights_pct"][s],
                     "allocation_inr": res["allocations_inr"][s], **v}
                    for s, v in res.get("sleeves", {}).items()]
        elif kind == "regime":
            rows = [{"regime": r, **v} for r, v in res.get("per_regime", {}).items()]
        elif kind == "montecarlo":
            rows = []
            for metric in ("final_equity_percentiles", "final_return_pct_percentiles",
                           "max_drawdown_pct_percentiles", "longest_losing_streak_percentiles"):
                for q, v in (res.get(metric) or {}).items():
                    rows.append({"metric": metric, "percentile": q, "value": v})
        else:
            return err("Unknown analysis kind.", 404)
        return _csv_response(rows, f"quantai_{kind}.csv")

    # ---------------- authorized data feeds ----------------
    @app.get("/api/feeds")
    def api_feeds():
        return jsonify({"ok": True, "feeds": st().list_feeds()})

    @app.post("/api/feeds")
    def api_feed_add():
        body = request.json or {}
        try:
            name = str(body.get("name", "")).strip()
            url = str(body.get("url", "")).strip()
            symbol = str(body.get("symbol", "")).strip().upper()
            tf = str(body.get("timeframe", "1D"))
            note = str(body.get("license_note", ""))
            if not name or len(name) > 80:
                raise ValueError("Feed name required (1-80 chars).")
            if not SYMBOL_RE.fullmatch(symbol):
                raise ValueError("Invalid symbol.")
            return jsonify({"ok": True, "feed": st().add_feed(name, url, symbol, tf, note)})
        except Exception as e:
            return err(str(e))

    @app.delete("/api/feeds/<name>")
    def api_feed_remove(name):
        st().remove_feed(name)
        return jsonify({"ok": True})

    @app.post("/api/feeds/<name>/fetch")
    def api_feed_fetch(name):
        try:
            meta = st().fetch_feed(name)
            return jsonify({"ok": True, "dataset": meta})
        except Exception as e:
            app.logger.warning("Feed fetch failed: %s", e)
            return err(str(e))

    @app.post("/api/dataset/update")
    def api_dataset_update():
        key = request.form.get("key", "")
        f = request.files.get("file")
        if key not in st().datasets:
            return err("Unknown dataset.")
        if f is None or not f.filename or Path(f.filename).suffix.lower() not in ALLOWED_EXT:
            return err("Upload a .csv file.")
        dest = DATA_DIR / f"update_{uuid.uuid4().hex}.csv"
        try:
            f.save(dest)
            if dest.stat().st_size > 64 * 1024 * 1024:
                return err("File exceeds 64 MB cap.")
            result = st().update_dataset_append(key, dest)
            return jsonify(result)
        except Exception as e:
            return err(str(e))
        finally:
            dest.unlink(missing_ok=True)

    # ---------------- replay ----------------
    @app.post("/api/replay/start")
    def api_replay_start():
        body = request.json or {}
        try:
            st().start_replay(speed_ms=int(body.get("speed_ms", 600)),
                              use_test_window=bool(body.get("use_test_window", True)),
                              mode=body.get("mode", "ensemble"),
                              threshold=body.get("threshold"))
            return jsonify({"ok": True})
        except Exception as e:
            return err(str(e))

    @app.post("/api/replay/stop")
    def api_replay_stop():
        st().stop_replay()
        return jsonify({"ok": True})

    @app.post("/api/kill")
    def api_kill():
        body = request.json or {}
        on = bool(body.get("on", True))
        reason = str(body.get("reason", "") or "")
        try:
            res = st().set_kill(on, reason=reason)
        except Exception as e:
            return err(str(e))
        return jsonify({"ok": True, **res})

    @app.post("/api/risk")
    def api_risk():
        """Apply risk limits.

        If a paper position is open the backend REFUSES the change with a 409
        and a detailed warning, unless the caller explicitly acknowledges
        the open position. The frontend shows that warning and asks for a
        confirmation; it is not a client-side-only check.
        """
        try:
            res = st().update_risk(request.json or {})
        except Exception as e:
            return err(str(e))
        if not res.get("applied", True):
            w = res.get("warning") or {}
            return jsonify({"ok": False, "error": w.get("message", "Risk change refused."),
                            "warning": w, "requires_acknowledgement": True}), 409
        return jsonify({"ok": True, "risk": res.get("risk", {}),
                        "changed": res.get("changed", [])})

    @app.get("/api/risk/open_position")
    def api_risk_open_position():
        """The open paper position, if any — used by the risk-change warning."""
        pos = st().open_position_snapshot()
        return jsonify({"ok": True, "open_position": pos,
                        "has_open_position": pos is not None})

    @app.post("/api/execution")
    def api_execution():
        try:
            return jsonify({"ok": True, "execution": st().update_execution(request.json or {})})
        except Exception as e:
            return err(str(e))

    # ---------------- journal ----------------
    @app.get("/api/journal")
    def api_journal():
        s = st()
        return jsonify({"ok": True, "trades": s.journal.list(
            limit=int(request.args.get("limit", 200)),
            run_id=request.args.get("run_id"), symbol=request.args.get("symbol"),
            strategy=request.args.get("strategy"),
            tag=request.args.get("tag"), emotion=request.args.get("emotion"))})

    @app.post("/api/journal/note")
    def api_journal_note():
        body = request.json or {}
        ok = st().journal.update_note(body.get("id", ""), body.get("notes", ""))
        return jsonify({"ok": ok}) if ok else err("Journal trade not found.", 404)

    @app.post("/api/journal/annotate")
    def api_journal_annotate():
        """Update notes, tags and/or the emotional state of one trade.

        Only the fields present in the body are written, so the three kinds of
        annotation never overwrite each other.
        """
        body = request.json or {}
        tid = str(body.get("id", "")).strip()
        if not tid:
            return err("id is required.", 400)
        has_notes = "notes" in body
        has_tags = "tags" in body
        has_emotion = "emotion" in body
        if not (has_notes or has_tags or has_emotion):
            return err("Provide at least one of: notes, tags, emotion.", 400)
        ok = st().journal.update_annotation(
            tid,
            notes=body.get("notes") if has_notes else None,
            tags=body.get("tags") if has_tags else None,
            emotion=body.get("emotion") if has_emotion else None)
        return jsonify({"ok": ok}) if ok else err("Journal trade not found.", 404)

    @app.post("/api/journal/bulk_tag")
    def api_journal_bulk_tag():
        """Tag many trades at once (optionally scoped by run / symbol / strategy)."""
        body = request.json or {}
        tag = str(body.get("tag", "")).strip()
        if not tag:
            return err("tag is required.", 400)
        mode = str(body.get("mode", "add")).lower()
        if mode not in ("add", "remove", "replace"):
            return err("mode must be add, remove or replace.", 400)
        try:
            changed = st().journal.bulk_tag(
                tag, trade_ids=body.get("trade_ids"), run_id=body.get("run_id"),
                symbol=body.get("symbol"), strategy=body.get("strategy"), mode=mode)
        except Exception as e:
            return err(str(e))
        return jsonify({"ok": True, "changed": changed, "tag": tag, "mode": mode})

    @app.get("/api/journal/summary")
    def api_journal_summary():
        period = request.args.get("period", "daily")
        try:
            return jsonify({"ok": True, "period": period, "summaries": st().journal.summaries(period)})
        except Exception as e:
            return err(str(e))

    @app.get("/api/journal/overview")
    def api_journal_overview():
        """Whole-journal totals plus the strategy / emotion / tag breakdowns."""
        try:
            return jsonify({"ok": True, "overview": st().journal.overview()})
        except Exception as e:
            return err(str(e))

    @app.get("/api/journal/breakdown")
    def api_journal_breakdown():
        dimension = request.args.get("dimension", "strategy")
        if dimension not in ("strategy", "emotion", "tag", "symbol"):
            return err("dimension must be strategy, emotion, tag or symbol.", 400)
        try:
            return jsonify({"ok": True, "dimension": dimension,
                            "rows": st().journal.breakdown(dimension)})
        except Exception as e:
            return err(str(e))

    @app.get("/api/journal/events")
    def api_journal_events():
        """The risk / engine events (kill switch, limit breaches)."""
        try:
            return jsonify({"ok": True, "events": st().journal.events(
                limit=int(request.args.get("limit", 100)),
                event_type=request.args.get("event_type"),
                run_id=request.args.get("run_id"))})
        except Exception as e:
            return err(str(e))

    @app.get("/api/journal/vocabulary")
    def api_journal_vocabulary():
        """The tag / emotion vocabulary the UI offers."""
        return jsonify({"ok": True, "suggested_tags": SUGGESTED_TAGS,
                        "emotion_states": EMOTION_STATES})

    # ---------------- exports ----------------
    @app.get("/api/export/journal")
    def export_journal():
        return Response(st().journal.to_csv(), mimetype="text/csv",
                        headers={"Content-Disposition": "attachment; filename=quantai_journal.csv"})

    @app.get("/api/export/journal_events")
    def export_journal_events():
        return Response(st().journal.events_csv(), mimetype="text/csv",
                        headers={"Content-Disposition":
                                 "attachment; filename=quantai_journal_events.csv"})

    @app.get("/api/export/journal_breakdown")
    def export_journal_breakdown():
        dimension = request.args.get("dimension", "strategy")
        if dimension not in ("strategy", "emotion", "tag", "symbol"):
            return err("dimension must be strategy, emotion, tag or symbol.", 400)
        return Response(st().journal.breakdown_csv(dimension), mimetype="text/csv",
                        headers={"Content-Disposition":
                                 f"attachment; filename=quantai_journal_{dimension}.csv"})

    @app.get("/api/export/journal_summary")
    def export_journal_summary():
        period = request.args.get("period", "daily")
        try:
            rows = st().journal.summaries(period)
        except Exception as e:
            return err(str(e))
        return _csv_response(rows, f"quantai_journal_{period}.csv")

    @app.get("/api/export/research")
    def export_research():
        r = st().research
        if not r:
            return err("No research run to export.")
        return Response(__import__("json").dumps(r, indent=2), mimetype="application/json",
                        headers={"Content-Disposition": f"attachment; filename={r.get('run_id','research')}.json"})

    @app.get("/api/export/backtests")
    def export_backtests():
        r = st().research
        if not r:
            return err("No research run to export.")
        rows = []
        for mode, b in r["backtests"].items():
            rows.append({"mode": mode, **{k: v for k, v in b.items() if not isinstance(v, (dict, list))}})
        return _csv_response(rows, "quantai_backtest_summary.csv")

    @app.get("/api/export/trades")
    def export_trades():
        r = st().research
        if not r:
            return err("No research run to export.")
        mode = request.args.get("mode", "ensemble")
        trades = r.get("trade_logs", {}).get(mode, [])
        flat = []
        for t in trades:
            flat.append({k: v for k, v in t.items() if not isinstance(v, (dict, list))})
        return _csv_response(flat, f"quantai_trades_{mode}.csv", fieldnames=TRADE_EXPORT_COLS)

    @app.get("/api/export/performance")
    def export_performance():
        r = st().research
        if not r:
            return err("No research run to export.")
        rows = []
        for mode, b in r["backtests"].items():
            rows.append({
                "mode": mode, "label": b["label"], "total_return_pct": b["net_return_pct"],
                "cagr_pct": b.get("cagr_pct"), "sharpe_ratio": b.get("sharpe_ratio"),
                "sortino_ratio": b.get("sortino_ratio"), "max_drawdown_pct": b["max_drawdown_pct"],
                "win_rate_pct": b["win_rate_pct"], "profit_factor": b.get("profit_factor"),
                "avg_profit_per_trade": b.get("avg_profit_per_trade"),
                "avg_loss_per_trade": b.get("avg_loss_per_trade"),
                "risk_reward_ratio": b.get("risk_reward_ratio"), "total_trades": b["total_trades"],
                "max_consecutive_wins": b.get("max_consecutive_wins"),
                "max_consecutive_losses": b.get("max_consecutive_losses"),
                "total_costs": b["total_costs"], "total_slippage": b["total_slippage"],
            })
        return _csv_response(rows, "quantai_performance.csv")

    # ---------------- demo / sample ----------------
    @app.post("/api/demo")
    def api_demo():
        bars = int((request.json or {}).get("bars", 2000))
        bars = int(np.clip(bars, 300, 6000))
        rng = np.random.default_rng(7)
        idx = pd.bdate_range("2015-01-01", periods=bars, freq="B", tz="Asia/Kolkata")
        price, rows = 1000.0, []
        for i, t in enumerate(idx):
            drift = 0.0002 * np.sin(i / 40.0)
            shock = rng.normal(0, 0.008)
            o = price
            c = max(o * (1 + drift + shock), 1.0)
            h = max(o, c) * (1 + abs(rng.normal(0, 0.003)))
            l = min(o, c) * (1 - abs(rng.normal(0, 0.003)))
            rows.append((t.strftime("%Y-%m-%d %H:%M:%S"), round(o, 2), round(h, 2),
                         round(l, 2), round(c, 2), int(rng.integers(50_000, 500_000))))
            price = c
        p = DATA_DIR / "DEMO_TEST_FIXTURE_1D.csv"
        p.write_text("# SYNTHETIC TEST_FIXTURE - NOT REAL MARKET DATA\n" +
                     pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"]).to_csv(index=False),
                     encoding="utf-8")
        meta = st().import_csv(p, "DEMOFIX", "1D", "TEST_FIXTURE", "UNKNOWN_UNVERIFIED")
        return jsonify({"ok": True, "dataset": meta})

    @app.get("/api/sample_csv")
    def api_sample_csv():
        csv_text = ("timestamp,open,high,low,close,volume\n"
                    "2015-01-01 00:00:00,745.00,752.30,743.10,750.85,3254100\n"
                    "2015-01-02 00:00:00,750.85,758.00,749.50,756.20,2987400\n")
        return Response(csv_text, mimetype="text/csv",
                        headers={"Content-Disposition": "attachment; filename=quantai_sample.csv"})

    # ---------------- downloadable builds ----------------
    # The distributable archives live one level ABOVE the app directory (the
    # workspace root). Only these exact names are served — the URL never
    # contributes a path, so this route can not be used to read arbitrary
    # files from the machine.
    DOWNLOADS = {
        "quantai-app.zip": "QuantAI Terminal - web app (Flask). Unzip, then: python app.py",
        "quantai-research.zip": "QuantAI Research Kit - standalone research toolkit",
        "README.md": "QuantAI Terminal - documentation",
    }

    @app.get("/download/<name>")
    def api_download(name):
        """Download a distributable build of this project.

        The name must be in the whitelist above — the URL never contributes
        a path, so this route can not be used to read arbitrary files.
        """
        if name not in DOWNLOADS:
            return err("Unknown download.", 404)
        # The build archives live in the workspace root; the README lives
        # with the app.
        for folder in (WORKSPACE_ROOT, APP_ROOT):
            path = folder / name
            if path.is_file():
                return send_from_directory(str(folder), name, as_attachment=True)
        return err(f"{name} has not been built yet.", 404)

    @app.get("/api/downloads")
    def api_downloads():
        """What can be downloaded, and how big it is."""
        out = []
        for name, note in DOWNLOADS.items():
            path = next((f / name for f in (WORKSPACE_ROOT, APP_ROOT)
                         if (f / name).is_file()), None)
            out.append({"name": name, "note": note,
                        "ready": path is not None,
                        "size_bytes": path.stat().st_size if path else None,
                        "url": f"/download/{name}"})
        return jsonify({"ok": True, "downloads": out})

    return app


app = create_app()

if __name__ == "__main__":
    host = os.environ.get("QUANTAI_HOST", "127.0.0.1")
    port = int(os.environ.get("QUANTAI_PORT", "8000"))
    if host == "0.0.0.0":
        print("WARNING: QUANTAI_HOST=0.0.0.0 exposes the terminal on all interfaces. "
              "Use only in a trusted sandbox/preview. Default is 127.0.0.1.")
    app.run(host=host, port=port, debug=False, threaded=True)
