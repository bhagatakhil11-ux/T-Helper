"""Causal candlestick pattern recognition.

A pattern at bar i is confirmed at the CLOSE of bar i (or the third bar for
3-bar stars) and uses only bars <= i. Patterns are descriptive observations,
NOT guaranteed buy/sell signals. Each detection carries a plain-language
explanation and a directional bias label (bullish/bearish/neutral candidate).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .indicators import atr

PATTERN_NAMES = (
    "Doji", "Hammer", "Inverted Hammer", "Shooting Star",
    "Bullish Engulfing", "Bearish Engulfing",
    "Morning Star", "Evening Star", "Marubozu",
)


def _geom(o, h, l, c):
    body = abs(c - o)
    rng = h - l
    upper = h - max(o, c)
    lower = min(o, c) - l
    return body, rng, upper, lower


def _prior_trend(close: np.ndarray, i: int, lookback: int = 5) -> float:
    """Return close[i-1] - close[i-1-lookback]; 0 if not enough history.

    The lookback shrinks to whatever history exists (minimum 2 bars) so the
    very first candles of a dataset are still classified.
    """
    if i < 2:
        return 0.0
    lb = min(lookback, i - 1)
    j = i - 1 - lb
    if j < 0:
        return 0.0
    return float(close[i - 1] - close[j])


# --- strength scoring -------------------------------------------------------
# A pattern's strength comes from TWO observable things, never from a forecast:
#   * VOLUME  — how heavy the pattern bar was relative to the bars before it
#   * LOCATION — where in the recent range the pattern bar sat
# The two are added into a 0-4 score and banded into weak / medium / strong.

STRENGTH_LABELS = ("weak", "medium", "strong")


def _volume_ratio(vol: np.ndarray, i: int, lookback: int = 20) -> float | None:
    """The pattern bar's volume relative to the mean of the bars BEFORE it.

    Causal by construction: the average never includes the pattern bar itself,
    so a heavy bar is never compared against itself.
    """
    if i < 1 or not np.isfinite(vol[i]) or vol[i] <= 0:
        return None
    start = max(0, i - lookback)
    prior = vol[start:i]
    prior = prior[np.isfinite(prior) & (prior > 0)]
    if len(prior) < 3:
        return None
    mean = float(prior.mean())
    if mean <= 0:
        return None
    return float(vol[i] / mean)


def _volume_score(ratio: float | None) -> tuple[int, str]:
    if ratio is None:
        return 0, "volume not comparable (too little history)"
    if ratio >= 1.5:
        return 2, f"heavy volume ({ratio:.2f}x the recent average)"
    if ratio >= 1.0:
        return 1, f"normal volume ({ratio:.2f}x the recent average)"
    return 0, f"light volume ({ratio:.2f}x the recent average)"


def _location_score(df: pd.DataFrame, i: int, bias: str, atr_series: np.ndarray,
                    lookback: int = 20) -> tuple[int, str]:
    """How well-placed the pattern bar was, in the direction the pattern implies.

    For a bullish pattern the bar's LOW sitting near the bottom of the recent
    range is a good location; for a bearish one the bar's HIGH near the top.
    A neutral pattern (a doji) is scored on EXHAUSTION: indecision right
    after a large move means something, indecision in the middle of a range
    does not.
    """
    start = max(0, i - lookback)
    window = df.iloc[start:i + 1]
    if len(window) < 3:
        return 0, "too little history to judge the location"
    hi = float(window["high"].max())
    lo = float(window["low"].min())
    rng = hi - lo
    if rng <= 0:
        return 0, "flat recent range — no meaningful location"
    if bias == "bullish":
        pos = (float(df["low"].iloc[i]) - lo) / rng
        if pos <= 0.25:
            return 2, "the bar's low sits in the bottom quarter of the recent range"
        if pos <= 0.50:
            return 1, "the bar's low sits in the lower half of the recent range"
        return 0, "the bar's low is in the upper half of the recent range — poor reversal location"
    if bias == "bearish":
        pos = (hi - float(df["high"].iloc[i])) / rng
        if pos <= 0.25:
            return 2, "the bar's high sits in the top quarter of the recent range"
        if pos <= 0.50:
            return 1, "the bar's high sits in the upper half of the recent range"
        return 0, "the bar's high is in the lower half of the recent range — poor reversal location"
    # neutral: exhaustion after a strong prior move
    a = atr_series[i] if i < len(atr_series) else np.nan
    if not np.isfinite(a) or a <= 0:
        return 0, "no ATR available — the location of an indecision bar cannot be rated"
    move = abs(_prior_trend(df["close"].to_numpy(dtype=float), i)) / a
    if move >= 1.5:
        return 2, f"indecision after a {move:.1f} ATR move — exhaustion"
    if move >= 0.75:
        return 1, f"indecision after a {move:.1f} ATR move"
    return 0, "indecision without a meaningful prior move"


def _strength_from(volume_score: int, location_score: int) -> str:
    total = int(volume_score) + int(location_score)
    if total <= 1:
        return "weak"
    if total <= 2:
        return "medium"
    return "strong"


def detect_patterns(df: pd.DataFrame) -> list[dict]:
    o = df["open"].to_numpy(dtype=float)
    h = df["high"].to_numpy(dtype=float)
    l = df["low"].to_numpy(dtype=float)
    c = df["close"].to_numpy(dtype=float)
    v = df["volume"].to_numpy(dtype=float) if "volume" in df.columns else np.zeros(len(df))
    ts = df["timestamp"]
    n = len(df)
    per_bar: dict[int, list[dict]] = {}
    atr_series = atr(df, 14).to_numpy(dtype=float)

    def add(i, name, bias, explanation):
        # Strength: volume + location. Both are measured from the bars UP TO
        # this one, so the score is causal like the pattern itself.
        vratio = _volume_ratio(v, i)
        vscore, vnote = _volume_score(vratio)
        lscore, lnote = _location_score(df, i, bias, atr_series)
        per_bar.setdefault(int(i), []).append({
            "bar": int(i),
            "timestamp": str(ts.iloc[i]),
            "pattern": name,
            "bias": bias,
            "explanation": explanation,
            "confirmed_at_bar": int(i),
            "strength": _strength_from(vscore, lscore),
            "strength_score": int(vscore) + int(lscore),
            "volume_score": int(vscore),
            "location_score": int(lscore),
            "volume_ratio": vratio,
            "volume_note": vnote,
            "location_note": lnote,
            "strength_note": f"{vnote}; {lnote}.",
            "note": "Candlestick patterns are not guaranteed buy/sell signals; confirm with context and risk management.",
        })

    for i in range(n):
        body, rng, upper, lower = _geom(o[i], h[i], l[i], c[i])
        if rng <= 0:
            if body == 0:
                add(i, "Doji", "neutral",
                    "Open, high, low and close are equal (four-price doji): extreme indecision / illiquidity.")
            continue
        body_frac = body / rng
        trend = _prior_trend(c, i)

        # Doji: very small body relative to range.
        if body_frac <= 0.10:
            add(i, "Doji", "neutral",
                "Very small real body relative to the range: indecision between buyers and sellers. "
                "Meaning depends on the preceding trend and the next candle.")

        # Marubozu: almost no shadows.
        if body_frac >= 0.90 and body > 0 and upper <= 0.12 * rng and lower <= 0.12 * rng:
            if c[i] > o[i]:
                add(i, "Marubozu", "bullish",
                    "Bullish marubozu: long green body with little/no shadow; buyers controlled the whole bar.")
            else:
                add(i, "Marubozu", "bearish",
                    "Bearish marubozu: long red body with little/no shadow; sellers controlled the whole bar.")

        small_body = body_frac <= 0.34
        # Hammer: small body near top, long lower shadow, after a decline.
        if small_body and body > 0 and lower >= 2 * body and upper <= max(body, 0.15 * rng) and trend < 0:
            add(i, "Hammer", "bullish",
                "Small body near the high with a long lower shadow after a decline: sellers pushed price down "
                "but buyers recovered it. Potential bullish reversal; needs confirmation.")

        # Inverted hammer / shooting star: small body near low, long upper shadow.
        if small_body and body > 0 and upper >= 2 * body and lower <= max(body, 0.15 * rng):
            if trend < 0:
                add(i, "Inverted Hammer", "bullish",
                    "Small body near the low with a long upper shadow after a decline: buyers attempted a rally. "
                    "Potential bullish reversal; needs confirmation.")
            elif trend > 0:
                add(i, "Shooting Star", "bearish",
                    "Small body near the low with a long upper shadow after an advance: rally was rejected. "
                    "Potential bearish reversal; needs confirmation.")

        # Engulfing (needs previous bar).
        if i >= 1:
            pb = abs(c[i - 1] - o[i - 1])
            prev_bear = c[i - 1] < o[i - 1]
            prev_bull = c[i - 1] > o[i - 1]
            if prev_bear and c[i] > o[i] and o[i] <= c[i - 1] and c[i] >= o[i - 1] and body > pb:
                add(i, "Bullish Engulfing", "bullish",
                    "A green real body fully engulfs the prior red body: buyers overwhelmed the previous session's selling.")
            if prev_bull and c[i] < o[i] and o[i] >= c[i - 1] and c[i] <= o[i - 1] and body > pb:
                add(i, "Bearish Engulfing", "bearish",
                    "A red real body fully engulfs the prior green body: sellers overwhelmed the previous session's buying.")

        # Three-bar stars.
        if i >= 2:
            b1, r1, _, _ = _geom(o[i - 2], h[i - 2], l[i - 2], c[i - 2])
            b2, r2, _, _ = _geom(o[i - 1], h[i - 1], l[i - 1], c[i - 1])
            b3, r3, _, _ = _geom(o[i], h[i], l[i], c[i])
            mid1 = (o[i - 2] + c[i - 2]) / 2.0
            long1 = r1 > 0 and b1 / r1 >= 0.5
            long3 = r3 > 0 and b3 / r3 >= 0.5
            star = b2 <= 0.5 * b1 if b1 > 0 else False
            # Morning Star: long red, small star lower, long green closing above midpoint of first body.
            if long1 and star and long3 and c[i - 2] < o[i - 2] and c[i] > o[i] \
               and max(o[i - 1], c[i - 1]) < min(o[i - 2], c[i - 2]) and c[i] > mid1:
                add(i, "Morning Star", "bullish",
                    "Three-bar bottom reversal: long red body, a small-bodied star gapping lower, then a long green "
                    "body closing well into the first body. Potential bullish reversal.")
            # Evening Star: long green, small star higher, long red closing below midpoint of first body.
            if long1 and star and long3 and c[i - 2] > o[i - 2] and c[i] < o[i] \
               and min(o[i - 1], c[i - 1]) > max(o[i - 2], c[i - 2]) and c[i] < mid1:
                add(i, "Evening Star", "bearish",
                    "Three-bar top reversal: long green body, a small-bodied star gapping higher, then a long red "
                    "body closing well into the first body. Potential bearish reversal.")

    out: list[dict] = []
    for bar in sorted(per_bar):
        found = per_bar[bar]
        names = {p["pattern"] for p in found}
        # A Doji is a catch-all shape: when a more specific pattern fires on the
        # same candle we keep the specific one (and note the doji-like body).
        if len(names) > 1 and "Doji" in names:
            found = [p for p in found if p["pattern"] != "Doji"]
            for p in found:
                p["explanation"] += " Body is doji-like (near-zero real body)."
        out.extend(found)
    out.sort(key=lambda p: (p["bar"], p["pattern"]))
    return out
