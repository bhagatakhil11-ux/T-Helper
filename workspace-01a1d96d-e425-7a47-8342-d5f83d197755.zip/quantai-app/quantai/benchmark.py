"""NIFTY 50 benchmark comparison.

The benchmark is NEVER fabricated. It is computed only from a user-imported
NIFTY 50 dataset that overlaps the strategy's unseen-test window. If no such
dataset exists, the report says so explicitly instead of inventing numbers.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import BARS_PER_YEAR
from .metrics import cagr_pct, max_drawdown_pct


def _to_ist_dates(ts: pd.Series) -> pd.Series:
    return ts.dt.tz_convert("Asia/Kolkata").dt.normalize()


def nifty_benchmark(
    nifty_df: pd.DataFrame | None,
    strategy_df: pd.DataFrame,
    test_start_bar: int,
    initial_capital: float,
    timeframe: str,
) -> dict:
    """Compare buy-and-hold NIFTY 50 over the exact strategy test window.

    Returns a dict with status. `status == 'ok'` only when real overlap exists.
    """
    base = {
        "status": "missing", "label": "NIFTY 50 buy & hold",
        "message": "No NIFTY 50 dataset imported. Import NIFTY 50 OHLCV (symbol NIFTY50) to enable benchmark comparison.",
        "net_return_pct": None, "cagr_pct": None, "max_drawdown_pct": None,
        "sharpe_ratio": None, "sortino_ratio": None, "overlap_bars": 0,
        "equity_curve": [], "window": None,
    }
    if nifty_df is None or len(nifty_df) < 2:
        return base

    strat_ts = strategy_df["timestamp"].dt.tz_convert("Asia/Kolkata")
    start_ts = strat_ts.iloc[test_start_bar]
    end_ts = strat_ts.iloc[-1]

    nts = nifty_df["timestamp"].dt.tz_convert("Asia/Kolkata")
    if timeframe == "1D":
        # Align on calendar dates for daily data.
        s_dates = _to_ist_dates(strat_ts.iloc[test_start_bar:])
        n_dates = _to_ist_dates(nts)
        mask = n_dates.isin(set(s_dates))
        aligned = nifty_df.loc[mask].copy()
        overlap = int(mask.sum())
    else:
        mask = (nts >= start_ts) & (nts <= end_ts)
        aligned = nifty_df.loc[mask].copy()
        overlap = int(mask.sum())

    if overlap < 2:
        base["message"] = (f"NIFTY 50 dataset has only {overlap} overlapping bar(s) with the test window "
                           f"({start_ts.isoformat()} → {end_ts.isoformat()}). Import matching history.")
        return base

    close = aligned["close"].astype(float).to_numpy()
    equity = initial_capital * close / close[0]
    ret = float((close[-1] / close[0] - 1) * 100)
    dd = max_drawdown_pct(equity.tolist())
    cagr, _ = cagr_pct(initial_capital, float(equity[-1]),
                       aligned["timestamp"].iloc[0], aligned["timestamp"].iloc[-1])
    bar_ret = np.diff(equity) / equity[:-1]
    bpy = BARS_PER_YEAR.get(timeframe, 252.0)
    sharpe = sortino = None
    if len(bar_ret) > 2 and np.std(bar_ret, ddof=1) > 1e-12:
        sharpe = float(np.mean(bar_ret) / np.std(bar_ret, ddof=1) * np.sqrt(bpy))
        down = bar_ret[bar_ret < 0]
        if len(down) and np.sqrt(np.mean(down ** 2)) > 1e-12:
            sortino = float(np.mean(bar_ret) / np.sqrt(np.mean(down ** 2)) * np.sqrt(bpy))

    return {
        "status": "ok", "label": "NIFTY 50 buy & hold",
        "message": f"Computed from {overlap} imported NIFTY 50 bars overlapping the test window. "
                   "Index buy-and-hold is shown gross of costs (an index is not directly tradable; "
                   "use an ETF/fund with its own costs for a like-for-like comparison).",
        "net_return_pct": ret, "cagr_pct": cagr, "max_drawdown_pct": dd,
        "sharpe_ratio": sharpe, "sortino_ratio": sortino, "overlap_bars": overlap,
        "equity_curve": [float(x) for x in equity],
        "window": {"start": str(aligned["timestamp"].iloc[0]), "end": str(aligned["timestamp"].iloc[-1])},
    }
