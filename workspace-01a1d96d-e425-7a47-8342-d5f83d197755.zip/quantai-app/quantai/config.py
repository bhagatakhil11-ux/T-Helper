"""Configuration, provenance enums, and the dated Indian cost model.

Nothing here fetches data or places orders. This is a RESEARCH-ONLY toolkit.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum


class DataOrigin(str, Enum):
    SIMULATED = "SIMULATED"
    TEST_FIXTURE = "TEST_FIXTURE"
    IMPORTED_CSV = "IMPORTED_CSV"
    BROKER_VENDOR = "BROKER_VENDOR"
    DATA_FEED = "DATA_FEED"          # fetched from a user-configured authorized feed


class VerificationStatus(str, Enum):
    SIMULATED_NOT_REAL = "SIMULATED_NOT_REAL"
    TEST_FIXTURE_NOT_MARKET_DATA = "TEST_FIXTURE_NOT_MARKET_DATA"
    IMPORTED_CSV_UNVERIFIED = "IMPORTED_CSV_UNVERIFIED"
    VERIFIED_EXCHANGE_OR_VENDOR = "VERIFIED_EXCHANGE_OR_VENDOR"
    DATA_FEED_UNVERIFIED = "DATA_FEED_UNVERIFIED"   # fetched, but content NOT independently verified


class ResearchQuality(str, Enum):
    RESEARCH_GRADE = "RESEARCH_GRADE"
    LOW_CONFIDENCE_INSUFFICIENT_DATA = "LOW_CONFIDENCE_INSUFFICIENT_DATA"


SUPPORTED_TIMEFRAMES = ("1m", "5m", "15m", "1D")

# Minimum bars for the pipeline to even run (plumbing check, NOT research quality).
MIN_SMOKE_TEST_BARS = 80

# Minimum bars before results deserve any research attention.
RESEARCH_MIN_BARS = {"1D": 1500, "15m": 7500, "5m": 15000, "1m": 30000}

# Annualisation factors: NSE has ~252 sessions/year, 375 minutes/session.
BARS_PER_YEAR = {"1D": 252.0, "15m": 252.0 * 25.0, "5m": 252.0 * 75.0, "1m": 252.0 * 375.0}

IST = "Asia/Kolkata"
SESSION_START_MIN = 9 * 60 + 15   # 09:15
SESSION_END_MIN = 15 * 60 + 30    # 15:30

# Bar interval, in minutes, for each intraday timeframe.
INTERVAL_MIN = {"1m": 1, "5m": 5, "15m": 15}


def research_quality(candle_count: int, timeframe: str, overrides: dict | None = None) -> ResearchQuality:
    table = dict(RESEARCH_MIN_BARS)
    if overrides:
        table.update(overrides)
    required = table.get(timeframe, 1500)
    return (
        ResearchQuality.RESEARCH_GRADE
        if candle_count >= required
        else ResearchQuality.LOW_CONFIDENCE_INSUFFICIENT_DATA
    )


def required_research_bars(timeframe: str, overrides: dict | None = None) -> int:
    table = dict(RESEARCH_MIN_BARS)
    if overrides:
        table.update(overrides)
    return table.get(timeframe, 1500)


@dataclass(frozen=True)
class CostModel:
    """Dated, configurable NSE equity cost model.

    Rates are ASSUMPTIONS, not live broker quotes. Verify against your own broker's
    contract note before trusting any net-profit number.
    """

    effective_date: str = "2025-10-01"
    is_intraday: bool = False
    delivery_stt: float = 0.0010          # 0.10% both legs
    intraday_stt_sell: float = 0.00025    # 0.025% sell leg only
    exchange_turnover: float = 0.0000325  # NSE CM
    sebi_fee: float = 0.0000010           # Rs 10 / crore
    stamp_delivery_buy: float = 0.00015
    stamp_intraday_buy: float = 0.00003
    brokerage_flat_inr: float = 20.0
    brokerage_pct_cap: float = 0.0003
    gst: float = 0.18
    slippage_pct: float = 0.0003          # per fill, 3 bps

    def leg_cost(self, turnover: float, is_buy: bool) -> dict:
        if turnover <= 0:
            return {k: 0.0 for k in
                    ("stt", "brokerage", "exchange", "sebi", "stamp", "gst", "total")}
        stt = (0.0 if (self.is_intraday and is_buy)
               else turnover * (self.intraday_stt_sell if self.is_intraday else self.delivery_stt))
        brokerage = min(self.brokerage_flat_inr, turnover * self.brokerage_pct_cap)
        exchange = turnover * self.exchange_turnover
        sebi = turnover * self.sebi_fee
        stamp = turnover * (self.stamp_intraday_buy if self.is_intraday else self.stamp_delivery_buy) if is_buy else 0.0
        gst = (brokerage + exchange + sebi) * self.gst
        total = stt + brokerage + exchange + sebi + stamp + gst
        return dict(stt=stt, brokerage=brokerage, exchange=exchange, sebi=sebi,
                    stamp=stamp, gst=gst, total=total)

    def summary(self) -> str:
        mode = "Intraday" if self.is_intraday else "Delivery"
        stt = "0.025% sell-only" if self.is_intraday else "0.10% both legs"
        return (f"NSE {mode} (assumed effective {self.effective_date}): "
                f"slippage {self.slippage_pct * 100:.3f}%/fill, STT {stt}, "
                f"brokerage min(Rs{self.brokerage_flat_inr:.0f}, {self.brokerage_pct_cap * 100:.2f}%), "
                f"exchange+SEBI+stamp+{self.gst * 100:.0f}% GST")


@dataclass
class RiskConfig:
    """Hard limits. The backtest and replay may never override these."""

    initial_capital: float = 500_000.0
    risk_per_trade_pct: float = 0.5       # % of capital risked to the stop
    max_daily_drawdown_pct: float = 2.0
    max_weekly_drawdown_pct: float = 5.0  # NEW: blocks NEW entries until the next ISO week
    max_total_drawdown_pct: float = 15.0  # halt ALL trading if peak-to-trough breaches this
    max_exposure_pct: float = 50.0
    max_open_positions: int = 1           # single-symbol engine: enforced cap (see README)
    max_consecutive_losses: int = 3
    cooldown_bars: int = 15
    # The cooldown LENGTHENS with the loss streak, in three BANDS:
    #   band 1 — `max_consecutive_losses` .. +1 losses -> `cooldown_bars`
    #   band 2 — the next two losses             -> `cooldown_bars_level2`
    #   band 3 — 7+ losses                       -> `cooldown_bars_level3`
    # With the defaults (threshold 3): 3-4 losses -> 15 bars, 5-6 -> 30 bars,
    # 7 or more -> 50 bars. Band 3 is FLAT: the cooldown does not keep
    # growing, so a long losing streak can never lock the engine out for an
    # unbounded number of bars. See quantai.risk_rules.progressive_cooldown_bars.
    cooldown_bars_level2: int = 30
    cooldown_bars_level3: int = 50
    progressive_cooldown: bool = True
    # NEW: scale the risk per trade down when the market is more volatile than
    # `risk_vol_target_pct` (ATR as a % of price). Off by default so the
    # sizing of an existing research run is unchanged until it is switched on.
    auto_risk_by_volatility: bool = False
    risk_vol_target_pct: float = 2.0      # the "normal" ATR% for this instrument
    risk_vol_min_factor: float = 0.25     # never risk less than 25% of the base
    risk_vol_max_factor: float = 2.0      # never risk more than 200% of the base
    stop_atr_mult: float = 1.8
    target_atr_mult: float = 3.6
    max_cash_fraction: float = 0.95       # never deploy 100% of cash

    def summary(self) -> str:
        vol = ("off" if not self.auto_risk_by_volatility else
               f"ATR% target {self.risk_vol_target_pct:.2f}% "
               f"(x{self.risk_vol_min_factor:.2f}-{self.risk_vol_max_factor:.2f})")
        cd = ("fixed" if not self.progressive_cooldown else
              f"progressive ({self.max_consecutive_losses}L->{self.cooldown_bars}b, "
              f"+2L->{self.cooldown_bars_level2}b, "
              f"{self.max_consecutive_losses + 4}+L->{self.cooldown_bars_level3}b)")
        return (f"risk/trade {self.risk_per_trade_pct:.2f}% ({vol}), "
                f"day DD {self.max_daily_drawdown_pct:.2f}%, "
                f"week DD {self.max_weekly_drawdown_pct:.2f}%, "
                f"total DD {self.max_total_drawdown_pct:.2f}%, "
                f"exposure {self.max_exposure_pct:.1f}%, "
                f"cooldown after {self.max_consecutive_losses} losses ({cd})")


@dataclass(frozen=True)
class ExecutionConfig:
    """Configurable execution assumptions. The fill TIMING contract is fixed
    (signal at close -> next-bar open) and cannot be relaxed here."""

    slippage_bps: float = 3.0                 # per fill, basis points
    brokerage_flat_inr: float = 20.0
    brokerage_pct_cap: float = 0.0003
    max_volume_participation_pct: float = 0.0  # 0 = disabled; >0 caps qty to % of signal-bar volume

    def to_cost_model(self, is_intraday: bool) -> CostModel:
        return CostModel(
            is_intraday=is_intraday,
            slippage_pct=self.slippage_bps / 10_000.0,
            brokerage_flat_inr=self.brokerage_flat_inr,
            brokerage_pct_cap=self.brokerage_pct_cap,
        )

    def summary(self) -> str:
        vol = ("disabled" if self.max_volume_participation_pct <= 0
               else f"{self.max_volume_participation_pct:.2f}% of signal-bar volume")
        return (f"slippage {self.slippage_bps:.2f} bps/fill, "
                f"brokerage min(Rs{self.brokerage_flat_inr:.0f}, {self.brokerage_pct_cap * 100:.3f}%), "
                f"volume participation cap {vol}")


@dataclass
class ResearchConfig:
    symbol: str = "RELIANCE"
    timeframe: str = "1D"
    forward_horizon: int = 5
    return_threshold: float = 0.0020
    train_frac: float = 0.60
    val_frac: float = 0.20
    # Minimum bars of history before a row may become a training sample.
    # This is a FLOOR: build_dataset() raises it to quantai.features.FEATURE_WARMUP
    # (60) so no row is ever built from a shorter price history than the
    # longest feature look-back (the 200-period EMA and the 100-period ATR
    # baseline both need 60 settled bars).
    warmup_bars: int = 60
    n_estimators: int = 300
    max_depth: int = 6
    min_samples_leaf: int = 20
    random_state: int = 42
    walk_forward_folds: int = 4
    cost: CostModel = field(default_factory=CostModel)
    risk: RiskConfig = field(default_factory=RiskConfig)

    def to_dict(self) -> dict:
        d = asdict(self)
        return d
