"""Strictly causal features, forward labels, and purged chronological splits.

CAUSALITY CONTRACT
------------------
Every feature at row ``i`` is a function of rows ``0..i`` ONLY. Concretely:

* ``pct_change``, ``diff`` and ``shift(n)`` with ``n > 0`` look backwards.
* ``rolling``/``ewm`` are left-trailing by construction (no ``center=True``).
* Nothing here ever reads row ``i + k``. ``tests/test_features_causality.py``
  proves it by mutating future bars and asserting that every earlier feature
  value is bit-identical.

Feature-set version
-------------------
``FEATURE_VERSION`` is part of the model id, so a model trained on an older
feature set is never silently reused for a newer one.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict

import numpy as np
import pandas as pd

#: The feature set, in the exact column order the model is trained on.
FEATURE_NAMES = [
    # --- returns over past windows ---
    "return_1", "return_3", "return_5", "return_10",
    # --- volatility ---
    "atr_ratio", "atr_expansion", "volatility_20", "volatility_ratio",
    # --- volume ---
    "volume_ratio", "volume_trend", "volume_zscore",
    # --- price distance from EMAs ---
    "ema_9_dist", "ema_21_dist", "ema_50_dist", "ema_200_dist", "ema_9_21_diff",
    # --- RSI ---
    "rsi_14_norm", "rsi_slope_5",
    # --- MACD ---
    "macd_hist_norm", "macd_norm", "macd_cross",
    # --- Bollinger ---
    "bb_percent_b",
]

FEATURE_VERSION = "features-v2.0"
CLASSES = ["DOWN", "SIDE", "UP"]  # index order used everywhere

#: Minimum number of bars any single feature is allowed to consume. The slow
#: EMAs (50/200) use this as their ``min_periods`` so that a 200-EMA is
#: available after 60 bars instead of 200 — it is still a strictly causal
#: estimate, it is simply an estimate from a shorter history. Rows before this
#: index are excluded from training so the model is never scored on features
#: built from a shorter history than the one it was trained on.
FEATURE_WARMUP = 60


def _rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0.0)
    loss = (-delta).clip(lower=0.0)
    avg_gain = gain.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    rs = avg_gain / avg_loss.replace(0.0, np.nan)
    rsi = 100 - 100 / (1 + rs)
    return rsi.fillna(100.0).where(avg_loss.notna(), 50.0)


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """Every value at row i uses only rows 0..i (rolling / ewm are causal).

    The eight original features keep their exact formulas and their exact
    values, so every downstream consumer (rules-only backtest, paper replay,
    older reports) behaves identically.
    """
    close = df["close"].astype(float)
    high = df["high"].astype(float)
    low = df["low"].astype(float)
    vol = df["volume"].astype(float)
    denom = close.replace(0.0, np.nan)

    out = pd.DataFrame(index=df.index)

    # ---------------- returns (past windows only) ----------------
    out["return_1"] = close.pct_change(1)
    out["return_3"] = close.pct_change(3)
    out["return_5"] = close.pct_change(5)
    out["return_10"] = close.pct_change(10)

    # ---------------- volatility ----------------
    prev_close = close.shift(1)
    tr = pd.concat([high - low, (high - prev_close).abs(), (low - prev_close).abs()],
                   axis=1).max(axis=1)
    atr = tr.ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    atr_slow = tr.ewm(span=100, adjust=False, min_periods=1).mean()
    out["atr"] = atr                    # used by the backtest for stops, never a model feature
    out["atr_ratio"] = atr / close      # unchanged formula
    # ATR now vs its own slow baseline: >0 means volatility is expanding.
    out["atr_expansion"] = atr / atr_slow.replace(0.0, np.nan) - 1.0

    ret_1 = close.pct_change(1)
    vol_std_20 = ret_1.rolling(20, min_periods=20).std(ddof=0)
    vol_std_5 = ret_1.rolling(5, min_periods=5).std(ddof=0)
    out["volatility_20"] = vol_std_20
    # Short-horizon volatility against the long horizon: >0 = calm, <0 = jittery.
    out["volatility_ratio"] = vol_std_5 / vol_std_20.replace(0.0, np.nan)

    # ---------------- volume ----------------
    avg_vol = vol.rolling(20, min_periods=20).mean()
    out["volume_ratio"] = (vol / avg_vol.replace(0.0, np.nan)).clip(0.2, 5.0).fillna(1.0)  # unchanged
    vol_ma_5 = vol.rolling(5, min_periods=5).mean()
    # Volume trend: recent 5-bar average against the 20-bar average.
    out["volume_trend"] = vol_ma_5 / avg_vol.replace(0.0, np.nan) - 1.0
    vol_sd_20 = vol.rolling(20, min_periods=20).std(ddof=0)
    out["volume_zscore"] = (vol - avg_vol) / vol_sd_20.replace(0.0, np.nan)

    # ---------------- price distance from EMAs ----------------
    for span in (9, 21, 50, 200):
        # min_periods only masks the warm-up; the underlying EWM numbers are
        # identical to the full-history ones, so this stays strictly causal.
        mp = min(span, FEATURE_WARMUP)
        e = close.ewm(span=span, adjust=False, min_periods=mp).mean()
        # Positive = trading above the EMA, negative = below.
        out[f"ema_{span}_dist"] = (close - e) / denom

    ema12 = close.ewm(span=12, adjust=False, min_periods=12).mean()
    ema26 = close.ewm(span=26, adjust=False, min_periods=26).mean()
    macd = ema12 - ema26
    signal = macd.ewm(span=9, adjust=False, min_periods=9).mean()

    ema9 = close.ewm(span=9, adjust=False, min_periods=9).mean()
    ema21 = close.ewm(span=21, adjust=False, min_periods=21).mean()
    out["ema_9_21_diff"] = (ema9 - ema21) / close  # unchanged

    # ---------------- RSI ----------------
    rsi = _rsi(close)
    out["rsi_14_norm"] = (rsi - 50.0) / 50.0   # unchanged
    # Momentum of RSI itself over 5 bars, normalised to [-1, 1].
    out["rsi_slope_5"] = (rsi - rsi.shift(5)) / 50.0

    # ---------------- MACD ----------------
    out["macd_hist_norm"] = (macd - signal) / close   # unchanged
    out["macd_norm"] = macd / denom
    # +1 while the MACD line is above its signal line, -1 below, 0 exactly equal.
    out["macd_cross"] = np.sign(macd - signal)

    # ---------------- Bollinger ----------------
    mid = close.rolling(20, min_periods=20).mean()
    sd = close.rolling(20, min_periods=20).std(ddof=0)
    band = (4.0 * sd).replace(0.0, np.nan)
    out["bb_percent_b"] = ((close - (mid - 2 * sd)) / band).fillna(0.5)  # unchanged

    return out


def make_labels(close: pd.Series, horizon: int, round_trip_cost: float, threshold: float) -> pd.Series:
    """Label at i uses close[i+horizon] ONLY. Rows without a future bar get NaN."""
    fwd = close.shift(-horizon) / close - 1.0
    hurdle = round_trip_cost + threshold
    lab = pd.Series(np.nan, index=close.index, dtype="float64")
    lab[fwd > hurdle] = 2.0   # UP
    lab[fwd < -hurdle] = 1.0  # SIDE
    lab[(fwd <= hurdle) & (fwd >= -hurdle)] = 1.0
    lab[fwd < -hurdle] = 0.0  # DOWN
    lab[fwd.isna()] = np.nan
    return lab


@dataclass
class SplitInfo:
    train_idx: np.ndarray
    val_idx: np.ndarray
    test_idx: np.ndarray
    purged_idx: np.ndarray
    feature_version: str = FEATURE_VERSION

    def to_dict(self) -> dict:
        def rng(a):
            return {"count": int(len(a)),
                    "first_candle": int(a[0]) if len(a) else None,
                    "last_candle": int(a[-1]) if len(a) else None}
        return {"train": rng(self.train_idx), "validation": rng(self.val_idx),
                "test": rng(self.test_idx), "purged": rng(self.purged_idx),
                "feature_version": self.feature_version}


def purged_split(sample_candles: np.ndarray, horizon: int,
                 train_frac: float = 0.60, val_frac: float = 0.20) -> SplitInfo:
    """Chronological split with `horizon` sample purge gaps so labels cannot overlap.

    sample_candles are the ORIGINAL candle indices of each labelled sample.
    """
    n = len(sample_candles)
    train_end = int(n * train_frac)
    val_start = train_end + horizon
    val_count = max(1, int(n * val_frac))
    val_end = min(val_start + val_count, n)
    test_start = val_end + horizon
    if train_end < 20 or test_start >= n:
        raise ValueError(
            f"Not enough samples for a purged split (n={n}, horizon={horizon}). "
            "Import more history; do not shrink the purge to force a result."
        )
    all_pos = np.arange(n)
    train_pos = all_pos[:train_end]
    val_pos = all_pos[val_start:val_end]
    test_pos = all_pos[test_start:]
    purged = np.concatenate([all_pos[train_end:val_start], all_pos[val_end:test_start]])
    return SplitInfo(
        train_idx=sample_candles[train_pos], val_idx=sample_candles[val_pos],
        test_idx=sample_candles[test_pos], purged_idx=sample_candles[purged],
    )


def build_dataset(df: pd.DataFrame, horizon: int, round_trip_cost: float,
                  threshold: float, warmup: int = 35):
    """Build the (X, y, candle_index, features) training set.

    ``warmup`` is raised to :data:`FEATURE_WARMUP` so that no training row is
    built from a shorter price history than the longest feature look-back.
    """
    feats = build_features(df)
    labels = make_labels(df["close"], horizon, round_trip_cost, threshold)
    usable = feats[FEATURE_NAMES].notna().all(axis=1) & labels.notna()
    effective_warmup = max(int(warmup), FEATURE_WARMUP)
    usable &= pd.Series(df.index >= effective_warmup, index=df.index)
    pos = np.flatnonzero(usable.to_numpy())
    X = feats.loc[pos, FEATURE_NAMES].to_numpy(dtype=float)
    y = labels.iloc[pos].to_numpy(dtype=int)
    return X, y, pos, feats
