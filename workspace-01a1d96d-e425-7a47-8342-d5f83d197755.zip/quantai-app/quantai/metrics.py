"""Performance analytics computed from realised equity curves and closed trades.

Every metric here is derived from actual simulated fills — nothing is invented.
Metrics that are statistically meaningless on short windows return None with a
reason instead of a misleading number.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from .config import BARS_PER_YEAR


def _streaks(pnls: list[float]) -> tuple[int, int]:
    max_w = max_l = cur_w = cur_l = 0
    for p in pnls:
        if p > 0:
            cur_w += 1
            cur_l = 0
        elif p < 0:
            cur_l += 1
            cur_w = 0
        else:
            cur_w = cur_l = 0
        max_w = max(max_w, cur_w)
        max_l = max(max_l, cur_l)
    return max_w, max_l


def max_drawdown_pct(equity: list[float]) -> float:
    peak = -math.inf
    dd = 0.0
    for v in equity:
        peak = max(peak, v)
        if peak > 0:
            dd = max(dd, (peak - v) / peak * 100.0)
    return float(dd)


def cagr_pct(initial: float, final: float, start_ts, end_ts) -> tuple[float | None, str]:
    """Calendar-time CAGR. None when the window is too short to annualise honestly."""
    if initial <= 0 or final <= 0:
        return None, "N/A: non-positive equity"
    try:
        days = (pd.Timestamp(end_ts) - pd.Timestamp(start_ts)).total_seconds() / 86400.0
    except Exception:
        return None, "N/A: missing timestamps"
    if days < 30:
        return None, f"N/A: window is {days:.0f} days; CAGR needs >= 30 days"
    years = days / 365.25
    return float(((final / initial) ** (1.0 / years) - 1.0) * 100.0), f"Calendar-time CAGR over {years:.2f} years"


def risk_adjusted(returns: np.ndarray, timeframe: str, n_trades: int,
                  min_bars: int = 30, min_trades: int = 5) -> dict:
    """Annualised Sharpe and Sortino from per-bar MTM returns.

    Returns None (not 0.0) when there is too little data — a fake 0.0 would be
    indistinguishable from a genuinely flat strategy.
    """
    bpy = BARS_PER_YEAR.get(timeframe, 252.0)
    out = {"sharpe": None, "sharpe_reason": "", "sortino": None, "sortino_reason": ""}
    if len(returns) < 2:
        out["sharpe_reason"] = out["sortino_reason"] = "N/A: insufficient return observations"
        return out
    if len(returns) < min_bars or n_trades < min_trades:
        msg = f"N/A: needs >= {min_bars} bars and >= {min_trades} closed trades (got {len(returns)} bars, {n_trades} trades)"
        out["sharpe_reason"] = out["sortino_reason"] = msg
        return out
    sd = float(np.std(returns, ddof=1))
    mean = float(np.mean(returns))
    if sd <= 1e-12:
        out["sharpe_reason"] = "N/A: zero return volatility"
    else:
        out["sharpe"] = mean / sd * math.sqrt(bpy)
        out["sharpe_reason"] = f"Annualised MTM bar Sharpe (bars/year={bpy:.0f})"
    # Standard Sortino downside deviation: sqrt(mean(min(r,0)^2)) over ALL bars
    # (positive bars contribute zero). Averaging over only the negative bars is a
    # non-standard variant that changes the result; we use the canonical all-bar form.
    downside = np.minimum(returns, 0.0)
    dd_dev = float(np.sqrt(np.mean(downside ** 2)))
    if dd_dev <= 1e-12:
        out["sortino_reason"] = "N/A: no downside; downside deviation is zero"
    else:
        out["sortino"] = mean / dd_dev * math.sqrt(bpy)
        out["sortino_reason"] = f"Annualised Sortino, downside deviation vs 0 over all bars (bars/year={bpy:.0f})"
    return out


def performance_metrics(
    equity_curve: list[float],
    trades: list[dict],
    initial_capital: float,
    timeframe: str,
    timestamps: list | None = None,
    max_dd_override: float | None = None,
    min_trades_for_ratio: int = 5,
) -> dict:
    """Full analytics block for one strategy / replay run.

    `max_dd_override` lets the caller pass an intrabar (worst-low) drawdown that
    is stricter than the close-to-close curve drawdown.
    """
    eq = np.asarray(equity_curve, dtype=float)
    final = float(eq[-1]) if len(eq) else initial_capital
    total_return = (final - initial_capital) / initial_capital * 100.0 if initial_capital > 0 else 0.0

    pnls = [float(t.get("pnl", 0.0)) for t in trades]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p < 0]
    n = len(pnls)
    gross_win = sum(wins)
    gross_loss = abs(sum(losses))
    avg_win = gross_win / len(wins) if wins else 0.0
    avg_loss = gross_loss / len(losses) if losses else 0.0
    pf = (gross_win / gross_loss) if gross_loss > 0 else (None if gross_win == 0 else float("inf"))
    rr = (avg_win / avg_loss) if avg_loss > 0 else None
    max_w, max_l = _streaks(pnls)

    returns = np.diff(eq) / eq[:-1] if len(eq) > 1 else np.array([])
    returns = returns[np.isfinite(returns)]
    ratios = risk_adjusted(returns, timeframe, n, min_trades=min_trades_for_ratio)

    cagr, cagr_reason = (None, "N/A: no timestamps")
    if timestamps is not None and len(timestamps) >= 2:
        cagr, cagr_reason = cagr_pct(initial_capital, final, timestamps[0], timestamps[-1])

    dd = max_drawdown_pct(equity_curve) if len(equity_curve) else 0.0
    if max_dd_override is not None:
        dd = max(dd, max_dd_override)

    return {
        "total_return_pct": float(total_return),
        "cagr_pct": cagr,
        "cagr_status": cagr_reason,
        "sharpe_ratio": ratios["sharpe"],
        "sharpe_status": ratios["sharpe_reason"],
        "sortino_ratio": ratios["sortino"],
        "sortino_status": ratios["sortino_reason"],
        "max_drawdown_pct": float(dd),
        "win_rate_pct": float(len(wins) / n * 100.0) if n else 0.0,
        "profit_factor": pf,
        "avg_profit_per_trade": float(avg_win),
        "avg_loss_per_trade": float(avg_loss),
        "avg_pnl_per_trade": float(sum(pnls) / n) if n else 0.0,
        "risk_reward_ratio": rr,
        "total_trades": n,
        "winning_trades": len(wins),
        "losing_trades": len(losses),
        "max_consecutive_wins": max_w,
        "max_consecutive_losses": max_l,
        "expectancy_per_trade": float(sum(pnls) / n) if n else 0.0,
    }


# ---------------------------------------------------------------------------
# Live (running) replay statistics
# ---------------------------------------------------------------------------

def new_live_stats() -> dict:
    """A fresh, zeroed running-statistics accumulator.

    The accumulator is updated **once per closed trade**, so the numbers the
    dashboard shows never depend on how long the in-memory trade list is.
    That matters: capping the trade list would silently change the win rate.
    """
    return {
        "trades": 0, "wins": 0, "losses": 0, "breakeven": 0,
        "gross_profit": 0.0, "gross_loss": 0.0, "sum_pnl": 0.0,
        "total_costs": 0.0, "sum_costs": 0.0,
        "best_trade": None, "worst_trade": None,
        "current_streak": 0, "streak_kind": "",
        "max_win_streak": 0, "max_loss_streak": 0,
        "largest_win": 0.0, "largest_loss": 0.0,
        "win_streak_pnl": 0.0,
    }


def update_live_stats(stats: dict, pnl: float, costs: float = 0.0) -> dict:
    """Fold one closed trade into the running accumulator (in place).

    A trade with ``pnl == 0`` counts as a breakeven, not as a loss — folding
    it into the loss bucket would quietly understate the win rate.
    """
    pnl = float(pnl)
    costs = float(costs or 0.0)
    stats["trades"] = int(stats.get("trades", 0)) + 1
    stats["sum_pnl"] = float(stats.get("sum_pnl", 0.0)) + pnl
    stats["total_costs"] = float(stats.get("total_costs", 0.0)) + costs
    stats["sum_costs"] = float(stats.get("sum_costs", 0.0)) + costs
    if stats.get("best_trade") is None or pnl > stats["best_trade"]:
        stats["best_trade"] = pnl
    if stats.get("worst_trade") is None or pnl < stats["worst_trade"]:
        stats["worst_trade"] = pnl

    if pnl > 0:
        stats["wins"] = int(stats.get("wins", 0)) + 1
        stats["gross_profit"] = float(stats.get("gross_profit", 0.0)) + pnl
        stats["largest_win"] = max(float(stats.get("largest_win", 0.0)), pnl)
        stats["win_streak_pnl"] = float(stats.get("win_streak_pnl", 0.0)) + pnl
        stats["streak_kind"] = "win"
    elif pnl < 0:
        stats["losses"] = int(stats.get("losses", 0)) + 1
        stats["gross_loss"] = float(stats.get("gross_loss", 0.0)) + abs(pnl)
        stats["largest_loss"] = min(float(stats.get("largest_loss", 0.0)), pnl)
        stats["win_streak_pnl"] = 0.0
        stats["streak_kind"] = "loss"
    else:
        stats["breakeven"] = int(stats.get("breakeven", 0)) + 1
        stats["win_streak_pnl"] = 0.0
        # A breakeven is neither a win nor a loss, so it BREAKS the streak.
        # Leaving the previous streak kind in place would let the next trade
        # extend a streak that a breakeven had already ended.
        stats["streak_kind"] = ""

    kind = stats.get("streak_kind", "")
    streak = int(stats.get("current_streak", 0))
    if kind == "win":
        streak = streak + 1 if stats.get("last_kind") == "win" else 1
        stats["max_win_streak"] = max(int(stats.get("max_win_streak", 0)), streak)
    elif kind == "loss":
        streak = streak + 1 if stats.get("last_kind") == "loss" else 1
        stats["max_loss_streak"] = max(int(stats.get("max_loss_streak", 0)), streak)
    else:
        streak = 0
    stats["current_streak"] = streak
    stats["last_kind"] = kind
    return stats


def replay_live_stats(stats: dict, equity_curve: list[float] | None = None,
                      initial_capital: float = 0.0, max_dd: float = 0.0,
                      open_pnl: float = 0.0) -> dict:
    """Derive the LIVE performance readout from the running accumulator.

    Everything here is computed from realised fills. Metrics that cannot be
    computed honestly (profit factor with no losing trade yet) come back as
    ``None`` with a reason, never as a fake 0.0 or a flattering 1.0.
    """
    st = stats or new_live_stats()
    n = int(st.get("trades", 0))
    wins = int(st.get("wins", 0))
    losses = int(st.get("losses", 0))
    gross_profit = float(st.get("gross_profit", 0.0))
    gross_loss = float(st.get("gross_loss", 0.0))
    decisions = wins + losses

    win_rate = (wins / decisions * 100.0) if decisions else None
    profit_factor = None
    if gross_loss > 0:
        profit_factor = gross_profit / gross_loss
    elif gross_profit > 0:
        profit_factor = None            # no losses yet -> undefined, not infinite
    avg_win = gross_profit / wins if wins else None
    avg_loss = gross_loss / losses if losses else None
    payoff = None
    if avg_win is not None and avg_loss:
        payoff = avg_win / avg_loss
    expectancy = (float(st.get("sum_pnl", 0.0)) / n) if n else None

    eq = list(equity_curve or [])
    curve_dd = max_drawdown_pct(eq) if len(eq) > 1 else 0.0
    drawdown = max(float(max_dd or 0.0), curve_dd)
    peak = max(eq) if eq else float(initial_capital or 0.0)
    equity_now = eq[-1] if eq else float(initial_capital or 0.0)
    current_dd = ((peak - equity_now) / peak * 100.0) if peak > 0 else 0.0

    realized = float(st.get("sum_pnl", 0.0))
    unrealized = float(open_pnl or 0.0)
    total_pnl = realized + unrealized

    reason = ""
    if n == 0:
        reason = "No closed trade yet — these numbers appear after the first exit."
    elif decisions == 0:
        reason = "Every trade so far was a breakeven, so there is no win rate yet."

    return {
        "trades": n,
        "wins": wins,
        "losses": losses,
        "breakeven": int(st.get("breakeven", 0)),
        "win_rate_pct": win_rate,
        "profit_factor": profit_factor,
        "expectancy_per_trade": expectancy,
        "avg_win": avg_win,
        "avg_loss": avg_loss,
        "payoff_ratio": payoff,
        "gross_profit": gross_profit,
        "gross_loss": gross_loss,
        "realized_pnl": realized,
        "unrealized_pnl": unrealized,
        "total_pnl": total_pnl,
        "best_trade": st.get("best_trade"),
        "worst_trade": st.get("worst_trade"),
        "current_streak": int(st.get("current_streak", 0)),
        "streak_kind": st.get("streak_kind", ""),
        "max_win_streak": int(st.get("max_win_streak", 0)),
        "max_loss_streak": int(st.get("max_loss_streak", 0)),
        "max_drawdown_pct": float(drawdown),
        "current_drawdown_pct": float(current_dd),
        "peak_equity": float(peak),
        "equity": float(equity_now),
        "total_costs": float(st.get("total_costs", 0.0)),
        "cost_drag_pct": (float(st.get("total_costs", 0.0)) / initial_capital * 100.0)
        if initial_capital else None,
        "status_reason": reason,
    }
