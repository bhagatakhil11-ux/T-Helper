"""CSV ingestion with strict validation and honest provenance.

Rules enforced here:
  * Importing a CSV never makes it "verified genuine market data".
  * Synthetic/test fixtures can never be labelled as real market history.
  * Invalid rows are rejected and reported, never silently repaired.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from .config import (
    IST, INTERVAL_MIN, SESSION_END_MIN, SESSION_START_MIN, SUPPORTED_TIMEFRAMES,
    DataOrigin, ResearchQuality, VerificationStatus,
    required_research_bars, research_quality,
)
from .quality import (
    analyse_gaps, analyse_volume, assess_quality, detect_corporate_actions,
)

REQUIRED = ("open", "high", "low", "close", "volume")
TIME_ALIASES = ("timestamp", "date", "datetime", "time", "tradetime")


@dataclass
class DatasetMeta:
    symbol: str
    timeframe: str
    source_name: str
    source_type: DataOrigin
    verification_status: VerificationStatus
    dataset_id: str
    sha256: str
    imported_at: str
    timezone: str
    candle_count: int
    start: str
    end: str
    adjustment_policy: str
    rows_read: int
    rows_rejected: int
    duplicates: int
    missing_bars: int
    holiday_or_weekend_skips: int
    research_quality: ResearchQuality
    required_research_bars: int
    warnings: list[str] = field(default_factory=list)
    rejection_samples: list[str] = field(default_factory=list)
    abnormal_volume_bars: int = 0
    zero_volume_bars: int = 0
    volume_median: float = 0.0
    # Optional authorized-feed provenance (None for manual/synthetic imports).
    feed_url: str | None = None
    retrieved_at: str | None = None
    license_note: str | None = None
    acquisition: str = "MANUAL_IMPORT"   # MANUAL_IMPORT | AUTHORIZED_FEED | SYNTHETIC
    # ---------------- data-quality layer (quantai/quality.py) ----------------
    # Additive: older provenance files simply load with these defaults.
    data_quality_score: int = 0           # 0-100, internal consistency + sufficiency
    data_quality_grade: str = "F"         # A | B | C | D | F
    data_quality_verdict: str = ""
    data_quality_components: list[dict] = field(default_factory=list)
    data_quality_notes: list[str] = field(default_factory=list)
    data_quality_penalty: float = 0.0
    serious_issues: list[str] = field(default_factory=list)
    corporate_actions: list[dict] = field(default_factory=list)
    corporate_action_count: int = 0       # SUSPECTED corporate actions only
    discontinuity_count: int = 0          # every detected overnight price discontinuity
    gap_report: dict = field(default_factory=dict)
    volume_profile: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["source_type"] = self.source_type.value
        d["verification_status"] = self.verification_status.value
        d["research_quality"] = self.research_quality.value
        return d

    @property
    def is_real_market_claim(self) -> bool:
        return self.source_type in (DataOrigin.IMPORTED_CSV, DataOrigin.BROKER_VENDOR,
                                    DataOrigin.DATA_FEED)


def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip().lower().replace("_", "").replace(" ", "") for c in df.columns]
    rename = {}
    for c in df.columns:
        if c in TIME_ALIASES and "timestamp" not in df.columns:
            rename[c] = "timestamp"
        elif c in ("vol", "qty", "totaltradedquantity", "sharestraded"):
            rename[c] = "volume"
        elif c in ("ticker", "tradingsymbol", "scrip"):
            rename[c] = "symbol"
    return df.rename(columns=rename)


def _parse_times(raw: pd.Series) -> pd.Series:
    """Parse ISO / dd-MMM-yyyy / epoch s / epoch ms into IST-aware datetimes."""
    s = raw.astype(str).str.strip()
    numeric = s.str.fullmatch(r"\d{9,16}")
    out = pd.Series(pd.NaT, index=s.index, dtype="datetime64[ns, Asia/Kolkata]")

    if numeric.any():
        nums = pd.to_numeric(s[numeric], errors="coerce")
        # >= 1e11 => milliseconds, otherwise seconds
        ms = nums.where(nums >= 100_000_000_000, nums * 1000)
        out.loc[numeric] = pd.to_datetime(ms, unit="ms", utc=True, errors="coerce").dt.tz_convert(IST)

    text_idx = s.index[~numeric]
    if len(text_idx):
        parsed = pd.to_datetime(s.loc[text_idx], errors="coerce", utc=True, format="mixed")
        # Naive strings must be interpreted as IST, not UTC.
        naive_mask = ~s.loc[text_idx].str.contains(r"(?:Z|[+-]\d{2}:?\d{2})$", regex=True, na=False)
        if naive_mask.any():
            naive = pd.to_datetime(s.loc[text_idx][naive_mask], errors="coerce")
            parsed.loc[naive_mask[naive_mask].index] = naive.dt.tz_localize(
                IST, ambiguous="NaT", nonexistent="NaT"
            ).dt.tz_convert(IST)
        out.loc[text_idx] = parsed.dt.tz_convert(IST)
    return out


def _session_and_alignment(ts: pd.Series, timeframe: str) -> tuple[pd.Series, pd.Series]:
    minutes = ts.dt.hour * 60 + ts.dt.minute
    weekday = ts.dt.dayofweek < 5
    if timeframe == "1D":
        in_session = weekday
        aligned = (ts.dt.hour == 0) & (ts.dt.minute == 0) & (ts.dt.second == 0)
        # Daily bars stamped at any intraday time are tolerated but flagged.
        aligned = aligned | weekday
        return in_session, aligned
    step = INTERVAL_MIN[timeframe]
    in_session = weekday & (minutes >= SESSION_START_MIN) & (minutes <= SESSION_END_MIN)
    offset = minutes - SESSION_START_MIN
    aligned = (offset % step == 0) & (ts.dt.second == 0)
    return in_session, aligned


def _count_gaps(ts: pd.Series, timeframe: str, holidays: set[str]) -> tuple[int, int, list[str]]:
    """Return (missing_bars, holiday/weekend skips, warnings).

    Kept for backwards compatibility; the arithmetic now lives in
    :func:`quantai.quality.analyse_gaps`, which produces the SAME headline
    numbers plus a detailed breakdown.
    """
    rep = analyse_gaps(ts, timeframe, holidays)
    warnings: list[str] = []
    if rep.missing_bars:
        warnings.append(f"{rep.missing_bars} expected bar(s) absent on non-holiday sessions (gaps).")
    if rep.holiday_skips:
        warnings.append(f"{rep.holiday_skips} weekday(s) skipped that match the configured holiday list.")
    return rep.missing_bars, rep.holiday_skips, warnings


def compute_quality_layer(df: pd.DataFrame, *, rows_read: int, rows_rejected: int,
                          duplicates: int, timeframe: str, adjustment_policy: str,
                          source_type: DataOrigin, holidays=None) -> dict:
    """Compute the full data-quality layer for an already-validated frame.

    Used by :func:`load_csv` at import time and by the server when it restores
    a dataset whose provenance file predates the quality layer.
    """
    actions = detect_corporate_actions(df, timeframe)
    gaps = analyse_gaps(df["timestamp"], timeframe, holidays or set())
    volume = analyse_volume(df["volume"], df["timestamp"])
    assessment = assess_quality(
        rows_read=rows_read,
        candle_count=len(df),
        rows_rejected=rows_rejected,
        duplicates=duplicates,
        timeframe=timeframe,
        gaps=gaps,
        volume=volume,
        actions=actions,
        adjustment_policy=adjustment_policy,
        source_type=source_type.value if hasattr(source_type, "value") else str(source_type),
    )
    return {
        "actions": actions,
        "gaps": gaps,
        "volume": volume,
        "assessment": assessment,
    }


def load_csv(
    path: str | Path,
    symbol: str,
    timeframe: str,
    source_type: DataOrigin = DataOrigin.IMPORTED_CSV,
    adjustment_policy: str = "UNKNOWN_UNVERIFIED",
    holidays: set[str] | None = None,
    source_name: str | None = None,
    feed_url: str | None = None,
    retrieved_at: str | None = None,
    license_note: str | None = None,
) -> tuple[pd.DataFrame, DatasetMeta]:
    path = Path(path)
    if timeframe not in SUPPORTED_TIMEFRAMES:
        raise ValueError(f"Unsupported timeframe {timeframe!r}. Use one of {SUPPORTED_TIMEFRAMES}.")

    raw_bytes = path.read_bytes()
    digest = hashlib.sha256(raw_bytes).hexdigest()

    verification = {
        DataOrigin.SIMULATED: VerificationStatus.SIMULATED_NOT_REAL,
        DataOrigin.TEST_FIXTURE: VerificationStatus.TEST_FIXTURE_NOT_MARKET_DATA,
        DataOrigin.IMPORTED_CSV: VerificationStatus.IMPORTED_CSV_UNVERIFIED,
        DataOrigin.BROKER_VENDOR: VerificationStatus.VERIFIED_EXCHANGE_OR_VENDOR,
        DataOrigin.DATA_FEED: VerificationStatus.DATA_FEED_UNVERIFIED,
    }[source_type]

    df = pd.read_csv(path, comment="#")
    df = _normalise_columns(df)
    rows_read = len(df)

    missing_cols = [c for c in ("timestamp",) + REQUIRED if c not in df.columns]
    if missing_cols:
        raise ValueError(f"CSV missing required column(s): {missing_cols}. Found: {list(df.columns)}")

    warnings: list[str] = []
    rejections: list[str] = []
    bad = pd.Series(False, index=df.index)

    ts = _parse_times(df["timestamp"])
    m = ts.isna()
    bad |= m
    rejections += [f"row {i+2}: unparseable timestamp {df['timestamp'].iloc[i]!r}" for i in df.index[m][:10]]

    num = df[list(REQUIRED)].apply(pd.to_numeric, errors="coerce")
    m = num.isna().any(axis=1) | ~np.isfinite(num).all(axis=1)
    bad |= m
    rejections += [f"row {i+2}: non-numeric/non-finite OHLCV" for i in df.index[m][:10]]

    m = (num[["open", "high", "low", "close"]] <= 0).any(axis=1)
    bad |= m
    rejections += [f"row {i+2}: zero/negative price" for i in df.index[m][:10]]

    m = (num["high"] < num[["open", "close"]].max(axis=1)) | (num["low"] > num[["open", "close"]].min(axis=1)) | (num["high"] < num["low"])
    bad |= m
    rejections += [f"row {i+2}: invalid OHLC relationship" for i in df.index[m][:10]]

    m = (num["volume"] < 0) | (num["volume"] % 1 != 0)
    bad |= m
    rejections += [f"row {i+2}: negative or fractional volume (not silently truncated)" for i in df.index[m][:10]]

    in_session, aligned = _session_and_alignment(ts, timeframe)
    m = ~in_session.fillna(False)
    bad |= m
    rejections += [f"row {i+2}: outside NSE session / weekend" for i in df.index[m][:10]]
    m = (~aligned.fillna(False)) & in_session.fillna(False)
    bad |= m
    rejections += [f"row {i+2}: timestamp not aligned to {timeframe} grid" for i in df.index[m][:10]]

    if "symbol" in df.columns:
        csv_symbols = df["symbol"].astype(str).str.upper().str.replace(r"\.(NS|BO)$", "", regex=True).str.strip()
        m = csv_symbols.ne(symbol.upper())
        bad |= m
        rejections += [f"row {i+2}: symbol mismatch (expected {symbol})" for i in df.index[m][:10]]

    clean = pd.DataFrame({
        "timestamp": ts, "open": num["open"], "high": num["high"],
        "low": num["low"], "close": num["close"], "volume": num["volume"].astype("float64"),
    })[~bad].dropna(subset=["timestamp"])

    dup_mask = clean["timestamp"].duplicated(keep=False)
    duplicates = int(dup_mask.sum())
    if duplicates:
        # Ambiguous duplicates are dropped entirely rather than guessed at.
        clean = clean[~dup_mask]
        warnings.append(f"{duplicates} duplicate-timestamp row(s) dropped (conflicting duplicates are never guessed).")

    was_unsorted = not clean["timestamp"].is_monotonic_increasing
    clean = clean.sort_values("timestamp").reset_index(drop=True)
    if was_unsorted:
        warnings.append("Input rows were unsorted; sorted chronologically.")
    clean["volume"] = clean["volume"].astype("int64")

    if len(clean) == 0:
        raise ValueError("No valid candles after validation. Fix the CSV; nothing was silently repaired.")

    if adjustment_policy == "UNKNOWN_UNVERIFIED":
        warnings.append("Adjustment policy unknown: multi-year splits/bonuses can create fake signals. Verify before trusting results.")

    # ---------------- data-quality layer ----------------
    # Corporate actions / price discontinuities: DETECTION FOR REVIEW only.
    # Nothing is adjusted — raw prices are always left untouched.
    qlayer = compute_quality_layer(
        clean, rows_read=rows_read, rows_rejected=int(bad.sum()),
        duplicates=duplicates, timeframe=timeframe,
        adjustment_policy=adjustment_policy, source_type=source_type,
        holidays=holidays or set())
    actions = qlayer["actions"]
    gap_detail = qlayer["gaps"]
    volume_profile = qlayer["volume"]
    assessment = qlayer["assessment"]

    missing_bars = gap_detail.missing_bars
    skipped = gap_detail.holiday_skips
    # Legacy warning wording, unchanged.
    if missing_bars:
        warnings.append(f"{missing_bars} expected bar(s) absent on non-holiday sessions (gaps).")
    if skipped:
        warnings.append(f"{skipped} weekday(s) skipped that match the configured holiday list.")

    zero_volume_bars = volume_profile.zero_bars
    abnormal_volume_bars = volume_profile.abnormal_bars
    volume_median = volume_profile.median

    if zero_volume_bars:
        warnings.append(f"{zero_volume_bars} zero-volume bar(s): possible stale/placeholder candles.")
    if volume_profile.ratio_alert_bars:
        warnings.append(f"{volume_profile.ratio_alert_bars} bar(s) with volume >8x or <1/8x the trailing median: verify against the source (news/result spikes are real, bad ticks are not).")
    if volume_profile.zscore_alerts:
        warnings.append(f"{volume_profile.zscore_alerts} bar(s) flagged by the rolling-median z-score "
                        f"(robust median/MAD and log-volume z-score): volume outside its own recent distribution.")

    # Legacy headline (>= 22% overnight gaps) — same count and wording as before.
    big = [a for a in actions if abs(a.gap_pct) >= 0.22]
    if big:
        warnings.append(f"{len(big)} single-bar open gap(s) >= 22% flagged as possible corporate action; raw prices left untouched.")

    suspected = [a for a in actions if a.kind == "CORPORATE_ACTION_SUSPECTED"]
    if suspected:
        shown = ", ".join(f"{a.timestamp[:10]} (~{a.implied_ratio})" for a in suspected[:5])
        more = f" (+{len(suspected) - 5} more)" if len(suspected) > 5 else ""
        warnings.append(
            f"{len(suspected)} suspected split/bonus event(s) detected: {shown}{more}. "
            f"Price data alone cannot separate a corporate action from a market move of the "
            f"same size — confirm against the exchange corporate-action register before "
            f"treating these as adjusted.")
    other_gaps = [a for a in actions if a.kind != "CORPORATE_ACTION_SUSPECTED"]
    if other_gaps:
        warnings.append(
            f"{len(other_gaps)} overnight price discontinuity(ies) that do NOT match a canonical "
            f"split/bonus ratio (>= 8%). Review them: they are more likely genuine market moves "
            f"or bad ticks than corporate actions.")

    if gap_detail.missing_sessions:
        warnings.append(
            f"{gap_detail.missing_sessions} trading session(s) are entirely absent "
            f"({gap_detail.missing_bars} bar(s) in total). Features are still causal, but the "
            f"grid is incomplete — re-export the file if the gaps are not intentional.")
    if gap_detail.late_session_starts:
        warnings.append(
            f"{gap_detail.late_session_starts} intraday session(s) begin after the 09:15 open; "
            f"the leading bar(s) of those sessions are missing.")

    serious_issues = list(assessment.serious_issues)
    for issue in serious_issues:
        if issue not in warnings:
            warnings.append(issue)

    if source_type in (DataOrigin.SIMULATED, DataOrigin.TEST_FIXTURE):
        warnings.append("NOT REAL MARKET DATA. Results describe plumbing only, never market edge.")
    if source_type is DataOrigin.DATA_FEED:
        warnings.append("Fetched from a user-configured feed. Authorization is user-asserted; "
                        "content is NOT independently verified against the exchange.")

    if source_type in (DataOrigin.SIMULATED, DataOrigin.TEST_FIXTURE):
        acquisition = "SYNTHETIC"
    elif source_type is DataOrigin.DATA_FEED:
        acquisition = "AUTHORIZED_FEED"
    else:
        acquisition = "MANUAL_IMPORT"

    quality = research_quality(len(clean), timeframe)
    if quality is ResearchQuality.LOW_CONFIDENCE_INSUFFICIENT_DATA:
        warnings.append(f"Only {len(clean)} bars; research-grade needs >= {required_research_bars(timeframe)} for {timeframe}.")

    meta = DatasetMeta(
        symbol=symbol.upper(), timeframe=timeframe,
        source_name=source_name or path.name,
        source_type=source_type, verification_status=verification,
        dataset_id=f"{symbol.upper()}_{timeframe}_{digest[:12]}", sha256=digest,
        imported_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        timezone=IST, candle_count=len(clean),
        start=clean["timestamp"].iloc[0].isoformat(), end=clean["timestamp"].iloc[-1].isoformat(),
        adjustment_policy=adjustment_policy, rows_read=rows_read,
        rows_rejected=int(bad.sum()), duplicates=duplicates,
        missing_bars=missing_bars, holiday_or_weekend_skips=skipped,
        research_quality=quality, required_research_bars=required_research_bars(timeframe),
        warnings=warnings, rejection_samples=rejections[:25],
        abnormal_volume_bars=abnormal_volume_bars,
        zero_volume_bars=zero_volume_bars, volume_median=volume_median,
        feed_url=feed_url, retrieved_at=retrieved_at, license_note=license_note,
        acquisition=acquisition,
        # ---- data-quality layer ----
        data_quality_score=assessment.score,
        data_quality_grade=assessment.grade,
        data_quality_verdict=assessment.verdict,
        data_quality_components=[c.to_dict() for c in assessment.components],
        data_quality_notes=list(assessment.notes),
        data_quality_penalty=assessment.penalty,
        serious_issues=serious_issues,
        corporate_actions=[a.to_dict() for a in actions],
        corporate_action_count=len(suspected),
        discontinuity_count=len(actions),
        gap_report=gap_detail.to_dict(),
        volume_profile=volume_profile.to_dict(),
    )
    return clean, meta


def preview_csv(path: str | Path, symbol: str, timeframe: str,
                source_type: DataOrigin = DataOrigin.IMPORTED_CSV,
                adjustment_policy: str = "UNKNOWN_UNVERIFIED",
                holidays: set[str] | None = None,
                head: int = 8) -> dict:
    """Validate WITHOUT importing. Returns the full quality report + first/last
    rows so the user can inspect before committing. Raises on invalid input."""
    df, meta = load_csv(path, symbol, timeframe, source_type=source_type,
                        adjustment_policy=adjustment_policy, holidays=holidays)
    def rows(d):
        return [{"timestamp": str(r.timestamp), "open": float(r.open), "high": float(r.high),
                 "low": float(r.low), "close": float(r.close), "volume": int(r.volume)}
                for r in d.itertuples()]
    return {"meta": meta.to_dict(), "head": rows(df.head(head)), "tail": rows(df.tail(head)),
            "sha256": meta.sha256}


def write_meta(meta: DatasetMeta, out_dir: str | Path) -> Path:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    p = out_dir / "dataset_provenance.json"
    p.write_text(json.dumps(meta.to_dict(), indent=2), encoding="utf-8")
    return p
