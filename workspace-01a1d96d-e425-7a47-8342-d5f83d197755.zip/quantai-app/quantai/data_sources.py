"""Optional authorized market-data feed registry + safe fetch + append-only update.

SAFETY / COMPLIANCE CONTRACT
----------------------------
* This module NEVER scrapes an exchange, bypasses paywalls/auth, or fabricates
  missing prices. It only fetches a CSV from a URL the USER explicitly registers
  and asserts they are authorized to use (their broker/vendor export, a licensed
  data API, or their own hosting).
* Fetches are SSRF-guarded: https only, public unicast IPs only, no redirects to
  private hosts, size and time capped. Cloud-metadata and loopback/link-local/
  private ranges are blocked.
* Downloaded content is labelled DATA_FEED_UNVERIFIED. Authorization is
  user-asserted; the app does not independently verify exchange provenance.
* Updates are APPEND-ONLY: only bars strictly newer than the last stored bar are
  added. Overlapping bars with conflicting values are rejected, never overwritten
  or interpolated. Gaps are reported, never filled.
"""
from __future__ import annotations

import ipaddress
import socket
import urllib.request
import urllib.error
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from urllib.parse import urlparse

import pandas as pd

MAX_FEED_BYTES = 64 * 1024 * 1024
FEED_TIMEOUT_S = 30


@dataclass
class FeedSource:
    name: str
    url: str
    symbol: str
    timeframe: str
    license_note: str
    added_at: str
    last_fetched_at: str | None = None
    last_status: str | None = None


def _is_public_ip(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return not (addr.is_private or addr.is_loopback or addr.is_link_local
                or addr.is_reserved or addr.is_multicast or addr.is_unspecified)


def validate_feed_url(url: str) -> str:
    """Validate scheme + resolve host and reject non-public targets (SSRF guard)."""
    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise ValueError("Only https:// feed URLs are allowed.")
    if not parsed.hostname:
        raise ValueError("Feed URL has no hostname.")
    if parsed.username or parsed.password:
        raise ValueError("Credentials in feed URLs are not allowed; use a pre-signed/export URL.")
    try:
        infos = socket.getaddrinfo(parsed.hostname, parsed.port or 443, proto=socket.IPPROTO_TCP)
    except socket.gaierror as e:
        raise ValueError(f"Cannot resolve feed host: {e}")
    ips = {info[4][0] for info in infos}
    if not ips:
        raise ValueError("Feed host resolved to no addresses.")
    for ip in ips:
        if not _is_public_ip(ip):
            raise ValueError(f"Feed host resolves to a non-public address ({ip}); blocked for SSRF safety.")
    return url


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Re-validate the redirect target instead of blindly following it.
        validate_feed_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch_feed_csv(url: str, fetcher=None) -> tuple[bytes, str]:
    """Fetch CSV bytes from an authorized https feed. Returns (bytes, retrieved_at).

    `fetcher` is injectable for tests; in production it performs a guarded GET.
    """
    validate_feed_url(url)
    retrieved_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    if fetcher is not None:
        data = fetcher(url)
        if not isinstance(data, (bytes, bytearray)):
            raise ValueError("Fetcher must return bytes.")
        if len(data) > MAX_FEED_BYTES:
            raise ValueError("Feed response exceeds 64 MB cap.")
        return bytes(data), retrieved_at

    opener = urllib.request.build_opener(_NoRedirect())
    req = urllib.request.Request(url, headers={"User-Agent": "QuantAI-Terminal/1.0 (research)"})
    try:
        with opener.open(req, timeout=FEED_TIMEOUT_S) as resp:
            ctype = (resp.headers.get("Content-Type") or "").lower()
            if not any(t in ctype for t in ("csv", "text/plain", "application/octet-stream", "text/")):
                raise ValueError(f"Feed returned non-CSV content type: {ctype!r}")
            data = resp.read(MAX_FEED_BYTES + 1)
    except urllib.error.HTTPError as e:
        raise ValueError(f"Feed HTTP error {e.code}: {e.reason}")
    except urllib.error.URLError as e:
        raise ValueError(f"Feed connection failed: {e.reason}")
    if len(data) > MAX_FEED_BYTES:
        raise ValueError("Feed response exceeds 64 MB cap.")
    if not data.strip():
        raise ValueError("Feed returned an empty response.")
    return data, retrieved_at


def merge_append_only(existing: pd.DataFrame, incoming: pd.DataFrame,
                      tolerance: float = 1e-6) -> tuple[pd.DataFrame, dict]:
    """Append only strictly-newer bars. Reject conflicting overlaps; never fill gaps.

    Returns (merged_df, report). Raises ValueError on conflicting overlap.
    """
    if existing.empty:
        return incoming.copy(), {"appended": len(incoming), "overlap_identical": 0,
                                 "overlap_conflicting": 0, "skipped_older": 0}
    last_ts = existing["timestamp"].max()
    newer = incoming[incoming["timestamp"] > last_ts]
    overlap = incoming[incoming["timestamp"] <= last_ts]

    # Check overlaps against existing rows at the same timestamp.
    ex_idx = existing.set_index("timestamp")
    conflicting = 0
    identical = 0
    for row in overlap.itertuples():
        if row.timestamp in ex_idx.index:
            ex = ex_idx.loc[row.timestamp]
            same = all(abs(float(getattr(row, c)) - float(ex[c])) <= tolerance
                       for c in ("open", "high", "low", "close")) and int(row.volume) == int(ex["volume"])
            if same:
                identical += 1
            else:
                conflicting += 1
    if conflicting:
        raise ValueError(f"{conflicting} overlapping bar(s) conflict with stored values. "
                         "Append-only update refuses to overwrite history. Re-import the full "
                         "dataset explicitly if a correction is intended.")

    merged = pd.concat([existing, newer], ignore_index=True)
    merged = merged.sort_values("timestamp").reset_index(drop=True)
    # Report gaps in the appended region but NEVER fill them.
    appended = len(newer)
    report = {"appended": appended, "overlap_identical": identical,
              "overlap_conflicting": 0, "skipped_older": len(overlap) - identical,
              "note": "Append-only. Missing bars are reported by the validator, never fabricated."}
    return merged, report
