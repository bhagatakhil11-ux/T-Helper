"""Parameter sensitivity / robustness analysis.

Runs the SAME strategy and data across a grid of entry thresholds, stop-loss ATR
and target ATR multipliers. The goal is NOT to find the best parameters — it is to
see whether performance is stable across a neighbourhood, or whether the strategy
only works at one narrowly-optimised point (a classic overfit signature).
"""
from __future__ import annotations

import itertools
from dataclasses import replace

import numpy as np

from .backtest import run_backtest
from .config import CostModel, RiskConfig


def _neighbours(point: tuple, axes: list[list[float]]) -> list[tuple]:
    """Grid points that differ by one step on exactly one axis."""
    out = []
    idx = [axes[d].index(point[d]) for d in range(len(axes))]
    for d in range(len(axes)):
        for delta in (-1, 1):
            j = idx[d] + delta
            if 0 <= j < len(axes[d]):
                nb = list(point)
                nb[d] = axes[d][j]
                out.append(tuple(nb))
    return out


def run_sensitivity(df, feats, start_bar: int, cost: CostModel, base_risk: RiskConfig,
                    timeframe: str, mode: str = "ensemble", proba=None,
                    thresholds: list[float] | None = None,
                    stop_mults: list[float] | None = None,
                    target_mults: list[float] | None = None,
                    volume_cap_pct: float = 0.0,
                    max_combinations: int = 200) -> dict:
    thresholds = thresholds or [0.30, 0.42, 0.55]
    stop_mults = stop_mults or [1.2, 1.8, 2.5]
    target_mults = target_mults or [2.4, 3.6, 5.0]
    axes = [list(thresholds), list(stop_mults), list(target_mults)]
    combos = list(itertools.product(*axes))
    if len(combos) > max_combinations:
        raise ValueError(f"Grid has {len(combos)} combinations; limit is {max_combinations}. "
                         "Use a coarser grid.")

    rows = []
    by_point = {}
    for thr, sl, tp in combos:
        risk = replace(base_risk, stop_atr_mult=sl, target_atr_mult=tp)
        res = run_backtest(df, feats, start_bar, cost, risk, timeframe, proba=proba,
                           mode=mode, entry_threshold=thr, label=f"thr={thr} sl={sl} tp={tp}",
                           max_volume_participation_pct=volume_cap_pct)
        row = {"threshold": thr, "stop_atr_mult": sl, "target_atr_mult": tp,
               "net_return_pct": res.net_return_pct, "sharpe_ratio": res.sharpe,
               "max_drawdown_pct": res.max_drawdown_pct, "total_trades": res.total_trades,
               "win_rate_pct": res.win_rate_pct, "profit_factor": res.profit_factor}
        rows.append(row)
        by_point[(thr, sl, tp)] = row

    returns = np.array([r["net_return_pct"] for r in rows], dtype=float)
    profitable = int(np.sum(returns > 0))
    best = max(rows, key=lambda r: r["net_return_pct"])
    worst = min(rows, key=lambda r: r["net_return_pct"])
    median = float(np.median(returns))
    mean = float(np.mean(returns))
    std = float(np.std(returns, ddof=1)) if len(returns) > 1 else 0.0
    frac_profitable = profitable / len(rows)

    # Stability: how does the best point compare with its immediate neighbours?
    best_point = (best["threshold"], best["stop_atr_mult"], best["target_atr_mult"])
    nb_points = _neighbours(best_point, axes)
    nb_returns = [by_point[p]["net_return_pct"] for p in nb_points if p in by_point]
    neighbour_median = float(np.median(nb_returns)) if nb_returns else None
    # A robust optimum keeps most neighbours profitable and close in performance.
    neighbour_profitable_frac = (float(np.mean([r > 0 for r in nb_returns]))
                                 if nb_returns else None)

    flags = []
    if frac_profitable < 0.5:
        flags.append(f"Only {profitable}/{len(rows)} parameter combinations are profitable after costs.")
    if std > 0 and abs(mean) < std:
        flags.append("Return dispersion across the grid exceeds the mean: results are parameter-sensitive.")
    if neighbour_median is not None and best["net_return_pct"] > 0 and neighbour_median <= 0:
        flags.append("Best point is profitable but its immediate neighbours are not: narrow optimisation / likely overfit.")
    if neighbour_profitable_frac is not None and neighbour_profitable_frac < 0.5:
        flags.append("Fewer than half of the best point's neighbours are profitable.")
    if len(rows) and best["total_trades"] < 5:
        flags.append("Best combination has < 5 trades: its apparent edge is statistically meaningless.")

    if frac_profitable >= 0.7 and (neighbour_profitable_frac or 0) >= 0.6 and not flags:
        stability = "STABLE"
    elif frac_profitable >= 0.4 and not any("narrow" in f for f in flags):
        stability = "MIXED"
    else:
        stability = "FRAGILE"

    return {
        "status": "ok", "mode": mode, "grid_size": len(rows),
        "axes": {"thresholds": axes[0], "stop_atr_mults": axes[1], "target_atr_mults": axes[2]},
        "results": rows,
        "summary": {
            "profitable_combinations": profitable,
            "fraction_profitable": frac_profitable,
            "best": best, "worst": worst,
            "median_return_pct": median, "mean_return_pct": mean, "std_return_pct": std,
            "best_neighbour_median_return_pct": neighbour_median,
            "best_neighbour_profitable_fraction": neighbour_profitable_frac,
        },
        "stability": stability,
        "flags": flags,
        "interpretation": {
            "STABLE": "Performance holds across a broad parameter neighbourhood. Necessary, not sufficient, evidence of robustness.",
            "MIXED": "Performance depends materially on parameters. Treat any single good result with caution.",
            "FRAGILE": "Performance appears only at isolated parameter points. This is an overfit signature, not a deployable edge.",
        }[stability],
    }
