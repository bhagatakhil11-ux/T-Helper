"""Chart payload assembly and the descriptive technical-analysis summary.

The payload contains ONLY actual imported candles plus causal indicator values,
pattern detections and support/resistance zones. Warm-up indicator values are
null (never fabricated). The summary reports individual indicator readings and
conditions — it deliberately does NOT emit an unexplained BUY/SELL verdict.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import DataOrigin
from .indicators import INDICATOR_COLUMNS, compute_indicators, vwap
from .levels import support_resistance
from .patterns import detect_patterns


def _list(s: pd.Series) -> list:
    return [None if not np.isfinite(v) else float(v) for v in s.to_numpy(dtype=float)]


def _val(row, key):
    v = row.get(key)
    if v is None or not np.isfinite(v):
        return None
    return float(v)


def _confluence(close: float, ema20, ema50, ema200, rsi_v, rsi_slope,
                macd_v, sig_v, hist_v, prev_hist, pb, vw, ret5, macd_cross) -> dict:
    """How many indicator readings point the SAME way.

    This is deliberately a COUNT, not a verdict. Each reading that has enough
    history to be meaningful contributes one vote to "bullish" or "bearish";
    a reading that is still warming up, or that is genuinely neutral,
    contributes to "neutral". No BUY or SELL conclusion is drawn here — that
    is the trader's job, and the app's job is to show the ingredients.
    """
    bull: list[str] = []
    bear: list[str] = []
    neutral: list[str] = []

    def vote(name, value):
        if value is None:
            neutral.append(f"{name} (not available yet)")
        elif value > 0:
            bull.append(name)
        elif value < 0:
            bear.append(name)
        else:
            neutral.append(f"{name} (flat)")

    # 1) EMA alignment (the trend structure)
    if ema20 is None or ema50 is None:
        neutral.append("EMA 20/50 alignment (warm-up)")
    elif close > ema20 > ema50:
        bull.append("EMA alignment (close > EMA20 > EMA50)")
    elif close < ema20 < ema50:
        bear.append("EMA alignment (close < EMA20 < EMA50)")
    else:
        neutral.append("EMA alignment (not cleanly stacked)")

    # 2-4) price vs each EMA on its own
    for name, v in (("price vs EMA20", ema20), ("price vs EMA50", ema50),
                    ("price vs EMA200", ema200)):
        vote(name, None if v is None else (1.0 if close >= v else -1.0))

    # 5) MACD histogram sign
    vote("MACD histogram", None if hist_v is None else (1.0 if hist_v > 0 else (-1.0 if hist_v < 0 else 0.0)))

    # 6) MACD line vs signal line
    if macd_v is None or sig_v is None:
        neutral.append("MACD vs signal (warm-up)")
    elif macd_v > sig_v:
        bull.append("MACD above signal")
    elif macd_v < sig_v:
        bear.append("MACD below signal")
    else:
        neutral.append("MACD vs signal (equal)")

    # 7) RSI side of 50
    vote("RSI vs 50", None if rsi_v is None else (1.0 if rsi_v > 50 else (-1.0 if rsi_v < 50 else 0.0)))

    # 8) RSI slope
    vote("RSI slope", None if rsi_slope is None else (1.0 if rsi_slope > 0 else (-1.0 if rsi_slope < 0 else 0.0)))

    # 9) Bollinger %B side of the middle
    vote("Bollinger %B vs 0.5", None if pb is None else (1.0 if pb > 0.5 else (-1.0 if pb < 0.5 else 0.0)))

    # 10) price vs VWAP (intraday only)
    vote("price vs VWAP", None if vw is None else (1.0 if close >= vw else -1.0))

    # 11) the 5-bar return
    vote("5-bar return", None if ret5 is None else (1.0 if ret5 > 0 else (-1.0 if ret5 < 0 else 0.0)))

    # 12) a fresh MACD cross
    if macd_cross == "BULLISH_CROSS":
        bull.append("fresh bullish MACD cross")
    elif macd_cross == "BEARISH_CROSS":
        bear.append("fresh bearish MACD cross")

    total = len(bull) + len(bear) + len(neutral)
    considered = len(bull) + len(bear)
    if considered == 0:
        lean = "undetermined"
    elif len(bull) > len(bear):
        lean = "bullish-leaning"
    elif len(bear) > len(bull):
        lean = "bearish-leaning"
    else:
        lean = "evenly split"
    return {
        "bullish_count": len(bull),
        "bearish_count": len(bear),
        "neutral_count": len(neutral),
        "total_readings": total,
        "readings_considered": considered,
        "agreement_pct": (max(len(bull), len(bear)) / considered * 100.0) if considered else None,
        "lean": lean,
        "bullish": bull,
        "bearish": bear,
        "neutral": neutral,
        "note": ("This is a COUNT of indicator readings that point the same way — NOT a "
                 "buy/sell signal and NOT a forecast. A high agreement count means the "
                 "indicators are telling a consistent story right now, not that the trade "
                 "will work. Indicators can agree and still be wrong."),
    }


def technical_summary(df: pd.DataFrame, ind: pd.DataFrame, patterns: list[dict],
                      levels: dict, as_of: int) -> dict:
    i = as_of
    row = ind.iloc[i]
    close = float(df["close"].iloc[i])
    ema20, ema50, ema200 = _val(row, "ema_20"), _val(row, "ema_50"), _val(row, "ema_200")
    rsi_v = _val(row, "rsi_14")
    macd_v, sig_v, hist_v = _val(row, "macd"), _val(row, "macd_signal"), _val(row, "macd_hist")

    # Trend
    if ema20 is None or ema50 is None:
        trend, trend_note = "INSUFFICIENT_DATA", "EMA 20/50 still in warm-up; need more history."
    elif ema200 is not None:
        if close > ema20 > ema50 > ema200:
            trend, trend_note = "UPTREND", "Price > EMA20 > EMA50 > EMA200 (bullish alignment)."
        elif close < ema20 < ema50 < ema200:
            trend, trend_note = "DOWNTREND", "Price < EMA20 < EMA50 < EMA200 (bearish alignment)."
        else:
            trend, trend_note = "MIXED", "Moving averages are not cleanly aligned; trend is transitional."
    else:
        if close > ema20 > ema50:
            trend, trend_note = "UPTREND", "Price > EMA20 > EMA50 (EMA200 unavailable: limited history)."
        elif close < ema20 < ema50:
            trend, trend_note = "DOWNTREND", "Price < EMA20 < EMA50 (EMA200 unavailable: limited history)."
        else:
            trend, trend_note = "MIXED", "EMA20/50 not aligned; EMA200 unavailable (limited history)."

    # Momentum
    prev_hist = _val(ind.iloc[i - 1], "macd_hist") if i > 0 else None
    ret5 = float(close / df["close"].iloc[i - 5] - 1.0) if i >= 5 else None
    if hist_v is not None and rsi_v is not None:
        if hist_v > 0 and rsi_v > 50:
            momentum = "BULLISH"
        elif hist_v < 0 and rsi_v < 50:
            momentum = "BEARISH"
        else:
            momentum = "MIXED"
    else:
        momentum = "INSUFFICIENT_DATA"

    # RSI condition
    if rsi_v is None:
        rsi_condition = "WARM_UP"
    elif rsi_v >= 70:
        rsi_condition = "OVERBOUGHT"
    elif rsi_v <= 30:
        rsi_condition = "OVERSOLD"
    else:
        rsi_condition = "NEUTRAL"
    rsi_slope = None
    if i > 0:
        pr = _val(ind.iloc[i - 1], "rsi_14")
        if pr is not None and rsi_v is not None:
            rsi_slope = rsi_v - pr

    # MACD condition / cross
    macd_cross = None
    if hist_v is not None and prev_hist is not None:
        if prev_hist <= 0 < hist_v:
            macd_cross = "BULLISH_CROSS"
        elif prev_hist >= 0 > hist_v:
            macd_cross = "BEARISH_CROSS"
    macd_condition = ("BULLISH" if hist_v > 0 else "BEARISH" if hist_v < 0 else "FLAT") if hist_v is not None else "WARM_UP"

    def ema_rel(v):
        if v is None:
            return {"value": None, "position": "WARM_UP", "distance_pct": None}
        return {"value": v, "position": "ABOVE" if close >= v else "BELOW",
                "distance_pct": (close / v - 1.0) * 100.0}

    pb = _val(row, "bb_percent_b")
    bb_pos = "WARM_UP"
    if pb is not None:
        bb_pos = "ABOVE_UPPER" if pb > 1 else "BELOW_LOWER" if pb < 0 else "INSIDE_BANDS"

    vw = _val(row, "vwap")
    vwap_valid = vw is not None

    recent_patterns = [p for p in patterns if p["bar"] <= i][-8:]

    readings = {k: _val(row, k) for k in INDICATOR_COLUMNS}

    confluence = _confluence(close, ema20, ema50, ema200, rsi_v, rsi_slope,
                             macd_v, sig_v, hist_v, prev_hist, pb, vw, ret5, macd_cross)

    return {
        "as_of_bar": int(i),
        "as_of_timestamp": str(df["timestamp"].iloc[i]),
        "close": close,
        "trend": trend, "trend_note": trend_note,
        "momentum": momentum,
        "return_5bar_pct": ret5 * 100 if ret5 is not None else None,
        "rsi": {"value": rsi_v, "condition": rsi_condition, "slope": rsi_slope},
        "macd": {"macd": macd_v, "signal": sig_v, "histogram": hist_v,
                 "condition": macd_condition, "cross": macd_cross},
        "price_vs_ema": {"ema_20": ema_rel(ema20), "ema_50": ema_rel(ema50), "ema_200": ema_rel(ema200)},
        "bollinger": {"percent_b": pb, "bandwidth": _val(row, "bb_bandwidth"), "position": bb_pos},
        "atr": {"value": _val(row, "atr_14"),
                "pct_of_price": (_val(row, "atr_14") / close * 100) if _val(row, "atr_14") is not None else None},
        "vwap": {"value": vw, "valid": vwap_valid,
                 "position": ("ABOVE" if close >= vw else "BELOW") if vw is not None else "UNAVAILABLE"},
        "nearby_support": levels.get("nearby_support"),
        "nearby_resistance": levels.get("nearby_resistance"),
        "recent_patterns": recent_patterns,
        "confluence": confluence,
        "indicator_readings": readings,
        "disclaimer": "Descriptive indicator readings only. This is NOT a buy/sell recommendation. "
                      "Candlestick patterns and levels are probabilistic observations, not guaranteed signals.",
    }


def build_chart_payload(df: pd.DataFrame, meta: dict, as_of_bar: int | None = None) -> dict:
    """Build the chart payload.

    When ``as_of_bar`` is given the payload is TRUNCATED at that bar: candles,
    indicators, patterns and levels all stop there. A historical view therefore
    can never display or use a future candle.
    """
    n = len(df)
    if n == 0:
        raise ValueError("Dataset has no candles.")
    as_of = n - 1 if as_of_bar is None else max(0, min(int(as_of_bar), n - 1))
    timeframe = meta.get("timeframe", "1D")

    sub = df.iloc[:as_of + 1].reset_index(drop=True)
    ind = compute_indicators(sub, timeframe)
    patterns = detect_patterns(sub)
    levels = support_resistance(sub, as_of_bar=as_of)
    _, vw_valid = vwap(sub, timeframe)

    candles = [{
        "bar": int(i),
        "t": str(r.timestamp),
        "o": float(r.open), "h": float(r.high), "l": float(r.low),
        "c": float(r.close), "v": int(r.volume),
        "zero_volume": bool(r.volume == 0),
    } for i, r in enumerate(sub.itertuples())]

    summary = technical_summary(sub, ind, patterns, levels, as_of)

    missing = int(meta.get("missing_bars", 0) or 0)
    zero_vol = int(meta.get("zero_volume_bars", 0) or 0)
    data_notes = []
    if missing:
        data_notes.append(f"{missing} expected bar(s) missing from the source; gaps are NOT filled.")
    if zero_vol:
        data_notes.append(f"{zero_vol} zero-volume bar(s): possible stale/placeholder candles (marked on chart).")
    if not vw_valid and timeframe != "1D":
        data_notes.append("VWAP unavailable: intraday volume is zero/invalid.")
    if timeframe == "1D":
        data_notes.append("VWAP is intraday-only and is not shown for daily data.")
    grade = meta.get("quality_grade")
    if grade in ("D", "F"):
        data_notes.append(
            f"This dataset's quality report is grade {grade} "
            f"({meta.get('quality_score')}/100) — serious data issues were found. "
            f"Check the Data Import tab before trusting any signal built on it.")
    if as_of < n - 1:
        data_notes.append(f"View truncated at bar {as_of} ({len(sub)} of {n} bars). "
                          f"Patterns, levels and readings use no candle after this point.")

    return {
        "status": "ok",
        "meta": {
            "dataset_id": meta.get("dataset_id"),
            "symbol": meta.get("symbol"), "timeframe": timeframe,
            "source_type": meta.get("source_type"),
            "verification_status": meta.get("verification_status"),
            "acquisition": meta.get("acquisition"),
            "bars": len(sub), "total_bars": n,
            "start": meta.get("start"), "end": meta.get("end"),
            "missing_bars": missing, "zero_volume_bars": zero_vol,
            "research_quality": meta.get("research_quality"),
            "quality_score": meta.get("quality_score"),
            "quality_grade": meta.get("quality_grade"),
            "vwap_valid": vw_valid,
            "feed_url": meta.get("feed_url"), "retrieved_at": meta.get("retrieved_at"),
        },
        "as_of_bar": as_of,
        "truncated": bool(as_of < n - 1),
        "candles": candles,
        "indicators": {k: _list(ind[k]) for k in INDICATOR_COLUMNS},
        "indicator_columns": list(INDICATOR_COLUMNS),
        "patterns": patterns,
        "levels": levels,
        "summary": summary,
        "data_notes": data_notes,
        "integrity_note": "Candles are the actual imported historical data. Indicator warm-up values are null. "
                          "No candles or prices are fabricated; missing bars are reported, never interpolated.",
    }


def chart_symbol_groups(rows: list[dict]) -> dict:
    """Group chartable datasets BY SYMBOL, with the timeframes each has.

    The Charts tab uses this to offer a symbol picker plus a timeframe
    picker that only shows timeframes that actually exist for the chosen
    symbol — no empty dropdowns, no "symbol/timeframe" mega-combobox.
    """
    by_symbol: dict[str, list[dict]] = {}
    for r in rows:
        by_symbol.setdefault(r["symbol"], []).append(r)
    return {
        "symbols": sorted(by_symbol.keys()),
        "by_symbol": by_symbol,
        "timeframes": sorted({r["timeframe"] for r in rows}),
    }


def chart_compare_rows(datasets: list[dict]) -> list[dict]:
    """A compact TA snapshot of every timeframe available for one symbol.

    This is the cross-timeframe COMPARISON view: one row per timeframe with
    the handful of readings that actually differ between timeframes. It is
    deliberately compact — a table to orient yourself, not a second chart.
    """
    out: list[dict] = []
    for ds in datasets:
        m = ds["meta"]
        df = ds["df"]
        if df is None or len(df) == 0:
            continue
        i = len(df) - 1
        ind = compute_indicators(df, m.timeframe)
        pats = detect_patterns(df)
        lv = support_resistance(df, as_of_bar=i)
        s = technical_summary(df, ind, pats, lv, i)
        cf = s.get("confluence") or {}
        out.append({
            "key": ds["key"],
            "symbol": m.symbol,
            "timeframe": m.timeframe,
            "bars": int(m.candle_count),
            "last_bar": str(df["timestamp"].iloc[i]),
            "close": s["close"],
            "trend": s["trend"],
            "momentum": s["momentum"],
            "rsi": (s.get("rsi") or {}).get("value"),
            "atr_pct_of_price": (s.get("atr") or {}).get("pct_of_price"),
            "macd_condition": (s.get("macd") or {}).get("condition"),
            "bullish_readings": cf.get("bullish_count"),
            "bearish_readings": cf.get("bearish_count"),
            "confluence_lean": cf.get("lean"),
            "nearby_support": (lv.get("nearby_support") or {}).get("mid"),
            "nearby_resistance": (lv.get("nearby_resistance") or {}).get("mid"),
            "is_real_market_data": bool(m.source_type in (
                DataOrigin.IMPORTED_CSV, DataOrigin.BROKER_VENDOR, DataOrigin.DATA_FEED)),
        })
    out.sort(key=lambda r: (r["symbol"], r["timeframe"]))
    return out
