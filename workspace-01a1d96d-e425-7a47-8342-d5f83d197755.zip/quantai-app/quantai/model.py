"""Random Forest training, honest baselines, probability calibration,
feature-importance stability and purged walk-forward evaluation.

Everything here is deliberately conservative:

* The calibration is fitted on the VALIDATION split only. The unseen test
  split is never used to fit anything, and the report says so.
* Feature-importance stability is a DIAGNOSTIC. A stable importance ranking
  does NOT mean the feature has predictive power, and an unstable one does
  not mean the model is broken.
* Accuracy is a classification metric. It is never presented as evidence of
  trading profit.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, brier_score_loss, confusion_matrix,
                             f1_score, log_loss, precision_recall_fscore_support)

from .features import CLASSES, FEATURE_NAMES


@dataclass
class EvalReport:
    scope: str
    n: int
    accuracy: float
    majority_baseline_accuracy: float
    momentum_baseline_accuracy: float
    macro_f1: float
    log_loss: float
    brier: float
    confusion: list[list[int]]
    per_class: list[dict]
    class_counts: dict

    def to_dict(self) -> dict:
        return {
            "scope": self.scope, "samples": self.n, "accuracy": self.accuracy,
            "baseline_majority_accuracy": self.majority_baseline_accuracy,
            "baseline_momentum_accuracy": self.momentum_baseline_accuracy,
            "macro_f1": self.macro_f1, "log_loss": self.log_loss, "brier": self.brier,
            "confusion_matrix_rows_actual_cols_pred": self.confusion,
            "class_order": CLASSES, "per_class": self.per_class, "class_counts": self.class_counts,
        }


def fit_forest(X: np.ndarray, y: np.ndarray, n_estimators: int, max_depth: int,
               min_samples_leaf: int, seed: int) -> RandomForestClassifier:
    if len(np.unique(y)) < 2:
        raise ValueError("Training window contains a single class; cannot train a classifier.")
    clf = RandomForestClassifier(
        n_estimators=n_estimators, max_depth=max_depth, min_samples_leaf=min_samples_leaf,
        max_features="sqrt", bootstrap=True, random_state=seed, n_jobs=-1,
    )
    clf.fit(X, y)
    return clf


def _proba(clf, X: np.ndarray) -> np.ndarray:
    """Expand a model's class-column probabilities into the full 3-class matrix.

    Works for a plain RandomForestClassifier and for a CalibratedForest.
    """
    p = clf.predict_proba(X)
    full = np.zeros((len(X), 3))
    for col, cls in enumerate(clf.classes_):
        full[:, int(cls)] = p[:, col]
    return full


def evaluate(clf: RandomForestClassifier, X: np.ndarray, y: np.ndarray,
             train_y: np.ndarray, momentum_signal: np.ndarray, scope: str,
             proba_override: np.ndarray | None = None) -> EvalReport:
    proba = _proba(clf, X) if proba_override is None else np.asarray(proba_override, dtype=float)
    pred = proba.argmax(axis=1)
    majority = int(np.bincount(train_y, minlength=3).argmax())
    conf = confusion_matrix(y, pred, labels=[0, 1, 2])
    prec, rec, f1, sup = precision_recall_fscore_support(y, pred, labels=[0, 1, 2], zero_division=0)
    per_class = [
        {"class": CLASSES[i], "support": int(sup[i]), "precision": float(prec[i]),
         "recall": float(rec[i]), "f1": float(f1[i])}
        for i in range(3)
    ]
    return EvalReport(
        scope=scope, n=int(len(y)),
        accuracy=float(accuracy_score(y, pred)),
        majority_baseline_accuracy=float((y == majority).mean()),
        momentum_baseline_accuracy=float((y == momentum_signal).mean()),
        macro_f1=float(f1_score(y, pred, average="macro", labels=[0, 1, 2], zero_division=0)),
        log_loss=float(log_loss(y, proba, labels=[0, 1, 2])),
        brier=float(np.mean(np.sum((proba - np.eye(3)[y]) ** 2, axis=1))),
        confusion=conf.tolist(), per_class=per_class,
        class_counts={CLASSES[i]: int((y == i).sum()) for i in range(3)},
    )


def momentum_baseline(returns_5: np.ndarray, threshold: float = 0.002) -> np.ndarray:
    out = np.full(len(returns_5), 1, dtype=int)
    out[returns_5 > threshold] = 2
    out[returns_5 < -threshold] = 0
    return out


def walk_forward(X: np.ndarray, y: np.ndarray, candles: np.ndarray, horizon: int,
                 folds: int, n_estimators: int, max_depth: int, min_samples_leaf: int,
                 seed: int) -> list[dict]:
    """Expanding-window, purged, out-of-sample folds. No shuffling, ever.

    Every fold also records the feature importance of the forest that produced
    it, so the walk-forward section can show whether the model relied on the
    same features as it went on.
    """
    n = len(y)
    min_train = max(50, int(n * 0.4))
    fold_size = (n - min_train - horizon) // max(1, folds)
    results = []
    if fold_size < 10:
        return results
    for k in range(folds):
        split = min_train + k * fold_size
        test_start = split + horizon
        test_end = min(n, test_start + fold_size)
        if test_end - test_start < 5:
            break
        try:
            clf = fit_forest(X[:split], y[:split], n_estimators, max_depth, min_samples_leaf, seed + k)
        except ValueError:
            continue
        proba = _proba(clf, X[test_start:test_end])
        pred = proba.argmax(axis=1)
        truth = y[test_start:test_end]
        imp = feature_importance(clf)
        top = sorted(imp.items(), key=lambda kv: kv[1], reverse=True)[:5]
        results.append({
            "fold": k + 1,
            "train_candles": [int(candles[0]), int(candles[split - 1])],
            "purged_candles": [int(candles[split]), int(candles[test_start - 1])],
            "test_candles": [int(candles[test_start]), int(candles[test_end - 1])],
            "test_samples": int(len(truth)),
            "accuracy": float((pred == truth).mean()),
            "macro_f1": float(f1_score(truth, pred, average="macro", labels=[0, 1, 2], zero_division=0)),
            "feature_importance": imp,
            "top_features": [name for name, _ in top],
        })
    return results


def aggregate_walk_forward_importance(walk_forward: list[dict]) -> dict:
    """Mean feature importance across the walk-forward folds.

    Each fold trains on its own expanding window, so the aggregate shows how
    much the model's explanation moved as the window grew.
    """
    folds = [f for f in (walk_forward or []) if f.get("feature_importance")]
    if not folds:
        return {"mean": {}, "per_fold_top_features": [], "n_folds": 0,
                "note": "No walk-forward folds carried a feature-importance snapshot."}
    names = list(FEATURE_NAMES)
    mean = {}
    for name in names:
        vals = [float(f["feature_importance"].get(name, 0.0)) for f in folds]
        mean[name] = float(np.mean(vals))
    per_fold_top = [f.get("top_features", []) for f in folds]
    # How often each feature was in a fold's top 5.
    freq = {name: 0 for name in names}
    for top in per_fold_top:
        for name in top:
            if name in freq:
                freq[name] += 1
    top_features = sorted(freq.items(), key=lambda kv: (-kv[1], -mean.get(kv[0], 0.0)))
    return {
        "mean": mean,
        "n_folds": len(folds),
        "per_fold_top_features": per_fold_top,
        "top_feature_frequency": {name: freq[name] / len(folds) for name, _ in top_features},
        "most_consistent_features": [name for name, _ in top_features[:5]],
        "note": "Each fold trains on its own expanding window; the aggregate is the mean "
                "importance across folds. Importance is an explanation of the MODEL, not "
                "evidence that a feature predicts anything.",
    }


class CalibratedForest:
    """A trained forest plus its probability calibrator, as ONE deployable model.

    This is the object that gets saved and reloaded. It keeps the exact
    interface the rest of the app already relies on:

    * ``classes_``            -> the forest's classes, in order
    * ``predict_proba(X)``    -> CALIBRATED probabilities, same column layout
    * ``predict(X)``          -> the (unchanged) predicted class
    * ``feature_importances_``-> the forest's importances

    Because temperature scaling preserves the class order inside every row,
    ``predict`` returns exactly what the uncalibrated forest returned. The
    only thing that changes is how confident the numbers sound.

    A plain ``RandomForestClassifier`` saved by an older version still loads
    and works everywhere — it simply has no calibrator, so its probabilities
    are the raw ones.
    """

    def __init__(self, forest: RandomForestClassifier, calibrator: "ProbabilityCalibrator | None" = None):
        self.forest = forest
        self.calibrator = calibrator

    # --- sklearn-ish surface -------------------------------------------
    @property
    def classes_(self):
        return self.forest.classes_

    @property
    def feature_importances_(self):
        return self.forest.feature_importances_

    @property
    def n_features_in_(self) -> int:
        return int(self.forest.n_features_in_)

    @property
    def n_estimators(self) -> int:
        return int(self.forest.n_estimators)

    @property
    def max_depth(self):
        return self.forest.max_depth

    @property
    def min_samples_leaf(self) -> int:
        return int(self.forest.min_samples_leaf)

    @property
    def random_state(self):
        return self.forest.random_state

    def predict_proba(self, X) -> np.ndarray:
        """Calibrated probabilities, in the SAME column layout as the forest.

        The calibration is always applied in the full DOWN/SIDE/UP space and
        then projected back onto the columns the forest actually has, so the
        numbers are identical to ``_proba(forest, X)`` after calibration.
        """
        raw = self.forest.predict_proba(X)
        if self.calibrator is None:
            return raw
        full = np.zeros((len(raw), 3))
        for col, cls in enumerate(self.forest.classes_):
            full[:, int(cls)] = raw[:, col]
        cal = self.calibrator.apply(full)
        out = np.zeros_like(raw)
        for col, cls in enumerate(self.forest.classes_):
            out[:, col] = cal[:, int(cls)]
        return out

    def predict(self, X) -> np.ndarray:
        return self.forest.classes_[np.argmax(self.predict_proba(X), axis=1)]

    def score(self, X, y) -> float:
        return float((self.predict(X) == np.asarray(y)).mean())

    # --- diagnostics ----------------------------------------------------
    def calibration_dict(self) -> dict:
        if self.calibrator is None:
            return {"method": "none", "fitted": False,
                    "note": "This model has no calibrator; its probabilities are raw."}
        return self.calibrator.to_dict()

    def __repr__(self) -> str:
        t = self.calibrator.temperature if self.calibrator else None
        return f"<CalibratedForest trees={self.forest.n_estimators} temperature={t}>"


def model_feature_count(model) -> int | None:
    """How many features a saved model was trained on (None if unknown)."""
    n = getattr(model, "n_features_in_", None)
    try:
        return int(n) if n is not None else None
    except (TypeError, ValueError):
        return None


def model_matches_features(model, expected: int | None = None) -> bool:
    """True when the saved model can consume TODAY's feature matrix.

    A model trained on an older feature set (a different number of columns)
    would raise inside scikit-learn. Checking the recorded width here lets the
    app skip an incompatible model instead of crashing the replay.
    """
    want = len(FEATURE_NAMES) if expected is None else int(expected)
    have = model_feature_count(model)
    if have is None:
        return True          # unknown width -> let the caller try it
    return have == want


def feature_importance(clf) -> dict:
    """Feature importances of a forest or a CalibratedForest, in FEATURE_NAMES order."""
    return {name: float(imp) for name, imp in zip(FEATURE_NAMES, clf.feature_importances_)}


# --------------------------------------------------------------------------
# Probability calibration (temperature scaling)
# --------------------------------------------------------------------------
#
# WHY TEMPERATURE SCALING
# ------------------------
# A random forest trained on three noisy classes is usually badly OVER-confident
# on the bars it gets wrong and under-confident on the bars it gets right. The
# fix must repair the CONFIDENCE without quietly changing the DECISIONS, so
# this app calibrates with a single temperature ``T`` applied in logit space:
#
#     z = log(p)                       # the forest's log-probabilities
#     p_calibrated  =  softmax(z / T)  # == p ** (1/T), renormalised
#
# Because ``T`` is one positive number, the ORDER of the three classes inside
# every row is preserved: softmax(z/T) is maximised by the same class that
# maximises z. The arg-max is therefore mathematically identical before and
# after calibration. That matters here because the backtest turns
# ``p_up - p_down`` into a score and compares it to a fixed threshold — a
# calibrator that silently flipped classes would change live trading behaviour
# under the guise of "better probabilities".
#
# WHAT IS AND IS NOT CONTAMINATED
# --------------------------------
# The calibrator is fitted on the VALIDATION split only. The test split is
# never seen by the calibrator, so the calibration numbers reported for the
# test split are a genuine out-of-sample measurement of the deployed pipeline
# (forest + calibrator). The training split is reported with the raw forest,
# because it is in-sample for the forest and calibrating it would only make
# an already optimistic number look prettier.

CALIBRATION_TEMPERATURE_BOUNDS = (0.25, 4.0)
CALIBRATION_MIN_SAMPLES = 30


def _nll(proba: np.ndarray, y: np.ndarray) -> float:
    """Mean negative log-likelihood of the true class."""
    p = np.asarray(proba, dtype=float)
    y = np.asarray(y, dtype=int)
    if len(y) == 0:
        return float("nan")
    picked = np.clip(p[np.arange(len(y)), y], 1e-12, 1.0)
    return float(-np.log(picked).mean())


def apply_temperature(proba: np.ndarray, temperature: float) -> np.ndarray:
    """softmax(log(p) / T) == p ** (1/T), renormalised. Arg-max preserving."""
    p = np.asarray(proba, dtype=float)
    T = float(temperature)
    if not np.isfinite(T) or T <= 0:
        T = 1.0
    q = np.power(np.clip(p, 1e-12, None), 1.0 / T)
    s = q.sum(axis=1, keepdims=True)
    return q / np.where(s > 0, s, 1.0)


@dataclass
class ProbabilityCalibrator:
    """A single-temperature calibrator fitted on the validation split.

    Attributes
    ----------
    method : str
        Always ``"temperature_scaling"``.
    temperature : float
        The fitted ``T``. ``T > 1`` flattens (fixes over-confidence),
        ``T < 1`` sharpens (fixes under-confidence), ``T == 1`` is a no-op.
    n_samples : int
        How many validation samples the temperature was fitted on.
    fitted : bool
        ``False`` means the calibrator is an identity transform and the
        reported probabilities are the raw, uncalibrated ones.
    notes : list
        Human-readable statements about anything that limited the fit.
    """

    method: str = "temperature_scaling"
    temperature: float = 1.0
    n_samples: int = 0
    fitted: bool = False
    notes: list = field(default_factory=list)

    def apply(self, proba: np.ndarray) -> np.ndarray:
        p = np.asarray(proba, dtype=float)
        if not self.fitted or p.ndim != 2:
            return p.copy()
        return apply_temperature(p, self.temperature)

    def to_dict(self) -> dict:
        return {
            "method": self.method,
            "fitted": bool(self.fitted),
            "temperature": float(self.temperature),
            "n_samples": int(self.n_samples),
            "notes": list(self.notes),
            "guarantee": "Temperature scaling preserves the class ordering of every row, so the "
                         "arg-max (and therefore the predicted class) is unchanged. "
                         "It fixes confidence, not the prediction. Threshold-based rules that "
                         "act on p_up - p_down can still change their entry frequency.",
        }


def _fit_temperature(proba: np.ndarray, y: np.ndarray) -> float:
    """Deterministic coarse-to-fine search for the NLL-minimising temperature."""
    lo, hi = CALIBRATION_TEMPERATURE_BOUNDS
    grid = np.linspace(lo, hi, 61)
    best_t, best_nll = 1.0, float("inf")
    for t in grid:
        nll = _nll(apply_temperature(proba, t), y)
        if np.isfinite(nll) and nll < best_nll:
            best_t, best_nll = float(t), nll
    # Local refinement around the grid winner.
    span = (hi - lo) / 60.0
    for _ in range(4):
        centre = best_t
        cand = np.linspace(max(lo, centre - span), min(hi, centre + span), 21)
        for t in cand:
            nll = _nll(apply_temperature(proba, t), y)
            if np.isfinite(nll) and nll < best_nll:
                best_t, best_nll = float(t), nll
        span /= 4.0
    return best_t


def fit_probability_calibrator(clf: RandomForestClassifier, X_cal: np.ndarray,
                                y_cal: np.ndarray,
                                min_samples: int = CALIBRATION_MIN_SAMPLES) -> ProbabilityCalibrator:
    """Fit the temperature on the VALIDATION split only.

    ``X_cal`` / ``y_cal`` MUST be the validation arrays. The test split is
    never passed here, which is what keeps the reported test calibration
    numbers honest.

    The temperature is fitted in the full DOWN/SIDE/UP probability space.
    A class the forest never saw contributes exactly zero, and raising zero to
    a power still gives zero, so the normalisation is identical whether it is
    done over three columns or over the columns the forest actually has.
    """
    cal = ProbabilityCalibrator()
    if X_cal is None or len(X_cal) == 0:
        cal.notes.append("No calibration samples were available; probabilities are uncalibrated.")
        return cal
    y = np.asarray(y_cal, dtype=int)
    cal.n_samples = int(len(y))
    if len(y) < min_samples:
        cal.notes.append(
            f"Only {len(y)} validation sample(s) (minimum {min_samples}); "
            "probabilities are left uncalibrated rather than fitted on a thin sample.")
        return cal
    if len(np.unique(y)) < 2:
        cal.notes.append("The validation split contains a single class; probabilities are left uncalibrated.")
        return cal
    raw = _proba(clf, X_cal)
    t = _fit_temperature(raw, y)
    cal.temperature = t
    cal.fitted = True
    lo, hi = CALIBRATION_TEMPERATURE_BOUNDS
    if t <= lo + 1e-9 or t >= hi - 1e-9:
        cal.notes.append(
            f"The fitted temperature {t:.3f} sits at the edge of the allowed range "
            f"[{lo}, {hi}]; the model is badly miscalibrated in this sample and the "
            "correction should be treated as provisional.")
    if t > 1.0:
        cal.notes.append(
            f"Temperature {t:.3f} > 1: the forest was OVER-confident and the "
            "calibrated probabilities are pulled closer to the base rates.")
    elif t < 1.0:
        cal.notes.append(
            f"Temperature {t:.3f} < 1: the forest was UNDER-confident and the "
            "calibrated probabilities are sharpened.")
    cal.notes.append(
        "The temperature was fitted on the validation split only. The test split was "
        "never used to fit it, so the test calibration numbers are out-of-sample.")
    return cal


def expected_calibration_error(proba: np.ndarray, y: np.ndarray, bins: int = 10) -> float:
    """Top-label ECE: |confidence - accuracy| weighted by bin population."""
    p = np.asarray(proba, dtype=float)
    y = np.asarray(y, dtype=int)
    if len(y) == 0:
        return float("nan")
    conf = p.max(axis=1)
    correct = (p.argmax(axis=1) == y).astype(float)
    edges = np.linspace(0.0, 1.0, bins + 1)
    ece = 0.0
    for i in range(bins):
        lo, hi = edges[i], edges[i + 1]
        m = (conf > lo) & (conf <= hi)
        if i == 0:
            m = m | (conf == edges[0])
        if not m.any():
            continue
        ece += m.mean() * abs(correct[m].mean() - conf[m].mean())
    return float(ece)


def calibration_report(raw_proba: np.ndarray, cal_proba: np.ndarray, y: np.ndarray) -> dict:
    """Before/after calibration on the same samples. Numbers only, no claims."""
    raw = np.asarray(raw_proba, dtype=float)
    cal = np.asarray(cal_proba, dtype=float)
    y = np.asarray(y, dtype=int)
    if len(y) == 0:
        return {"samples": 0, "note": "No samples to calibrate."}
    onehot = np.eye(3)[y]
    brier_raw = float(np.mean(np.sum((raw - onehot) ** 2, axis=1)))
    brier_cal = float(np.mean(np.sum((cal - onehot) ** 2, axis=1)))
    ece_raw = expected_calibration_error(raw, y)
    ece_cal = expected_calibration_error(cal, y)
    try:
        ll_raw = float(log_loss(y, raw, labels=[0, 1, 2]))
    except Exception:
        ll_raw = float("nan")
    try:
        ll_cal = float(log_loss(y, cal, labels=[0, 1, 2]))
    except Exception:
        ll_cal = float("nan")
    acc_raw = float((raw.argmax(axis=1) == y).mean())
    acc_cal = float((cal.argmax(axis=1) == y).mean())
    return {
        "samples": int(len(y)),
        "accuracy_raw": acc_raw, "accuracy_calibrated": acc_cal,
        "argmax_preserved": bool((raw.argmax(axis=1) == cal.argmax(axis=1)).all()),
        "brier_raw": brier_raw, "brier_calibrated": brier_cal,
        "brier_improvement": brier_raw - brier_cal,
        "log_loss_raw": ll_raw, "log_loss_calibrated": ll_cal,
        "expected_calibration_error_raw": ece_raw,
        "expected_calibration_error_calibrated": ece_cal,
        "ece_improvement": (ece_raw - ece_cal) if np.isfinite(ece_raw) and np.isfinite(ece_cal) else None,
        "improved": bool(brier_cal < brier_raw or ece_cal < ece_raw),
        "note": "Calibration changes how confident the model is allowed to sound. It does "
                "NOT change the ranking of the classes, and it is NOT evidence of an edge.",
    }


# --------------------------------------------------------------------------
# Feature-importance stability across seeds
# --------------------------------------------------------------------------
def _average_ranks(values: np.ndarray) -> np.ndarray:
    """Ranks with ties averaged (1 = highest value)."""
    x = np.asarray(values, dtype=float)
    n = len(x)
    order = np.argsort(-x, kind="mergesort")
    ranks = np.empty(n, dtype=float)
    i = 0
    while i < n:
        j = i
        while j + 1 < n and x[order[j + 1]] == x[order[i]]:
            j += 1
        avg = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        i = j + 1
    return ranks


def _pearson(a: np.ndarray, b: np.ndarray) -> float:
    if len(a) < 2:
        return float("nan")
    sa, sb = a.std(), b.std()
    if sa == 0 or sb == 0:
        return float("nan")
    return float(np.mean((a - a.mean()) * (b - b.mean())) / (sa * sb))


def feature_importance_stability(
    X: np.ndarray, y: np.ndarray, *,
    seeds=(42, 7, 2024), n_estimators: int = 200, max_depth: int = 6,
    min_samples_leaf: int = 20,
) -> dict:
    """Refit the forest on several seeds and compare the importance rankings.

    A feature that matters will keep roughly the same rank across seeds. One
    whose rank swings around is not a stable explanation of the model — that is
    a diagnostic about the FEATURE, never a statement that the model is right
    or wrong.
    """
    seeds = tuple(int(s) for s in seeds)
    importances: list[np.ndarray] = []
    used_seeds: list[int] = []
    for s in seeds:
        try:
            clf = fit_forest(X, y, n_estimators, max_depth, min_samples_leaf, s)
        except ValueError:
            continue
        importances.append(np.asarray(clf.feature_importances_, dtype=float))
        used_seeds.append(s)
    if len(importances) < 2:
        return {
            "seeds": used_seeds, "stability_score": None,
            "note": "At least two seeds are needed for a stability comparison; "
                    "the training window may contain a single class.",
            "features": {}, "flags": [],
        }

    I = np.vstack(importances)                      # (seeds, features)
    ranks = np.vstack([_average_ranks(row) for row in I])
    mean_imp = I.mean(axis=0)
    std_imp = I.std(axis=0)
    mean_rank = ranks.mean(axis=0)
    rank_std = ranks.std(axis=0)

    corrs: list[float] = []
    for a in range(len(used_seeds)):
        for b in range(a + 1, len(used_seeds)):
            c = _pearson(ranks[a], ranks[b])
            if np.isfinite(c):
                corrs.append(c)
    mean_corr = float(np.mean(corrs)) if corrs else float("nan")
    stability_score = int(round(max(0.0, min(100.0, 100.0 * mean_corr)))) if np.isfinite(mean_corr) else None

    top_k = min(5, len(FEATURE_NAMES))
    per_feature = {}
    unstable: list[str] = []
    zero_importance: list[str] = []
    for i, name in enumerate(FEATURE_NAMES):
        top_count = int(sum(1 for row in ranks if row[i] <= top_k))
        entry = {
            "mean_importance": float(mean_imp[i]),
            "std_importance": float(std_imp[i]),
            "mean_rank": float(mean_rank[i]),
            "rank_std": float(rank_std[i]),
            "min_rank": float(ranks[:, i].min()),
            "max_rank": float(ranks[:, i].max()),
            "top5_frequency": top_count / len(used_seeds),
            "used_in_all_seeds": bool((I[:, i] > 0).all()),
        }
        per_feature[name] = entry
        if entry["rank_std"] > 3.0 and entry["mean_importance"] > 0:
            unstable.append(name)
        if entry["mean_importance"] == 0.0:
            zero_importance.append(name)

    flags: list[str] = []
    if stability_score is not None and stability_score < 60:
        flags.append(
            f"Feature-importance rankings are only weakly stable across {len(used_seeds)} seeds "
            f"(rank correlation {mean_corr:.2f}). Treat any single-feature story with caution.")
    if unstable:
        flags.append(
            f"{len(unstable)} feature(s) moved more than 3 rank positions between seeds: "
            f"{', '.join(unstable[:6])}.")
    if zero_importance:
        flags.append(
            f"{len(zero_importance)} feature(s) received zero importance in every seed "
            f"(the forest never split on them).")
    return {
        "seeds": used_seeds,
        "n_features": len(FEATURE_NAMES),
        "rank_correlation_mean": mean_corr,
        "rank_correlation_pairs": corrs,
        "stability_score": stability_score,
        "unstable_features": unstable,
        "zero_importance_features": zero_importance,
        "features": per_feature,
        "flags": flags,
        "note": "Stability measures whether the model tells the same story across random "
                "seeds. It says NOTHING about predictive power or trading edge — a "
                "consistently useless feature can be perfectly stable.",
    }


def overfit_diagnostics(train_rep: dict, val_rep: dict, test_rep: dict,
                        walk_forward: list[dict]) -> dict:
    """Heuristic overfit / reliability flags. These are warnings, not proofs.

    A model is NOT declared to have an edge here — only whether its reported
    numbers look internally consistent enough to deserve further study.
    """
    flags: list[str] = []
    train_acc = train_rep.get("accuracy", 0.0)
    val_acc = val_rep.get("accuracy", 0.0)
    test_acc = test_rep.get("accuracy", 0.0)
    gap_train_test = train_acc - test_acc
    gap_val_test = val_acc - test_acc

    if gap_train_test > 0.15:
        flags.append(f"Train→test accuracy gap {gap_train_test:.1%} (>15%): likely overfitting.")
    if gap_val_test > 0.10:
        flags.append(f"Validation→test accuracy gap {gap_val_test:.1%} (>10%): unstable generalisation.")
    if test_rep.get("samples", 0) < 100:
        flags.append(f"Only {test_rep.get('samples', 0)} test samples: metrics are high-variance.")

    wf_accs = [f["accuracy"] for f in walk_forward] if walk_forward else []
    wf_mean = float(np.mean(wf_accs)) if wf_accs else None
    if wf_mean is not None and test_acc - wf_mean > 0.10:
        flags.append(f"Holdout accuracy {test_acc:.1%} exceeds walk-forward mean {wf_mean:.1%} by >10%: possible window luck.")

    best_baseline = max(test_rep.get("baseline_majority_accuracy", 0),
                        test_rep.get("baseline_momentum_accuracy", 0))
    beats_baseline = test_acc > best_baseline
    if not beats_baseline:
        flags.append("Model does not beat the better simple baseline on the unseen test split.")

    # Class imbalance can make accuracy flattering.
    counts = test_rep.get("class_counts", {})
    if counts:
        total = sum(counts.values()) or 1
        majority_share = max(counts.values()) / total
        if majority_share > 0.70:
            flags.append(f"Majority class is {majority_share:.0%} of test labels: accuracy alone is misleading.")

    if gap_train_test > 0.25 or not beats_baseline:
        reliability = "LOW"
    elif flags:
        reliability = "MEDIUM"
    else:
        reliability = "OK"

    return {
        "train_accuracy": train_acc, "validation_accuracy": val_acc, "test_accuracy": test_acc,
        "train_test_gap": gap_train_test, "validation_test_gap": gap_val_test,
        "walk_forward_mean_accuracy": wf_mean, "beats_better_baseline": beats_baseline,
        "flags": flags, "reliability": reliability,
        "note": "Accuracy is a classification metric, NOT evidence of trading profit. "
                "The verdict also requires positive after-cost backtest returns, enough trades, "
                "and beating buy & hold.",
    }

