"""Causal support / resistance zone detection from historical price action.

Method:
  * Fractal pivots: a pivot high/low at bar i is the extreme of a
    [i-left, i+right] window. It is only CONFIRMED at bar i+right, because the
    right-hand bars must exist. We never confirm a pivot using bars after the
    requested `as_of_bar`.
  * Confirmed pivots are clustered by price into zones (tolerance = max of a
    price percentage and half an ATR). Zone strength = number of touches.
  * DEVELOPING levels are the most recent unconfirmed swing high/low (last
    `right` bars). They are shown separately and are explicitly unconfirmed.

For a historical signal at bar t, call support_resistance(df, as_of_bar=t):
only information available up to t is used.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .indicators import atr


def detect_pivots(df: pd.DataFrame, left: int = 5, right: int = 5) -> list[dict]:
    """Fractal swing pivots.

    A pivot high at bar i is the highest high of the window [i-left, i+right].
    Ties are resolved to the FIRST bar that reaches the extreme, so a flat or
    repetitive series still produces usable (if weak) pivots instead of none.
    The pivot is only CONFIRMED at bar i+right.
    """
    h = df["high"].to_numpy(dtype=float)
    l = df["low"].to_numpy(dtype=float)
    n = len(df)
    pivots = []
    if n < left + right + 1:
        return pivots
    for i in range(left, n - right):
        left_h = h[i - left:i]
        right_h = h[i + 1:i + right + 1]
        left_l = l[i - left:i]
        right_l = l[i + 1:i + right + 1]
        # Strict on the left, non-strict on the right: when several bars tie for
        # the extreme, the EARLIEST one wins (the confirmed pivot).
        if h[i] > left_h.max() and h[i] >= right_h.max():
            pivots.append({"bar": i, "price": float(h[i]), "kind": "high",
                           "confirmation_bar": i + right})
        if l[i] < left_l.min() and l[i] <= right_l.min():
            pivots.append({"bar": i, "price": float(l[i]), "kind": "low",
                           "confirmation_bar": i + right})
    return pivots


def zone_activity(df: pd.DataFrame, zone: dict, atr_series: pd.Series,
                  lookforward: int = 5, reaction_atr: float = 0.5) -> dict:
    """How often a zone was TOUCHED and how often it REACTED.

    A *touch* is a bar whose range reaches into the zone band. A *reaction* is
    a touch after which price moved AWAY from the zone by at least
    ``reaction_atr`` ATRs within the next ``lookforward`` bars.

    The direction of "away" comes from the zone's own pivots: a zone built
    mostly from swing LOWS is treated as support (price should bounce UP out
    of it), a zone built mostly from swing HIGHS as resistance (price should
    fall back out of it).

    This is a descriptive count of what happened at that price. It says
    nothing about whether the zone will hold next time.
    """
    lo = float(zone["price_low"])
    hi = float(zone["price_high"])
    kinds = zone.get("pivot_kinds") or {}
    bullish_reaction = kinds.get("low", 0) >= kinds.get("high", 0)

    n = len(df)
    if n == 0:
        return {"touch_count": 0, "reaction_count": 0, "reaction_rate": None,
                "touches": [], "first_touch_bar": None, "last_touch_bar": None,
                "avg_bars_between_touches": None, "reaction_direction":
                "bullish" if bullish_reaction else "bearish"}

    h = df["high"].to_numpy(dtype=float)
    l = df["low"].to_numpy(dtype=float)
    c = df["close"].to_numpy(dtype=float)
    a = np.asarray(atr_series, dtype=float)

    touches: list[dict] = []
    for i in range(n):
        if not (l[i] <= hi and h[i] >= lo):
            continue
        # A touch that is already deep inside the band is not a test of it.
        if bullish_reaction:
            moved = c[i] > hi
            away = "up"
        else:
            moved = c[i] < lo
            away = "down"
        reacted = False
        react_bar = None
        react_price = None
        if moved:
            reacted = True
            react_bar = i
            react_price = float(c[i])
        else:
            for j in range(i + 1, min(n, i + 1 + lookforward)):
                av = a[j] if j < len(a) else np.nan
                if not np.isfinite(av):
                    continue
                if bullish_reaction and c[j] >= hi + reaction_atr * av:
                    reacted = True
                    react_bar = j
                    react_price = float(c[j])
                    break
                if not bullish_reaction and c[j] <= lo - reaction_atr * av:
                    reacted = True
                    react_bar = j
                    react_price = float(c[j])
                    break
        touches.append({
            "bar": int(i),
            "time": str(df["timestamp"].iloc[i]),
            "reacted": bool(reacted),
            "reaction_bar": react_bar,
            "reaction_price": react_price,
            "reaction_move": ("away up" if bullish_reaction else "away down"),
        })

    touch_bars = [t["bar"] for t in touches]
    gaps = [b - a_ for a_, b in zip(touch_bars, touch_bars[1:])] if len(touch_bars) > 1 else []
    n_reacted = sum(1 for t in touches if t["reacted"])
    return {
        "touch_count": len(touches),
        "reaction_count": n_reacted,
        "reaction_rate": (n_reacted / len(touches)) if touches else None,
        "touches": touches[-40:],
        "touches_shown": min(len(touches), 40),
        "touches_truncated": len(touches) > 40,
        "first_touch_bar": touch_bars[0] if touch_bars else None,
        "last_touch_bar": touch_bars[-1] if touch_bars else None,
        "last_touch_time": touches[-1]["time"] if touches else None,
        "avg_bars_between_touches": (sum(gaps) / len(gaps)) if gaps else None,
        "reaction_direction": "bullish" if bullish_reaction else "bearish",
        "note": ("A touch is a bar that reached into the zone; a reaction is a touch after "
                 "which price moved away by at least 0.5 ATR within 5 bars. These are counts "
                 "of what happened, not a forecast."),
    }


def _cluster(pivots: list[dict], tolerance: float, current_price: float,
             confirmed: bool) -> list[dict]:
    if not pivots:
        return []
    ordered = sorted(pivots, key=lambda p: p["price"])
    clusters: list[list[dict]] = []
    for p in ordered:
        if clusters and p["price"] - clusters[-1][-1]["price"] <= tolerance:
            clusters[-1].append(p)
        else:
            clusters.append([p])
    zones = []
    for cl in clusters:
        prices = [p["price"] for p in cl]
        lo, hi = min(prices), max(prices)
        mid = float(np.mean(prices))
        if hi < current_price:
            kind = "support"
        elif lo > current_price:
            kind = "resistance"
        else:
            kind = "in_zone"
        kinds: dict[str, int] = {}
        for p in cl:
            kinds[p.get("kind", "low")] = kinds.get(p.get("kind", "low"), 0) + 1
        zones.append({
            "price_low": float(lo), "price_high": float(hi), "mid": mid,
            "strength": len(cl), "kind": kind, "confirmed": confirmed,
            "last_bar": int(max(p["bar"] for p in cl)),
            "source": "pivot_cluster" if confirmed else "recent_swing",
            "pivot_kinds": kinds,
        })
    return zones


def zone_strength_label(zone: dict) -> str:
    """A plain-language strength label for a zone.

    ``touches`` is how many pivot touches built the zone; ``reactions`` is how
    often price actually bounced off it. A zone with many touches but few
    reactions is a level that price kept reaching THROUGH — which is the
    opposite of a strong level, so the label says so.
    """
    touches = int(zone.get("touches", 0) or 0)
    reactions = int(zone.get("reactions", 0) or 0)
    rate = zone.get("reaction_rate")
    pivot_strength = int(zone.get("strength", 0) or 0)
    if touches == 0:
        return "untested"
    if rate is None:
        return "unrated"
    if rate >= 0.7 and touches >= 3:
        return "strong"
    if rate >= 0.45:
        return "moderate"
    if rate >= 0.25:
        return "weak"
    return "failed"          # price kept reaching it and kept going through


def support_resistance(df: pd.DataFrame, as_of_bar: int | None = None,
                       left: int = 5, right: int = 5,
                       tolerance_pct: float = 0.5, max_zones: int = 10) -> dict:
    n = len(df)
    if n == 0:
        return {"as_of_bar": None, "zones": [], "confirmed": [], "developing": [],
                "nearby_support": None, "nearby_resistance": None,
                "message": "No data."}
    as_of = n - 1 if as_of_bar is None else int(as_of_bar)
    as_of = max(0, min(as_of, n - 1))
    sub = df.iloc[:as_of + 1]
    current_price = float(sub["close"].iloc[-1])

    pivots = detect_pivots(sub, left, right)
    # Every pivot here has confirmation_bar <= as_of by construction (sub length).
    a = atr(sub, 14)
    atr_val = float(a.iloc[-1]) if len(a) and np.isfinite(a.iloc[-1]) else 0.0
    tolerance = max(current_price * tolerance_pct / 100.0, atr_val * 0.5, 1e-9)

    confirmed_zones = _cluster(pivots, tolerance, current_price, confirmed=True)

    # Developing: recent unconfirmed swing extremes over the last `right` bars.
    recent = sub.iloc[max(0, len(sub) - right - 1):]
    dev_pivots = []
    if len(recent):
        dev_pivots.append({"bar": as_of, "price": float(recent["high"].max()), "kind": "high"})
        dev_pivots.append({"bar": as_of, "price": float(recent["low"].min()), "kind": "low"})
    developing_zones = _cluster(dev_pivots, tolerance, current_price, confirmed=False)
    # Drop developing zones that duplicate an already-confirmed zone.
    developing_zones = [
        z for z in developing_zones
        if not any(abs(z["mid"] - cz["mid"]) <= tolerance for cz in confirmed_zones)
    ]

    zones = confirmed_zones + developing_zones
    zones.sort(key=lambda z: abs(z["mid"] - current_price))
    zones = zones[:max_zones]

    # Attach the touch / reaction history to every zone. This is what makes a
    # zone's STRENGTH meaningful: how often price reached it, and how often it
    # actually pushed price away afterwards.
    for z in zones:
        act = zone_activity(sub, z, a)
        z["touches"] = act["touch_count"]
        z["reactions"] = act["reaction_count"]
        z["reaction_rate"] = act["reaction_rate"]
        z["touch_history"] = act["touches"]
        z["touch_history_shown"] = act["touches_shown"]
        z["touch_history_truncated"] = act["touches_truncated"]
        z["touch_note"] = act["note"]
        z["first_touch_bar"] = act["first_touch_bar"]
        z["last_touch_bar"] = act["last_touch_bar"]
        z["last_touch_time"] = act["last_touch_time"]
        z["avg_bars_between_touches"] = act["avg_bars_between_touches"]
        z["reaction_direction"] = act["reaction_direction"]
        z["strength_label"] = zone_strength_label(z)
        # A stable id so the UI can select "this zone" across renders and
        # across a timeframe switch (ids are derived from kind + price band).
        z["zone_id"] = f"{z['kind']}:{z['price_low']:.4f}:{z['price_high']:.4f}"

    supports = [z for z in zones if z["kind"] == "support"]
    resistances = [z for z in zones if z["kind"] == "resistance"]

    def _nearest(cands, pick_max):
        """Prefer a CONFIRMED zone; fall back to a developing one."""
        conf = [z for z in cands if z["confirmed"]]
        pool = conf if conf else cands
        if not pool:
            return None
        return (max if pick_max else min)(pool, key=lambda z: z["mid"])

    nearby_support = _nearest(supports, True)
    nearby_resistance = _nearest(resistances, False)

    return {
        "as_of_bar": as_of,
        "as_of_timestamp": str(sub["timestamp"].iloc[-1]),
        "current_price": current_price,
        "tolerance": float(tolerance),
        "zones": zones,
        "confirmed": [z for z in zones if z["confirmed"]],
        "developing": [z for z in zones if not z["confirmed"]],
        "nearby_support": nearby_support,
        "nearby_resistance": nearby_resistance,
        "method": f"Fractal pivots (left={left}, right={right}) confirmed only after {right} "
                  f"right-hand bars; clustered within {tolerance:.4f}. Developing levels are "
                  f"unconfirmed recent swings. Each zone also reports how many times price "
                  f"TOUCHED it and how many of those touches REACTED (moved away by >= 0.5 ATR "
                  f"within 5 bars).",
        "note": "Levels are probabilistic price-action observations, not guaranteed reversal points.",
    }
