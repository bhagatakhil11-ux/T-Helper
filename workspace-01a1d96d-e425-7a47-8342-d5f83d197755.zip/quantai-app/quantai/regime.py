"""Causal market-regime detection and per-regime performance.

Regimes are labelled from a slow EMA, its slope, and price position relative to it,
using ONLY data available at each bar (no centred windows, no future bars):
  * BULLISH  : close above the slow EMA and the EMA slope is positive
  * BEARISH  : close below the slow EMA and the EMA slope is negative
  * SIDEWAYS : everything else (flat / conflicting trend)

Strategy trades and mark-to-market returns are then bucketed by the regime at the
trade's ENTRY bar, so you can see whether an edge survives outside one regime.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .metrics import max_drawdown_pct

REGIMES = ("BEARISH", "SIDEWAYS", "BULLISH")


def detect_regimes(df: pd.DataFrame, ema_span: int = 50, slope_lookback: int = 10,
                   slope_threshold: float = 0.001) -> pd.Series:
    """Return a causal regime label per bar. Early warm-up bars are SIDEWAYS."""
    close = df["close"].astype(float)
    ema = close.ewm(span=ema_span, adjust=False, min_periods=ema_span).mean()
    slope = ema.pct_change(slope_lookback)
    above = close > ema
    below = close < ema
    regime = pd.Series("SIDEWAYS", index=df.index, dtype=object)
    bull = above & (slope > slope_threshold) & ema.notna() & slope.notna()
    bear = below & (slope < -slope_threshold) & ema.notna() & slope.notna()
    regime[bull] = "BULLISH"
    regime[bear] = "BEARISH"
    return regime


def regime_distribution(regimes: pd.Series) -> dict:
    n = len(regimes)
    counts = {r: int((regimes == r).sum()) for r in REGIMES}
    return {"counts": counts,
            "fractions": {r: (counts[r] / n if n else 0.0) for r in REGIMES},
            "total_bars": n}


def regime_performance(df: pd.DataFrame, regimes: pd.Series, trade_log: list[dict],
                       equity_curve: list[float], start_bar: int,
                       initial_capital: float) -> dict:
    """Bucket realised trades and MTM bar returns by the regime at entry / bar."""
    per_regime = {r: {"trades": 0, "wins": 0, "losses": 0, "net_pnl": 0.0,
                      "gross_profit": 0.0, "gross_loss": 0.0, "bar_returns": []}
                  for r in REGIMES}

    for t in trade_log:
        eb = t.get("entry_bar")
        if eb is None or eb < 0 or eb >= len(regimes):
            continue
        r = regimes.iloc[eb]
        b = per_regime[r]
        pnl = float(t.get("pnl", 0.0))
        b["trades"] += 1
        b["net_pnl"] += pnl
        if pnl > 0:
            b["wins"] += 1
            b["gross_profit"] += pnl
        elif pnl < 0:
            b["losses"] += 1
            b["gross_loss"] += abs(pnl)

    # MTM bar returns: equity_curve has len = (n - start_bar + 1); align to bars.
    eq = np.asarray(equity_curve, dtype=float)
    if len(eq) > 1:
        bar_rets = np.diff(eq) / eq[:-1]
        # bar_rets[k] corresponds to bar (start_bar + k)
        for k, r in enumerate(bar_rets):
            bar_idx = start_bar + k
            if start_bar <= bar_idx < len(regimes):
                per_regime[regimes.iloc[bar_idx]]["bar_returns"].append(float(r))

    out = {}
    for r in REGIMES:
        b = per_regime[r]
        n = b["trades"]
        rets = np.array(b["bar_returns"], dtype=float)
        sharpe = None
        if len(rets) > 2 and np.std(rets, ddof=1) > 1e-12:
            sharpe = float(np.mean(rets) / np.std(rets, ddof=1) * np.sqrt(252.0))
        pf = (b["gross_profit"] / b["gross_loss"]) if b["gross_loss"] > 0 else (
            None if b["gross_profit"] == 0 else float("inf"))
        out[r] = {
            "trades": n, "wins": b["wins"], "losses": b["losses"],
            "win_rate_pct": (b["wins"] / n * 100) if n else 0.0,
            "net_pnl": b["net_pnl"],
            "profit_factor": pf,
            "bars": len(rets),
            "annualised_bar_sharpe": sharpe,
            "note": ("No trades in this regime — the strategy is untested here." if n == 0 else
                     "Losing regime: the edge does not survive this market condition." if b["net_pnl"] < 0 else
                     "Profitable regime (after costs)."),
        }

    profitable_regimes = [r for r in REGIMES if out[r]["net_pnl"] > 0 and out[r]["trades"] > 0]
    tested_regimes = [r for r in REGIMES if out[r]["trades"] > 0]
    losing_regimes = [r for r in tested_regimes if out[r]["net_pnl"] < 0]
    flags = []
    if len(tested_regimes) < 2:
        flags.append("Strategy traded in fewer than 2 regimes; robustness across market conditions is unproven.")
    if losing_regimes:
        flags.append(f"Losing in regime(s): {', '.join(losing_regimes)}. Do not assume one strategy works everywhere.")
    untested = [r for r in REGIMES if out[r]["trades"] == 0]
    if untested:
        flags.append(f"No trades in regime(s): {', '.join(untested)} — performance there is unknown.")

    return {"per_regime": out, "distribution": regime_distribution(regimes),
            "profitable_regimes": profitable_regimes, "tested_regimes": tested_regimes,
            "losing_regimes": losing_regimes, "flags": flags,
            "regime_labels": regimes.tolist()}
