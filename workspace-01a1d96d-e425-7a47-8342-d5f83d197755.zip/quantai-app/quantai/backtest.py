"""Event-driven long-only backtest with honest execution and hard risk limits.

Execution contract (documented, tested):
  * Signal uses candles[0..i] and is formed at bar i CLOSE.
  * Entry fills at bar i+1 OPEN plus slippage. Never at the signal bar's close.
  * If a gap opens beyond the stop, the fill is at the OPEN (worse), not the stop.
  * If both stop and target sit inside one bar, the STOP is assumed hit first.
  * Equity is marked to market every bar; drawdown includes unrealized loss.
  * Costs are charged on both legs.
  * A total-drawdown breach halts ALL further entries and squares off.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

import numpy as np
import pandas as pd

from .config import BARS_PER_YEAR, CostModel, RiskConfig
from .risk_rules import (daily_drawdown_pct, effective_risk_pct, iso_week_key,
                        progressive_cooldown_bars, weekly_drawdown_pct)
from .indicators import compute_indicators, indicator_score
from .metrics import performance_metrics


@dataclass
class BacktestResult:
    label: str
    evaluated_bars: int
    total_trades: int
    winning_trades: int
    losing_trades: int
    win_rate_pct: float
    profit_factor: float | None
    expectancy: float
    net_profit: float
    net_return_pct: float
    max_drawdown_pct: float
    sharpe: float | None
    sharpe_reason: str
    total_costs: float
    total_slippage: float
    rejected_signals: dict
    final_equity: float
    equity_curve: list[float] = field(repr=False, default_factory=list)
    trade_log: list[dict] = field(repr=False, default_factory=list)
    # Extended analytics (v2)
    cagr_pct: float | None = None
    cagr_status: str = ""
    sortino: float | None = None
    sortino_reason: str = ""
    avg_profit_per_trade: float = 0.0
    avg_loss_per_trade: float = 0.0
    risk_reward_ratio: float | None = None
    max_consecutive_wins: int = 0
    max_consecutive_losses: int = 0
    halted_reason: str | None = None
    # NEW: the risk decisions this run actually made.
    cooldown_events: list[dict] = field(repr=False, default_factory=list)
    # Every weekly-loss-limit breach, so the report can show WHEN the week
    # was stopped and by how much.
    weekly_breaches: list[dict] = field(repr=False, default_factory=list)
    risk_config: dict = field(default_factory=dict)

    def to_dict(self, include_curves: bool = False) -> dict:
        d = {
            "label": self.label, "evaluated_bars": self.evaluated_bars,
            "total_trades": self.total_trades, "winning_trades": self.winning_trades,
            "losing_trades": self.losing_trades, "win_rate_pct": self.win_rate_pct,
            "profit_factor": self.profit_factor, "expectancy_per_trade": self.expectancy,
            "net_profit": self.net_profit, "net_return_pct": self.net_return_pct,
            "total_return_pct": self.net_return_pct,
            "max_drawdown_pct": self.max_drawdown_pct, "sharpe_ratio": self.sharpe,
            "sharpe_status": self.sharpe_reason, "total_costs": self.total_costs,
            "total_slippage": self.total_slippage, "rejected_signals": self.rejected_signals,
            "final_equity": self.final_equity,
            "cagr_pct": self.cagr_pct, "cagr_status": self.cagr_status,
            "sortino_ratio": self.sortino, "sortino_status": self.sortino_reason,
            "avg_profit_per_trade": self.avg_profit_per_trade,
            "avg_loss_per_trade": self.avg_loss_per_trade,
            "risk_reward_ratio": self.risk_reward_ratio,
            "max_consecutive_wins": self.max_consecutive_wins,
            "max_consecutive_losses": self.max_consecutive_losses,
            "halted_reason": self.halted_reason,
            "cooldown_events": self.cooldown_events,
            "weekly_breaches": self.weekly_breaches,
            "risk_config": self.risk_config,
        }
        if include_curves:
            d["equity_curve"] = self.equity_curve
            d["trade_log"] = self.trade_log
        return d


def technical_score(row: pd.Series) -> float:
    """Transparent 4-factor vote, each factor in [-1, 1]."""
    votes = []
    rsi = row["rsi_14_norm"] * 50 + 50
    votes.append(1.0 if rsi < 32 else (-1.0 if rsi > 68 else 0.0))
    votes.append(float(np.sign(row["macd_hist_norm"])))
    pb = row["bb_percent_b"]
    votes.append(1.0 if pb <= 0.05 else (-1.0 if pb >= 0.95 else 0.0))
    votes.append(float(np.sign(row["ema_9_21_diff"])))
    return float(np.mean(votes))


def run_backtest(
    df: pd.DataFrame,
    feats: pd.DataFrame,
    start_bar: int,
    cost: CostModel,
    risk: RiskConfig,
    timeframe: str,
    proba: np.ndarray | None = None,
    mode: str = "ensemble",
    entry_threshold: float = 0.42,
    label: str = "strategy",
    intraday_square_off: bool | None = None,
    max_volume_participation_pct: float = 0.0,
    indicator_df: pd.DataFrame | None = None,
) -> BacktestResult:
    assert mode in ("ensemble", "ml_only", "rules_only", "indicators", "buy_and_hold")
    # Intraday cost assumptions are only valid if positions are actually closed the same day.
    eod_square_off = cost.is_intraday if intraday_square_off is None else intraday_square_off
    if mode == "indicators" and indicator_df is None:
        indicator_df = compute_indicators(df, timeframe)
    start_bar = max(start_bar, 1)
    n = len(df)
    if start_bar >= n:
        raise ValueError("start_bar beyond data")

    ts = df["timestamp"].dt.tz_convert("Asia/Kolkata")
    days = ts.dt.normalize()

    cash = risk.initial_capital
    peak = cash
    max_dd = 0.0
    prev_equity = cash
    bar_returns: list[float] = []
    equity_curve = [cash]
    equity_times = [ts.iloc[start_bar - 1]] if start_bar > 0 else [ts.iloc[0]]

    in_pos = False
    qty = 0
    entry_price = stop = target = entry_cost = 0.0
    entry_day = None
    entry_reason = ""
    pending: dict | None = None
    entered_this_bar = False
    halted_reason: str | None = None

    wins = losses = 0
    gross_win = gross_loss = 0.0
    total_costs = total_slippage = 0.0
    consec_losses = 0
    cooldown_until = -1
    cooldown_events: list[dict] = []
    day_start_equity = cash
    current_day = days.iloc[start_bar]
    day_blocked = False
    # Weekly loss limit: measured from the equity at the start of the ISO
    # week. Breaching it blocks NEW ENTRIES until the next week — it does
    # not halt the engine, exactly like the daily limit.
    current_week = iso_week_key(ts.iloc[start_bar])
    week_start_equity = cash
    week_blocked = False
    # Every weekly-limit breach is recorded, so the report can show WHEN the
    # week was stopped and by how much.
    weekly_breaches: list[dict] = []
    rejected = {"risk_qty_zero": 0, "daily_drawdown": 0, "weekly_drawdown": 0,
                "cooldown": 0,
                "exposure_cap": 0, "insufficient_cash": 0, "no_signal": 0,
                "intraday_no_overnight": 0, "total_drawdown_halt": 0,
                "max_open_positions": 0, "volume_cap": 0}
    entry_bar = -1
    risk_pct_used = None
    vol_detail: dict = {}
    trades: list[dict] = []

    def close_position(price: float, bar: int, reason: str):
        nonlocal cash, in_pos, qty, wins, losses, gross_win, gross_loss
        nonlocal total_costs, total_slippage, consec_losses, cooldown_until, entry_cost
        nonlocal cooldown_events
        slip = price * cost.slippage_pct
        fill = max(price - slip, 0.05)
        turnover = fill * qty
        leg = cost.leg_cost(turnover, is_buy=False)
        total_slippage += slip * qty
        total_costs += leg["total"]
        pnl = (fill - entry_price) * qty - entry_cost - leg["total"]
        # Entry notional + entry charges were ALREADY deducted from cash at fill time,
        # so only the sale proceeds (net of exit charges) come back in.
        cash += fill * qty - leg["total"]
        if pnl > 0:
            wins += 1
            gross_win += pnl
            consec_losses = 0
        else:
            losses += 1
            gross_loss += abs(pnl)
            consec_losses += 1
            if consec_losses >= risk.max_consecutive_losses:
                cd = progressive_cooldown_bars(
                    consec_losses, risk.max_consecutive_losses,
                    risk.cooldown_bars, risk.progressive_cooldown,
                    level2_bars=risk.cooldown_bars_level2,
                    level3_bars=risk.cooldown_bars_level3)
                cooldown_until = bar + cd
                cooldown_events.append({"bar": bar, "consecutive_losses": consec_losses,
                                        "cooldown_bars": cd, "until_bar": cooldown_until})
        trades.append({
            "entry_bar": entry_bar, "exit_bar": bar, "reason": reason, "qty": qty,
            "entry": entry_price, "exit": fill, "pnl": pnl,
            "costs": entry_cost + leg["total"],
            "entry_time": ts.iloc[entry_bar].isoformat(),
            "exit_time": ts.iloc[bar].isoformat(),
            "direction": "LONG", "stop": stop, "target": target,
            "entry_reason": entry_reason, "exit_reason": reason,
            "strategy": mode, "cost_breakdown_exit": leg,
            "risk_pct_used": risk_pct_used,
            "atr_pct": vol_detail.get("atr_pct"),
            "risk_vol_factor": vol_detail.get("factor"),
        })
        in_pos = False
        qty = 0
        entry_cost = 0.0

    if mode == "buy_and_hold":
        price = float(df["open"].iloc[start_bar])
        slip = price * cost.slippage_pct
        fill = price + slip
        qty = int((cash * risk.max_cash_fraction) // fill)
        bh_entry_cost = 0.0
        if qty > 0 and risk.max_open_positions >= 1:
            leg = cost.leg_cost(fill * qty, is_buy=True)
            cash -= fill * qty + leg["total"]
            total_costs += leg["total"]
            total_slippage += slip * qty
            invested_qty, invested_price, invested_cost = qty, fill, leg["total"]
            bh_entry_cost = leg["total"]
        else:
            invested_qty, invested_price, invested_cost = 0, fill, 0.0
        curve = [risk.initial_capital]
        curve_times = [ts.iloc[start_bar]]
        for i in range(start_bar, n):
            eq = cash + invested_qty * float(df["close"].iloc[i])
            curve.append(eq)
            curve_times.append(ts.iloc[i])
            peak = max(peak, eq)
            if peak > 0:
                max_dd = max(max_dd, (peak - eq) / peak * 100)
            if prev_equity > 0:
                bar_returns.append((eq - prev_equity) / prev_equity)
            prev_equity = eq
        final_price = float(df["close"].iloc[-1])
        slip = final_price * cost.slippage_pct
        fill = max(final_price - slip, 0.05)
        leg = cost.leg_cost(fill * invested_qty, is_buy=False) if invested_qty else {"total": 0.0}
        final_eq = cash + invested_qty * fill - leg["total"]
        total_costs += leg["total"]
        total_slippage += slip * invested_qty
        curve[-1] = final_eq
        bh_trades = []
        if invested_qty:
            bh_trades = [{
                "entry_bar": start_bar, "exit_bar": n - 1, "reason": "buy_and_hold_liquidation",
                "qty": invested_qty, "entry": invested_price, "exit": fill,
                "pnl": (fill - invested_price) * invested_qty - bh_entry_cost - leg["total"],
                "costs": bh_entry_cost + leg["total"],
                "entry_time": ts.iloc[start_bar].isoformat(), "exit_time": ts.iloc[-1].isoformat(),
                "direction": "LONG", "stop": None, "target": None,
                "entry_reason": "buy_and_hold", "exit_reason": "buy_and_hold_liquidation",
                "strategy": "buy_and_hold",
            }]
        bh_pnl = bh_trades[0]["pnl"] if bh_trades else 0.0
        bh_wins, bh_losses = (1, 0) if bh_pnl > 0 else ((0, 1) if bh_pnl < 0 else (0, 0))
        return _finalise(label, curve, bar_returns, n - start_bar, wins=bh_wins, losses=bh_losses,
                         gross_win=max(bh_pnl, 0.0), gross_loss=abs(min(bh_pnl, 0.0)), total_costs=total_costs,
                         total_slippage=total_slippage, rejected=rejected,
                         initial=risk.initial_capital, final_equity=final_eq,
                         max_dd=max_dd, timeframe=timeframe, trades=bh_trades,
                         equity_times=curve_times, is_benchmark=True)

    for i in range(start_bar, n):
        bar = df.iloc[i]
        entered_this_bar = False

        if days.iloc[i] != current_day:
            current_day = days.iloc[i]
            day_start_equity = prev_equity
            day_blocked = False

        # ISO-week rollover: the weekly loss limit resets with the week.
        week = iso_week_key(ts.iloc[i])
        if week != current_week:
            current_week = week
            week_start_equity = prev_equity
            week_blocked = False
            weekly_breaches = []

        # 1) fill pending entry at THIS bar's open
        if pending is not None and not in_pos:
            raw_open = float(bar["open"])
            slip = raw_open * cost.slippage_pct
            fill = raw_open + slip
            q = pending["qty"]
            turnover = fill * q
            leg = cost.leg_cost(turnover, is_buy=True)
            if turnover + leg["total"] <= cash:
                cash -= turnover + leg["total"]
                total_costs += leg["total"]
                total_slippage += slip * q
                in_pos = True
                entered_this_bar = True
                entry_bar = i
                qty = q
                entry_price = fill
                entry_cost = leg["total"]
                entry_reason = pending.get("entry_reason", "signal")
                stop = max(fill - pending["stop_dist"], 0.05)
                target = fill + pending["target_dist"]
                entry_day = current_day
                risk_pct_used = pending.get("risk_pct_used")
                vol_detail = pending.get("vol_detail") or {}
            else:
                rejected["insufficient_cash"] += 1
            pending = None

        # 2) conservative intrabar exits
        if in_pos:
            o, h, l = float(bar["open"]), float(bar["high"]), float(bar["low"])
            if not entered_this_bar and o <= stop:
                close_position(o, i, "gap_stop_at_open")
            elif l <= stop:
                close_position(stop, i, "stop_loss")
            elif not entered_this_bar and o >= target:
                close_position(o, i, "gap_target_at_open")
            elif h >= target:
                close_position(target, i, "target")

        # 2b) Intraday cost assumptions are only valid if we do not carry overnight.
        if eod_square_off and in_pos:
            is_last_bar_of_day = (i == n - 1) or (days.iloc[i + 1] != current_day)
            if is_last_bar_of_day:
                close_position(float(bar["close"]), i, "intraday_eod_square_off")

        # 3) mark to market
        holdings_close = qty * float(bar["close"]) if in_pos else 0.0
        holdings_low = qty * float(bar["low"]) if in_pos else 0.0
        eq_close = cash + holdings_close
        eq_worst = cash + holdings_low
        peak = max(peak, eq_close)
        if peak > 0:
            max_dd = max(max_dd, (peak - eq_worst) / peak * 100)
        if prev_equity > 0:
            bar_returns.append((eq_close - prev_equity) / prev_equity)
        prev_equity = eq_close
        equity_curve.append(eq_close)
        equity_times.append(ts.iloc[i])

        if day_start_equity > 0 and (day_start_equity - eq_close) / day_start_equity * 100 >= risk.max_daily_drawdown_pct:
            day_blocked = True

        # Weekly loss limit: blocks NEW ENTRIES until the next ISO week.
        wk_dd = weekly_drawdown_pct(week_start_equity, eq_close)
        if wk_dd >= risk.max_weekly_drawdown_pct:
            if not week_blocked:
                weekly_breaches.append({
                    "bar": i, "week": current_week,
                    "weekly_drawdown_pct": wk_dd,
                    "limit_pct": risk.max_weekly_drawdown_pct,
                })
            week_blocked = True

        # 3b) TOTAL drawdown circuit breaker — squares off and halts all new entries.
        if halted_reason is None and peak > 0 and \
           (peak - eq_worst) / peak * 100 >= risk.max_total_drawdown_pct:
            halted_reason = f"total_drawdown_halt: breached {risk.max_total_drawdown_pct:.2f}% peak-to-trough limit"
            pending = None
            if in_pos:
                close_position(float(bar["close"]), i, "total_drawdown_halt")
                equity_curve[-1] = cash
                prev_equity = cash

        # 4) form signal at CLOSE for next bar
        if halted_reason is not None:
            if i < n - 1:
                rejected["total_drawdown_halt"] += 1
            continue
        if in_pos or pending is not None or i >= n - 1:
            continue
        row = feats.iloc[i]
        if not np.isfinite(row[["atr", "rsi_14_norm", "bb_percent_b"]].to_numpy(dtype=float)).all():
            rejected["no_signal"] += 1
            continue
        atr = float(row["atr"])
        if atr <= 0:
            rejected["no_signal"] += 1
            continue

        tech = technical_score(row)
        p_up = p_down = 0.0
        if proba is not None and np.isfinite(proba[i]).all():
            p_down, _, p_up = proba[i]
        if mode == "indicators":
            score = indicator_score(indicator_df.iloc[i])
            if not np.isfinite(score):
                rejected["no_signal"] += 1
                continue
        elif mode == "rules_only":
            score = tech
        elif mode == "ml_only":
            score = p_up - p_down
        else:
            score = 0.6 * tech + 0.4 * (p_up - p_down)

        if score < entry_threshold:
            rejected["no_signal"] += 1
            continue
        if risk.max_open_positions < 1:
            rejected["max_open_positions"] += 1
            continue
        if day_blocked:
            rejected["daily_drawdown"] += 1
            continue
        if week_blocked:
            rejected["weekly_drawdown"] += 1
            continue
        if i < cooldown_until:
            rejected["cooldown"] += 1
            continue
        if eod_square_off and (i >= n - 1 or days.iloc[i + 1] != current_day):
            # Do not queue an entry that would fill on the next trading day.
            rejected["intraday_no_overnight"] += 1
            continue

        stop_dist = atr * risk.stop_atr_mult
        target_dist = atr * risk.target_atr_mult
        est_price = float(bar["close"])
        # Volatility-adjusted risk: the rupee risk at the stop shrinks when
        # the market is more volatile than the target ATR%.
        eff_risk_pct, vol_detail = effective_risk_pct(
            risk.risk_per_trade_pct, atr, est_price, risk.auto_risk_by_volatility,
            risk.risk_vol_target_pct, risk.risk_vol_min_factor, risk.risk_vol_max_factor)
        risk_amount = risk.initial_capital * eff_risk_pct / 100.0
        q_risk = int(risk_amount // stop_dist)
        q_cash = int((cash * risk.max_cash_fraction) // est_price)
        max_exposure_value = risk.initial_capital * risk.max_exposure_pct / 100.0
        q_exp = int(max_exposure_value // est_price)
        q = min(q_risk, q_cash, q_exp)
        if max_volume_participation_pct > 0:
            q_vol = int(float(bar["volume"]) * max_volume_participation_pct / 100.0)
            q = min(q, q_vol)
            if q_vol <= 0:
                rejected["volume_cap"] += 1
        if q <= 0:
            rejected["risk_qty_zero"] += 1
            continue
        if q < q_risk:
            rejected["exposure_cap"] += 1
        pending = {"qty": q, "stop_dist": stop_dist, "target_dist": target_dist,
                   "signal_bar": i,
                   "risk_pct_used": eff_risk_pct,
                   "vol_detail": vol_detail,
                   "entry_reason": f"{mode} score={score:.3f} thr={entry_threshold:.2f}"}

    if in_pos:
        close_position(float(df["close"].iloc[-1]), n - 1, "final_liquidation")
        equity_curve[-1] = cash

    return _finalise(label, equity_curve, bar_returns, n - start_bar, wins, losses,
                     gross_win, gross_loss, total_costs, total_slippage, rejected,
                     risk.initial_capital, cash, max_dd, timeframe, trades,
                     equity_times=equity_times, halted_reason=halted_reason,
                     cooldown_events=cooldown_events, weekly_breaches=weekly_breaches,
                     risk_config=asdict(risk) if hasattr(risk, "__dataclass_fields__") else {})


def _finalise(label, curve, bar_returns, evaluated, wins, losses, gross_win, gross_loss,
              total_costs, total_slippage, rejected, initial, final_equity, max_dd,
              timeframe, trades, force_na_reason: str | None = None,
              equity_times: list | None = None, halted_reason: str | None = None,
              is_benchmark: bool = False, cooldown_events: list | None = None,
              weekly_breaches: list | None = None,
              risk_config: dict | None = None) -> BacktestResult:
    # Benchmarks (buy & hold) are judged on their equity curve, not trade count.
    m = performance_metrics(curve, trades, initial, timeframe,
                            timestamps=equity_times, max_dd_override=max_dd,
                            min_trades_for_ratio=0 if is_benchmark else 5)
    total = wins + losses
    win_rate = wins / total * 100 if total else 0.0
    pf = (gross_win / gross_loss) if gross_loss > 0 else (None if gross_win == 0 else float("inf"))
    avg_win = gross_win / wins if wins else 0.0
    avg_loss = gross_loss / losses if losses else 0.0
    expectancy = (win_rate / 100) * avg_win - (1 - win_rate / 100) * avg_loss if total else 0.0

    sharpe, reason = m["sharpe_ratio"], m["sharpe_status"]
    if force_na_reason:
        sharpe, reason = None, force_na_reason

    return BacktestResult(
        label=label, evaluated_bars=int(evaluated), total_trades=total,
        winning_trades=wins, losing_trades=losses, win_rate_pct=win_rate,
        profit_factor=pf, expectancy=expectancy, net_profit=final_equity - initial,
        net_return_pct=(final_equity - initial) / initial * 100,
        max_drawdown_pct=max_dd, sharpe=sharpe, sharpe_reason=reason,
        total_costs=total_costs, total_slippage=total_slippage,
        rejected_signals=rejected, final_equity=final_equity,
        equity_curve=[float(x) for x in curve], trade_log=trades,
        cagr_pct=m["cagr_pct"], cagr_status=m["cagr_status"],
        sortino=m["sortino_ratio"], sortino_reason=m["sortino_status"],
        avg_profit_per_trade=avg_win, avg_loss_per_trade=avg_loss,
        risk_reward_ratio=m["risk_reward_ratio"],
        max_consecutive_wins=m["max_consecutive_wins"],
        max_consecutive_losses=m["max_consecutive_losses"],
        halted_reason=halted_reason,
        cooldown_events=list(cooldown_events or []),
        weekly_breaches=list(weekly_breaches or []),
        risk_config=dict(risk_config or {}),
    )
