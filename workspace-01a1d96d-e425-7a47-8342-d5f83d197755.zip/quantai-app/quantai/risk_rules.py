"""Shared risk rules used by BOTH the backtest engine and the paper replay.

These are pure functions on purpose. The backtest and the replay must agree
on every risk decision, otherwise a research result would not describe the
behaviour of the live replay. Putting the rules here — instead of inlining
them twice — is what guarantees that agreement.

Nothing here places an order or talks to a broker. It only computes limits.
"""
from __future__ import annotations

import pandas as pd

# The cooldown can never exceed this many bars, however long the loss streak.
MAX_COOLDOWN_BARS = 500

# The default progressive-cooldown BANDS. With the default threshold of 3
# consecutive losses these give: 3-4 losses -> 15 bars, 5-6 -> 30 bars,
# 7 or more -> 50 bars (flat, it does not keep growing).
DEFAULT_COOLDOWN_LEVEL2 = 30
DEFAULT_COOLDOWN_LEVEL3 = 50


def progressive_cooldown_bars(consecutive_losses: int, max_consecutive_losses: int,
                              base_bars: int, progressive: bool = True,
                              cap: int = MAX_COOLDOWN_BARS,
                              level2_bars: int = DEFAULT_COOLDOWN_LEVEL2,
                              level3_bars: int = DEFAULT_COOLDOWN_LEVEL3) -> int:
    """How long the cooldown lasts after a given number of consecutive losses.

    With ``progressive=False`` this is the old flat behaviour: always
    ``base_bars``.

    With ``progressive=True`` the cooldown grows with the streak in three
    BANDS, anchored on the ``max_consecutive_losses`` threshold:

    ==================  ====================  ==================
    consecutive losses  band (threshold = 3)   cooldown
    ==================  ====================  ==================
    0 - 2               below the threshold    base (no cooldown)
    3 - 4               band 1                 15 bars
    5 - 6               band 2                 30 bars
    7 and above         band 3                 50 bars
    ==================  ====================  ==================

    Band 3 is deliberately FLAT. The cooldown stops growing once the streak
    reaches ``threshold + 4`` losses, so a long losing streak can never lock
    the engine out for an unbounded number of bars — the total-drawdown
    circuit breaker is the control that ends such a run, not the cooldown.

    The bands are configurable: ``level2_bars`` and ``level3_bars`` set the
    second and third band lengths. The result is always clamped into
    ``[base_bars, cap]`` and the bands never shrink below the one before
    them, so a mis-configured set can not produce a shorter pause after a
    longer streak.
    """
    base = max(1, int(base_bars))
    losses = max(0, int(consecutive_losses))
    threshold = max(1, int(max_consecutive_losses))
    if not progressive or losses < threshold:
        return base
    band2 = max(base, int(level2_bars))
    band3 = max(band2, int(level3_bars))
    if losses < threshold + 2:
        return base                       # band 1
    if losses < threshold + 4:
        return min(band2, cap)            # band 2
    return min(band3, cap)                # band 3 (flat)


def iso_week_key(ts) -> str:
    """The ISO week a timestamp belongs to, e.g. ``"2024-W03"``.

    ISO weeks start on Monday, which is what a "weekly loss limit" should
    mean for a trading week.
    """
    iso = pd.Timestamp(ts).isocalendar()
    return f"{int(iso.year)}-W{int(iso.week):02d}"


def effective_risk_pct(base_risk_pct: float, atr: float, price: float,
                       auto: bool = False, target_atr_pct: float = 2.0,
                       min_factor: float = 0.25, max_factor: float = 2.0) -> tuple[float, dict]:
    """The risk per trade actually used, after the volatility adjustment.

    The base rule sizes the position so the RUPEE risk at the stop is a fixed
    fraction of capital. That already keeps the rupee risk constant, but it
    means a volatile instrument is traded with the SAME rupee risk as a calm
    one — which is exactly when stops get hit by noise.

    With ``auto=True`` the risk is scaled by how far the current ATR% is from
    the target ATR%::

        factor     = clamp(target_atr_pct / measured_atr_pct, min_factor, max_factor)
        risk_pct   = base_risk_pct * factor

    So twice the normal volatility halves the risk, and half the normal
    volatility doubles it (within the clamps). With ``auto=False`` the base
    value is returned UNCHANGED — the feature is genuinely off by default.
    """
    base = float(base_risk_pct)
    detail = {
        "auto": bool(auto),
        "base_risk_pct": base,
        "atr": float(atr) if atr is not None else None,
        "price": float(price) if price else None,
        "atr_pct": None,
        "target_atr_pct": float(target_atr_pct),
        "factor": 1.0,
        "effective_risk_pct": base,
        "note": "volatility adjustment OFF — the base risk per trade is used",
    }
    if not auto:
        return base, detail
    if not atr or not price or atr <= 0 or price <= 0 or target_atr_pct <= 0:
        detail["note"] = ("volatility adjustment ON but ATR/price unavailable "
                           "— the base risk per trade is used")
        return base, detail

    atr_pct = float(atr) / float(price) * 100.0
    factor = float(target_atr_pct) / atr_pct if atr_pct > 0 else float(max_factor)
    factor = max(float(min_factor), min(float(max_factor), factor))
    effective = base * factor
    detail.update({
        "atr_pct": atr_pct,
        "factor": factor,
        "effective_risk_pct": effective,
        "note": (f"ATR {atr_pct:.2f}% of price vs target {target_atr_pct:.2f}% "
                 f"→ risk factor {factor:.2f}×"),
    })
    return effective, detail


def weekly_drawdown_pct(week_start_equity: float, equity: float) -> float:
    """The drawdown measured from the start of the current week, in %."""
    if not week_start_equity or week_start_equity <= 0:
        return 0.0
    return (week_start_equity - equity) / week_start_equity * 100.0


def daily_drawdown_pct(day_start_equity: float, equity: float) -> float:
    """The drawdown measured from the start of the current day, in %."""
    if not day_start_equity or day_start_equity <= 0:
        return 0.0
    return (day_start_equity - equity) / day_start_equity * 100.0
