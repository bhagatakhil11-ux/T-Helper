"""Multi-symbol portfolio research.

Model: each symbol runs the SAME strategy as an independent capital "sleeve".
Capital is allocated up-front (equal or inverse-volatility weight), each sleeve
trades with its own risk limits scaled to its allocation, and the sleeve equity
curves are aligned on a common timestamp index and summed into a portfolio curve.

This is a honest, leak-free construction:
  * Allocation weights use ONLY pre-test data (inverse-vol uses pre-test returns).
  * No sleeve can see another sleeve's future.
  * Concentration / exposure caps are enforced on the allocation and per sleeve.

It is NOT a shared-margin intraday portfolio with cross-symbol netting; that is a
documented limitation. Costs and execution assumptions are identical to the
single-symbol backtest.
"""
from __future__ import annotations

from dataclasses import replace

import numpy as np
import pandas as pd

from .backtest import run_backtest
from .config import CostModel, RiskConfig
from .metrics import max_drawdown_pct, performance_metrics


def allocation_weights(symbols: list[str], method: str, pretest_vol: dict[str, float],
                       max_symbol_weight_pct: float) -> tuple[dict[str, float], list[str]]:
    """Return weights summing to 1, capped at max_symbol_weight_pct, with notes."""
    notes: list[str] = []
    n = len(symbols)
    if n == 0:
        raise ValueError("Portfolio needs at least one symbol.")
    if method == "inverse_vol":
        inv = {}
        for s in symbols:
            v = pretest_vol.get(s)
            if v is None or not np.isfinite(v) or v <= 1e-9:
                inv[s] = None
            else:
                inv[s] = 1.0 / v
        if any(v is None for v in inv.values()):
            notes.append("Some symbols lack a valid pre-test volatility; fell back to equal weight.")
            w = {s: 1.0 / n for s in symbols}
        else:
            tot = sum(inv.values())
            w = {s: inv[s] / tot for s in symbols}
    else:
        w = {s: 1.0 / n for s in symbols}

    cap = max_symbol_weight_pct / 100.0
    if cap * n < 1.0 - 1e-9:
        notes.append(f"max_symbol_weight_pct={max_symbol_weight_pct}% is infeasible for {n} symbols; "
                     f"raised to {100.0 / n:.2f}% (minimum feasible equal weight).")
        cap = 1.0 / n
    # Iteratively cap and redistribute to the uncapped names.
    raw_w = dict(w)
    for _ in range(n + 1):
        over = {s: w[s] for s in symbols if w[s] > cap + 1e-12}
        if not over:
            break
        excess = sum(w[s] - cap for s in over)
        for s in over:
            w[s] = cap
        under = [s for s in symbols if w[s] < cap - 1e-12]
        if not under:
            break
        room = {s: cap - w[s] for s in under}
        tot_room = sum(room.values())
        if tot_room <= 0:
            break
        for s in under:
            w[s] += excess * room[s] / tot_room
    total = sum(w.values())
    w = {s: w[s] / total for s in symbols}
    if any(abs(w[s] - raw_w[s]) > 1e-9 for s in symbols):
        notes.append(f"Weights clipped/redistributed to respect the {max_symbol_weight_pct}% "
                     "per-symbol concentration cap.")
    return w, notes


def concentration_report(weights: dict[str, float]) -> dict:
    vals = np.array(list(weights.values()), dtype=float)
    hhi = float(np.sum(vals ** 2))
    n = len(vals)
    return {
        "max_weight_pct": float(vals.max() * 100) if n else 0.0,
        "min_weight_pct": float(vals.min() * 100) if n else 0.0,
        "herfindahl_index": hhi,
        "effective_n": float(1.0 / hhi) if hhi > 0 else 0.0,
        "n_symbols": n,
        "diversification_note": ("Highly concentrated (HHI > 0.25)." if hhi > 0.25 else
                                 "Moderately concentrated." if hhi > 0.15 else
                                 "Well diversified by weight."),
    }


def correlation_matrix(closes: dict[str, pd.Series], start_ts=None, end_ts=None) -> dict:
    """Pearson correlation of daily returns between symbols over the common window."""
    frame = pd.DataFrame(closes)
    if start_ts is not None:
        frame = frame.loc[frame.index >= pd.Timestamp(start_ts)]
    if end_ts is not None:
        frame = frame.loc[frame.index <= pd.Timestamp(end_ts)]
    rets = frame.pct_change().dropna(how="all")
    if rets.shape[0] < 3 or rets.shape[1] < 2:
        return {"status": "insufficient", "symbols": list(closes), "matrix": [],
                "message": "Need >= 3 common return observations and >= 2 symbols."}
    corr = rets.corr()
    symbols = list(corr.columns)
    mat = corr.to_numpy()
    # Average pairwise correlation (off-diagonal).
    off = mat[np.triu_indices(len(symbols), k=1)]
    avg = float(np.nanmean(off)) if len(off) else None
    return {"status": "ok", "symbols": symbols,
            "matrix": [[None if not np.isfinite(v) else float(v) for v in row] for row in mat],
            "avg_pairwise_correlation": avg,
            "observations": int(rets.shape[0]),
            "message": ("High average correlation (>0.7): diversification benefit is limited."
                        if avg is not None and avg > 0.7 else
                        "Correlation computed from overlapping daily returns.")}


def combine_sleeve_equity(curves: dict[str, pd.Series], allocations: dict[str, float]) -> pd.Series:
    """Align sleeve equity curves on the union timestamp index and sum them.

    Leading gaps (a sleeve that starts later) hold its allocated cash; later gaps
    forward-fill the last marked equity. No look-ahead: forward-fill only.
    """
    if not curves:
        raise ValueError("No sleeve equity curves to combine.")
    union = None
    for s in curves.values():
        union = s.index if union is None else union.union(s.index)
    union = union.sort_values()
    combined = pd.Series(0.0, index=union)
    for sym, s in curves.items():
        aligned = s.reindex(union).ffill()
        aligned = aligned.fillna(allocations[sym])   # leading cash before sleeve starts
        combined = combined + aligned
    return combined


def run_portfolio(sleeves: list[dict], total_capital: float, cost: CostModel,
                  base_risk: RiskConfig, timeframe: str, mode: str = "ensemble",
                  entry_threshold: float = 0.42, allocation_method: str = "equal",
                  max_symbol_weight_pct: float = 40.0,
                  max_portfolio_exposure_pct: float = 90.0,
                  volume_cap_pct: float = 0.0) -> dict:
    """sleeves: [{key, symbol, df, feats, proba, start_bar, pretest_vol}]"""
    if not sleeves:
        raise ValueError("Portfolio needs at least one symbol.")
    symbols = [s["symbol"] for s in sleeves]
    if len(set(symbols)) != len(symbols):
        raise ValueError("Duplicate symbols in portfolio.")
    pretest_vol = {s["symbol"]: s.get("pretest_vol") for s in sleeves}
    weights, alloc_notes = allocation_weights(symbols, allocation_method, pretest_vol, max_symbol_weight_pct)
    allocations = {s: total_capital * weights[s] for s in symbols}

    sleeve_results = {}
    curves = {}
    all_trades = []
    for sl in sleeves:
        sym = sl["symbol"]
        sleeve_risk = replace(base_risk, initial_capital=allocations[sym],
                              max_exposure_pct=min(base_risk.max_exposure_pct, max_portfolio_exposure_pct))
        res = run_backtest(sl["df"], sl["feats"], sl["start_bar"], cost, sleeve_risk,
                           timeframe, proba=sl.get("proba"), mode=mode,
                           entry_threshold=entry_threshold, label=f"{sym} sleeve",
                           max_volume_participation_pct=volume_cap_pct)
        sleeve_results[sym] = res
        ts = sl["df"]["timestamp"].iloc[sl["start_bar"] - 1: len(sl["df"])]
        eq = res.equity_curve
        m = min(len(ts), len(eq))
        curves[sym] = pd.Series(eq[-m:], index=pd.DatetimeIndex(ts[-m:]))
        for t in res.trade_log:
            all_trades.append({**t, "symbol": sym})

    combined = combine_sleeve_equity(curves, allocations)
    portfolio_metrics = performance_metrics(combined.tolist(), all_trades, total_capital,
                                            timeframe, timestamps=[str(x) for x in combined.index])
    closes = {}
    for sl in sleeves:
        d = sl["df"].copy()
        d.index = pd.DatetimeIndex(d["timestamp"])
        closes[sl["symbol"]] = d["close"].astype(float)
    start_ts = min(sl["df"]["timestamp"].iloc[sl["start_bar"]] for sl in sleeves)
    corr = correlation_matrix(closes, start_ts=start_ts)

    return {
        "status": "ok",
        "allocation_method": allocation_method,
        "weights_pct": {s: weights[s] * 100 for s in symbols},
        "allocations_inr": allocations,
        "allocation_notes": alloc_notes,
        "concentration": concentration_report(weights),
        "max_symbol_weight_pct": max_symbol_weight_pct,
        "max_portfolio_exposure_pct": max_portfolio_exposure_pct,
        "correlation": corr,
        "portfolio_metrics": portfolio_metrics,
        "portfolio_equity": [float(x) for x in combined.tolist()],
        "portfolio_timestamps": [str(x) for x in combined.index],
        "portfolio_max_drawdown_pct": max_drawdown_pct(combined.tolist()),
        "sleeves": {s: sleeve_results[s].to_dict() for s in symbols},
        "sleeve_equity": {s: [float(x) for x in curves[s].tolist()] for s in symbols},
        "total_trades": len(all_trades),
        "model_note": "Independent capital sleeves summed on a common clock; no cross-symbol "
                      "margin netting or shared-cash contention. Allocation uses pre-test data only.",
    }
