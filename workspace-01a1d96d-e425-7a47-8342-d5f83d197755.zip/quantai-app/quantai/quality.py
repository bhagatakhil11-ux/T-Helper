"""Dataset quality analysis: corporate actions, gaps, volume anomalies, score.

Everything in this module is a REPORT about the bytes the user imported.
Nothing is repaired, adjusted, interpolated or fabricated. Every number is
derived from the cleaned, validated frame that :func:`quantai.data.load_csv`
produces — the same frame that goes on to feed the research pipeline.

Honesty rules baked into this module
------------------------------------
* A detected price discontinuity is a FACT about the file. Calling it a
  corporate action is a SUSPICION, not a proof: a genuine -50% market move is
  mathematically indistinguishable from a 1:2 split in price data alone. Every
  corporate-action entry therefore carries an explicit caveat.
* The quality score measures INTERNAL CONSISTENCY and SUFFICIENCY of the file.
  It says nothing about market authenticity, profitability, edge or skill.
* A test fixture still gets a score, but the score describes the FILE only —
  never the market. Callers must keep that distinction visible.
* Missing data is reported, never filled in.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import date

import numpy as np
import pandas as pd

from .config import (
    IST, INTERVAL_MIN, SESSION_END_MIN, SESSION_START_MIN, required_research_bars,
)

# --------------------------------------------------------------------------
# Tunables. Every threshold is a documented, conservative constant — not a
# fitted parameter. Changing one changes what the report SAYS, never what the
# data IS.
# --------------------------------------------------------------------------

#: Overnight gap (open vs previous close) large enough to be worth reporting.
GAP_CANDIDATE_PCT = 0.08

#: Relative tolerance for "the gap size matches a canonical corporate-action
#: ratio exactly" (tight) / "closely" (loose).
RATIO_SNAP_TIGHT = 0.015
RATIO_SNAP_LOOSE = 0.05

#: How far the close may sit from the open for the bar to count as a
#: "level reset" (the new price level stuck) rather than an opening spike.
LEVEL_RESET_TOL = 0.05

#: Rolling window (bars) for the volume median / MAD / z-score.
VOLUME_WINDOW = 20
VOLUME_MIN_PERIODS = 5
VOLUME_Z_MIN_PERIODS = 10

#: Robust z-score (median/MAD based) and classic log-space z-score thresholds.
ROBUST_Z_THRESHOLD = 6.0
LOG_Z_THRESHOLD = 4.0

#: Ratio-of-median thresholds kept from the original implementation so that
#: existing warning behaviour is preserved.
VOLUME_SPIKE_RATIO = 8.0
VOLUME_DRY_RATIO = 0.125

#: Multiplier applied to a PRE-event price to obtain the POST-event price for
#: each canonical corporate-action ratio (label -> multiplier).
CANONICAL_FACTORS: dict[str, float] = {
    "1:10": 0.10, "1:5": 0.20, "1:4": 0.25, "1:3": 1 / 3, "1:2": 0.50,
    "1:1.25": 0.80, "1:1.5": 2 / 3, "1:1.4": 5 / 7, "3:2": 1 / 1.5,
    "2:1": 2.0, "3:1": 3.0, "4:1": 4.0, "5:1": 5.0, "10:1": 10.0,
}

#: One-off caveat attached to every suspected corporate action.
CAVEAT = ("Price data alone cannot separate a corporate action from a market "
          "move of the same size (a -50% crash looks exactly like a 1:2 "
          "split). Confirm against the exchange corporate-action register "
          "before adjusting anything.")


# --------------------------------------------------------------------------
# Result types
# --------------------------------------------------------------------------
@dataclass
class PriceDiscontinuity:
    """A single overnight price discontinuity (candidate corporate action)."""

    index: int
    timestamp: str
    prev_timestamp: str
    prev_close: float
    open: float
    close: float
    gap_pct: float                 # (open - prev_close) / prev_close
    ret_pct: float                 # (close - prev_close) / prev_close
    level_reset: bool              # the new price level stuck through the bar
    implied_factor: float          # open / prev_close (pre -> post multiplier)
    implied_ratio: str | None      # closest canonical ratio label, if any
    ratio_snap_pct: float | None   # how far the factor is from that label
    volume_ratio: float | None     # volume vs trailing median
    confidence: float              # 0..1
    confidence_label: str          # HIGH | MEDIUM | LOW
    kind: str                      # CORPORATE_ACTION_SUSPECTED | PRICE_DISCONTINUITY
    evidence: list[str] = field(default_factory=list)
    caveat: str = CAVEAT

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class GapEvent:
    """A stretch of expected data that is simply not in the file."""

    kind: str                     # MISSING_SESSION | HOLIDAY_SESSION | INTRA_SESSION
    from_timestamp: str
    to_timestamp: str
    missing_sessions: int = 0
    holiday_sessions: int = 0
    missing_bars: int = 0
    detail: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class GapReport:
    """Detailed missing-bar / holiday-gap accounting."""

    missing_bars: int = 0                 # identical semantics to the legacy counter
    holiday_skips: int = 0
    missing_sessions: int = 0
    holiday_sessions: int = 0
    intra_session_missing_bars: int = 0
    late_session_starts: int = 0
    expected_bars: int = 0
    observed_bars: int = 0
    coverage_pct: float = 100.0
    events: list[GapEvent] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["events"] = [e.to_dict() for e in self.events]
        return d


@dataclass
class VolumeAnomaly:
    index: int
    timestamp: str
    volume: float
    rolling_median: float | None
    ratio: float | None
    robust_z: float | None
    log_z: float | None
    direction: str               # SPIKE | DRY | ZERO
    severity: str                # HIGH | MEDIUM | LOW

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class VolumeProfile:
    median: float = 0.0
    iqr: float = 0.0
    p95: float = 0.0
    total_bars: int = 0
    spike_bars: int = 0
    dry_bars: int = 0
    zero_bars: int = 0
    zscore_alerts: int = 0
    abnormal_bars: int = 0
    ratio_alert_bars: int = 0      # legacy criterion only (>8x / <1/8x median)
    anomalies: list[VolumeAnomaly] = field(default_factory=list)
    method: str = (
        "Rolling 20-bar median of volume (shifted by one bar, so a bar is "
        "never compared with itself), plus a robust z-score "
        "(0.6745*(v-median)/MAD) and a classic z-score on log(volume). "
        "A bar is abnormal when the ratio test, the robust z-test or the "
        "log z-test fires. Zero-volume bars are counted once, in their own "
        "category, never as a dry-up."
    )

    def to_dict(self) -> dict:
        d = asdict(self)
        d["anomalies"] = [a.to_dict() for a in self.anomalies]
        return d


@dataclass
class QualityComponent:
    key: str
    label: str
    weight: float
    score: float                 # 0..1
    points: float                # score * weight
    detail: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class QualityAssessment:
    score: int                   # 0..100
    grade: str                   # A | B | C | D | F
    verdict: str
    components: list[QualityComponent] = field(default_factory=list)
    serious_issues: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    penalty: float = 0.0         # points deducted for serious issues

    def to_dict(self) -> dict:
        d = asdict(self)
        d["components"] = [c.to_dict() for c in self.components]
        return d


# --------------------------------------------------------------------------
# 1. Corporate action / price discontinuity detection
# --------------------------------------------------------------------------
def _snap_ratio(factor: float) -> tuple[str | None, float | None]:
    """Closest canonical corporate-action ratio for a multiplier."""
    if not np.isfinite(factor) or factor <= 0:
        return None, None
    best_label, best_diff = None, None
    for label, f in CANONICAL_FACTORS.items():
        diff = abs(f - factor) / factor
        if best_diff is None or diff < best_diff:
            best_label, best_diff = label, diff
    return best_label, best_diff


def detect_corporate_actions(df: pd.DataFrame, timeframe: str = "1D") -> list[PriceDiscontinuity]:
    """Find overnight price discontinuities that look like split/bonus events.

    This is DETECTION FOR REVIEW, never an adjustment. The returned list is
    empty when the file shows no material overnight gaps.
    """
    if df is None or len(df) < 2:
        return []

    close = df["close"].astype(float).to_numpy()
    open_ = df["open"].astype(float).to_numpy()
    volume = df["volume"].astype(float).to_numpy()
    ts = df["timestamp"]

    # Trailing volume median (shifted) so the event bar is never its own baseline.
    s_vol = pd.Series(volume).rolling(VOLUME_WINDOW, min_periods=VOLUME_MIN_PERIODS).median().shift(1)
    vol_med = s_vol.to_numpy()

    out: list[PriceDiscontinuity] = []
    for i in range(1, len(df)):
        prev_close = close[i - 1]
        o = open_[i]
        c = close[i]
        if prev_close <= 0 or o <= 0:
            continue
        gap_pct = (o - prev_close) / prev_close
        if abs(gap_pct) < GAP_CANDIDATE_PCT:
            continue

        factor = o / prev_close
        level_reset = abs(c - o) / o <= LEVEL_RESET_TOL
        label, snap = _snap_ratio(factor)

        evidence: list[str] = []
        confidence = 0.0
        if snap is not None:
            if snap <= RATIO_SNAP_TIGHT:
                confidence += 0.45
                evidence.append(
                    f"the price gap matches the canonical corporate-action ratio "
                    f"{label} to within {snap * 100:.2f}%")
            elif snap <= RATIO_SNAP_LOOSE:
                confidence += 0.25
                evidence.append(
                    f"the price gap is close to the canonical ratio {label} "
                    f"({snap * 100:.2f}% off)")

        magnitude = abs(gap_pct)
        if magnitude >= 0.40:
            confidence += 0.25
            evidence.append(f"a {magnitude * 100:.1f}% overnight gap is far beyond normal daily noise")
        elif magnitude >= 0.20:
            confidence += 0.18
            evidence.append(f"a {magnitude * 100:.1f}% overnight gap is well beyond normal daily noise")
        else:
            confidence += 0.08
            evidence.append(f"a {magnitude * 100:.1f}% overnight gap is beyond normal daily noise")

        if level_reset:
            confidence += 0.20
            evidence.append("the new price level held through the close (a one-bar opening spike would have reverted)")
        else:
            evidence.append("the gap partly reverted inside the bar — more like a trading spike than a level reset")

        vr = None
        if not np.isnan(vol_med[i]) and vol_med[i] > 0:
            vr = float(volume[i] / vol_med[i])
            if vr >= 3.0:
                confidence += 0.10
                evidence.append(f"volume was {vr:.1f}x its trailing median on the event bar")

        confidence = float(min(1.0, max(0.0, confidence)))
        if confidence >= 0.70:
            conf_label = "HIGH"
        elif confidence >= 0.45:
            conf_label = "MEDIUM"
        else:
            conf_label = "LOW"

        kind = ("CORPORATE_ACTION_SUSPECTED"
                if (snap is not None and snap <= RATIO_SNAP_TIGHT
                    and level_reset and magnitude >= 0.15)
                else "PRICE_DISCONTINUITY")

        out.append(PriceDiscontinuity(
            index=int(i),
            timestamp=str(ts.iloc[i]),
            prev_timestamp=str(ts.iloc[i - 1]),
            prev_close=round(float(prev_close), 6),
            open=round(float(o), 6),
            close=round(float(c), 6),
            gap_pct=round(float(gap_pct), 6),
            ret_pct=round(float((c - prev_close) / prev_close), 6),
            level_reset=bool(level_reset),
            implied_factor=round(float(factor), 6),
            implied_ratio=label,
            ratio_snap_pct=round(float(snap), 6) if snap is not None else None,
            volume_ratio=round(vr, 4) if vr is not None else None,
            confidence=round(confidence, 3),
            confidence_label=conf_label,
            kind=kind,
            evidence=evidence,
        ))
    return out


def summarise_corporate_actions(actions: list[PriceDiscontinuity]) -> dict:
    """Compact, honest summary of the detected discontinuities."""
    if not actions:
        return {"count": 0, "suspected": 0, "other": 0, "max_confidence": 0.0,
                "caveat": CAVEAT, "events": []}
    suspected = [a for a in actions if a.kind == "CORPORATE_ACTION_SUSPECTED"]
    return {
        "count": len(actions),
        "suspected": len(suspected),
        "other": len(actions) - len(suspected),
        "max_confidence": round(max(a.confidence for a in actions), 3),
        "caveat": CAVEAT,
        "events": [a.to_dict() for a in actions],
    }


# --------------------------------------------------------------------------
# 2. Missing bars and holiday gaps
# --------------------------------------------------------------------------
def _bars_per_session(timeframe: str) -> int:
    """Legacy convention: (session end - session start) / interval."""
    if timeframe == "1D":
        return 1
    return int((SESSION_END_MIN - SESSION_START_MIN) / INTERVAL_MIN[timeframe])


def _holiday_set(holidays) -> set[str]:
    return {str(h)[:10] for h in (holidays or set())}


def analyse_gaps(ts: pd.Series, timeframe: str, holidays=None) -> GapReport:
    """Detailed missing-bar / holiday-gap accounting.

    The headline ``missing_bars`` and ``holiday_skips`` numbers use exactly
    the legacy arithmetic so that saved datasets and existing reports stay
    comparable; the extra fields add the detail the old counter threw away.
    """
    rep = GapReport()
    holidays = _holiday_set(holidays)
    if ts is None or len(ts) < 2:
        rep.observed_bars = int(len(ts)) if ts is not None else 0
        rep.expected_bars = rep.observed_bars
        return rep

    ts = ts.dt.tz_convert(IST) if ts.dt.tz is not None else ts.dt.tz_localize(IST)
    dates = ts.dt.normalize()
    per_session = _bars_per_session(timeframe)
    events: list[GapEvent] = []

    if timeframe == "1D":
        prev = dates.shift(1)
        for p, c in zip(prev.iloc[1:], dates.iloc[1:]):
            if pd.isna(p):
                continue
            days = pd.bdate_range(p, c, freq="B")[1:-1]
            if len(days) == 0:
                continue
            real = [d for d in days if d.strftime("%Y-%m-%d") not in holidays]
            hol = len(days) - len(real)
            rep.missing_sessions += len(real)
            rep.holiday_sessions += hol
            rep.missing_bars += len(real)
            rep.holiday_skips += hol
            if len(real):
                events.append(GapEvent(
                    kind="MISSING_SESSION",
                    from_timestamp=str(p.date()), to_timestamp=str(c.date()),
                    missing_sessions=len(real), holiday_sessions=hol,
                    missing_bars=len(real),
                    detail=f"{len(real)} trading session(s) with no data between "
                           f"{p.date()} and {c.date()}",
                ))
            if hol:
                events.append(GapEvent(
                    kind="HOLIDAY_SESSION",
                    from_timestamp=str(p.date()), to_timestamp=str(c.date()),
                    missing_sessions=0, holiday_sessions=hol, missing_bars=0,
                    detail=f"{hol} session(s) skipped that match the configured "
                           f"holiday list (expected, not missing data)",
                ))
    else:
        step = pd.Timedelta(minutes=INTERVAL_MIN[timeframe])
        same_day = dates.eq(dates.shift(1))
        diffs = ts.diff()
        gap_mask = (same_day & (diffs > step)).fillna(False)
        ts_values = ts.to_numpy()
        diff_values = diffs.to_numpy()
        gap_positions = np.flatnonzero(gap_mask.to_numpy())
        for i_pos in gap_positions:
            if i_pos == 0:
                continue
            holes = int((diff_values[i_pos] / step) - 1)
            if holes <= 0:
                continue
            rep.intra_session_missing_bars += holes
            rep.missing_bars += holes
            events.append(GapEvent(
                kind="INTRA_SESSION",
                from_timestamp=str(ts_values[i_pos - 1]), to_timestamp=str(ts_values[i_pos]),
                missing_bars=holes,
                detail=f"{holes} bar(s) missing inside the "
                       f"{pd.Timestamp(ts_values[i_pos]).date()} session",
            ))

        prev = dates.shift(1)
        for p, c in zip(prev.iloc[1:], dates.iloc[1:]):
            if pd.isna(p) or p == c:
                continue
            days = pd.bdate_range(p, c, freq="B")[1:-1]
            if len(days) == 0:
                continue
            real = [d for d in days if d.strftime("%Y-%m-%d") not in holidays]
            hol = len(days) - len(real)
            rep.missing_sessions += len(real)
            rep.holiday_sessions += hol
            rep.holiday_skips += hol
            rep.missing_bars += len(real) * per_session
            if len(real):
                events.append(GapEvent(
                    kind="MISSING_SESSION",
                    from_timestamp=str(p.date()), to_timestamp=str(c.date()),
                    missing_sessions=len(real), holiday_sessions=hol,
                    missing_bars=len(real) * per_session,
                    detail=f"{len(real)} whole trading session(s) with no data between "
                           f"{p.date()} and {c.date()}",
                ))
            if hol:
                events.append(GapEvent(
                    kind="HOLIDAY_SESSION",
                    from_timestamp=str(p.date()), to_timestamp=str(c.date()),
                    missing_sessions=0, holiday_sessions=hol, missing_bars=0,
                    detail=f"{hol} session(s) skipped that match the configured "
                           f"holiday list (expected, not missing data)",
                ))

        # Sessions that start late: the first bar of a day is after the session
        # open, so the earliest bars of that session are missing.
        first_of_day = ~same_day.fillna(True)
        for i_pos in np.flatnonzero(first_of_day.to_numpy()):
            if i_pos == 0:
                continue
            t = ts.iloc[i_pos]
            minutes = t.hour * 60 + t.minute
            late = (minutes - SESSION_START_MIN) / INTERVAL_MIN[timeframe]
            if late >= 1:
                rep.late_session_starts += 1
                open_hh, open_mm = divmod(SESSION_START_MIN, 60)
                events.append(GapEvent(
                    kind="INTRA_SESSION",
                    from_timestamp=str(t.normalize() + pd.Timedelta(minutes=SESSION_START_MIN)),
                    to_timestamp=str(t),
                    missing_bars=int(late),
                    detail=f"the {t.date()} session starts at {t.strftime('%H:%M')} "
                           f"instead of {open_hh:02d}:{open_mm:02d} "
                           f"(~{int(late)} leading bar(s) absent)",
                ))

    rep.observed_bars = int(len(ts))
    # Expected bars over the observed span (sessions x bars-per-session).
    try:
        span_start = dates.iloc[0]
        span_end = dates.iloc[-1]
        session_days = pd.bdate_range(span_start, span_end, freq="B")
        expected_sessions = len([d for d in session_days
                                 if d.strftime("%Y-%m-%d") not in holidays])
    except Exception:
        expected_sessions = len(ts) // max(1, per_session)
    rep.expected_bars = int(expected_sessions * per_session)
    if rep.expected_bars > 0:
        rep.coverage_pct = round(100.0 * rep.observed_bars / rep.expected_bars, 2)
    events.sort(key=lambda e: (-e.missing_bars, e.from_timestamp))
    rep.events = events[:200]
    return rep


# --------------------------------------------------------------------------
# 3. Volume anomalies: rolling median + robust z-score + log z-score
# --------------------------------------------------------------------------
def analyse_volume(volume: pd.Series, timestamps: pd.Series | None = None) -> VolumeProfile:
    """Flag unusual volume bars using a rolling median AND z-scores.

    The original rule (ratio vs trailing median) is kept intact; the z-scores
    are added so that bars which are unusual relative to the *distribution*
    are caught even when the ratio test does not fire.
    """
    prof = VolumeProfile()
    if volume is None or len(volume) == 0:
        return prof

    v = pd.Series(volume).astype(float).reset_index(drop=True)
    total = int(len(v))
    prof.total_bars = total
    prof.zero_bars = int((v == 0).sum())
    prof.median = float(v.median()) if total else 0.0
    prof.iqr = float(v.quantile(0.75) - v.quantile(0.25)) if total else 0.0
    prof.p95 = float(v.quantile(0.95)) if total else 0.0

    med = v.rolling(VOLUME_WINDOW, min_periods=VOLUME_MIN_PERIODS).median().shift(1)
    ratio = (v / med.replace(0.0, np.nan))

    # Robust scale: median absolute deviation of the trailing window. When the
    # MAD collapses to zero (a perfectly flat volume series) fall back to the
    # mean absolute deviation, otherwise the z-score would be undefined and a
    # genuine spike in flat data would go unnoticed.
    dev = (v - med).abs()
    mad = dev.rolling(VOLUME_WINDOW, min_periods=VOLUME_MIN_PERIODS).median()
    mean_dev = dev.rolling(VOLUME_WINDOW, min_periods=VOLUME_MIN_PERIODS).mean()
    scale = mad.where(mad > 0, mean_dev)
    with np.errstate(divide="ignore", invalid="ignore"):
        robust_z = 0.6745 * (v - med) / scale.replace(0.0, np.nan)

    logv = np.log1p(v)
    lmean = logv.rolling(VOLUME_WINDOW, min_periods=VOLUME_Z_MIN_PERIODS).mean().shift(1)
    lstd = logv.rolling(VOLUME_WINDOW, min_periods=VOLUME_Z_MIN_PERIODS).std().shift(1)
    ldev = (logv - lmean).abs()
    lstd_fallback = ldev.rolling(VOLUME_WINDOW, min_periods=VOLUME_Z_MIN_PERIODS).mean()
    lscale = lstd.where(lstd > 0, lstd_fallback)
    with np.errstate(divide="ignore", invalid="ignore"):
        log_z = (logv - lmean) / lscale.replace(0.0, np.nan)

    spike_ratio = ratio > VOLUME_SPIKE_RATIO
    dry_ratio = (ratio < VOLUME_DRY_RATIO) & (v > 0)
    spike_z = robust_z >= ROBUST_Z_THRESHOLD
    dry_z = robust_z <= -ROBUST_Z_THRESHOLD
    spike_lz = log_z >= LOG_Z_THRESHOLD
    dry_lz = log_z <= -LOG_Z_THRESHOLD

    spike = (spike_ratio | spike_z | spike_lz).fillna(False)
    # A zero-volume bar is reported under `zero_bars`, not as a "dry-up", so the
    # two categories never double-count the same bar.
    dry = ((dry_ratio | dry_z | dry_lz) & (v > 0)).fillna(False)
    zero = (v == 0)
    z_alerts = (spike_z | dry_z | spike_lz | dry_lz).fillna(False)

    prof.spike_bars = int(spike.sum())
    prof.dry_bars = int(dry.sum())
    prof.zscore_alerts = int(z_alerts.sum())
    prof.abnormal_bars = int((spike | dry | zero).sum())
    prof.ratio_alert_bars = int((spike_ratio | dry_ratio).fillna(False).sum())

    ts = timestamps.reset_index(drop=True) if timestamps is not None else None
    for i in range(total):
        is_zero = bool(zero.iloc[i])
        if not (spike.iloc[i] or dry.iloc[i] or is_zero):
            continue
        r = ratio.iloc[i]
        rz = robust_z.iloc[i]
        lz = log_z.iloc[i]
        direction = "ZERO" if is_zero else ("SPIKE" if spike.iloc[i] else "DRY")
        mag_ratio = float(r) if r == r and np.isfinite(r) else None
        mag_z = float(rz) if rz == rz and np.isfinite(rz) else None
        if is_zero:
            severity = "HIGH"
        elif (mag_ratio is not None and mag_ratio >= 20.0) or (mag_z is not None and abs(mag_z) >= 10.0):
            severity = "HIGH"
        elif (mag_ratio is not None and mag_ratio >= VOLUME_SPIKE_RATIO) or \
             (mag_z is not None and abs(mag_z) >= ROBUST_Z_THRESHOLD):
            severity = "MEDIUM"
        else:
            severity = "LOW"
        prof.anomalies.append(VolumeAnomaly(
            index=int(i),
            timestamp=str(ts.iloc[i]) if ts is not None else "",
            volume=float(v.iloc[i]),
            rolling_median=float(med.iloc[i]) if med.iloc[i] == med.iloc[i] else None,
            ratio=round(mag_ratio, 4) if mag_ratio is not None else None,
            robust_z=round(mag_z, 3) if mag_z is not None else None,
            log_z=round(float(lz), 3) if lz == lz and np.isfinite(lz) else None,
            direction=direction,
            severity=severity,
        ))
        if len(prof.anomalies) >= 500:
            break
    return prof


# --------------------------------------------------------------------------
# 4. The 0-100 dataset quality score
# --------------------------------------------------------------------------
GRADE_TABLE = [
    (90, "A", "Clean — no significant data-integrity problems found"),
    (80, "B", "Good — usable, with minor issues worth knowing about"),
    (70, "C", "Usable with caution — fix or accept the flagged issues first"),
    (60, "D", "Poor — serious gaps or integrity problems; treat results skeptically"),
    (0, "F", "Unreliable — serious integrity problems; repair or re-export the file"),
]


def _grade(score: int) -> tuple[str, str]:
    for threshold, letter, verdict in GRADE_TABLE:
        if score >= threshold:
            return letter, verdict
    return "F", GRADE_TABLE[-1][2]


def assess_quality(
    *,
    rows_read: int,
    candle_count: int,
    rows_rejected: int,
    duplicates: int,
    timeframe: str,
    gaps: GapReport,
    volume: VolumeProfile,
    actions: list[PriceDiscontinuity],
    adjustment_policy: str,
    source_type: str = "",
) -> QualityAssessment:
    """Score the dataset 0-100 and list the issues that matter.

    The score is a weighted sum of five transparent components, MINUS a
    severity-weighted penalty for every serious issue found. It measures the
    internal consistency and the sufficiency of the FILE. It is NOT a measure
    of market authenticity, profitability or edge.

    Severity weights (points deducted from the 0-100 base):
      HIGH   -12 : the file can produce misleading price-based signals
      MEDIUM  -6 : the file has a real, meaningful defect
      LOW     -2 : worth knowing about, unlikely to mislead
    """
    components: list[QualityComponent] = []
    notes: list[str] = []
    issues: list[tuple[str, str]] = []          # (severity, message)

    def add(severity: str, message: str) -> None:
        issues.append((severity, message))

    rows_read = max(int(rows_read), 1)
    candle_count = max(int(candle_count), 0)

    # ---- 1. Row integrity (weight 20) -----------------------------------
    keep_ratio = candle_count / rows_read
    dup_penalty = min(0.5, duplicates / rows_read * 4)
    score = max(0.0, min(1.0, keep_ratio - dup_penalty))
    components.append(QualityComponent(
        key="row_integrity", label="Row integrity", weight=20.0, score=round(score, 4),
        points=round(score * 20.0, 2),
        detail=f"{candle_count} of {rows_read} rows kept"
               + (f", {rows_rejected} rejected, {duplicates} duplicate row(s) dropped"
                  if (rows_rejected or duplicates) else ", no rows rejected"),
    ))
    reject_ratio = rows_rejected / rows_read
    if reject_ratio > 0.30:
        add("HIGH", f"{rows_rejected} of {rows_read} input rows were rejected "
                    f"({reject_ratio * 100:.1f}%) — more than a third of the file did not "
                    f"pass validation. Check the CSV format before using it.")
    elif reject_ratio > 0.10:
        add("MEDIUM", f"{rows_rejected} of {rows_read} input rows were rejected "
                      f"({reject_ratio * 100:.1f}%) — check the CSV format.")
    if duplicates:
        add("MEDIUM", f"{duplicates} duplicate-timestamp row(s) were dropped; "
                      f"duplicated bars mean the source is inconsistent.")

    # ---- 2. Continuity / coverage (weight 25) ---------------------------
    expected = max(gaps.expected_bars, candle_count, 1)
    cov = min(1.0, candle_count / expected)
    components.append(QualityComponent(
        key="continuity", label="Continuity & coverage", weight=25.0, score=round(cov, 4),
        points=round(cov * 25.0, 2),
        detail=f"{gaps.observed_bars} bar(s) present vs {gaps.expected_bars} expected "
               f"({gaps.coverage_pct:.2f}% coverage); {gaps.missing_bars} missing bar(s), "
               f"{gaps.missing_sessions} missing session(s), "
               f"{gaps.holiday_sessions} holiday session(s) skipped",
    ))
    if gaps.missing_sessions:
        share = gaps.missing_sessions / max(gaps.expected_bars // max(1, _bars_per_session(timeframe)), 1)
        add("HIGH" if share > 0.05 else "MEDIUM",
            f"{gaps.missing_sessions} trading session(s) are missing from the file "
            f"({gaps.missing_bars} bar(s)). Gaps create look-ahead-free but "
            f"mis-timed features — re-export or accept the distortion.")
    if gaps.intra_session_missing_bars:
        add("MEDIUM", f"{gaps.intra_session_missing_bars} bar(s) are missing from the middle "
                      f"of intraday sessions; intraday indicators will be computed on an "
                      f"incomplete grid.")
    if gaps.late_session_starts:
        add("LOW", f"{gaps.late_session_starts} intraday session(s) start after the "
                   f"09:15 open; the leading bars of those sessions are absent.")
    if gaps.missing_bars and not gaps.missing_sessions and gaps.intra_session_missing_bars:
        notes.append(f"{gaps.missing_bars} bar(s) missing inside sessions.")

    # ---- 3. Volume sanity (weight 15) -----------------------------------
    if candle_count:
        # `abnormal_bars` already includes the zero-volume bars, so they are
        # not counted twice here.
        vol_bad = min(candle_count, volume.abnormal_bars)
        vscore = max(0.0, 1.0 - vol_bad / candle_count)
    else:
        vscore = 0.0
    components.append(QualityComponent(
        key="volume_sanity", label="Volume sanity", weight=15.0, score=round(vscore, 4),
        points=round(vscore * 15.0, 2),
        detail=f"{volume.spike_bars} spike(s), {volume.dry_bars} dry-up(s), "
               f"{volume.zero_bars} zero-volume bar(s), {volume.zscore_alerts} z-score alert(s)",
    ))
    zero_share = volume.zero_bars / max(candle_count, 1)
    if zero_share > 0.20:
        add("HIGH", f"{volume.zero_bars} zero-volume bar(s) — more than a fifth of the file "
                    f"did not trade. These are likely stale or placeholder candles.")
    elif zero_share > 0.05:
        add("MEDIUM", f"{volume.zero_bars} zero-volume bar(s) — likely stale or "
                      f"placeholder candles.")
    abnormal_share = volume.abnormal_bars / max(candle_count, 1)
    if abnormal_share > 0.10:
        add("MEDIUM", f"{volume.abnormal_bars} abnormal-volume bar(s) "
                      f"({abnormal_share * 100:.1f}% of the file) — verify against the "
                      f"source; bad ticks look like real spikes.")
    if volume.spike_bars:
        notes.append(f"{volume.spike_bars} volume spike(s) detected (rolling median + "
                     f"robust and log z-scores).")

    # ---- 4. Price consistency (weight 20) --------------------------------
    sus = [a for a in actions if a.kind == "CORPORATE_ACTION_SUSPECTED"]
    other = [a for a in actions if a.kind != "CORPORATE_ACTION_SUSPECTED"]
    n_disc = len(actions)
    disc_ratio = min(1.0, n_disc / max(candle_count, 1) / 0.01)   # 1% of bars = full penalty
    pscore = max(0.0, 1.0 - disc_ratio)
    components.append(QualityComponent(
        key="price_consistency", label="Price consistency", weight=20.0, score=round(pscore, 4),
        points=round(pscore * 20.0, 2),
        detail=f"{len(sus)} suspected corporate action(s), {len(other)} other price "
               f"discontinuity(ies) detected; prices left unadjusted",
    ))
    if sus:
        add("HIGH", f"{len(sus)} suspected split/bonus event(s) detected "
                    f"({', '.join(a.implied_ratio or '?' for a in sus[:5])}). "
                    f"Price-based indicators will show artificial jumps unless the "
                    f"series is adjusted — verify against the corporate-action register.")
    if adjustment_policy == "SPLIT_AND_BONUS_ADJUSTED" and sus:
        add("HIGH", "The file claims to be split & bonus adjusted, yet "
                    f"{len(sus)} suspected corporate action(s) are still present — "
                    "the adjustment is incomplete or the label is wrong.")
    if other:
        notes.append(f"{len(other)} price discontinuity(ies) that do not match a canonical "
                     f"corporate-action ratio — review them as possible market moves or bad ticks.")
    extreme = [a for a in other if abs(a.gap_pct) >= 0.40]
    if extreme:
        add("MEDIUM", f"{len(extreme)} overnight move(s) of 40% or more that do NOT match a "
                      f"corporate-action ratio — these are more likely a bad tick or an "
                      f"unannounced event than a split. Check those bars against the source "
                      f"before using them.")

    # ---- 5. Sufficiency (weight 20) --------------------------------------
    need = required_research_bars(timeframe)
    sscore = min(1.0, candle_count / max(need, 1))
    components.append(QualityComponent(
        key="sufficiency", label="History sufficiency", weight=20.0, score=round(sscore, 4),
        points=round(sscore * 20.0, 2),
        detail=f"{candle_count} bar(s) vs {need} required for research-grade {timeframe}",
    ))
    if candle_count < need:
        notes.append(f"Only {candle_count} bars; research-grade for {timeframe} needs "
                     f"{need}. This is a sufficiency limit, not a data defect.")

    # ---- penalty + total --------------------------------------------------
    penalty_weights = {"HIGH": 12.0, "MEDIUM": 6.0, "LOW": 2.0}
    penalty = sum(penalty_weights[sev] for sev, _ in issues)
    total_points = sum(c.points for c in components)
    score_int = int(round(max(0.0, min(100.0, total_points - penalty))))

    # Grade caps: a file with a serious issue must never be graded as clean.
    # HIGH -> at best C, MEDIUM -> at best B, LOW -> at best A.
    severities = [sev for sev, _ in issues]
    cap = 100
    cap_label = ""
    if "HIGH" in severities:
        cap, cap_label = 70, "HIGH"
    elif "MEDIUM" in severities:
        cap, cap_label = 80, "MEDIUM"
    elif "LOW" in severities:
        cap, cap_label = 90, "LOW"
    if score_int > cap:
        notes.append(f"Grade capped at {_grade(cap)[0]} because a {cap_label}-severity "
                     f"issue was found — the file cannot be graded clean.")
        score_int = cap
    grade, verdict = _grade(score_int)

    serious = [msg for _, msg in issues]
    if penalty:
        notes.append(f"Severity penalty applied: -{penalty:.0f} points for "
                     f"{len(issues)} serious issue(s).")

    if source_type in ("SIMULATED", "TEST_FIXTURE"):
        notes.append("This file is NOT market data. The score describes the file's internal "
                     "consistency only — it says nothing about markets, returns or edge.")

    return QualityAssessment(
        score=score_int, grade=grade, verdict=verdict,
        components=components, serious_issues=serious, notes=notes,
        penalty=penalty,
    )
