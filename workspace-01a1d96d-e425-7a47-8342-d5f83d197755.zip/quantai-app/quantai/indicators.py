"""Causal technical indicators for charting and indicator-based strategies.

Conventions (documented, hand-tested):
  * EMA / MACD signal: SMA-seeded recursive EMA (first valid value at period-1
    of the first contiguous valid window). alpha = 2/(period+1).
  * RSI(14) and ATR(14): Wilder smoothing, SMA-seeded.
  * Bollinger(20, 2): SMA +/- 2 * population std (ddof=0).
  * VWAP: session-anchored (IST trading date), cumulative typical-price*volume /
    cumulative volume. ONLY for intraday timeframes with positive volume.
  * Warm-up bars are NaN — never back-filled, never fabricated.

Every value at row i uses only rows 0..i. No centred windows, no future bars.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

EMA_PERIODS = (9, 20, 50, 200)
SMA_PERIODS = (20, 50, 200)
INDICATOR_COLUMNS = (
    [f"ema_{p}" for p in EMA_PERIODS] + [f"sma_{p}" for p in SMA_PERIODS]
    + ["rsi_14", "macd", "macd_signal", "macd_hist",
       "bb_mid", "bb_upper", "bb_lower", "bb_percent_b", "bb_bandwidth",
       "atr_14", "vwap"]
)


def _ema(values: np.ndarray, period: int) -> np.ndarray:
    """SMA-seeded EMA. Handles leading NaNs (e.g. MACD signal line)."""
    n = len(values)
    out = np.full(n, np.nan)
    if period <= 0 or n < period:
        return out
    finite = np.isfinite(values)
    first = None
    count = 0
    for i in range(n):
        if finite[i]:
            count += 1
            if count == period:
                first = i - period + 1
                break
        else:
            count = 0
    if first is None:
        return out
    seed_idx = first + period - 1
    out[seed_idx] = float(np.mean(values[first:seed_idx + 1]))
    alpha = 2.0 / (period + 1)
    for i in range(seed_idx + 1, n):
        if finite[i] and np.isfinite(out[i - 1]):
            out[i] = alpha * values[i] + (1 - alpha) * out[i - 1]
        else:
            out[i] = np.nan
    return out


def sma(series: pd.Series, period: int) -> pd.Series:
    return series.rolling(period, min_periods=period).mean()


def ema(series: pd.Series, period: int) -> pd.Series:
    return pd.Series(_ema(series.to_numpy(dtype=float), period), index=series.index)


def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    c = close.to_numpy(dtype=float)
    n = len(c)
    out = np.full(n, np.nan)
    if n <= period:
        return pd.Series(out, index=close.index)
    delta = np.diff(c)
    gain = np.where(delta > 0, delta, 0.0)
    loss = np.where(delta < 0, -delta, 0.0)
    avg_g = float(gain[:period].mean())
    avg_l = float(loss[:period].mean())

    def _rsi(ag, al):
        if ag == 0 and al == 0:
            return 50.0
        if al == 0:
            return 100.0
        if ag == 0:
            return 0.0
        return 100.0 - 100.0 / (1.0 + ag / al)

    out[period] = _rsi(avg_g, avg_l)
    for i in range(period + 1, n):
        avg_g = (avg_g * (period - 1) + gain[i - 1]) / period
        avg_l = (avg_l * (period - 1) + loss[i - 1]) / period
        out[i] = _rsi(avg_g, avg_l)
    return pd.Series(out, index=close.index)


def true_range(df: pd.DataFrame) -> pd.Series:
    h = df["high"].astype(float)
    l = df["low"].astype(float)
    pc = df["close"].astype(float).shift(1)
    tr = pd.concat([h - l, (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    return tr


def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    tr = true_range(df).to_numpy(dtype=float)
    n = len(tr)
    out = np.full(n, np.nan)
    if n < period:
        return pd.Series(out, index=df.index)
    out[period - 1] = float(np.mean(tr[:period]))
    for i in range(period, n):
        out[i] = (out[i - 1] * (period - 1) + tr[i]) / period
    return pd.Series(out, index=df.index)


def macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    ema_fast = _ema(close.to_numpy(dtype=float), fast)
    ema_slow = _ema(close.to_numpy(dtype=float), slow)
    line = ema_fast - ema_slow
    sig = _ema(line, signal)
    hist = line - sig
    idx = close.index
    return (pd.Series(line, index=idx), pd.Series(sig, index=idx), pd.Series(hist, index=idx))


def bollinger(close: pd.Series, period: int = 20, num_std: float = 2.0):
    mid = close.rolling(period, min_periods=period).mean()
    sd = close.rolling(period, min_periods=period).std(ddof=0)
    upper = mid + num_std * sd
    lower = mid - num_std * sd
    band = (upper - lower)
    pb = (close - lower) / band.where(band > 0)
    bw = band / mid.where(mid > 0)
    return mid, upper, lower, pb, bw


def vwap(df: pd.DataFrame, timeframe: str) -> tuple[pd.Series, bool]:
    """Session-anchored VWAP. Returns (series, valid). Daily -> all NaN, invalid."""
    n = len(df)
    if timeframe == "1D" or n == 0:
        return pd.Series(np.full(n, np.nan), index=df.index), False
    vol = df["volume"].astype(float)
    if float(vol.sum()) <= 0:
        return pd.Series(np.full(n, np.nan), index=df.index), False
    ts = pd.to_datetime(df["timestamp"])
    if ts.dt.tz is None:
        ts = ts.dt.tz_localize("Asia/Kolkata")
    else:
        ts = ts.dt.tz_convert("Asia/Kolkata")
    session = ts.dt.normalize()
    typical = (df["high"].astype(float) + df["low"].astype(float) + df["close"].astype(float)) / 3.0
    pv = typical * vol
    tmp = pd.DataFrame({"session": session.to_numpy(), "pv": pv.to_numpy(), "v": vol.to_numpy()})
    cum_pv = tmp.groupby("session")["pv"].cumsum()
    cum_v = tmp.groupby("session")["v"].cumsum()
    out = cum_pv / cum_v.where(cum_v > 0)
    return pd.Series(out.to_numpy(), index=df.index), True


def compute_indicators(df: pd.DataFrame, timeframe: str) -> pd.DataFrame:
    """Compute the full indicator set. Warm-up bars are NaN."""
    close = df["close"].astype(float)
    out = pd.DataFrame(index=df.index)
    for p in EMA_PERIODS:
        out[f"ema_{p}"] = ema(close, p)
    for p in SMA_PERIODS:
        out[f"sma_{p}"] = sma(close, p)
    out["rsi_14"] = rsi(close, 14)
    line, sig, hist = macd(close)
    out["macd"] = line
    out["macd_signal"] = sig
    out["macd_hist"] = hist
    mid, upper, lower, pb, bw = bollinger(close)
    out["bb_mid"] = mid
    out["bb_upper"] = upper
    out["bb_lower"] = lower
    out["bb_percent_b"] = pb
    out["bb_bandwidth"] = bw
    out["atr_14"] = atr(df, 14)
    vw, _ = vwap(df, timeframe)
    out["vwap"] = vw
    return out


def indicator_score(row: pd.Series) -> float:
    """Transparent long-bias score in [-1, 1] from indicator readings at ONE bar.

    Factors: EMA20/50 trend, MACD histogram sign, RSI distance from 50,
    Bollinger %B position, and (when available) EMA20 vs EMA200 regime.
    Returns NaN if the required readings are still in warm-up.
    """
    required = ["ema_20", "ema_50", "rsi_14", "macd_hist", "bb_percent_b"]
    vals = {k: row.get(k) for k in required}
    if any(v is None or not np.isfinite(v) for v in vals.values()):
        return float("nan")
    votes = [
        float(np.sign(vals["ema_20"] - vals["ema_50"])),
        float(np.sign(vals["macd_hist"])),
        float(np.clip((vals["rsi_14"] - 50.0) / 25.0, -1.0, 1.0)),
        float(np.clip((vals["bb_percent_b"] - 0.5) * 2.0, -1.0, 1.0)),
    ]
    e200 = row.get("ema_200")
    if e200 is not None and np.isfinite(e200):
        votes.append(float(np.sign(vals["ema_20"] - e200)))
    return float(np.mean(votes))
