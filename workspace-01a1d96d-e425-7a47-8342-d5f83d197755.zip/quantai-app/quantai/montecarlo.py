"""Monte Carlo trade-sequence simulation from ACTUAL historical/simulated trades.

Resamples the realised per-trade P&L sequence (IID bootstrap or moving-block
bootstrap to preserve streaks) and rebuilds equity paths. Reports DISTRIBUTIONS
(percentiles, probabilities) — never a guaranteed future outcome.

Assumptions / limits:
  * Resampling assumes future trades resemble the sampled trade distribution.
    It cannot model regime changes, slippage drift, or capacity decay.
  * Fixed per-trade P&L (no compounding of position size); this is a distribution
    of the existing edge, not a forecast of scaled capital.
  * With very few trades the distribution is unreliable and we say so.
"""
from __future__ import annotations

import numpy as np

from .metrics import max_drawdown_pct


def _longest_losing_streak(pnls: np.ndarray) -> int:
    best = cur = 0
    for p in pnls:
        if p < 0:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


def _resample(rng: np.random.Generator, pnls: np.ndarray, n: int,
              method: str, block_size: int) -> np.ndarray:
    if method == "block" and 1 < block_size < n:
        # Moving-block bootstrap: concatenate random contiguous blocks.
        starts = rng.integers(0, n - block_size + 1, size=int(np.ceil(n / block_size)))
        seq = np.concatenate([pnls[s:s + block_size] for s in starts])[:n]
        return seq
    idx = rng.integers(0, n, size=n)
    return pnls[idx]


def run_monte_carlo(trade_pnls: list[float], initial_capital: float,
                    n_simulations: int = 2000, method: str = "block",
                    block_size: int = 5, seed: int = 42,
                    ruin_drawdown_pct: float = 50.0,
                    max_paths_shown: int = 40) -> dict:
    pnls = np.asarray([float(p) for p in trade_pnls], dtype=float)
    n = len(pnls)
    if n < 10:
        return {"status": "insufficient",
                "message": f"Only {n} trades. Monte Carlo needs >= 10 realised trades to be meaningful.",
                "n_trades": n}
    if method not in ("iid", "block"):
        raise ValueError("method must be 'iid' or 'block'.")
    n_simulations = int(np.clip(n_simulations, 100, 20000))
    rng = np.random.default_rng(seed)

    finals = np.empty(n_simulations)
    dds = np.empty(n_simulations)
    streaks = np.empty(n_simulations, dtype=int)
    paths = []
    ruined = 0
    for i in range(n_simulations):
        seq = _resample(rng, pnls, n, method, block_size)
        equity = initial_capital + np.concatenate([[0.0], np.cumsum(seq)])
        finals[i] = equity[-1]
        dd = max_drawdown_pct(equity.tolist())
        dds[i] = dd
        streaks[i] = _longest_losing_streak(seq)
        if dd >= ruin_drawdown_pct:
            ruined += 1
        if i < max_paths_shown:
            paths.append([float(x) for x in equity.tolist()])

    def pct(a, q):
        return float(np.percentile(a, q))

    final_returns = (finals - initial_capital) / initial_capital * 100.0
    return {
        "status": "ok", "method": method, "block_size": block_size if method == "block" else None,
        "n_simulations": n_simulations, "n_trades": n, "seed": seed,
        "initial_capital": initial_capital,
        "final_equity_percentiles": {str(q): pct(finals, q) for q in (5, 25, 50, 75, 95)},
        "final_return_pct_percentiles": {str(q): pct(final_returns, q) for q in (5, 25, 50, 75, 95)},
        "max_drawdown_pct_percentiles": {str(q): pct(dds, q) for q in (5, 25, 50, 75, 95)},
        "longest_losing_streak_percentiles": {str(q): pct(streaks, q) for q in (5, 25, 50, 75, 95)},
        "probability_of_loss": float(np.mean(finals < initial_capital)),
        "probability_of_drawdown_ge_threshold": float(ruined / n_simulations),
        "ruin_drawdown_threshold_pct": ruin_drawdown_pct,
        "mean_final_return_pct": float(np.mean(final_returns)),
        "sample_paths": paths,
        "historical_max_drawdown_pct": max_drawdown_pct(
            (initial_capital + np.concatenate([[0.0], np.cumsum(pnls)])).tolist()),
        "historical_longest_losing_streak": _longest_losing_streak(pnls),
        "disclaimer": "Resampled distribution of the EXISTING trade sample. Not a prediction. "
                      "Cannot model regime shifts, changing slippage, or capacity limits. "
                      "Few trades => wide, unreliable distributions.",
    }
