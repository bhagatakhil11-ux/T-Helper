"""One-shot refactor: reorganise the inline JS in static/index.html into
clearly delimited logical sections.

The code itself is moved VERBATIM — only section banner comments are added and
the order of the top-level blocks is made logical. Load-time execution order is
preserved for every `const`/`let` (no TDZ risk): the charts block declares its
state before anything reads it, and function declarations are hoisted anyway.

!! ARCHIVED — DO NOT RE-RUN. !!
This was a one-shot migration script. It REWRITES static/index.html in place.
Re-running it now would append a second set of section banners on top of the
already-sectioned file. The refactor it performed is already complete and
tested (tests/test_frontend_sections.py). Kept only as a record of how the
sectioning was produced.

Sections (in final order):
  1 BOOTSTRAP & SHARED STATE      7 ADVANCED RESEARCH RENDERERS
  2 THEME & TAB NAVIGATION        8 TRADING JOURNAL
  3 API & DOM HELPERS             9 CHARTS & TECHNICAL ANALYSIS
  4 CANVAS PRIMITIVES            10 EVENT HANDLERS & API ACTIONS
  5 RENDER HELPERS               11 BOOT
  6 MAIN RENDERER
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path("/home/user/quantai-app")
HTML = ROOT / "static" / "index.html"
src = HTML.read_text()
m = re.search(r"<script>([\s\S]*?)</script>", src)
assert m, "inline script block not found"
js = m.group(1)
L = js.split("\n")


def find(marker: str, start: int = 0) -> int:
    for i in range(start, len(L)):
        if L[i].strip() == marker:
            return i
    raise SystemExit(f"marker not found: {marker!r}")


# ---------------------------------------------------------------- anchors
i_boot_strap = 0
i_theme = find("// theme")
i_api = find("async function api(path,body,method='POST'){")
i_charts = find("// ---------- charts ----------")
i_render = find("// ---------- render helpers ----------")
i_draw = find("// ---------- main draw ----------")
i_adv = find("// ---------- advanced research ----------")
i_journal = find("// ---------- journal ----------")
i_actions = find("// ---------- actions ----------")
i_advact = find("// ---------- advanced actions ----------")
i_ta = find("// ================= CHARTS & TECHNICAL ANALYSIS =================")
i_resize = find("window.addEventListener('resize',()=>S&&draw(S));")

# ---------------------------------------------------------------- chunks
def between(a: int, b: int) -> str:
    """Lines a..b-1 (0-indexed), trimmed of leading/trailing blank lines."""
    out = L[a:b]
    while out and not out[0].strip():
        out.pop(0)
    while out and not out[-1].strip():
        out.pop()
    return "\n".join(out)


C_BASE = between(i_boot_strap, i_theme)
C_THEME = between(i_theme, i_api)
C_API = between(i_api, i_charts)
C_CANVAS = between(i_charts, i_render)
C_RENDER = between(i_render, i_draw)
C_DRAW = between(i_draw, i_adv)
C_ADV = between(i_adv, i_journal)
C_JOURNAL = between(i_journal, i_actions)
C_ACTIONS = between(i_actions, i_advact)
C_ADVACT = between(i_advact, i_ta)
C_TA = between(i_ta, i_resize)
C_BOOT = between(i_resize, len(L))


def banner(n: int, title: str, desc: str, body: str) -> str:
    bar = "═" * 74
    return (f"\n/* {bar}\n"
            f"   SECTION {n} — {title}\n"
            f"   {bar}\n"
            f"   {desc}\n"
            f"   {bar} */\n\n"
            f"{body}\n")


SECTIONS = [
    (1, "BOOTSTRAP & SHARED STATE",
     "DOM shortcuts, number formatters and the shared client-side state."),
    (2, "THEME & TAB NAVIGATION",
     "Dark/light theme toggle and the nav-button -> panel wiring."),
    (3, "API & DOM HELPERS",
     "fetch wrapper that raises on API errors, plus message/HTML-escape helpers."),
    (4, "CANVAS PRIMITIVES",
     "Low-level canvas helpers shared by every chart in the terminal."),
    (5, "RENDER HELPERS",
     "Reusable HTML builders: verdict banner, metric grid, comparison table."),
    (6, "MAIN RENDERER",
     "draw(state) — refreshes the Dashboard, Research, Paper, Risk and Reports tabs."),
    (7, "ADVANCED RESEARCH RENDERERS",
     "Portfolio / sensitivity / regime / Monte Carlo result rendering."),
    (8, "TRADING JOURNAL",
     "Paper-journal table loader."),
    (9, "CHARTS & TECHNICAL ANALYSIS",
     "Interactive candlestick chart: zoom, pan, crosshair, hover OHLCV, "
     "indicator toggles, patterns, support/resistance and the TA summary."),
    (10, "EVENT HANDLERS & API ACTIONS",
     "Every button / input binding. Lives after the code it calls so the "
     "readers see the behaviour first and the wiring second."),
    (11, "BOOT",
     "Start the 1-second state poller and keep the canvas sized on resize."),
]

parts = [
    banner(1, SECTIONS[0][1], SECTIONS[0][2], C_BASE),
    banner(2, SECTIONS[1][1], SECTIONS[1][2], C_THEME),
    banner(3, SECTIONS[2][1], SECTIONS[2][2], C_API),
    banner(4, SECTIONS[3][1], SECTIONS[3][2], C_CANVAS),
    banner(5, SECTIONS[4][1], SECTIONS[4][2], C_RENDER),
    banner(6, SECTIONS[5][1], SECTIONS[5][2], C_DRAW),
    banner(7, SECTIONS[6][1], SECTIONS[6][2], C_ADV),
    banner(8, SECTIONS[7][1], SECTIONS[7][2], C_JOURNAL),
    banner(9, SECTIONS[8][1], SECTIONS[8][2], C_TA),
    banner(10, SECTIONS[9][1], SECTIONS[9][2], C_ACTIONS + "\n\n" + C_ADVACT),
    banner(11, SECTIONS[10][1], SECTIONS[10][2], C_BOOT),
]

new_js = "\n".join(parts)

# A table of contents at the top of the script.
toc = ["/*",
       "   QuantAI Terminal — client-side script.",
       "",
       "   SECTION MAP",
       "   " + "-" * 72]
for n, title, _ in SECTIONS:
    toc.append(f"     {n:>2}. {title}")
toc += ["   " + "-" * 72,
        "",
        "   SAFETY: the UI never decides anything on its own. Risk limits, the kill",
        "   switch, the entry gate and every indicator are computed in the backend.",
        "   Charts draw ONLY real imported candles; nothing is fabricated.",
        "   */",
        ""]
new_js = "\n".join(toc) + new_js

out = src[:m.start(1)] + new_js + src[m.end(1):]
HTML.write_text(out)
print(f"JS reorganised: {len(L)} -> {len(new_js.splitlines())} lines, {len(SECTIONS)} sections")
